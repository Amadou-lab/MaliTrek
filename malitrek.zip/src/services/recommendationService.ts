import { Circuit, UserProfile } from '../types';
import { calculateRankingScore } from '../lib/rankingUtils';

/**
 * Intelligent Recommendation Engine
 * Sorts circuits based on user history, preferences, and quality
 */
export const getRecommendedCircuits = (circuits: Circuit[], profile: UserProfile | null): Circuit[] => {
  if (!profile) {
    // If no user is signed in, return top ranked circuits
    return circuits
      .filter(c => c.status === 'approved')
      .sort((a, b) => calculateRankingScore(b) - calculateRankingScore(a))
      .slice(0, 5);
  }

  // Calculate scores for each circuit based on user persona
  return circuits
    .filter(c => c.status === 'approved')
    .map(circuit => {
      let score = calculateRankingScore(circuit) * 0.5; // Base quality score (50%)

      // 1. match by category preference (25%)
      if (profile.categoryPreferences?.includes(circuit.category)) {
        score += 25;
      } else if (profile.role === 'ROLE_CLIENT' && circuit.category === 'Culture') {
         // Default high interest for culture in Mali
         score += 10;
      }

      // 2. match by location or proximity (15%)
      // If we had user location, we'd add it here. Default 10 for Bamako-based
      if (circuit.location.toLowerCase().includes('bamako')) {
        score += 10;
      }

      // 3. budget match (10%)
      const avgValue = profile.averageBookingValue || 50000;
      const budgetDiff = Math.abs(circuit.basePrice - avgValue);
      if (budgetDiff < 20000) {
        score += 10;
      } else if (budgetDiff < 50000) {
        score += 5;
      }

      return { ...circuit, recommendationScore: score };
    })
    .sort((a: any, b: any) => b.recommendationScore - a.recommendationScore)
    .slice(0, 6);
};

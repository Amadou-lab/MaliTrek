import { doc, updateDoc, writeBatch, increment, collection, setDoc, getDoc, query, where, getDocs, serverTimestamp, orderBy, limit, Timestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { Reservation, StepProgress, Transaction, UserProfile, Withdrawal, PaymentProvider, TransactionType } from '../types';

/**
 * Escrow Service
 * Manages the marketplace financial model: 80% Guide / 20% MaliTrek
 */

export const escrowService = {
  // DEFAULT CONFIGURATION (can be overridden by AppConfig in Firestore)
  DEFAULT_COMMISSION: 0.2, // 20%
  TIER_COMMISSIONS: {
    standard: 0.2,
    premium: 0.15,
    elite: 0.1,
    suspended: 0.5 // Penalty for suspended but active journeys
  },

  /**
   * Complex commission calculation based on multiple levels of priority.
   */
  async calculateCommission(reservation: { circuitId: string, guideId: string, totalAmount: number }) {
    try {
      // 1. Check Circuit Overrides
      const circuitSnap = await getDoc(doc(db, 'circuits', reservation.circuitId));
      const circuitData = circuitSnap.exists() ? circuitSnap.data() : null;
      if (circuitData?.customCommission !== undefined) {
        const rate = circuitData.customCommission;
        return this.generateSplit(reservation.totalAmount, rate);
      }

      // 2. Check Guide Overrides & Tier
      const guideSnap = await getDoc(doc(db, 'users', reservation.guideId));
      const guideData = guideSnap.exists() ? guideSnap.data() as UserProfile : null;
      
      if (guideData?.customCommissionRate !== undefined) {
        return this.generateSplit(reservation.totalAmount, guideData.customCommissionRate);
      }

      if (guideData?.guideTier && this.TIER_COMMISSIONS[guideData.guideTier] !== undefined) {
        return this.generateSplit(reservation.totalAmount, this.TIER_COMMISSIONS[guideData.guideTier]);
      }

      // 3. Global Default
      return this.generateSplit(reservation.totalAmount, this.DEFAULT_COMMISSION);
    } catch (e) {
      console.error('Commission calculation failed, falling back to default:', e);
      return this.generateSplit(reservation.totalAmount, this.DEFAULT_COMMISSION);
    }
  },

  generateSplit(amount: number, commissionRate: number) {
    const platformFee = Math.round(amount * commissionRate);
    const guideShare = amount - platformFee;
    return { platformFee, guideShare, commissionRate };
  },

  /**
   * Payment Provider Simulation Layer
   */
  async processPayment(amount: number, provider: PaymentProvider, details: any) {
    // In production, this would call Cinetpay/PayDunya/etc. APIs
    console.log(`Processing payment of ${amount} via ${provider}...`);
    return {
      success: true,
      providerReference: `TX-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      status: 'completed'
    };
  },

  /**
   * Confirms payment and applies dynamic logic.
   */
  async confirmPayment(reservationId: string, provider: PaymentProvider, details: any = {}) {
    const resRef = doc(db, 'reservations', reservationId);
    const resSnap = await getDoc(resRef);
    if (!resSnap.exists()) throw new Error('Reservation not found');
    const res = resSnap.data() as Reservation;

    if (res.paymentStatus === 'paid' || res.paymentStatus === 'held') return;

    // Split Calculation (Always recalculate at point of payment to be sure)
    const { platformFee, guideShare, commissionRate } = await this.calculateCommission({
      circuitId: res.circuitId,
      guideId: res.guideId,
      totalAmount: res.totalPaid
    });

    const paymentResult = await this.processPayment(res.totalPaid, provider, details);
    if (!paymentResult.success) throw new Error('Payment failed');

    const batch = writeBatch(db);
    
    // Update Reservation with dynamic split
    batch.update(resRef, {
      status: 'confirmed',
      paymentStatus: 'held',
      platformFee,
      guideShare,
      commissionRate,
      provider,
      providerReference: paymentResult.providerReference,
      updatedAt: serverTimestamp()
    });

    // Create Business Transactions
    const txMainRef = doc(collection(db, 'transactions'));
    batch.set(txMainRef, {
      id: txMainRef.id,
      reservationId: res.id,
      journeyId: res.journeyId,
      circuitId: res.circuitId,
      clientId: res.userId,
      guideId: res.guideId,
      amount: res.totalPaid,
      type: 'client_payment',
      category: 'credit',
      status: 'completed',
      provider,
      providerReference: paymentResult.providerReference,
      description: `Encaissement MaliTrek : rés. ${res.id}`,
      createdAt: serverTimestamp()
    });

    const txFeeRef = doc(collection(db, 'transactions'));
    batch.set(txFeeRef, {
      id: txFeeRef.id,
      reservationId: res.id,
      amount: platformFee,
      type: 'platform_fee',
      category: 'credit',
      status: 'completed',
      provider: 'manual_test',
      description: `Commission platforme (${(commissionRate * 100).toFixed(0)}%) : rés. ${res.id}`,
      createdAt: serverTimestamp()
    });

    const txGuideRef = doc(collection(db, 'transactions'));
    batch.set(txGuideRef, {
      id: txGuideRef.id,
      reservationId: res.id,
      guideId: res.guideId,
      amount: guideShare,
      type: 'guide_earning_pending',
      category: 'debit',
      status: 'pending',
      provider: 'manual_test',
      description: `Part guide en attente : rés. ${res.id}`,
      createdAt: serverTimestamp()
    });

    // Balances
    const guideRef = doc(db, 'users', res.guideId);
    batch.update(guideRef, {
      balancePending: increment(guideShare),
      lastActivityAt: serverTimestamp()
    });

    // Notify Guide
    const notifRef = doc(collection(db, 'notifications'));
    batch.set(notifRef, {
      id: notifRef.id,
      userId: res.guideId,
      title: 'Vente confirmée ! 💰',
      message: `Réservation payée par ${res.fullname}. Vos gains de ${guideShare.toLocaleString()} CFA sont en attente de validation du voyage.`,
      type: 'payment',
      read: false,
      reservationId: res.id,
      actionType: 'open_reservation',
      actionLabel: 'Gérer la réservation',
      actionRoute: `/guide/reservations/${res.id}`,
      createdAt: serverTimestamp()
    });

    await batch.commit();
  },

  /**
   * Finalizes fund release to guide after successful journey validation
   */
  async releaseFunds(reservationId: string, actorId: string, type: 'client_validation' | 'auto_validation' | 'admin_decision' = 'client_validation') {
    const resRef = doc(db, 'reservations', reservationId);
    const resSnap = await getDoc(resRef);
    if (!resSnap.exists()) throw new Error('Reservation not found');
    const res = resSnap.data() as Reservation;

    if (res.paymentStatus === 'released') return;
    
    // Safety check
    if (!res.guideShare) throw new Error('Guide share not calculated for this reservation');

    const batch = writeBatch(db);

    // 1. Update Reservation
    batch.update(resRef, {
      paymentStatus: 'released',
      status: 'completed',
      releasedAt: serverTimestamp(),
      releaseType: type,
      updatedAt: serverTimestamp()
    });

    // 2. Update Guide Balances (Pending -> Available)
    const guideRef = doc(db, 'users', res.guideId);
    batch.update(guideRef, {
      balanceAvailable: increment(res.guideShare),
      balancePending: increment(-res.guideShare),
      totalEarned: increment(res.guideShare),
      lastActivityAt: serverTimestamp()
    });

    // 3. Create Release Transaction
    const txRef = doc(collection(db, 'transactions'));
    batch.set(txRef, {
      id: txRef.id,
      reservationId: res.id,
      guideId: res.guideId,
      amount: res.guideShare,
      type: 'guide_earning_release',
      status: 'completed',
      provider: 'manual_test',
      description: `Fonds libérés pour rés. ${res.id} (${type})`,
      createdAt: serverTimestamp()
    });

    // 4. Notify Guide
    const guideNotifRef = doc(collection(db, 'notifications'));
    batch.set(guideNotifRef, {
      id: guideNotifRef.id,
      userId: res.guideId,
      title: 'Gains disponibles ! 💸',
      message: `Les fonds (${res.guideShare.toLocaleString()} CFA) sont maintenant disponibles sur votre solde pour retrait.`,
      type: 'payment',
      read: false,
      reservationId: res.id,
      actionType: 'open_wallet',
      actionLabel: 'Voir mon portefeuille',
      actionRoute: '/guide/wallet',
      createdAt: serverTimestamp()
    });

    await batch.commit();
  },

  /**
   * Handles withdrawal request from guide
   */
  async requestWithdrawal(guideId: string, amount: number, method: Withdrawal['method'], accountNumber: string) {
    const guideRef = doc(db, 'users', guideId);
    const guideSnap = await getDoc(guideRef);
    if (!guideSnap.exists()) throw new Error('Guide not found');
    const guide = guideSnap.data() as UserProfile;

    if (amount > (guide.balanceAvailable || 0)) {
      throw new Error('Solde disponible insuffisant');
    }

    if (amount < 5000) {
      throw new Error('Le montant minimum de retrait est de 5 000 CFA');
    }

    const batch = writeBatch(db);

    // 1. Block the amount
    batch.update(guideRef, {
      balanceAvailable: increment(-amount),
      balanceBlocked: increment(amount)
    });

    // 2. Create Withdrawal Request
    const withdrawRef = doc(collection(db, 'withdrawals'));
    const withdrawalId = withdrawRef.id;
    batch.set(withdrawRef, {
      id: withdrawalId,
      guideId,
      guideName: guide.displayName,
      amount,
      method,
      accountNumber,
      status: 'pending',
      createdAt: serverTimestamp()
    });

    // 3. Create Transaction Log
    const txRef = doc(collection(db, 'transactions'));
    batch.set(txRef, {
      id: txRef.id,
      guideId,
      amount,
      type: 'guide_withdrawal_request',
      status: 'pending',
      provider: 'manual_test',
      description: `Demande de retrait (${method})`,
      createdAt: serverTimestamp()
    });

    // 4. Audit Log
    const auditRef = doc(collection(db, 'auditLogs'));
    batch.set(auditRef, {
      id: auditRef.id,
      actorId: guideId,
      actorRole: 'ROLE_GUIDE',
      action: 'withdrawal_request',
      targetType: 'withdrawal',
      targetId: withdrawalId,
      amount,
      message: `Demande de retrait de ${amount} CFA par ${guide.displayName}`,
      createdAt: serverTimestamp()
    });

    await batch.commit();
    return withdrawalId;
  },

  /**
   * Admin approves and process withdrawal
   */
  async processWithdrawal(withdrawalId: string, adminId: string, status: 'processed' | 'rejected', reason?: string) {
    const wRef = doc(db, 'withdrawals', withdrawalId);
    const wSnap = await getDoc(wRef);
    if (!wSnap.exists()) throw new Error('Withdrawal not found');
    const wData = wSnap.data() as Withdrawal;

    if (wData.status !== 'pending' && wData.status !== 'approved') {
      throw new Error(`Statut invalide : ${wData.status}`);
    }

    const batch = writeBatch(db);
    const guideRef = doc(db, 'users', wData.guideId);

    if (status === 'processed') {
      batch.update(wRef, {
        status: 'processed',
        processedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      batch.update(guideRef, {
        balanceBlocked: increment(-wData.amount),
        totalWithdrawn: increment(wData.amount)
      });

      // Update transaction status
      const txQuery = query(collection(db, 'transactions'), where('guideId', '==', wData.guideId), where('type', '==', 'guide_withdrawal_request'), limit(5));
      // In a real environment we'd link tx with withdrawalId in metadata
      // For now we'll create a new completion tx
      const txRef = doc(collection(db, 'transactions'));
      batch.set(txRef, {
        id: txRef.id,
        guideId: wData.guideId,
        amount: wData.amount,
        type: 'guide_withdrawal_paid',
        status: 'completed',
        provider: 'manual_test',
        description: `Retrait payé par admin (${wData.method})`,
        createdAt: serverTimestamp()
      });

      // Notification
      const notifRef = doc(collection(db, 'notifications'));
      batch.set(notifRef, {
        id: notifRef.id,
        userId: wData.guideId,
        title: 'Retrait validé ! ✅',
        message: `Votre retrait de ${wData.amount.toLocaleString()} CFA a été traité avec succès.`,
        type: 'payment',
        read: false,
        actionType: 'open_wallet',
        actionLabel: 'Voir mon portefeuille',
        actionRoute: '/guide/wallet',
        createdAt: serverTimestamp()
      });

    } else if (status === 'rejected') {
      batch.update(wRef, {
        status: 'rejected',
        rejectionReason: reason,
        updatedAt: serverTimestamp()
      });

      batch.update(guideRef, {
        balanceAvailable: increment(wData.amount),
        balanceBlocked: increment(-wData.amount)
      });

      // Notification
      const notifRef = doc(collection(db, 'notifications'));
      batch.set(notifRef, {
        id: notifRef.id,
        userId: wData.guideId,
        title: 'Retrait refusé ❌',
        message: `Votre demande de retrait a été refusée. Motif : ${reason}`,
        type: 'payment',
        read: false,
        createdAt: serverTimestamp()
      });
    }

    await batch.commit();
  }
};

import { 
  collection, 
  deleteDoc, 
  doc, 
  getDocs, 
  serverTimestamp, 
  setDoc, 
  writeBatch 
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { trekService } from './trekService';
import { Circuit, Journey, UserProfile } from '../types';

export const maintenanceService = {
  
  async clearLocalAppCache() {
    localStorage.clear();
    sessionStorage.clear();
    // In a real browser we might want to unregister service workers or clear indexedDB
    console.log('Local app cache cleared.');
  },

  async resetAllCollections() {
    const collections = [
      'users', 'circuits', 'journeys', 'reservations', 'transactions', 
      'withdrawals', 'disputes', 'reservationEvents', 'conversations', 
      'messages', 'notifications', 'reviews', 'app_reviews', 'favorites', 
      'places', 'rankings', 'admins'
    ];

    for (const collName of collections) {
      const snap = await getDocs(collection(db, collName));
      const batch = writeBatch(db);
      snap.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    }
  },

  async seedInitialData() {
    console.log('Starting seed process...');
    
    // 1. Create Users
    const users: UserProfile[] = [
      {
        uid: 'ADMIN_USER_ID',
        displayName: 'MaliTrek Admin',
        email: 'admin@malitrek.com',
        role: 'ROLE_ADMIN',
        createdAt: serverTimestamp(),
        status: 'active'
      },
      {
        uid: 'GUIDE_ADAMA_ID',
        displayName: 'Adama Cissé',
        email: 'guide@malitrek.com',
        role: 'ROLE_GUIDE',
        createdAt: serverTimestamp(),
        status: 'active',
        balanceAvailable: 50000,
        balancePending: 0,
        bio: 'Guide expert certifié au Pays Dogon depuis 10 ans.',
        location: 'Mopti',
        rating: 4.8,
        reviewCount: 12
      },
      {
        uid: 'GUIDE_BAKARY_ID',
        displayName: 'Bakary Koné',
        email: 'guide2@malitrek.com',
        role: 'ROLE_GUIDE',
        createdAt: serverTimestamp(),
        status: 'active',
        balanceAvailable: 0,
        balancePending: 0,
        bio: 'Spécialiste de la boucle du Niger et de Tombouctou.',
        location: 'Ségou',
        rating: 4.5,
        reviewCount: 5
      },
      {
        uid: 'CLIENT_AMADOU_ID',
        displayName: 'Amadou Diabaté',
        email: 'client@malitrek.com',
        role: 'ROLE_CLIENT',
        createdAt: serverTimestamp(),
        status: 'active'
      },
      {
        uid: 'CLIENT_SARAH_ID',
        displayName: 'Sarah Traoré',
        email: 'client2@malitrek.com',
        role: 'ROLE_CLIENT',
        createdAt: serverTimestamp(),
        status: 'active'
      }
    ] as any[];

    for (const u of users) {
      await setDoc(doc(db, 'users', u.uid), u);
      if (u.role === 'ROLE_ADMIN') {
        await setDoc(doc(db, 'admins', u.uid), { uid: u.uid, email: u.email });
      }
    }

    // 2. Create Circuits
    const dogonCircuit = await trekService.createCircuit({
      title: 'Pays Dogon : Les Falaises de Bandiagara',
      location: 'Pays Dogon',
      region: 'Mopti',
      description: 'Découvrez la culture fascinante des Dogons et les paysages spectaculaires des falaises.',
      basePrice: 45000,
      duration: '3 jours',
      category: 'Culture',
      itinerary: [
        { id: 's1', title: 'Arrivée à Bandiagara', description: 'Rencontre avec le guide et briefing.', day: 1, order: 0, locationName: 'Bandiagara' },
        { id: 's2', title: 'Randonnée Sangha', description: 'Marche vers les falaises.', day: 2, order: 1, locationName: 'Sangha' },
        { id: 's3', title: 'Nuit en bivouac', description: 'Expérience authentique sous les étoiles.', day: 3, order: 2, locationName: 'Bivouac' }
      ]
    }, 'GUIDE_ADAMA_ID');

    const djenneCircuit = await trekService.createCircuit({
      title: 'Djenné : La Grande Mosquée et son Marché',
      location: 'Djenné',
      region: 'Mopti',
      description: 'Visitez la plus grande construction en terre crue au monde et son marché coloré.',
      basePrice: 25000,
      duration: '1 jour',
      category: 'Histoire',
      itinerary: [
        { id: 'd1', title: 'Visite de la Mosquée', description: 'Explications historiques et religieuses.', day: 1, order: 0, locationName: 'Grande Mosquée' },
        { id: 'd2', title: 'Marché Lundi', description: 'Immersion dans le commerce local.', day: 1, order: 1, locationName: 'Marché' }
      ]
    }, 'GUIDE_BAKARY_ID');

    if (dogonCircuit && djenneCircuit) {
      await trekService.validateCircuit(dogonCircuit.id, true);
      await trekService.validateCircuit(djenneCircuit.id, true);
      
      // JOURNEY 1: OPEN
      const jOpen = await trekService.createJourney({
        date: '2026-06-10',
        time: '08:00',
        totalSeats: 10,
        status: 'draft'
      }, dogonCircuit);
      if (jOpen) await trekService.publishJourney(jOpen.id);

      // JOURNEY 2: IN PROGRESS (Confirmed Reservation)
      const jInProgress = await trekService.createJourney({
        date: '2026-04-30',
        time: '07:00',
        totalSeats: 2,
        status: 'draft'
      }, djenneCircuit);
      
      if (jInProgress) {
        await trekService.publishJourney(jInProgress.id);
        const res = await trekService.createReservation(jInProgress.id, 'CLIENT_SARAH_ID', 2, 'Sarah Traoré', '70000001');
        if (res) {
          await trekService.confirmPayment(res.id, 'CLIENT_SARAH_ID');
          await trekService.startJourney(jInProgress.id, 'GUIDE_BAKARY_ID');
        }
      }

      // JOURNEY 3: COMPLETED (Awaiting Validation)
      const jCompleted = await trekService.createJourney({
        date: '2026-04-25',
        time: '09:00',
        totalSeats: 5,
        status: 'draft'
      }, dogonCircuit);
      
      if (jCompleted) {
        await trekService.publishJourney(jCompleted.id);
        const res = await trekService.createReservation(jCompleted.id, 'CLIENT_AMADOU_ID', 2, 'Amadou Diabaté', '70000000');
        if (res) {
          await trekService.confirmPayment(res.id, 'CLIENT_AMADOU_ID');
          await trekService.startJourney(jCompleted.id, 'GUIDE_ADAMA_ID');
          await trekService.completeJourney(jCompleted.id, 'GUIDE_ADAMA_ID');
        }
      }
    }

    console.log('Seed data complete.');
  }
};

import { openDB, IDBPDatabase } from 'idb';
import { OfflineAction } from '../types';

const DB_NAME = 'malitrek_offline';
const STORE_NAME = 'action_queue';
const CACHE_STORE = 'journey_cache';

class OfflineService {
  private db: Promise<IDBPDatabase> | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.db = openDB(DB_NAME, 2, {
        upgrade(db, oldVersion, newVersion) {
          if (oldVersion < 1) {
            db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          }
          if (oldVersion < 2) {
            db.createObjectStore(CACHE_STORE, { keyPath: 'id' });
          }
        },
      });
    }
  }

  async cacheJourney(journey: any) {
    if (!this.db) return;
    const db = await this.db;
    await db.put(CACHE_STORE, {
      id: journey.id,
      data: journey,
      timestamp: Date.now()
    });
    console.log(`[Offline] Cached journey: ${journey.id}`);
  }

  async getCachedJourney(journeyId: string) {
    if (!this.db) return null;
    const db = await this.db;
    const cached = await db.get(CACHE_STORE, journeyId);
    return cached?.data || null;
  }

  async queueAction(type: OfflineAction['type'], payload: any) {
    if (!this.db) return;
    const db = await this.db;
    const action: OfflineAction = {
      id: Math.random().toString(36).substring(7),
      type,
      payload,
      timestamp: Date.now(),
    };
    await db.put(STORE_NAME, action);
    console.log(`[Offline] Action queued: ${type}`, action);
    
    // Audit Log
    this.createAuditLog(action.id, 'offline_action_queued', type, payload);
    
    if (navigator.onLine) {
      this.sync();
    }
    return action.id;
  }

  private async createAuditLog(actionId: string, status: string, type: string, payload: any) {
    // In a real app, this might go to Firestore if online
    // For now, we store in console and prepare for sync
    console.log(`[Audit] ${status} | Action: ${actionId} | Type: ${type}`);
    if (navigator.onLine) {
      try {
        // Prepare to send to Firestore audit_logs collection
      } catch (e) {}
    }
  }

  async getQueue(): Promise<OfflineAction[]> {
    if (!this.db) return [];
    const db = await this.db;
    return db.getAll(STORE_NAME);
  }

  async removeAction(id: string) {
    if (!this.db) return;
    const db = await this.db;
    await db.delete(STORE_NAME, id);
  }

  async sync() {
    if (!navigator.onLine) return;
    
    const queue = await this.getQueue();
    if (queue.length === 0) return;

    console.log(`[Offline] Starting sync of ${queue.length} actions...`);
    
    // Sorted by timestamp
    const sorted = queue.sort((a, b) => a.timestamp - b.timestamp);

    for (const action of sorted) {
      try {
        await this.processAction(action);
        await this.removeAction(action.id);
        console.log(`[Offline] Synced: ${action.type}`);
      } catch (e) {
        console.error(`[Offline] Sync failed for ${action.id}:`, e);
        // Stop batch if one fails to preserve order
        break;
      }
    }
  }

  private async processAction(action: OfflineAction) {
    // This will be wired up to trekService in the final step to avoid circular deps
    // For now, we emit an event or call a global handler
    const event = new CustomEvent('malitrek_sync_action', { detail: action });
    window.dispatchEvent(event);
  }
}

export const offlineService = new OfflineService();

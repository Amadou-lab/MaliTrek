import { db } from '../firebase';
import { collection, addDoc, serverTimestamp, updateDoc, doc } from 'firebase/firestore';

export interface SMSAlert {
  id: string;
  type: 'incident' | 'delay' | 'emergency';
  recipientRole: 'admin' | 'client' | 'guide';
  recipientPhone: string;
  message: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'sent' | 'failed' | 'not_configured';
  journeyId: string;
}

class SMSFallbackService {
  async prepareCriticalIncidentSMS(journeyId: string, incidentData: any) {
    const message = `[MALITREK ALERT] Critical incident on Journey ${journeyId}. Type: ${incidentData.type}. Note: ${incidentData.description || 'N/A'}`;
    
    // We assume numbers are fetched from journey/user profile centrally
    // For now, we prepare the entry in a dedicated collection
    try {
      const smsRef = await addDoc(collection(db, 'sms_alerts'), {
        journeyId,
        type: 'incident',
        urgency: incidentData.urgency || 'critical',
        message,
        status: 'pending',
        createdAt: serverTimestamp(),
        smsFallbackProvider: 'SYSTEM_STRUCTURE_READY',
      });
      
      console.log(`[SMS Fallback] Prepared critical alert: ${smsRef.id}`);
      return smsRef.id;
    } catch (e) {
      console.error('[SMS Fallback] Failed to prepare alert:', e);
      return null;
    }
  }

  async sendJourneyDelaySMS(journeyId: string, delayMinutes: number) {
     // Implementation structure
  }

  async sendEmergencySMS(journeyId: string, message: string) {
     // Implementation structure
  }
}

export const smsFallbackService = new SMSFallbackService();

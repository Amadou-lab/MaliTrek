import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  increment, 
  query, 
  serverTimestamp, 
  setDoc, 
  updateDoc, 
  where, 
  writeBatch,
  addDoc,
  orderBy,
  limit,
  Timestamp
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import { escrowService } from './escrowService';
import { 
  Circuit, 
  Journey, 
  Reservation,
  ReservationStatus,
  PaymentStatus,
  ReservationEvent, 
  ReservationEventType, 
  Transaction, 
  UserProfile,
  Withdrawal,
  PaymentProvider,
  GuideTier
} from '../types';

/**
 * Trek Service - Core Business Logic for MaliTrek
 */
export const trekService = {
  
  // --- Helpers ---
  handleFirestoreError(error: any, operation: OperationType, path: string) {
    handleFirestoreError(error, operation, path);
  },

  // --- Events & Audit Logging ---
  async logEvent(reservationId: string, type: ReservationEventType, userId: string, metadata?: any) {
    const path = `reservationEvents`;
    try {
      const eventRef = doc(collection(db, path));
      const event: ReservationEvent = {
        id: eventRef.id,
        reservationId,
        type,
        userId,
        timestamp: serverTimestamp(),
        metadata: metadata || {}
      } as any;
      await setDoc(eventRef, event);
      
      // Also log to audit if it's high-level
      if (['payment_released', 'dispute_resolved', 'refund_processed', 'admin_decision'].includes(type)) {
        await this.createAuditLog({
          actorId: userId,
          actorRole: 'SYSTEM_OR_ADMIN',
          action: type,
          targetType: 'reservation',
          targetId: reservationId,
          reservationId,
          message: `Action budgetaire: ${type}`,
          metadata
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async createAuditLog(data: {
    actorId: string;
    actorRole: string;
    action: string;
    targetType: 'reservation' | 'journey' | 'user' | 'dispute' | 'withdrawal' | 'transaction' | 'circuit';
    targetId: string;
    reservationId?: string;
    journeyId?: string;
    amount?: number;
    message: string;
    metadata?: any;
  }) {
    try {
      const logRef = doc(collection(db, 'auditLogs'));
      await setDoc(logRef, {
        id: logRef.id,
        ...data,
        createdAt: serverTimestamp()
      });
    } catch (e) {
      console.error('Audit Log Error:', e);
    }
  },

  // --- Conversations & Chat ---
  async getOrCreateConversation(params: {
    reservationId: string;
    clientId: string;
    guideId: string;
    journeyId?: string;
    circuitId?: string;
  }) {
    try {
      // 1. Get reservation context for titles
      const resSnap = await getDoc(doc(db, 'reservations', params.reservationId));
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      const [clientSnap, guideSnap, journeySnap] = await Promise.all([
        getDoc(doc(db, 'users', params.clientId)),
        getDoc(doc(db, 'users', params.guideId)),
        getDoc(doc(db, 'journeys', params.journeyId || res.journeyId))
      ]);

      const client = (clientSnap.data() || {}) as UserProfile;
      const guide = (guideSnap.data() || {}) as UserProfile;
      const journey = (journeySnap.data() || {}) as Journey;

      // 2. Check for existing conversation for this specific reservation
      const currentUid = auth.currentUser?.uid;
      const q = query(
        collection(db, 'conversations'),
        where('reservationId', '==', params.reservationId),
        where('participants', 'array-contains', currentUid || params.clientId)
      );
      const snap = await getDocs(q);
      
      if (!snap.empty) {
        return snap.docs[0].id;
      }

      // 3. Create new conversation
      const convRef = doc(collection(db, 'conversations'));
      const conversation: any = {
        id: convRef.id,
        reservationId: params.reservationId,
        clientId: params.clientId,
        clientName: client.displayName || 'Client',
        guideId: params.guideId,
        guideName: guide.displayName || 'Guide',
        journeyId: res.journeyId,
        circuitTitle: journey.title || 'Voyage',
        journeyDate: journey.date || '',
        participants: [params.clientId, params.guideId],
        participantNames: {
          [params.clientId]: client.displayName || 'Client',
          [params.guideId]: guide.displayName || 'Guide'
        },
        title: `${journey.title || 'Voyage'} - ${journey.date || ''}`,
        lastMessage: 'Conversation démarrée',
        lastMessageAt: serverTimestamp(),
        unreadCountByUser: {
          [params.clientId]: 0,
          [params.guideId]: 0
        },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      await setDoc(convRef, conversation);
      return convRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'conversations');
    }
  },

  async checkExpiredValidationDeadlines() {
    try {
      const now = new Date();
      const q = query(
        collection(db, 'reservations'),
        where('status', '==', 'awaiting_client_validation'),
        where('validationDeadline', '<=', now)
      );
      
      const snap = await getDocs(q);
      console.log(`Found ${snap.size} expired reservations to auto-validate.`);
      
      for (const docSnap of snap.docs) {
        await this.validateExperience(docSnap.id, 'SYSTEM', true);
      }
    } catch (error) {
      console.error('Error checking expired deadlines:', error);
    }
  },

  async markConversationAsRead(conversationId: string, userId: string) {
    try {
      const convRef = doc(db, 'conversations', conversationId);
      const snap = await getDoc(convRef);
      if (!snap.exists()) return;
      
      const data = snap.data() as any;
      const unreadCount = data.unreadCountByUser?.[userId] || 0;
      
      if (unreadCount > 0) {
        await updateDoc(convRef, {
          [`unreadCountByUser.${userId}`]: 0
        });
      }
    } catch (error) {
      console.error('Error marking conversation as read:', error);
    }
  },

  async sendMessage(conversationId: string, senderId: string, text: string) {
    try {
      const convSnap = await getDoc(doc(db, 'conversations', conversationId));
      if (!convSnap.exists()) throw new Error('Conversation introuvable');
      const conv = convSnap.data() as any;

    const receiverId = (conv.participants || []).find((id: string) => id !== senderId) || 
                       (senderId === conv.clientId ? conv.guideId : conv.clientId) || '';
    const senderName = (conv.participantNames || {})[senderId] || 'Utilisateur';
    const receiverName = (conv.participantNames || {})[receiverId] || 'Destinataire';

    const msgRef = doc(collection(db, 'messages'));
    const message: any = {
      id: msgRef.id,
      conversationId,
      senderId,
      senderName,
      senderRole: senderId === conv.guideId ? 'ROLE_GUIDE' : 'ROLE_CLIENT',
      receiverId,
      receiverName,
      text,
      participants: conv.participants || [senderId, receiverId],
      readBy: [senderId],
      createdAt: serverTimestamp(),
      status: 'sent'
    };
    
    await setDoc(msgRef, message);
    
    // Update conversation
    await updateDoc(doc(db, 'conversations', conversationId), {
      lastMessage: text,
      lastMessageAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      [`unreadCountByUser.${receiverId}`]: increment(1)
    });

      // Notify receiver with actionable notification
      const notifRef = doc(collection(db, 'notifications'));
      await setDoc(notifRef, {
        id: notifRef.id,
        userId: receiverId,
        title: `Message de ${senderName} 💬`,
        message: text.length > 50 ? text.substring(0, 47) + '...' : text,
        type: 'message_received',
        read: false,
        actionType: 'open_chat',
        actionLabel: 'Répondre',
        actionRoute: `/chat?id=${conversationId}`,
        conversationId,
        createdAt: serverTimestamp()
      });

      return message;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'messages');
    }
  },

  // --- Circuits ---
  async createCircuit(data: Partial<Circuit>, guideId: string) {
    const path = `circuits`;
    try {
      const guideSnap = await getDoc(doc(db, 'users', guideId));
      const guideName = (guideSnap.data() as UserProfile)?.displayName || 'Guide';

      const circuitRef = doc(collection(db, path));
      const circuit: Circuit = {
        title: data.title || 'Sans titre',
        location: data.location || 'Mali',
        region: data.region || 'Bamako',
        description: data.description || '',
        basePrice: data.basePrice || 0,
        duration: data.duration || '1 jour',
        image: data.image || 'https://picsum.photos/seed/mali/1200/800',
        id: circuitRef.id,
        guideId,
        status: 'draft',
        category: data.category || 'Culture',
        lat: data.lat || null,
        lng: data.lng || null,
        createdAt: serverTimestamp(),
        itinerary: data.itinerary || [],
        inclus: data.inclus || [],
        nonInclus: data.nonInclus || [],
        cancellationPolicy: data.cancellationPolicy || 'Standard',
        minParticipants: data.minParticipants || 1,
      } as Circuit;
      await setDoc(circuitRef, circuit);
      await this.createAuditLog({
        actorId: guideId,
        actorRole: 'ROLE_GUIDE',
        action: 'circuit_created',
        targetType: 'circuit',
        targetId: circuitRef.id,
        message: `Circuit créé par ${guideName}`
      });
      return circuit;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async closeCircuit(circuitId: string, guideId: string, reason: string) {
    try {
      const batch = writeBatch(db);
      const circuitRef = doc(db, 'circuits', circuitId);
      
      batch.update(circuitRef, {
        status: 'closed',
        closedReason: reason,
        updatedAt: serverTimestamp()
      });

      // Mark all future journeys as unavailable
      const now = new Date().toISOString();
      const journeysQuery = query(
        collection(db, 'journeys'),
        where('circuitId', '==', circuitId),
        where('date', '>=', now.split('T')[0]),
        where('status', 'in', ['open', 'full'])
      );
      const journeysSnap = await getDocs(journeysQuery);
      
      journeysSnap.forEach(d => {
        batch.update(d.ref, {
          status: 'unavailable',
          updatedAt: serverTimestamp()
        });
      });

      await batch.commit();

      await this.createAuditLog({
        actorId: guideId,
        actorRole: 'ROLE_GUIDE',
        action: 'circuit_closed',
        targetType: 'circuit',
        targetId: circuitId,
        message: `Circuit fermé. Motif: ${reason}`
      });

      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.UPDATE, `circuits/${circuitId}`);
    }
  },

  async reopenCircuit(circuitId: string, guideId: string) {
    try {
      const batch = writeBatch(db);
      const circuitRef = doc(db, 'circuits', circuitId);
      
      batch.update(circuitRef, {
        status: 'approved',
        closedReason: null,
        updatedAt: serverTimestamp()
      });

      // Re-open unavailable journeys linked to this circuit
      const journeysQuery = query(
        collection(db, 'journeys'),
        where('circuitId', '==', circuitId),
        where('status', '==', 'unavailable')
      );
      const journeysSnap = await getDocs(journeysQuery);
      
      journeysSnap.forEach(d => {
        const j = d.data();
        batch.update(d.ref, {
          status: j.availableSeats > 0 ? 'open' : 'full',
          updatedAt: serverTimestamp()
        });
      });

      await batch.commit();

      await this.createAuditLog({
        actorId: guideId,
        actorRole: 'ROLE_GUIDE',
        action: 'circuit_reopened',
        targetType: 'circuit',
        targetId: circuitId,
        message: `Circuit réouvert`
      });

      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.UPDATE, `circuits/${circuitId}`);
    }
  },

  async disableCircuit(circuitId: string, adminId: string, reason: string) {
    try {
      const batch = writeBatch(db);
      const circuitRef = doc(db, 'circuits', circuitId);
      
      batch.update(circuitRef, {
        status: 'disabled',
        disabledReason: reason,
        updatedAt: serverTimestamp()
      });

      // Mark all future journeys as unavailable
      const now = new Date().toISOString();
      const journeysQuery = query(
        collection(db, 'journeys'),
        where('circuitId', '==', circuitId),
        where('status', 'in', ['open', 'full'])
      );
      const journeysSnap = await getDocs(journeysQuery);
      
      journeysSnap.forEach(d => {
        batch.update(d.ref, {
          status: 'unavailable',
          updatedAt: serverTimestamp()
        });
      });

      await batch.commit();

      await this.createAuditLog({
        actorId: adminId,
        actorRole: 'ROLE_ADMIN',
        action: 'circuit_disabled',
        targetType: 'circuit',
        targetId: circuitId,
        message: `Circuit désactivé par l'admin. Motif: ${reason}`
      });

      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.UPDATE, `circuits/${circuitId}`);
    }
  },

  async enableCircuitByAdmin(circuitId: string, adminId: string) {
    try {
      const circuitRef = doc(db, 'circuits', circuitId);
      await updateDoc(circuitRef, {
        status: 'approved',
        disabledReason: null,
        updatedAt: serverTimestamp()
      });

      await this.createAuditLog({
        actorId: adminId,
        actorRole: 'ROLE_ADMIN',
        action: 'circuit_enabled',
        targetType: 'circuit',
        targetId: circuitId,
        message: 'Circuit réactivé par l\'admin'
      });
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `circuits/${circuitId}`);
    }
  },

  async updateCircuit(circuitId: string, data: Partial<Circuit>) {
    const path = `circuits/${circuitId}`;
    try {
      await updateDoc(doc(db, 'circuits', circuitId), {
        ...data,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async submitCircuitForValidation(circuitId: string) {
    const path = `circuits/${circuitId}`;
    try {
      await updateDoc(doc(db, 'circuits', circuitId), {
        status: 'pending_admin_validation',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async validateCircuit(circuitId: string, approved: boolean, rejectionReason?: string) {
    const path = `circuits/${circuitId}`;
    try {
      await updateDoc(doc(db, 'circuits', circuitId), {
        status: approved ? 'approved' : 'rejected',
        rejectionReason: approved ? null : (rejectionReason || 'Non spécifié'),
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  // --- Journeys ---
  async createJourney(data: Partial<Journey>, circuit: Circuit) {
    if (circuit.status !== 'approved') {
      throw new Error(`Impossible de créer un trajet car le circuit est "${circuit.status}". Seul un circuit approuvé peut avoir des trajets.`);
    }
    const path = `journeys`;
    try {
      const journeyRef = doc(collection(db, path));
      const journey: Journey = {
        id: journeyRef.id,
        circuitId: circuit.id,
        guideId: circuit.guideId,
        date: data.date || new Date().toISOString(),
        time: data.time || '08:00',
        meetingPoint: data.meetingPoint || 'Lieu de rendez-vous',
        meetingTime: data.meetingTime || data.time || '08:00',
        pricePerPerson: data.pricePerPerson || circuit.basePrice || 0,
        totalSeats: data.totalSeats || 10,
        availableSeats: data.totalSeats || 10,
        minParticipants: data.minParticipants || circuit.minParticipants || 1,
        status: data.status || 'draft',
        title: circuit.title,
        location: circuit.location,
        image: circuit.image,
        category: circuit.category,
        createdAt: serverTimestamp(),
        itinerarySnapshot: data.itinerarySnapshot || circuit.itinerary || [],
        specialInstructions: data.specialInstructions || '',
        safetyNotes: data.safetyNotes || '',
        transportInfo: data.transportInfo || '',
        weatherNote: data.weatherNote || '',
        specialNote: data.specialNote || '',
      } as Journey;
      await setDoc(journeyRef, journey);
      return journey;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async updateJourney(journeyId: string, data: Partial<Journey>) {
    try {
      await updateDoc(doc(db, 'journeys', journeyId), {
        ...data,
        updatedAt: serverTimestamp()
      });
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `journeys/${journeyId}`);
    }
  },

  async publishJourney(journeyId: string) {
    const path = `journeys/${journeyId}`;
    try {
      await updateDoc(doc(db, 'journeys', journeyId), {
        status: 'open',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  // --- Journey Logic Helpers ---
  async recalculateJourneyParticipants(journeyId: string) {
    try {
      const journeyRef = doc(db, 'journeys', journeyId);
      const journeySnap = await getDoc(journeyRef);
      if (!journeySnap.exists()) return;

      const resQuery = query(collection(db, 'reservations'), where('journeyId', '==', journeyId));
      const resSnap = await getDocs(resQuery);
      
      let activeParticipantsCount = 0;
      let activeReservationsCount = 0;
      let cancelledParticipantsCount = 0;
      let disputedParticipantsCount = 0;

      resSnap.forEach(d => {
        const res = d.data() as Reservation;
        const passengers = res.passengers || 0;

        // Active: confirmed, in_progress, awaiting_validation, completed
        // AND payment: paid, held, released
        const isActive = ['confirmed', 'in_progress', 'awaiting_client_validation', 'completed'].includes(res.status) &&
                         ['paid', 'held', 'released'].includes(res.paymentStatus);
        
        if (isActive) {
          activeParticipantsCount += passengers;
          activeReservationsCount += 1;
        }

        if (res.status === 'cancelled' || res.status === 'refunded') {
          cancelledParticipantsCount += passengers;
        }

        if (res.status === 'disputed') {
          disputedParticipantsCount += passengers;
        }
      });

      await updateDoc(journeyRef, {
        activeParticipantsCount,
        activeReservationsCount,
        cancelledParticipantsCount,
        disputedParticipantsCount,
        updatedAt: serverTimestamp()
      });

      await this.logEvent(journeyId, 'journey_participants_recalculated' as any, 'SYSTEM', { 
        activeParticipantsCount, 
        activeReservationsCount 
      });

      return { activeParticipantsCount, activeReservationsCount };
    } catch (error) {
      console.error('Error recalculating participants:', error);
    }
  },

  async canStartJourney(journeyId: string, guideId?: string) {
    try {
      let resQuery = query(collection(db, 'reservations'), where('journeyId', '==', journeyId));
      if (guideId) {
        resQuery = query(resQuery, where('guideId', '==', guideId));
      }
      const resSnap = await getDocs(resQuery);
      
      const blockingReservations: any[] = [];
      let canStart = true;

      resSnap.forEach(d => {
        const res = d.data() as Reservation;
        
        const isPendingAction = 
          ['cancellation_requested', 'disputed'].includes(res.status) || 
          res.paymentStatus === 'disputed' || 
          res.cancellationStatus === 'pending_admin_review';

        if (isPendingAction) {
          canStart = false;
          blockingReservations.push({
            id: res.id,
            clientName: res.fullname || res.clientName || 'Client',
            status: res.status,
            reason: res.disputeReason || res.cancellationReason || 'Action admin en attente'
          });
        }
      });

      return { canStart, blockingReservations };
    } catch (error: any) {
      console.error('Error checking canStartJourney:', error);
      if (error.code === 'permission-denied' || error.message?.includes('permission')) {
        handleFirestoreError(error, OperationType.GET, 'reservations');
      }
      return { canStart: false, blockingReservations: [], error };
    }
  },

  async canCompleteJourney(journeyId: string, guideId?: string) {
    try {
      const jRef = doc(db, 'journeys', journeyId);
      const jSnap = await getDoc(jRef);
      
      if (!jSnap.exists()) {
        return { 
          canComplete: false, 
          blockingReservations: [], 
          error: "Trajet introuvable" 
        };
      }
      
      const journey = jSnap.data() as Journey;
      
      if (guideId && journey.guideId !== guideId) {
        return { 
          canComplete: false, 
          blockingReservations: [], 
          error: "Vous n'êtes pas autorisé à clôturer ce trajet." 
        };
      }
      
      if (journey.status !== 'in_progress') {
        return { 
          canComplete: false, 
          blockingReservations: [], 
          error: "Ce trajet n'est pas en cours." 
        };
      }

      // Check for active reservations and disputes
      let resQuery;
      if (guideId) {
        resQuery = query(
          collection(db, 'reservations'), 
          where('journeyId', '==', journeyId),
          where('guideId', '==', guideId)
        );
      } else {
        resQuery = query(collection(db, 'reservations'), where('journeyId', '==', journeyId));
      }
      
      const resSnap = await getDocs(resQuery);
      
      const blockingReservations: any[] = [];
      let activeCount = 0;

      resSnap.forEach(d => {
        const res = d.data() as Reservation;
        
        const isActive = ['confirmed', 'in_progress'].includes(res.status);
        if (isActive) activeCount++;

        const isBlocking = 
          ['cancellation_requested', 'disputed'].includes(res.status) || 
          res.paymentStatus === 'disputed' || 
          res.cancellationStatus === 'pending_admin_review';

        if (isBlocking) {
          blockingReservations.push({
            id: res.id,
            clientName: res.fullname || res.clientName || 'Client',
            status: res.status,
            reason: res.disputeReason || res.cancellationReason || 'Action admin en attente'
          });
        }
      });

      if (activeCount === 0 && blockingReservations.length === 0) {
        return { 
          canComplete: false, 
          blockingReservations: [], 
          error: "Aucune réservation active à clôturer." 
        };
      }

      return { 
        canComplete: blockingReservations.length === 0, 
        blockingReservations 
      };
    } catch (error: any) {
      console.error('Error checking canCompleteJourney:', error);
      return { canComplete: false, blockingReservations: [], error: error.message };
    }
  },

  async restoreSeatsForReservation(reservationId: string, actorId: string) {
    try {
      const resRef = doc(db, 'reservations', reservationId);
      const resSnap = await getDoc(resRef);
      if (!resSnap.exists()) return;
      const res = resSnap.data() as Reservation;

      if (res.seatsRestored) return;

      const journeyRef = doc(db, 'journeys', res.journeyId);
      const journeySnap = await getDoc(journeyRef);
      if (!journeySnap.exists()) return;
      const journey = journeySnap.data() as Journey;

      // Uniquement si trajet pas encore démarré ou terminé
      if (['in_progress', 'completed', 'cancelled'].includes(journey.status)) {
        return;
      }

      const batch = writeBatch(db);
      const newAvailable = Math.min(journey.totalSeats, journey.availableSeats + (res.passengers || 0));
      
      batch.update(journeyRef, {
        availableSeats: newAvailable,
        status: newAvailable > 0 ? 'open' : 'full',
        updatedAt: serverTimestamp()
      });

      batch.update(resRef, {
        seatsRestored: true,
        updatedAt: serverTimestamp()
      });

      await batch.commit();
      await this.logEvent(reservationId, 'seats_restored' as any, actorId, { count: res.passengers });
      await this.recalculateJourneyParticipants(res.journeyId);
    } catch (e) {
      console.error('Error restoring seats:', e);
    }
  },

  async createReservation(journeyId: string, userId: string, passengers: number, fullname: string, phone: string) {
    const journeyPath = `journeys/${journeyId}`;
    let journey: Journey | undefined;
    try {
      const journeySnap = await getDoc(doc(db, 'journeys', journeyId));
      if (!journeySnap.exists()) throw new Error('Trajet non trouvé');
      journey = journeySnap.data() as Journey;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, journeyPath);
    }

    if (!journey) throw new Error('Trajet non trouvé');
    if (journey.status !== 'open') {
      throw new Error(`Ce trajet n'est plus ouvert aux réservations (Statut: ${journey.status || 'indéfini'}).`);
    }
    if (journey.availableSeats < passengers) {
      throw new Error('Pas assez de places disponibles.');
    }

    const [clientSnap, guideSnap] = await Promise.all([
      getDoc(doc(db, 'users', userId)),
      getDoc(doc(db, 'users', journey.guideId))
    ]);

    const client = clientSnap.data() as UserProfile;
    const guide = guideSnap.data() as UserProfile;

    const totalPaid = (journey.pricePerPerson || 0) * passengers;
    const guideShare = Math.floor(totalPaid * 0.8);
    const platformFee = totalPaid - guideShare;

    const resPath = `reservations`;
    const resRef = doc(collection(db, resPath));
    const reservation: Reservation = {
      id: resRef.id,
      journeyId: journey.id,
      circuitId: journey.circuitId,
      circuitTitle: journey.title,
      guideId: journey.guideId, 
      guideName: guide?.displayName || 'Guide',
      userId,                   
      userEmail: client?.email || '',
      userPhoto: client?.photoURL || '',
      passengers,
      totalPaid,
      guideShare,
      platformFee,
      status: 'pending_payment',
      paymentStatus: 'unpaid',
      commissionStatus: 'pending',
      fullname: fullname || client?.displayName || 'Anonyme',
      phone: phone || client?.phone || 'Non spécifié',
      clientName: fullname || client?.displayName || 'Anonyme',
      clientPhone: phone || client?.phone || 'Non spécifié',
      experienceValidated: false,
      itineraryProgress: (journey.itinerarySnapshot || []).map((step: any, index: number) => ({
        stepId: step.id || `step-${index}`,
        title: step.title,
        status: 'en_attente',
        updatedAt: new Date().toISOString()
      })),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    } as any;

    try {
      const batch = writeBatch(db);
      batch.set(resRef, reservation);
      
      // Reserve seats
      const newAvailable = journey.availableSeats - passengers;
      batch.update(doc(db, 'journeys', journeyId), {
        availableSeats: newAvailable,
        status: newAvailable <= 0 ? 'full' : journey.status,
        updatedAt: serverTimestamp()
      });

      // Notifications
      const guideNotifRef = doc(collection(db, 'notifications'));
      batch.set(guideNotifRef, {
        id: guideNotifRef.id,
        userId: journey.guideId,
        title: 'Nouvelle réservation 🔔',
        message: `${reservation.clientName} a réservé ${passengers} place(s) pour votre trajet.`,
        type: 'reservation',
        read: false,
        createdAt: serverTimestamp(),
        reservationId: resRef.id,
        journeyId: journey.id,
        actionType: 'open_reservation',
        actionLabel: 'Voir la réservation',
        actionRoute: `/guide/reservations/${resRef.id}`
      });

      await batch.commit();

      await this.logEvent(resRef.id, 'reservation_created', userId);
      return reservation as Reservation;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, resPath);
    }
  },

  async confirmPayment(reservationId: string, userId: string, provider: PaymentProvider = 'manual_test') {
    try {
      await escrowService.confirmPayment(reservationId, provider);
      await this.logEvent(reservationId, 'payment_confirmed', userId, { provider });
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reservations/${reservationId}`);
      throw error;
    }
  },

  // --- Journey Lifecycle ---
  async startJourney(journeyId: string, guideId: string) {
    const path = `journeys/${journeyId}`;
    try {
      const { canStart, blockingReservations } = await this.canStartJourney(journeyId, guideId);
      if (!canStart) {
        await this.createAuditLog({
          actorId: guideId,
          actorRole: 'ROLE_GUIDE',
          action: 'journey_start_blocked',
          targetType: 'journey',
          targetId: journeyId,
          message: `Démarrage trajet bloqué par ${blockingReservations.length} litiges/annulations`,
          metadata: { blockingReservations }
        });
        throw new Error(`Action requise avant démarrage : ${blockingReservations.length} réservation(s) en litige ou en attente d'annulation.`);
      }

      const batch = writeBatch(db);
      
      const resQuery = query(
        collection(db, 'reservations'), 
        where('journeyId', '==', journeyId), 
        where('guideId', '==', guideId),
        where('status', '==', 'confirmed')
      );
      const resSnaps = await getDocs(resQuery);

      const confirmedReservations = resSnaps.docs.map(d => d.data() as Reservation);
      const totalParticipants = confirmedReservations.reduce((acc, r) => acc + (r.passengers || 0), 0);
      const totalResCount = resSnaps.size;

      // 1. Update journey status
      batch.update(doc(db, 'journeys', journeyId), {
        status: 'in_progress',
        startedAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        activeParticipantsCount: totalParticipants,
        confirmedReservationsCount: totalResCount,
        checkedInCount: 0,
        incidentCount: 0
      });

      // 2. Update ALL involved reservations
      resSnaps.forEach(d => {
        batch.update(d.ref, { 
          status: 'in_progress', 
          tripStartedAt: serverTimestamp(),
          checkInStatus: 'pending',
          incidentStatus: 'none',
          updatedAt: serverTimestamp() 
        });

        // Notify client
        const clientNotifRef = doc(collection(db, 'notifications'));
        batch.set(clientNotifRef, {
          id: clientNotifRef.id,
          userId: d.data().userId,
          title: 'C\'est parti ! Votre trajet commence 🎒',
          message: `Le guide a démarré le trajet. ${totalParticipants} participants sont attendus pour cette aventure.`,
          type: 'journey_started',
          read: false,
          reservationId: d.id,
          journeyId: journeyId,
          actionType: 'open_reservation',
          actionLabel: 'Suivre mon trajet',
          actionRoute: `/client/reservations/${d.id}`,
          createdAt: serverTimestamp()
        });
      });

      // Notify Guide
      const guideNotifRef = doc(collection(db, 'notifications'));
      batch.set(guideNotifRef, {
        id: guideNotifRef.id,
        userId: guideId,
        title: 'Trajet démarré ✅',
        message: `Le trajet est en cours avec ${totalParticipants} participants (${totalResCount} réservations).`,
        type: 'journey_started',
        read: false,
        journeyId: journeyId,
        actionType: 'open_journey',
        actionLabel: 'Suivre le trajet',
        actionRoute: `/guide/journeys/${journeyId}`,
        createdAt: serverTimestamp()
      });

      await batch.commit();
      
      // Log for each reservation
      for (const d of resSnaps.docs) {
        await this.logEvent(d.id, 'journey_started', guideId);
      }
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async requestCancellation(reservationId: string, userId: string, reason: string) {
    const resPath = `reservations/${reservationId}`;
    try {
      const resSnap = await getDoc(doc(db, 'reservations', reservationId));
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      const journeySnap = await getDoc(doc(db, 'journeys', res.journeyId));
      if (!journeySnap.exists()) throw new Error('Trajet introuvable');
      const journey = journeySnap.data() as Journey;

      if (journey.status === 'in_progress' || journey.status === 'completed') {
        throw new Error('Annulation impossible : le trajet a déjà démarré ou est terminé.');
      }

      // Cancellation Rules
      const now = new Date();
      const journeyDate = new Date(`${journey.date}T${journey.time || '00:00'}`);
      const diffMs = journeyDate.getTime() - now.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);

      let refundAmount = 0;
      let refundType: 'full' | 'partial' | 'none' = 'none';
      let policy: string = 'lt_24h';
      let autoProcess = false;

      if (diffHours >= 48) {
        refundAmount = res.totalPaid;
        refundType = 'full';
        policy = 'gt_48h';
        autoProcess = true;
      } else if (diffHours >= 24) {
        refundAmount = Math.floor(res.totalPaid * 0.5);
        refundType = 'partial';
        policy = '24_48h';
        autoProcess = true;
      }

      const batch = writeBatch(db);

      if (autoProcess) {
        // Automatic refund handling
        batch.update(doc(db, 'reservations', reservationId), {
          status: 'refunded',
          paymentStatus: refundType === 'full' ? 'refunded' : 'partial_refund',
          refundAmount,
          cancelledAt: serverTimestamp(),
          refundedAt: serverTimestamp(),
          cancellationReason: reason,
          updatedAt: serverTimestamp()
        });

        // Deduct from guide pending balance
        if (res.paymentStatus === 'paid') {
          batch.update(doc(db, 'users', res.guideId), {
            balancePending: increment(-(res.guideShare || 0))
          });
        }

        // Create refund transaction
        const txRef = doc(collection(db, 'transactions'));
        batch.set(txRef, {
          id: txRef.id,
          userId: res.userId,
          amount: refundAmount,
          type: 'refund',
          status: 'completed',
          category: 'credit',
          reservationId,
          description: `Remboursement annulation auto (${policy})`,
          createdAt: serverTimestamp()
        });
        
        // Restore seats
        await this.restoreSeatsForReservation(reservationId, userId);
      } else {
        // Less than 24h: Request sent to admin
        batch.update(doc(db, 'reservations', reservationId), {
          status: 'cancellation_requested',
          cancellationRequestedAt: serverTimestamp(),
          cancellationReason: reason,
          updatedAt: serverTimestamp()
        });
        
        // Notifications to admin
        const adminNotifRef = doc(collection(db, 'notifications'));
        batch.set(adminNotifRef, {
           id: adminNotifRef.id,
           userId: 'PLATFORM_ADMIN',
           title: 'Demande d\'annulation tardive ⚠️',
           message: `Le client ${res.fullname} demande une annulation à moins de 24h du départ.`,
           type: 'system',
           read: false,
           reservationId,
           actionType: 'open_reservation',
           actionLabel: 'Gérer la demande',
           actionRoute: `/admin/reservations/${reservationId}`,
           createdAt: serverTimestamp()
        });
      }

      const cancelDocRef = doc(collection(db, 'cancellations'));
      batch.set(cancelDocRef, {
        id: cancelDocRef.id,
        reservationId,
        journeyId: res.journeyId,
        clientId: res.userId,
        guideId: res.guideId,
        requestedBy: userId,
        requestedByRole: 'ROLE_CLIENT',
        reason,
        refundAmount,
        refundType,
        policyApplied: policy,
        status: autoProcess ? 'refunded' : 'requested',
        createdAt: serverTimestamp()
      });

      await batch.commit();
      await this.logEvent(reservationId, 'cancellation_requested', userId, { reason, refundAmount, autoProcess });
      return { success: true, refundAmount, autoProcess };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, resPath);
    }
  },

  async clientCheckIn(reservationId: string, userId: string) {
    const path = `reservations/${reservationId}`;
    try {
      const resSnap = await getDoc(doc(db, 'reservations', reservationId));
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      const hasConflict = res.guidePresenceStatus === 'absent';

      const batch = writeBatch(db);
      batch.update(doc(db, 'reservations', reservationId), {
        clientCheckInStatus: 'checked_in',
        clientCheckedInAt: serverTimestamp(),
        presenceConflict: hasConflict,
        updatedAt: serverTimestamp(),
        checkInStatus: 'checked_in'
      });

      if (res.guidePresenceStatus !== 'present') {
        batch.update(doc(db, 'journeys', res.journeyId), {
          checkedInCount: increment(1)
        });
      }

      const guideNotifRef = doc(collection(db, 'notifications'));
      batch.set(guideNotifRef, {
        id: guideNotifRef.id,
        userId: res.guideId,
        title: hasConflict ? 'Conflit de présence ! ⚠️' : 'Check-in Client 📍',
        message: hasConflict 
          ? `${res.fullname} s'est marqué présent alors que vous l'aviez marqué absent.`
          : `${res.fullname} a confirmé sa présence.`,
        type: 'system',
        read: false,
        reservationId,
        createdAt: serverTimestamp()
      });

      await batch.commit();
      await this.logEvent(reservationId, 'client_checked_in', userId, { hasConflict });
      if (hasConflict) {
        await this.logEvent(reservationId, 'presence_conflict_detected', 'SYSTEM');
      }
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async cancelJourney(journeyId: string, guideId: string, reason: string) {
    try {
      const journeySnap = await getDoc(doc(db, 'journeys', journeyId));
      if (!journeySnap.exists()) throw new Error('Trajet introuvable');
      const journey = journeySnap.data() as Journey;

      // Can only cancel before starting
      if (journey.status !== 'open' && journey.status !== 'full') {
        throw new Error('Impossible d\'annuler un trajet déjà démarré ou terminé.');
      }

      const resQuery = query(collection(db, 'reservations'), where('journeyId', '==', journeyId), where('guideId', '==', guideId), where('status', '==', 'confirmed'));
      const resSnaps = await getDocs(resQuery);

      const batch = writeBatch(db);

      // 1. Cancel Journey
      batch.update(doc(db, 'journeys', journeyId), {
        status: 'cancelled',
        cancellationReason: reason,
        updatedAt: serverTimestamp()
      });

      // 2. Process all reservations
      for (const d of resSnaps.docs) {
        const res = d.data() as Reservation;
        
        batch.update(d.ref, {
          status: 'cancelled',
          paymentStatus: 'refunded',
          refundAmount: res.totalPaid,
          updatedAt: serverTimestamp()
        });

        // Notifications
        const clientNotifRef = doc(collection(db, 'notifications'));
        batch.set(clientNotifRef, {
          id: clientNotifRef.id,
          userId: res.userId,
          title: 'Trajet Annulé par le Guide ⚠️',
          message: `Le trajet "${journey.title}" a été annulé: ${reason}. Un remboursement complet a été initié.`,
          type: 'system',
          read: false,
          reservationId: res.id,
          actionType: 'open_reservation',
          actionLabel: 'Voir les détails',
          actionRoute: `/client/reservations/${res.id}`,
          createdAt: serverTimestamp()
        });

        // Transactions
        const txRef = doc(collection(db, 'transactions'));
        batch.set(txRef, {
          id: txRef.id,
          userId: res.userId,
          amount: res.totalPaid,
          type: 'refund',
          status: 'completed',
          reservationId: res.id,
          description: `Remboursement suite annulation trajet par guide`,
          createdAt: serverTimestamp()
        });

        // Deduct from guide pending balance
        batch.update(doc(db, 'users', res.guideId), {
          balancePending: increment(-(res.guideShare || 0))
        });
      }

      // Update guide cancel count
      batch.update(doc(db, 'users', guideId), {
        cancellationCount: increment(1)
      });

      await batch.commit();
      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.UPDATE, `journeys/${journeyId}`);
    }
  },

  async openDispute(data: {
    reservationId: string;
    journeyId: string;
    userId: string;
    role: any;
    type: string;
    details: string;
    urgency: 'normal' | 'urgent' | 'critical';
  }) {
    try {
      const resSnap = await getDoc(doc(db, 'reservations', data.reservationId));
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      const batch = writeBatch(db);
      const disputeId = doc(collection(db, 'disputes')).id;

      batch.set(doc(db, 'disputes', disputeId), {
        id: disputeId,
        reservationId: data.reservationId,
        journeyId: data.journeyId,
        circuitId: res.circuitId,
        clientId: res.userId,
        guideId: res.guideId,
        reportedBy: data.userId,
        reportedByRole: data.role,
        type: data.type,
        description: data.details,
        urgency: data.urgency,
        status: 'open',
        createdAt: serverTimestamp()
      });

      // BLOCK PAYMENT
      batch.update(doc(db, 'reservations', data.reservationId), {
        status: 'disputed',
        paymentStatus: 'disputed',
        commissionStatus: 'blocked',
        updatedAt: serverTimestamp()
      });

      // Move from Pending to Blocked in guide's balance
      batch.update(doc(db, 'users', res.guideId), {
        balancePending: increment(-res.guideShare),
        balanceBlocked: increment(res.guideShare)
      });

      // Audit Log
      await this.createAuditLog({
        actorId: data.userId,
        actorRole: data.role,
        action: 'open_dispute',
        targetType: 'dispute',
        targetId: disputeId,
        reservationId: data.reservationId,
        message: `Ouverture d'un litige pour incident: ${data.type}`,
        metadata: { urgency: data.urgency }
      });

      // Notify admin
      const adminNotifRef = doc(collection(db, 'notifications'));
      batch.set(adminNotifRef, {
        id: adminNotifRef.id,
        userId: 'PLATFORM_ADMIN',
        title: 'Nouveau Litige Ouvert ⚠️',
        message: `Un litige a été ouvert pour la réservation ${data.reservationId}. Paiement bloqué.`,
        type: 'dispute_created',
        read: false,
        reservationId: data.reservationId,
        actionType: 'open_dispute',
        actionLabel: 'Gérer le litige',
        createdAt: serverTimestamp()
      });

      await batch.commit();
      await this.logEvent(data.reservationId, 'dispute_opened', data.userId, { type: data.type });
      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.WRITE, 'disputes');
    }
  },

  async guideMarkPresence(reservationId: string, guideId: string, status: 'present' | 'absent') {
    const path = `reservations/${reservationId}`;
    try {
      const resSnap = await getDoc(doc(db, 'reservations', reservationId));
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      const hasConflict = status === 'absent' && res.clientCheckInStatus === 'checked_in';

      const batch = writeBatch(db);
      batch.update(doc(db, 'reservations', reservationId), {
        guidePresenceStatus: status,
        guideMarkedPresenceAt: serverTimestamp(),
        guideMarkedPresenceBy: guideId,
        presenceConflict: hasConflict,
        updatedAt: serverTimestamp(),
        checkInStatus: status === 'present' ? 'marked_present_by_guide' : 'absent'
      });

      if (status === 'present' && res.clientCheckInStatus !== 'checked_in') {
        batch.update(doc(db, 'journeys', res.journeyId), {
          checkedInCount: increment(1)
        });
      }

      await batch.commit();
      await this.logEvent(
        reservationId, 
        status === 'present' ? 'guide_marked_present' : 'guide_marked_absent', 
        guideId,
        { hasConflict }
      );
      if (hasConflict) {
        await this.logEvent(reservationId, 'presence_conflict_detected', 'SYSTEM');
      }
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async reportIncident(data: {
    reservationId?: string;
    journeyId: string;
    userId: string;
    userName: string;
    type: string;
    description: string;
    urgency: 'low' | 'medium' | 'high' | 'critical';
  }) {
    try {
      const batch = writeBatch(db);
      const incidentId = doc(collection(db, 'incidents')).id;
      
      batch.set(doc(db, 'incidents', incidentId), {
        id: incidentId,
        ...data,
        status: 'open',
        createdAt: serverTimestamp()
      });

      if (data.reservationId) {
        batch.update(doc(db, 'reservations', data.reservationId), {
          status: 'disputed', // Mark as disputed if client reports issue
          incidentStatus: 'reported',
          updatedAt: serverTimestamp()
        });
      }

      batch.update(doc(db, 'journeys', data.journeyId), {
        incidentCount: increment(1),
        lastIncidentAt: serverTimestamp()
      });

      // Notify Admin
      const adminNotifRef = doc(collection(db, 'notifications'));
      batch.set(adminNotifRef, {
        id: adminNotifRef.id,
        userId: 'PLATFORM_ADMIN',
        title: `Incident ${data.urgency.toUpperCase()} 🚨`,
        message: `Signalement de ${data.userName} : ${data.type}. Urgence: ${data.urgency}.`,
        type: 'system',
        read: false,
        journeyId: data.journeyId,
        reservationId: data.reservationId,
        createdAt: serverTimestamp()
      });

      // Notify Other Party
      if (data.reservationId) {
        const resSnap = await getDoc(doc(db, 'reservations', data.reservationId));
        if (resSnap.exists()) {
          const res = resSnap.data();
          const targetUserId = data.userId === res.userId ? res.guideId : res.userId;
          const otherNotifRef = doc(collection(db, 'notifications'));
          batch.set(otherNotifRef, {
            id: otherNotifRef.id,
            userId: targetUserId,
            title: 'Incident Signalé ⚠️',
            message: `Un incident a été signalé concernant votre trajet. L'administration a été prévenue.`,
            type: 'system',
            read: false,
            reservationId: data.reservationId,
            createdAt: serverTimestamp()
          });
        }
      } else {
        // Full Journey incident - notify guide if reported by client
        const jSnap = await getDoc(doc(db, 'journeys', data.journeyId));
        if (jSnap.exists()) {
          const journey = jSnap.data();
          if (data.userId !== journey.guideId) {
             const guideNotifRef = doc(collection(db, 'notifications'));
             batch.set(guideNotifRef, {
               id: guideNotifRef.id,
               userId: journey.guideId,
               title: 'Incident Signalé (Trajet) ⚠️',
               message: `Un incident a été signalé sur votre trajet "${journey.title}".`,
               type: 'system',
               read: false,
               journeyId: data.journeyId,
               createdAt: serverTimestamp()
             });
          }
        }
      }

      await batch.commit();
      if (data.reservationId) {
        await this.logEvent(data.reservationId, 'incident_reported', data.userId, { type: data.type });
      }
      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.WRITE, 'incidents');
    }
  },

  async advanceJourneyStep(journeyId: string, currentStepIndex: number) {
    try {
      const journeyRef = doc(db, 'journeys', journeyId);
      await updateDoc(journeyRef, {
        currentStepIndex: currentStepIndex + 1,
        lastStepAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      return true;
    } catch (e) {
      console.error('Failed to advance step:', e);
      throw e;
    }
  },

  async pauseJourney(journeyId: string, reason: string) {
    try {
      const journeyRef = doc(db, 'journeys', journeyId);
      await updateDoc(journeyRef, {
        status: 'paused',
        pauseReason: reason,
        pausedAt: serverTimestamp()
      });
      return true;
    } catch (e) {
      console.error('Failed to pause journey:', e);
      throw e;
    }
  },

  async resumeJourney(journeyId: string) {
    try {
      const journeyRef = doc(db, 'journeys', journeyId);
      await updateDoc(journeyRef, {
        status: 'in_progress',
        resumedAt: serverTimestamp()
      });
      return true;
    } catch (e) {
      console.error('Failed to resume journey:', e);
      throw e;
    }
  },

  async completeJourney(journeyId: string, guideId: string) {
    try {
      const { canComplete, blockingReservations, error } = await this.canCompleteJourney(journeyId, guideId);
      
      if (error) {
        throw new Error(error);
      }

      if (!canComplete) {
        await this.createAuditLog({
          actorId: guideId,
          actorRole: 'ROLE_GUIDE',
          action: 'complete_journey_blocked',
          targetType: 'journey',
          targetId: journeyId,
          message: `Clôture trajet bloquée par ${blockingReservations.length} litiges/annulations`,
          metadata: { blockingReservations }
        });
        throw new Error(`Action requise : ${blockingReservations.length} réservation(s) en litige ou en attente d'annulation.`);
      }

      const batch = writeBatch(db);
      const now = new Date();
      const deadline = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24h

      // 1. Update Journey
      batch.update(doc(db, 'journeys', journeyId), {
        status: 'completed',
        completedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      // 2. Fetch and Update Reservations
      const resQuery = query(
        collection(db, 'reservations'), 
        where('journeyId', '==', journeyId), 
        where('guideId', '==', guideId),
        where('status', 'in', ['confirmed', 'in_progress']) 
      );
      const resSnaps = await getDocs(resQuery);
      
      for (const d of resSnaps.docs) {
        const resData = d.data();
        
        batch.update(d.ref, { 
          status: 'awaiting_client_validation',
          experienceValidated: false,
          validationRequestedAt: serverTimestamp(),
          validationDeadline: deadline,
          updatedAt: serverTimestamp() 
        });

        // 3. Notifications for Clients
        const notifRef = doc(collection(db, 'notifications'));
        batch.set(notifRef, {
          id: notifRef.id,
          userId: resData.userId,
          title: "Trajet terminé 🏁",
          message: "Votre voyage est terminé. Merci de valider votre expérience pour clôturer le paiement.",
          type: "client_validation_requested",
          reservationId: d.id,
          journeyId: journeyId,
          actionType: "validate_experience",
          actionLabel: "Valider le voyage",
          actionRoute: `/client/reservations/${d.id}`,
          read: false,
          createdAt: serverTimestamp()
        });

        // 4. Trace Events (Atomic)
        const eventRef1 = doc(collection(db, 'reservationEvents'));
        batch.set(eventRef1, {
          id: eventRef1.id,
          reservationId: d.id,
          type: 'journey_completed_by_guide',
          userId: guideId,
          timestamp: serverTimestamp()
        });

        const eventRef2 = doc(collection(db, 'reservationEvents'));
        batch.set(eventRef2, {
          id: eventRef2.id,
          reservationId: d.id,
          type: 'client_validation_requested',
          userId: guideId,
          timestamp: serverTimestamp()
        });
      }

      // 5. Audit Log (Atomic)
      const auditRef = doc(collection(db, 'auditLogs'));
      batch.set(auditRef, {
        id: auditRef.id,
        actorId: guideId,
        actorRole: 'ROLE_GUIDE',
        action: 'complete_journey',
        targetType: 'journey',
        targetId: journeyId,
        journeyId: journeyId,
        message: `Trajet clôturé par le guide. ${resSnaps.size} réservations en attente de validation.`,
        createdAt: serverTimestamp()
      });

      await batch.commit();
      return true;
    } catch (error: any) {
      console.error('Error completing journey:', error);
      if (error instanceof Error) throw error;
      handleFirestoreError(error, OperationType.UPDATE, `journeys/${journeyId}`);
    }
  },

  async validateExperience(reservationId: string, actorId: string, isAuto = false) {
    try {
      await escrowService.releaseFunds(
        reservationId, 
        actorId, 
        isAuto ? 'auto_validation' : 'client_validation'
      );
      await this.logEvent(
        reservationId, 
        isAuto ? 'experience_auto_validated' : 'experience_validated_by_client', 
        actorId
      );
      return true;
    } catch (error) {
      if (error instanceof Error && error.message.startsWith('{')) throw error;
      handleFirestoreError(error, OperationType.UPDATE, `reservations/${reservationId}`);
    }
  },
  async requestWithdrawal(guideId: string, amount: number, method: any, accountNumber: string) {
    try {
      return await escrowService.requestWithdrawal(guideId, amount, method, accountNumber);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'withdrawals');
    }
  },

  async handleWithdrawal(withdrawalId: string, approved: boolean, notes: string) {
    try {
      const adminId = auth.currentUser?.uid || 'ADMIN';
      await escrowService.processWithdrawal(
        withdrawalId, 
        adminId, 
        approved ? 'processed' : 'rejected', 
        notes
      );
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'withdrawals');
    }
  },

  async updateGuideProfile(guideId: string, data: Partial<UserProfile>) {
    try {
      const guideRef = doc(db, 'users', guideId);
      await updateDoc(guideRef, {
        ...data,
        updatedAt: serverTimestamp()
      });
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${guideId}`);
    }
  },

  /**
   * Recalculates all professional and financial stats for a guide.
   * This is the "Truth Engine" for the marketplace.
   */
  async recalculateGuideStats(guideId: string) {
    try {
      const qRes = query(collection(db, 'reservations'), where('guideId', '==', guideId));
      const qJourneys = query(collection(db, 'journeys'), where('guideId', '==', guideId));
      const qReviews = query(collection(db, 'reviews'), where('guideId', '==', guideId));
      
      const [resSnap, journeySnap, reviewSnap] = await Promise.all([
        getDocs(qRes),
        getDocs(qJourneys),
        getDocs(qReviews)
      ]);

      let totalEarned = 0;
      let balancePending = 0;
      let completedCount = 0;
      let cancelledCount = 0;
      let disputeCount = 0;
      let totalRating = 0;
      let totalUsersServed = 0;

      resSnap.forEach(d => {
        const res = d.data() as Reservation;
        if (res.paymentStatus === 'released') totalEarned += (res.guideShare || 0);
        if (res.paymentStatus === 'held') balancePending += (res.guideShare || 0);
        if (res.status === 'completed') completedCount++;
        if (res.status === 'cancelled') cancelledCount++;
        if (res.status === 'disputed') disputeCount++;
        totalUsersServed += (res.passengers || 0);
      });

      reviewSnap.forEach(d => {
        const rev = d.data() as any;
        totalRating += rev.rating || 0;
      });

      const averageRating = reviewSnap.size > 0 ? totalRating / reviewSnap.size : 0;
      const cancellationRate = journeySnap.size > 0 ? (cancelledCount / journeySnap.size) * 100 : 0;
      const disputeRate = resSnap.size > 0 ? (disputeCount / resSnap.size) * 100 : 0;

      const data: Partial<UserProfile> = {
        totalEarned,
        balancePending,
        completedJourneys: journeySnap.docs.filter(d => d.data().status === 'completed').length,
        averageRating,
        totalReviews: reviewSnap.size,
        cancellationRate,
        disputeRate,
        trustScore: this.calculateTrustScore(averageRating, reviewSnap.size, disputeRate)
      };

      await this.updateGuideProfile(guideId, data);
      await this.calculateGuideRanking(guideId); // Refresh ranking after stats
      
      return data;
    } catch (e) {
      console.error('Failed to recalculate guide stats:', e);
      return null;
    }
  },

  calculateTrustScore(rating: number, reviews: number, disputes: number) {
    let score = (rating / 5) * 60; // Max 60 points for rating
    score += Math.min(reviews, 50) * 0.8; // Max 40 points for volume
    score -= disputes * 10; // Penalize disputes
    return Math.max(0, Math.min(100, score));
  },

  async repairGuideData(guideId: string) {
    console.log(`Starting data repair for guide: ${guideId}`);
    return await this.recalculateGuideStats(guideId);
  },

  async setGuidePremium(guideId: string, tier: GuideTier, durationDays: number = 30) {
    const deadline = new Date();
    deadline.setDate(deadline.getDate() + durationDays);
    
    // Default tier rates
    const rates: Record<GuideTier, number | undefined> = {
      standard: undefined,
      premium: 0.15,
      elite: 0.1,
      suspended: 0.5
    };

    return this.updateGuideProfile(guideId, {
      guideTier: tier,
      premiumUntil: Timestamp.fromDate(deadline),
      customCommissionRate: rates[tier]
    });
  },

  async calculateGuideRanking(guideId: string) {
    try {
      const guideSnap = await getDoc(doc(db, 'users', guideId));
      if (!guideSnap.exists()) return 0;
      const guide = guideSnap.data() as UserProfile;

      let score = 0;
      score += (guide.averageRating || 0) * 100;
      score += (guide.totalReviews || 0) * 10;
      score += (guide.completedJourneys || 0) * 20;
      
      // Multipliers
      if (guide.guideTier === 'premium') score *= 1.25;
      if (guide.guideTier === 'elite') score *= 1.5;
      if (guide.isVerified) score += 500;
      if (guide.featuredStatus === 'featured') score += 1000;
      if (guide.featuredStatus === 'boosted') score += 2000;

      // Penalties
      score -= (guide.cancellationRate || 0) * 1000;
      score -= (guide.disputeRate || 0) * 2000;

      await this.updateGuideProfile(guideId, { rankingScore: score });
      return score;
    } catch (e) {
      console.error('Ranking calculation failed:', e);
      return 0;
    }
  },

  async getAdminSettings() {
    try {
      const snap = await getDoc(doc(db, 'appConfig', 'business'));
      if (snap.exists()) return snap.data();
      return {
        defaultCommission: 0.2,
        minWithdrawal: 5000,
        autoValidationHours: 24,
        serviceFee: 500
      };
    } catch (e) {
      return null;
    }
  },

  async submitReview(data: {
    reservationId: string;
    clientId: string;
    userName: string;
    userPhoto?: string;
    ratingGlobal: number;
    ratingGuide: number;
    ratingExperience: number;
    ratingPunctuality: number;
    ratingValue: number;
    comment: string;
    images?: string[];
  }) {
    try {
      const resSnap = await getDoc(doc(db, 'reservations', data.reservationId));
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      if (res.status !== 'completed' && !res.experienceValidated) {
        throw new Error('Vous ne pouvez noter qu\'une fois le trajet terminé et validé.');
      }

      const batch = writeBatch(db);
      const reviewRef = doc(db, 'reviews', data.reservationId);
      
      // Check if review already exists to prevent duplicates
      const existingReview = await getDoc(reviewRef);
      if (existingReview.exists()) {
        throw new Error('Vous avez déjà donné votre avis sur ce trajet.');
      }
      
      const review: any = {
        id: data.reservationId,
        reservationId: data.reservationId,
        journeyId: res.journeyId,
        circuitId: res.circuitId,
        guideId: res.guideId,
        userId: data.clientId,
        userName: data.userName,
        userPhoto: data.userPhoto || null,
        ratingGlobal: data.ratingGlobal,
        ratingGuide: data.ratingGuide,
        ratingExperience: data.ratingExperience,
        ratingPunctuality: data.ratingPunctuality,
        ratingValue: data.ratingValue,
        comment: data.comment,
        images: data.images || [],
        createdAt: serverTimestamp()
      };

      // 1. Get current stats
      const [circuitSnap, guideSnap] = await Promise.all([
        getDoc(doc(db, 'circuits', res.circuitId)),
        getDoc(doc(db, 'users', res.guideId))
      ]);

      const circuitData = circuitSnap.data() as any;
      const guideData = guideSnap.data() as any;

      const newCircuitCount = (circuitData.reviewCount || 0) + 1;
      const newCircuitSum = (circuitData.ratingSum || 0) + data.ratingGlobal;
      const newCircuitAvg = Number((newCircuitSum / newCircuitCount).toFixed(1));

      const newGuideCount = (guideData.reviewCount || 0) + 1;
      const newGuideSum = (guideData.ratingSum || 0) + data.ratingGuide;
      const newGuideAvg = Number((newGuideSum / newGuideCount).toFixed(1));

      batch.set(reviewRef, review);

      // Update Circuit Stats
      batch.update(doc(db, 'circuits', res.circuitId), {
        ratingSum: newCircuitSum,
        reviewCount: newCircuitCount,
        averageRating: newCircuitAvg
      });

      // Update Guide Stats
      batch.update(doc(db, 'users', res.guideId), {
        ratingSum: newGuideSum,
        reviewCount: newGuideCount,
        rating: newGuideAvg, // renamed 'rating' to 'averageRating' in my mind but type uses 'rating'
        averageRating: newGuideAvg
      });

      // Update reservation to mark reviewed
      batch.update(doc(db, 'reservations', data.reservationId), {
        reviewId: reviewRef.id,
        updatedAt: serverTimestamp()
      });

      await batch.commit();
      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.WRITE, `reviews/${data.reservationId}`);
    }
  },

  async updateJourneyStep(journeyId: string, currentStepIndex: number) {
    try {
      const batch = writeBatch(db);
      const journeyRef = doc(db, 'journeys', journeyId);
      const journeySnap = await getDoc(journeyRef);
      if (!journeySnap.exists()) throw new Error('Trajet introuvable');
      const journey = journeySnap.data() as Journey;

      // Update journey progress
      batch.update(journeyRef, {
        currentStepIndex,
        updatedAt: serverTimestamp()
      });

      // Notify clients of the journey
      const resQuery = query(collection(db, 'reservations'), where('journeyId', '==', journeyId), where('guideId', '==', journey.guideId), where('status', '==', 'in_progress'));
      const resSnaps = await getDocs(resQuery);
      
      const stepTitle = journey.itinerarySnapshot?.[currentStepIndex]?.title || 'Nouvelle étape';

      resSnaps.forEach(d => {
        const resData = d.data() as Reservation;
        const updatedProgress = (resData.itineraryProgress || []).map((step, idx) => {
          if (idx <= currentStepIndex) {
            return { ...step, status: 'validé', updatedAt: new Date().toISOString() };
          }
          return step;
        });

        batch.update(d.ref, {
          itineraryProgress: updatedProgress,
          currentStepIndex: currentStepIndex,
          updatedAt: serverTimestamp()
        });

        const notifRef = doc(collection(db, 'notifications'));
        batch.set(notifRef, {
          id: notifRef.id,
          userId: resData.userId,
          title: `Étape franchie ! 🧭`,
          message: `Votre guide a marqué l'étape "${stepTitle}" comme terminée.`,
          type: 'system',
          read: false,
          reservationId: d.id,
          journeyId,
          createdAt: serverTimestamp()
        });
      });

      await batch.commit();
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'journeys');
    }
  },

  async postponeJourney(journeyId: string, newDate: string, newTime: string, reason: string) {
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'journeys', journeyId), {
        date: newDate,
        time: newTime,
        status: 'open', // Ensure it stays open
        updatedAt: serverTimestamp()
      });

      const resQuery = query(collection(db, 'reservations'), where('journeyId', '==', journeyId));
      const resSnaps = await getDocs(resQuery);

      resSnaps.forEach(d => {
        const notifRef = doc(collection(db, 'notifications'));
        batch.set(notifRef, {
          id: notifRef.id,
          userId: d.data().userId,
          title: 'Trajet Reporté 📅',
          message: `Votre trajet a été reporté au ${new Date(newDate).toLocaleDateString()}. Raison: ${reason}`,
          type: 'system',
          read: false,
          reservationId: d.id,
          journeyId,
          createdAt: serverTimestamp()
        });
      });

      await batch.commit();
      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'journeys');
    }
  },

  async reportDispute(reservationId: string, userId: string, reason: string, details: string) {
    const resPath = `reservations/${reservationId}`;
    let res;
    try {
      const resRef = doc(db, 'reservations', reservationId);
      const resSnap = await getDoc(resRef);
      res = resSnap.data() as Reservation;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, resPath);
    }

    if (!res) throw new Error('Réservation non trouvée');

    try {
      const disputeRef = doc(collection(db, 'disputes'));
      const dispute = {
        id: disputeRef.id,
        reservationId,
        userId,
        guideId: res.guideId,
        reason,
        details,
        status: 'open',
        createdAt: serverTimestamp()
      };

      const batch = writeBatch(db);
      batch.set(disputeRef, dispute);
      batch.update(doc(db, 'reservations', reservationId), {
        status: 'disputed',
        disputedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      await batch.commit();
      await this.logEvent(reservationId, 'dispute_created', userId);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'disputes');
    }
  },

  async markStepComplete(reservationId: string, stepId: string) {
    try {
      const resRef = doc(db, 'reservations', reservationId);
      const resSnap = await getDoc(resRef);
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;
      
      const updatedProgress = (res.itineraryProgress || []).map(step => {
        if (step.stepId === stepId) {
          return { ...step, status: 'validé', updatedAt: new Date().toISOString() };
        }
        return step;
      });

      await updateDoc(resRef, {
        itineraryProgress: updatedProgress,
        updatedAt: serverTimestamp()
      });
      
      await this.logEvent(reservationId, 'step_completed', res.guideId, { stepId });
      return true;
    } catch (error) {
       handleFirestoreError(error, OperationType.UPDATE, `reservations/${reservationId}`);
    }
  },

  async resolveDispute(disputeId: string, decision: any, adminId: string) {
    try {
      const disputeRef = doc(db, 'disputes', disputeId);
      const disputeSnap = await getDoc(disputeRef);
      if (!disputeSnap.exists()) throw new Error('Litige introuvable');
      const dispute = disputeSnap.data() as any;

      if (dispute.status === 'resolved' || dispute.status === 'closed') {
        if (dispute.status !== 'reopened') {
           throw new Error('Ce litige est déjà résolu.');
        }
      }

      const resRef = doc(db, 'reservations', dispute.reservationId);
      const resSnap = await getDoc(resRef);
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      const batch = writeBatch(db);
      const now = serverTimestamp();

      const { resolutionType, refundAmount, guideAmount, adminComment, adminNotes, participantKept } = decision;
      const totalPaid = res.totalPaid || 0;
      const guideShareOriginal = res.guideShare || 0;

      // Update Dispute
      batch.update(disputeRef, {
        status: 'resolved',
        resolutionType,
        refundAmount: refundAmount || 0,
        guideAmount: guideAmount || 0,
        adminNotes: adminNotes || '',
        adminComment: adminComment || '',
        decisionAt: now,
        resolvedAt: now,
        updatedAt: now,
        history: [
          ...(dispute.history || []),
          {
            action: `resolved_${resolutionType}`,
            adminId,
            timestamp: new Date(),
            notes: adminComment || adminNotes || ''
          }
        ]
      });

      // Update Reservation
      let newResStatus: ReservationStatus = 'completed';
      let newPaymentStatus: PaymentStatus = 'released';
      
      if (resolutionType === 'refund_full') {
        newResStatus = 'refunded';
        newPaymentStatus = 'refunded';
      } else if (resolutionType === 'refund_partial') {
        newResStatus = 'refunded';
        newPaymentStatus = 'partial_refund';
      } else if (resolutionType === 'reject' || resolutionType === 'release_guide') {
        newResStatus = 'completed';
        newPaymentStatus = 'released';
      } else if (resolutionType === 'split') {
        newResStatus = 'completed';
        newPaymentStatus = (refundAmount > 0) ? 'partial_refund' : 'released';
      }

      batch.update(resRef, {
        status: newResStatus,
        paymentStatus: newPaymentStatus,
        refundedAmount: refundAmount || 0,
        releasedAmount: guideAmount || 0,
        adminDecision: resolutionType,
        decisionReason: adminComment || adminNotes || '',
        participantKept: participantKept !== undefined ? participantKept : (resolutionType === 'reject' || resolutionType === 'release_guide'),
        updatedAt: now
      });

      // Financial Logic
      batch.update(doc(db, 'users', res.guideId), {
        balanceBlocked: increment(-guideShareOriginal),
        balanceAvailable: increment(guideAmount || 0),
        totalEarned: increment(guideAmount || 0),
        lastActivityAt: now
      });

      if (refundAmount > 0) {
        batch.update(doc(db, 'users', res.userId), {
          balanceAvailable: increment(refundAmount),
          lastActivityAt: now
        });

        const clientTxRef = doc(collection(db, 'transactions'));
        batch.set(clientTxRef, {
          id: clientTxRef.id,
          userId: res.userId,
          amount: refundAmount,
          type: resolutionType === 'refund_full' ? 'dispute_refund_full' : 'dispute_refund_partial',
          status: 'completed',
          category: 'credit',
          reservationId: res.id,
          disputeId,
          description: `Remboursement suite à litige: ${adminComment || 'Décision admin'}`,
          createdAt: now
        });
      }

      if (guideAmount > 0) {
        const guideTxRef = doc(collection(db, 'transactions'));
        batch.set(guideTxRef, {
          id: guideTxRef.id,
          userId: res.guideId,
          amount: guideAmount,
          type: resolutionType === 'split' ? 'dispute_split_guide_payment' : 'dispute_guide_payment',
          status: 'completed',
          category: 'credit',
          reservationId: res.id,
          disputeId,
          description: `Paiement libéré suite à litige: ${adminComment || 'Décision admin'}`,
          createdAt: now
        });
      }

      // Notifications
      let clientTitle = 'Litige Résolu ✅';
      let clientMsg = `Votre litige ${disputeId} a été traité.`;
      
      switch(resolutionType) {
        case 'refund_full':
          clientTitle = 'Litige résolu — remboursement complet';
          clientMsg = `Votre litige a été traité. Un remboursement complet de ${refundAmount} FCFA a été enregistré pour votre réservation.`;
          break;
        case 'refund_partial':
          clientTitle = 'Litige résolu — remboursement partiel';
          clientMsg = `Votre litige a été traité. Un remboursement partiel de ${refundAmount} FCFA a été enregistré.`;
          break;
        case 'release_guide':
        case 'reject':
          clientTitle = 'Litige clôturé';
          clientMsg = `Après analyse, le litige a été clôturé et le paiement a été libéré au guide.`;
          break;
        case 'split':
          clientTitle = 'Litige résolu — décision partagée';
          clientMsg = `Votre litige a été traité. ${refundAmount} FCFA vous sont remboursés et ${guideAmount} FCFA sont libérés au guide.`;
          break;
      }

      const clientNotifRef = doc(collection(db, 'notifications'));
      batch.set(clientNotifRef, {
        id: clientNotifRef.id,
        userId: res.userId,
        title: clientTitle,
        message: clientMsg,
        type: 'system',
        read: false,
        reservationId: res.id,
        actionType: 'open_dispute',
        actionLabel: 'Voir la décision',
        actionRoute: `/client/reservations/${res.id}`,
        createdAt: now
      });

      const guideNotifRef = doc(collection(db, 'notifications'));
      batch.set(guideNotifRef, {
        id: guideNotifRef.id,
        userId: res.guideId,
        title: 'Arbitrage Litige ⚖️',
        message: `Décision pour la réservation ${res.id}: ${resolutionType}.`,
        type: 'system',
        read: false,
        reservationId: res.id,
        actionType: 'open_dispute',
        actionLabel: 'Voir détails',
        actionRoute: `/guide/reservations/${res.id}`,
        createdAt: now
      });

      await batch.commit();

      // Audit Logs
      await this.createAuditLog({
        actorId: adminId,
        actorRole: 'ROLE_ADMIN',
        action: 'resolve_dispute',
        targetType: 'dispute',
        targetId: disputeId,
        reservationId: res.id,
        amount: totalPaid,
        message: `Litige résolu par decision: ${resolutionType}. Comm: ${adminComment}`,
        metadata: { decision }
      });

      // Restore seats if participant is no longer kept and it's full refund or split without participation
      if (!decision.participantKept && resolutionType !== 'reject' && resolutionType !== 'release_guide') {
         await this.restoreSeatsForReservation(res.id, adminId);
         await this.logEvent(res.id, 'seats_restored' as any, adminId);
      } else {
         await this.recalculateJourneyParticipants(res.journeyId);
      }

      await this.logEvent(res.id, 'dispute_resolved', adminId, { disputeId, resolutionType });
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'disputes');
    }
  },

  async reopenDispute(disputeId: string, adminId: string, reason: string) {
    try {
      const disputeRef = doc(db, 'disputes', disputeId);
      const disputeSnap = await getDoc(disputeRef);
      if (!disputeSnap.exists()) throw new Error('Litige introuvable');
      const dispute = disputeSnap.data() as any;

      const batch = writeBatch(db);
      batch.update(disputeRef, {
        status: 'reopened',
        updatedAt: serverTimestamp(),
        history: [
          ...(dispute.history || []),
          {
            action: 'reopened',
            adminId,
            timestamp: new Date(),
            notes: reason
          }
        ]
      });

      // Notify parties
      await batch.commit();
      await this.logEvent(dispute.reservationId, 'dispute_reopened', adminId);
      return true;
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'disputes');
    }
  },

  async cancelReservationByClient(reservationId: string, userId: string, reason: string) {
     return this.cancelReservation(reservationId, userId, reason);
  },

  async cancelReservation(reservationId: string, userId: string, reason: string) {
    try {
      const resRef = doc(db, 'reservations', reservationId);
      const resSnap = await getDoc(resRef);
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const res = resSnap.data() as Reservation;

      if (['cancelled', 'refunded'].includes(res.status)) return;

      const journeySnap = await getDoc(doc(db, 'journeys', res.journeyId));
      if (!journeySnap.exists()) throw new Error('Trajet introuvable');
      const journey = journeySnap.data() as Journey;

      // Policy calculation (can be improved later if user wants strict admin review)
      const journeyDate = new Date(journey.date + 'T' + journey.time);
      const now = new Date();
      const hoursDiff = (journeyDate.getTime() - now.getTime()) / (1000 * 60 * 60);

      // Simple implementation: auto-resolve if rules are clear, or mark pending if unsure
      // For now, let's stick to the current logic but add the requested fields
      
      let refundAmount = 0;
      let refundType: 'none' | 'partial' | 'full' = 'none';
      let guideEarning = 0;

      if (hoursDiff > 48) {
        refundAmount = res.totalPaid;
        refundType = 'full';
        guideEarning = 0;
      } else if (hoursDiff > 24) {
        refundAmount = Math.floor(res.totalPaid * 0.5);
        refundType = 'partial';
        guideEarning = Math.floor(res.guideShare * 0.5);
      } else {
        refundAmount = 0;
        refundType = 'none';
        guideEarning = res.guideShare;
      }

      const batch = writeBatch(db);

      batch.update(resRef, {
        status: refundAmount === res.totalPaid ? 'refunded' : 'cancelled',
        paymentStatus: refundAmount === res.totalPaid ? 'refunded' : (refundAmount > 0 ? 'partial_refund' : 'paid'),
        cancellationStatus: 'resolved',
        refundedAmount: refundAmount,
        cancelledAt: serverTimestamp(),
        cancellationReason: reason,
        updatedAt: serverTimestamp()
      });

      if (res.paymentStatus === 'paid' || res.paymentStatus === 'held') {
        if (refundAmount > 0) {
           batch.update(doc(db, 'users', res.userId), {
             balanceAvailable: increment(refundAmount),
             lastActivityAt: serverTimestamp()
           });
           
           const txRef = doc(collection(db, 'transactions'));
           batch.set(txRef, {
             id: txRef.id,
             userId: res.userId,
             amount: refundAmount,
             type: 'refund',
             status: 'completed',
             category: 'credit',
             reservationId,
             description: `Remboursement suite annulation client (${refundType})`,
             createdAt: serverTimestamp()
           });
        }

        if (guideEarning >= 0) {
          batch.update(doc(db, 'users', res.guideId), {
             balancePending: increment(-(res.guideShare || 0)),
             balanceAvailable: increment(guideEarning),
             totalEarned: increment(guideEarning),
             lastActivityAt: serverTimestamp()
          });

          if (guideEarning > 0) {
            const txRef = doc(collection(db, 'transactions'));
            batch.set(txRef, {
              id: txRef.id,
              userId: res.guideId,
              amount: guideEarning,
              type: 'earning',
              status: 'completed',
              category: 'credit',
              reservationId,
              description: `Indemnité annulation client (${refundType})`,
              createdAt: serverTimestamp()
            });
          }
        }
      }

      // Restore seats if applicable
      if (!['in_progress', 'completed', 'cancelled'].includes(journey.status)) {
         const newSeats = Math.min(journey.totalSeats, journey.availableSeats + (res.passengers || 0));
         batch.update(doc(db, 'journeys', res.journeyId), {
           availableSeats: newSeats,
           status: newSeats > 0 ? 'open' : 'full',
           updatedAt: serverTimestamp()
         });
         batch.update(resRef, { seatsRestored: true });
      }

      // Notifications
      const guideNotifRef = doc(collection(db, 'notifications'));
      batch.set(guideNotifRef, {
        id: guideNotifRef.id,
        userId: res.guideId,
        title: 'Réservation Annulée 🛑',
        message: `${res.clientName} a annulé sa réservation pour ${res.circuitTitle}.`,
        type: 'system',
        read: false,
        reservationId,
        createdAt: serverTimestamp()
      });

      await batch.commit();
      
      // Recalculate participants for the journey
      await this.recalculateJourneyParticipants(res.journeyId);
      await this.logEvent(reservationId, 'cancelled', userId, { refundType, refundAmount });
      
      await this.createAuditLog({
        actorId: userId,
        actorRole: (userId === res.userId) ? 'ROLE_CLIENT' : 'ROLE_ADMIN',
        action: (userId === res.userId) ? 'reservation_cancelled_by_client' : 'cancellation_resolved',
        targetType: 'reservation',
        targetId: reservationId,
        amount: refundAmount,
        message: `Annulation par ${userId === res.userId ? 'client' : 'admin'}. Remboursement: ${refundAmount}`,
        metadata: { refundType, reason, cancellationStatus: 'resolved' }
      });

      return { refundAmount, refundType };
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `reservations/${reservationId}`);
    }
  },
  async cancelJourneyByGuide(journeyId: string, guideId: string) {
    const journeyPath = `journeys/${journeyId}`;
    try {
      const journeyRef = doc(db, 'journeys', journeyId);
      const resQuery = query(
        collection(db, 'reservations'), 
        where('guideId', '==', guideId),
        where('journeyId', '==', journeyId), 
        where('status', 'in', ['pending_payment', 'confirmed'])
      );
      const resSnaps = await getDocs(resQuery);

      const batch = writeBatch(db);
      batch.update(journeyRef, { status: 'cancelled', updatedAt: serverTimestamp() });

      resSnaps.forEach(d => {
        const res = d.data() as Reservation;
        batch.update(d.ref, { 
          status: 'cancelled',
          paymentStatus: res.paymentStatus === 'paid' ? 'refunded' : 'unpaid',
          updatedAt: serverTimestamp()
        });
        
        if (res.paymentStatus === 'paid') {
          // Remove from guide pending balance
          batch.update(doc(db, 'users', res.guideId), {
            balancePending: increment(-res.guideShare),
            lastActivityAt: serverTimestamp()
          });
        }
      });

      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, journeyPath);
    }
  },

  async checkAutoValidations(profile: UserProfile) {
    try {
      const now = new Date();
      let q;
      
      if (profile.role === 'ROLE_ADMIN') {
        q = query(
          collection(db, 'reservations'),
          where('status', '==', 'awaiting_client_validation'),
          where('validationDeadline', '<=', now)
        );
      } else if (profile.role === 'ROLE_GUIDE') {
        q = query(
          collection(db, 'reservations'),
          where('guideId', '==', profile.uid),
          where('status', '==', 'awaiting_client_validation'),
          where('validationDeadline', '<=', now)
        );
      } else {
        q = query(
          collection(db, 'reservations'),
          where('userId', '==', profile.uid),
          where('status', '==', 'awaiting_client_validation'),
          where('validationDeadline', '<=', now)
        );
      }
      
      const snap = await getDocs(q);
      if (snap.empty) return;

      console.log(`Found ${snap.size} reservations for auto-validation`);
      
      for (const docSnap of snap.docs) {
        const res = docSnap.data() as Reservation;
        await this.validateExperience(docSnap.id, res.userId, true);
      }
    } catch (error) {
      console.error('Auto-validation error:', error);
    }
  },
  async repairReservationsData() {
    try {
      const snap = await getDocs(collection(db, 'reservations'));
      let repairedCount = 0;
      let errorCount = 0;

      for (const d of snap.docs) {
        const res = d.data() as Reservation;
        let updates: any = {};
        let needsUpdate = false;

        if (!res.guideId || !res.circuitId || !res.circuitTitle || !res.guideName || !res.clientName) {
          try {
            const journeySnap = await getDoc(doc(db, 'journeys', res.journeyId));
            if (journeySnap.exists()) {
              const journey = journeySnap.data() as Journey;
              if (!res.guideId) { updates.guideId = journey.guideId; needsUpdate = true; }
              if (!res.circuitId) { updates.circuitId = journey.circuitId; needsUpdate = true; }
              if (!res.circuitTitle) { updates.circuitTitle = journey.title || 'Voyage'; needsUpdate = true; }
              
              if ((!res.guideName && updates.guideId) || (!res.guideName && res.guideId)) {
                const gSnap = await getDoc(doc(db, 'users', updates.guideId || res.guideId));
                if (gSnap.exists()) {
                  updates.guideName = gSnap.data().displayName || 'Guide';
                  needsUpdate = true;
                }
              }
            }

            if (!res.clientName || !res.clientPhone || !res.userEmail) {
              const uSnap = await getDoc(doc(db, 'users', res.userId));
              if (uSnap.exists()) {
                const user = uSnap.data() as UserProfile;
                if (!res.clientName) updates.clientName = user.displayName || 'Client';
                if (!res.clientPhone) updates.clientPhone = user.phone || 'Non spécifié';
                if (!res.userEmail) updates.userEmail = user.email || '';
                needsUpdate = true;
              }
            }

            if (needsUpdate) {
              await updateDoc(d.ref, {
                ...updates,
                updatedAt: serverTimestamp()
              });
              repairedCount++;
            }
          } catch (e) {
            console.error(`Error repairing reservation ${d.id}:`, e);
            errorCount++;
          }
        }
      }
      return { repairedCount, errorCount };
    } catch (error) {
      console.error('Repair error:', error);
      throw error;
    }
  },
};

import { auth } from '../firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  
  const errorJson = JSON.stringify(errInfo);
  console.error('Firestore Error: ', errorJson);
  
  // If it's a "client is offline" error, it's likely a config issue
  if (errInfo.error.includes('the client is offline')) {
    console.warn("CRITICAL: Firestore client is offline. This usually means the Firebase configuration (API Key, Project ID, or Database ID) is incorrect, or Firestore is not enabled in the console.");
  }

  throw new Error(errorJson);
}

/**
 * Normalizes a date field that could be a string or a Firestore Timestamp into a Date object.
 */
export function toDate(dateField: any): Date {
  if (!dateField) return new Date(0);
  if (typeof dateField === 'string') return new Date(dateField);
  if (dateField && typeof dateField.toDate === 'function') return dateField.toDate();
  if (dateField && dateField.seconds !== undefined) return new Date(dateField.seconds * 1000);
  return new Date(dateField);
}

/**
 * Helper to sort items by a date field descending.
 */
export function sortByDateDesc(a: any, b: any, field = 'createdAt'): number {
  const dateA = toDate(a[field]).getTime();
  const dateB = toDate(b[field]).getTime();
  return dateB - dateA;
}

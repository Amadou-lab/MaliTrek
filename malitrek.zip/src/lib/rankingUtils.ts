import { UserProfile, Circuit } from '../types';
import { toDate } from './firestoreUtils';

/**
 * Calculates badges for a guide based on performance metrics.
 */
export const calculateGuideBadges = (guide: UserProfile, circuitCount: number = 0): string[] => {
  const badges: string[] = [];
  const rating = guide.averageBookingValue || 0; // Using this as proxy or actual rating if available
  const reservations = guide.totalReservations || 0;
  
  // 1. Nouveau Guide (less than 30 days)
  const isNew = (Date.now() - toDate(guide.createdAt).getTime()) < (30 * 24 * 60 * 60 * 1000);
  if (isNew) badges.push('Nouveau Guide');

  // 2. Guide Vérifié (Always verified for this demo or based on status)
  if (guide.status === 'active' || guide.status === 'vip') badges.push('Guide Vérifié');

  // 3. Top Rated (note ≥ 4.5 + 5 avis min for demo purposes, prompt asked for 10)
  if (rating >= 4.5 && reservations >= 10) badges.push('Top Rated');

  // 4. Elite Guide (haute performance: volume + satisfaction)
  if (rating >= 4.8 && reservations >= 25) badges.push('Elite Guide');

  // 5. Guide Premium (expériences haut de gamme - e.g. having premium circuits)
  if (guide.status === 'vip') badges.push('Guide Premium');

  return badges;
};

/**
 * Calculates ranking score based on weighted criteria
 * Note moyenne (40%) + Volume d'avis (20%) + Réservations (20%) + Satisfaction (20%)
 */
export const calculateRankingScore = (circuit: Circuit): number => {
  const rating = circuit.averageRating || 0;
  const reviews = circuit.reviewCount || 0;
  const bookings = circuit.bookingCount || 0;
  
  // Normalize values for scoring (rough normalization)
  const ratingScore = (rating / 5) * 40; // max 40
  const reviewScore = Math.min((reviews / 50), 1) * 20; // max 20, cap at 50 reviews
  const bookingScore = Math.min((bookings / 100), 1) * 20; // max 20, cap at 100 bookings
  const satisfactionScore = rating >= 4 ? 20 : (rating / 4) * 20; // max 20

  return Number((ratingScore + reviewScore + bookingScore + satisfactionScore).toFixed(2));
};

export const getCircuitBadges = (circuit: Circuit) => {
  const badges: { label: string; color: string; icon: string }[] = [];
  const score = circuit.rankingScore || 0;
  const reviews = circuit.reviewCount || 0;

  if (score >= 80) badges.push({ label: '🔥 Trending', color: 'rose', icon: 'Flame' });
  if (circuit.averageRating && circuit.averageRating >= 4.8 && reviews >= 5) {
    badges.push({ label: '⭐ Coup de cœur', color: 'amber', icon: 'Heart' });
  }

  return badges;
};

import { collection, addDoc, writeBatch, doc, getDocs, query, where, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Circuit, Journey, UserProfile, Reservation, Notification, POI } from '../types';

const MOCK_IMAGES = {
  djenne: 'https://images.unsplash.com/photo-1599933333333-333333333333?auto=format&fit=crop&q=80&w=1000',
  bandiagara: 'https://images.unsplash.com/photo-1599944444444-444444444444?auto=format&fit=crop&q=80&w=1000',
  tombouctou: 'https://images.unsplash.com/photo-1599955555555-555555555555?auto=format&fit=crop&q=80&w=1000',
  niger: 'https://images.unsplash.com/photo-1599966666666-666666666666?auto=format&fit=crop&q=80&w=1000',
  mopti: 'https://images.unsplash.com/photo-1599977777777-777777777777?auto=format&fit=crop&q=80&w=1000',
};

export const POIS: Omit<POI, 'id'>[] = [
  {
    name: 'Grande Mosquée de Djenné',
    description: 'Le plus grand bâtiment au monde construit en terre crue.',
    lat: 13.9133,
    lng: -4.5558,
    category: 'monument',
    image: MOCK_IMAGES.djenne
  },
  {
    name: 'Falaises de Bandiagara',
    description: 'Site du patrimoine mondial de l\'UNESCO, berceau de la culture Dogon.',
    lat: 14.3333,
    lng: -3.5,
    category: 'nature',
    image: MOCK_IMAGES.bandiagara
  },
  {
    name: 'Tombouctou la Mystérieuse',
    description: 'Ancien centre de savoir islamique et ville aux 333 saints.',
    lat: 16.7666,
    lng: -3.0026,
    category: 'city',
    image: MOCK_IMAGES.tombouctou
  },
  {
    name: 'Port de Mopti',
    description: 'La Venise du Mali, point de rencontre des cultures sur le fleuve Niger.',
    lat: 14.4958,
    lng: -4.1917,
    category: 'city',
    image: MOCK_IMAGES.mopti
  }
];

export const seedDatabase = async () => {
  const batch = writeBatch(db);

  // 1. Seed POIs
  for (const poi of POIS) {
    const poiRef = doc(collection(db, 'pois'));
    batch.set(poiRef, { ...poi, isTest: true });
  }

  // 2. Seed some test circuits
  const testCircuits: Omit<Circuit, 'id'>[] = [
    {
      title: 'Expédition Dogon',
      location: 'Pays Dogon',
      description: 'Une immersion totale dans la culture Dogon à travers les falaises de Bandiagara.',
      basePrice: 150000,
      duration: '5 jours',
      image: MOCK_IMAGES.bandiagara,
      availabilityStart: '2026-05-01',
      availabilityEnd: '2026-05-31',
      maxParticipants: 15,
      region: 'Mali',
      itinerary: [],
      inclus: ['Guide', 'Transport'],
      nonInclus: ['Repas', 'Pourboires'],
      cancellationPolicy: 'Standard',
      minParticipants: 1,
      status: 'approved',
      category: 'Culture',
      lat: 14.3333,
      lng: -3.5,
      guideId: 'guide-test-1',
      createdAt: new Date().toISOString(),
      isTest: true
    },
    {
      title: 'Croisière sur le Niger',
      location: 'Mopti - Ségou',
      description: 'Naviguez sur le majestueux fleuve Niger en pinasse traditionnelle.',
      basePrice: 85000,
      duration: '3 jours',
      image: MOCK_IMAGES.niger,
      availabilityStart: '2026-06-10',
      availabilityEnd: '2026-06-20',
      maxParticipants: 20,
      region: 'Mali',
      itinerary: [],
      inclus: ['Pirogue', 'Guide'],
      nonInclus: ['Hébergement'],
      cancellationPolicy: 'Standard',
      minParticipants: 2,
      status: 'approved',
      category: 'Nature',
      lat: 14.4958,
      lng: -4.1917,
      guideId: 'guide-test-1',
      createdAt: new Date().toISOString(),
      isTest: true
    }
  ];

  for (const circuit of testCircuits) {
    const circuitRef = doc(collection(db, 'circuits'));
    batch.set(circuitRef, circuit);
    
    // Create a journey ONLY if circuit is approved
    if (circuit.status === 'approved') {
      const journeyRef = doc(collection(db, 'journeys'));
      batch.set(journeyRef, {
        circuitId: circuitRef.id,
        title: circuit.title,
        location: circuit.location,
        date: circuit.availabilityStart || '2026-05-01',
        meetingPoint: 'Bamako',
        pricePerPerson: circuit.basePrice,
        availableSeats: 12,
        totalSeats: 15,
        status: 'open',
        guideId: circuit.guideId,
        meetingTime: '08:00',
        meetingLink: 'https://maps.google.com',
        image: circuit.image,
        category: circuit.category,
        minParticipants: circuit.minParticipants || 1,
        lat: circuit.lat,
        lng: circuit.lng,
        createdAt: new Date().toISOString(),
        isTest: true
      });
    }
  }

  // 3. Seed some withdrawals
  const testWithdrawals = [
    {
      guideId: 'guide-test-1',
      guideName: 'Guide Test',
      amount: 50000,
      method: 'Orange Money',
      phone: '+223 70 00 00 00',
      status: 'pending',
      createdAt: new Date().toISOString(),
      isTest: true
    },
    {
      guideId: 'guide-test-1',
      guideName: 'Guide Test',
      amount: 25000,
      method: 'Moov Money',
      phone: '+223 60 00 00 00',
      status: 'approved',
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      isTest: true
    }
  ];

  for (const withdrawal of testWithdrawals) {
    const withdrawalRef = doc(collection(db, 'withdrawals'));
    batch.set(withdrawalRef, withdrawal);
  }

  await batch.commit();
};

export const clearTestData = async () => {
  const collections = ['circuits', 'journeys', 'reservations', 'notifications', 'withdrawals', 'pois', 'reviews'];
  
  for (const collName of collections) {
    const q = query(collection(db, collName), where('isTest', '==', true));
    const snapshot = await getDocs(q);
    for (const docSnap of snapshot.docs) {
      await deleteDoc(doc(db, collName, docSnap.id));
    }
  }
};

export const clearAllDatabase = async () => {
  const collections = ['circuits', 'journeys', 'reservations', 'notifications', 'withdrawals', 'pois', 'reviews'];
  
  for (const collName of collections) {
    const snapshot = await getDocs(collection(db, collName));
    const batch = writeBatch(db);
    snapshot.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();
  }
};

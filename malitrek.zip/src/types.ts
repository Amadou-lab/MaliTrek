export type UserRole = 'ROLE_ADMIN' | 'ROLE_GUIDE' | 'ROLE_CLIENT';
export type GuideTier = 'standard' | 'premium' | 'elite' | 'suspended';
export type GuideStatus = 'pending_verification' | 'active' | 'premium' | 'elite' | 'suspended' | 'under_review' | 'banned';
export type FeaturedStatus = 'none' | 'featured' | 'sponsored' | 'boosted';
export type JourneyStatus = 'draft' | 'planned' | 'open' | 'confirmed' | 'full' | 'in_progress' | 'paused' | 'cancelled' | 'completed' | 'disputed' | 'unavailable';

export interface OfflineAction {
  id: string;
  type: 'CHECK_IN' | 'NEXT_STEP' | 'INCIDENT' | 'PAUSE' | 'RESUME' | 'START';
  payload: any;
  timestamp: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phone?: string;
  role: UserRole;
  createdAt: any;
  favorites?: string[]; // Array of journey or circuit IDs
  photoURL?: string;
  balanceAvailable?: number; // Withdrawable funds
  balancePending?: number; // Funds in escrow
  balanceBlocked?: number; // Funds blocked due to dispute
  totalEarned?: number; // Historical total
  totalWithdrawn?: number; // Historical total withdrawn
  commissionRate?: number; // Default 0.8 (80%)
  lastActivityAt?: any;
  totalReservations?: number; // For clients
  totalBookings?: number; // For guides
  averageBookingValue?: number;
  rating?: number;
  reviewCount?: number;
  categoryPreferences?: string[];
  status?: 'active' | 'suspended' | 'pending' | 'vip' | 'inactive';
  
  // Guide Specific Professional Fields
  isVerified?: boolean;
  isTrusted?: boolean; // Guide de confiance
  guideTier?: GuideTier;
  guideStatus?: GuideStatus;
  customCommissionRate?: number; 
  trustScore?: number;
  rankingScore?: number;
  
  // Professional Details
  bio?: string;
  languages?: string[];
  regions?: string[];
  specialties?: string[];
  certifications?: string[];
  experienceYears?: number;
  gallery?: string[];
  
  // Stats
  averageRating?: number;
  totalReviews?: number;
  completedJourneys?: number;
  cancellationRate?: number;
  disputeRate?: number;
  responseRate?: number;
  responseTime?: number; // in minutes
  yearsOfExperience?: number; // Keep for compatibility
  location?: string;
  tags?: string[];
  
  // Visibility & Monetization
  featuredStatus?: FeaturedStatus;
  premiumUntil?: any;
  boostedUntil?: any;
  featuredUntil?: any;
  
  // Admin Notes
  adminNotes?: string;
  internalTags?: string[];
  
  paymentMethods?: {
    type: 'orange_money' | 'moov_money' | 'wave' | 'bank_transfer';
    number?: string;
    accountName?: string;
    bankName?: string;
    iban?: string;
    accountReference?: string;
  }[];
  preferences?: {
    notifications: boolean;
    language: 'fr' | 'en';
    theme: 'light' | 'dark';
  };
}

export interface StepProgress {
  stepId: string;
  title?: string;
  status: 'en_attente' | 'terminé_par_guide' | 'en_attente_validation_client' | 'validé' | 'payé';
  completedAt?: any;
}

export interface ItineraryStep {
  id: string;
  order: number;
  day: number;
  title: string;
  description: string;
  locationName: string;
  lat?: number;
  lng?: number;
  estimatedTime?: string;
  duration?: string;
  activities?: string[];
  images?: string[];
  notes?: string;
  status?: 'pending' | 'active' | 'completed' | 'skipped' | 'incident';
}

export type CircuitStatus = 'draft' | 'pending_admin_validation' | 'approved' | 'rejected' | 'closed' | 'disabled';

export interface Circuit {
  id: string;
  title: string;
  location: string;
  region: string;
  description: string;
  basePrice: number;
  duration: string;
  image: string;
  images?: string[];
  status: CircuitStatus;
  category: 'Culture' | 'Nature' | 'Aventure' | 'Histoire' | 'Artisanat';
  lat?: number;
  lng?: number;
  routePolyline?: { lat: number; lng: number }[];
  guideId: string;
  itinerary: ItineraryStep[];
  inclus: string[];
  nonInclus: string[];
  cancellationPolicy: string;
  minParticipants: number;
  maxParticipants?: number;
  rejectionReason?: string;
  closedReason?: string;
  disabledReason?: string;
  isPremium?: boolean;
  premiumUntil?: string;
  rankingScore?: number;
  availabilityStart?: string;
  availabilityEnd?: string;
  createdAt: any;
  updatedAt?: any;
  averageRating?: number;
  reviewCount?: number;
  bookingCount?: number;
  isTest?: boolean;
}

export interface Journey {
  id: string;
  circuitId: string;
  guideId: string;
  date: string;
  time: string;
  meetingPoint: string;
  meetingTime?: string;
  meetingLink?: string;
  specialInstructions?: string;
  safetyNotes?: string;
  transportInfo?: string;
  weatherNote?: string;
  specialNote?: string;
  journeyNotes?: string;
  pricePerPerson: number;
  totalSeats: number;
  availableSeats: number;
  minParticipants: number;
  status: JourneyStatus;
  difficulty?: 'facile' | 'moyen' | 'difficile';
  isPremium?: boolean;
  premiumLevel?: 'normal' | 'boosted' | 'top';
  itinerarySnapshot?: ItineraryStep[];
  currentStepIndex?: number;
  currentPosition?: { lat: number; lng: number };
  routePolyline?: { lat: number; lng: number }[];
  startedAt?: any;
  completedAt?: any;
  activeParticipantsCount?: number;
  activeReservationsCount?: number;
  checkedInCount?: number;
  incidentCount?: number;
  cancelledParticipantsCount?: number;
  disputedParticipantsCount?: number;
  createdAt: any;
  updatedAt?: any;
  // Denormalized data for easier display
  title: string;
  location: string;
  image: string;
  category: string;
}

export type ReservationStatus = 
  | 'pending_payment' 
  | 'confirmed' 
  | 'in_progress' 
  | 'awaiting_client_validation' 
  | 'completed' 
  | 'disputed'
  | 'cancellation_requested'
  | 'cancelled' 
  | 'refunded';

export type PaymentStatus = 'unpaid' | 'paid' | 'held' | 'disputed' | 'released' | 'refunded' | 'partial_refund';

export interface Reservation {
  id: string;
  journeyId: string;
  circuitId: string;
  circuitTitle?: string;
  userId: string;
  guideId: string;
  guideName?: string;
  passengers: number;
  totalPaid: number;
  guideShare: number; // 80% (guideEarning)
  platformFee: number; // 20%
  releasedAmount?: number; // Amount actually released to guide after resolution
  refundedAmount?: number; // Amount returned to client
  commissionStatus: 'pending' | 'released' | 'blocked' | 'refunded' | 'partially_refunded';
  releasedAt?: any;
  releaseType?: 'client_validation' | 'auto_validation' | 'admin_decision';
  status: ReservationStatus;
  paymentStatus: PaymentStatus;
  fullname: string;
  phone: string;
  clientName?: string;
  clientPhone?: string;
  userEmail?: string;
  userPhoto?: string;
  qrCode?: string;
  itineraryProgress?: StepProgress[];
  disputeReason?: string;
  experienceValidated?: boolean;
  reviewId?: string;
  autoValidation?: boolean;
  validationDeadline?: any;
  tripStartedAt?: any;
  checkInStatus?: 'pending' | 'checked_in' | 'marked_present_by_guide' | 'absent';
  clientCheckInStatus?: 'pending' | 'checked_in';
  clientCheckedInAt?: any;
  guidePresenceStatus?: 'pending' | 'present' | 'absent';
  guideMarkedPresenceAt?: any;
  guideMarkedPresenceBy?: string;
  presenceConflict?: boolean;
  checkedInAt?: any;
  presenceMarkedBy?: string;
  presenceMarkedAt?: any;
  incidentStatus?: 'none' | 'reported' | 'investigating' | 'resolved';
  cancellationRequestedAt?: any;
  cancellationReason?: string;
  cancellationStatus?: 'pending_admin_review' | 'resolved' | 'rejected';
  refundAmount?: number;
  seatsRestored?: boolean;
  participantKept?: boolean;
  createdAt: any;
  updatedAt?: any;
  validatedAt?: any;
  disputedAt?: any;
  completedAt?: any;
  cancelledAt?: any;
  refundedAt?: any;
  adminDecision?: string;
  decisionReason?: string;
}

export type ReservationEventType = 
  | 'reservation_created' 
  | 'payment_confirmed' 
  | 'journey_confirmed' 
  | 'journey_started' 
  | 'client_checked_in'
  | 'guide_marked_present'
  | 'guide_marked_absent'
  | 'presence_conflict_detected'
  | 'incident_reported'
  | 'dispute_opened'
  | 'dispute_resolved'
  | 'cancellation_requested'
  | 'cancelled'
  | 'journey_completed_by_guide' 
  | 'client_validation_requested' 
  | 'experience_validated_by_client' 
  | 'experience_auto_validated' 
  | 'dispute_created' 
  | 'payment_released' 
  | 'admin_decision' 
  | 'refund_processed'
  | 'journey_cancelled';

export interface ReservationEvent {
  id: string;
  reservationId: string;
  type: ReservationEventType;
  userId: string; // Actor
  timestamp: any;
  metadata?: any;
}

export interface Withdrawal {
  id: string;
  guideId: string;
  guideName: string;
  amount: number;
  method: 'orange_money' | 'moov_money' | 'wave' | 'bank_transfer';
  accountNumber: string;
  status: 'pending' | 'approved' | 'processed' | 'rejected';
  rejectionReason?: string;
  processedAt?: any;
  createdAt: any;
  note?: string;
}

export type TransactionType =
  | 'client_payment' 
  | 'payment_hold' 
  | 'platform_fee' 
  | 'guide_earning_pending' 
  | 'guide_earning_release' 
  | 'guide_withdrawal_request' 
  | 'guide_withdrawal_paid' 
  | 'refund_full' 
  | 'refund_partial' 
  | 'dispute_refund' 
  | 'dispute_split' 
  | 'cancellation_fee';

export type PaymentProvider = 'cinetpay' | 'paydunya' | 'orange_money' | 'moov_money' | 'wave' | 'bank_card' | 'manual_test';

export interface Transaction {
  id: string;
  reservationId?: string;
  journeyId?: string;
  circuitId?: string;
  clientId?: string;
  guideId?: string;
  amount: number;
  type: TransactionType;
  category: 'credit' | 'debit';
  status: 'pending' | 'completed' | 'failed' | 'reversed';
  provider: PaymentProvider;
  providerReference?: string;
  description: string;
  createdAt: any;
  metadata?: any;
}

export interface AppReview {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: any;
}

export interface Dispute {
  id: string;
  reservationId?: string;
  journeyId: string;
  circuitId?: string;
  clientId: string;
  guideId: string;
  reportedBy: string;
  reportedByRole: UserRole;
  type: string;
  description: string;
  urgency: 'normal' | 'urgent' | 'critical';
  evidenceUrls?: string[];
  status: 'open' | 'under_review' | 'resolved' | 'rejected' | 'reopened' | 'closed';
  resolutionType?: 'refund_full' | 'refund_partial' | 'release_guide' | 'split' | 'reject' | 'no_action';
  adminDecision?: string; // Legacy field for compatibility
  adminNotes?: string;
  adminComment?: string;
  decisionReason?: string;
  refundAmount?: number;
  guideAmount?: number;
  platformFee?: number;
  createdAt: any;
  resolvedAt?: any;
  updatedAt?: any;
  decisionAt?: any;
  history?: {
    action: string;
    adminId: string;
    timestamp: any;
    notes: string;
  }[];
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorRole: string;
  action: string;
  targetType: 'reservation' | 'journey' | 'user' | 'dispute' | 'withdrawal' | 'transaction' | 'circuit';
  targetId: string;
  reservationId?: string;
  journeyId?: string;
  amount?: number;
  message: string;
  metadata?: any;
  createdAt: any;
}

export interface Cancellation {
  id: string;
  reservationId?: string;
  journeyId: string;
  clientId?: string;
  guideId: string;
  requestedBy: string;
  requestedByRole: UserRole | 'admin';
  reason: string;
  refundAmount: number;
  refundType: 'full' | 'partial' | 'none';
  status: 'requested' | 'cancelled' | 'refunded' | 'rejected';
  createdAt: any;
  resolvedAt?: any;
}

export interface Review {
  id: string;
  reservationId: string;
  circuitId: string;
  journeyId: string;
  userId: string;
  guideId: string;
  userName: string;
  userPhoto?: string;
  ratingGlobal: number; // 1 to 5
  ratingGuide: number;
  ratingExperience: number;
  ratingPunctuality: number;
  ratingValue: number;
  comment: string;
  images?: string[];
  createdAt: any;
}

export interface Conversation {
  id: string;
  clientId: string;
  clientName: string;
  guideId: string;
  guideName: string;
  reservationId: string;
  journeyId: string;
  circuitId?: string;
  circuitTitle?: string;
  journeyDate?: string;
  participants: string[]; // [clientId, guideId]
  participantNames?: { [uid: string]: string };
  title: string;
  subtitle?: string;
  lastMessage?: string;
  lastMessageAt?: any;
  unreadCountByUser: { [uid: string]: number };
  status: 'active' | 'archived';
  createdAt: any;
  updatedAt: any;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  receiverId: string;
  receiverName?: string;
  text: string;
  attachments?: string[];
  readBy: string[]; // UIDs
  createdAt: any;
  status: 'sent' | 'delivered' | 'read';
}

export type NotificationType = 
  | 'reservation' 
  | 'payment' 
  | 'system' 
  | 'promotion' 
  | 'chat'
  | 'reservation_confirmed'
  | 'payment_confirmed'
  | 'journey_started'
  | 'journey_completed'
  | 'client_validation_requested'
  | 'experience_auto_validated'
  | 'payment_released'
  | 'dispute_created'
  | 'message_received'
  | 'circuit_approved'
  | 'circuit_rejected';

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: NotificationType;
  read: boolean;
  reservationId?: string;
  journeyId?: string;
  conversationId?: string;
  actionType?: 'validate_experience' | 'open_chat' | 'open_reservation' | 'open_dispute' | 'view_reservation';
  actionLabel?: string;
  actionRoute?: string;
  createdAt: any;
}

export interface WithdrawalRequest {
  id: string;
  guideId: string;
  guideName: string;
  amount: number;
  method: 'orange_money' | 'moov_money' | 'wave' | 'bank_transfer';
  accountNumber: string;
  phone?: string;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  createdAt: any;
}

export interface POI {
  id: string;
  name: string;
  description: string;
  location?: string;
  lat: number;
  lng: number;
  category: 'monument' | 'nature' | 'city' | 'activity';
  image?: string;
}

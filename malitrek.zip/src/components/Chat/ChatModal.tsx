import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Message, Reservation, Journey, UserProfile } from '../../types';
import { trekService } from '../../services/trekService';
import { collection, query, where, onSnapshot, addDoc, orderBy, serverTimestamp, updateDoc, doc, limit, getDoc, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { Send, X, Smartphone, User, MessageCircle, Clock, Calendar } from 'lucide-react';
import { handleFirestoreError, OperationType, toDate } from '../../lib/firestoreUtils';

interface ChatModalProps {
  reservation: Reservation;
  currentUserId: string;
  currentUserName: string;
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ reservation, currentUserId, currentUserName, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [journey, setJourney] = useState<Journey | null>(null);
  const [participantName, setParticipantName] = useState('Chauffeur/Guide');
  const [conversationId, setConversationId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    const setupChat = async () => {
      try {
        setIsLoading(true);
        // 1. Fetch Journey and Participant Info
        const jSnap = await getDoc(doc(db, 'journeys', reservation.journeyId));
        if (jSnap.exists()) setJourney({ id: jSnap.id, ...jSnap.data() } as Journey);

        const otherId = currentUserId === reservation.userId ? reservation.guideId : reservation.userId;
        const uSnap = await getDoc(doc(db, 'users', otherId));
        if (uSnap.exists()) setParticipantName(uSnap.data().displayName);

        // 2. Get or Create Conversation
        const convid = await trekService.getOrCreateConversation({
          reservationId: reservation.id,
          clientId: reservation.userId,
          guideId: reservation.guideId,
          journeyId: reservation.journeyId,
          circuitId: reservation.circuitId
        });

        if (convid) {
          setConversationId(convid);
          
          // 3. Listen to messages for this conversation
          const q = query(
            collection(db, 'messages'),
            where('conversationId', '==', convid),
            orderBy('createdAt', 'asc'),
            limit(100)
          );

          unsubscribe = onSnapshot(q, (snapshot) => {
            const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
            setMessages(msgs);
            setIsLoading(false);

            // Reset unread count for this conversation
            trekService.markConversationAsRead(convid, currentUserId);

            // Mark unread messages as read (using new readBy field)
            // Filter first to only update what's necessary to avoid infinite loop
            const messagesToUpdate = msgs.filter(msg => 
              msg.senderId !== currentUserId && 
              (!msg.readBy || !msg.readBy.includes(currentUserId))
            );

            if (messagesToUpdate.length > 0) {
              // Use a batch or at least don't do it inside the main map if possible
              // but for now, we just ensure it's filtered correctly
              messagesToUpdate.forEach(async (msg) => {
                try {
                  const currentReadBy = msg.readBy || [];
                  await updateDoc(doc(db, 'messages', msg.id), { 
                    readBy: [...currentReadBy, currentUserId] 
                  });
                } catch (e) {
                  console.error('Error marking message as read:', e);
                }
              });
            }
          }, (error) => {
            handleFirestoreError(error, OperationType.LIST, 'messages');
            setIsLoading(false);
          });
        }
      } catch (e) {
        console.error('Chat setup error:', e);
        setIsLoading(false);
      }
    };

    setupChat();

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [reservation.id, currentUserId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !conversationId) return;

    const messageText = newMessage;
    setNewMessage('');

    try {
      const isSenderClient = currentUserId === reservation.userId;
      const receiverId = isSenderClient ? reservation.guideId : reservation.userId;

      await trekService.sendMessage(
        conversationId,
        currentUserId,
        messageText
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'messages');
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-[2.5rem] w-full max-w-lg h-[600px] shadow-2xl relative z-10 flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-stone-100 flex justify-between items-center bg-stone-900 text-white">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-600/20">
              <MessageCircle size={24} />
            </div>
            <div>
              <h3 className="font-black tracking-tight text-sm uppercase mb-0.5">Chat avec {participantName}</h3>
              <div className="flex items-center gap-2">
                <p className="text-[10px] font-black uppercase tracking-widest text-emerald-400">
                  {journey?.title || 'Voyage Malitrek'}
                </p>
                <span className="text-white/20">•</span>
                <div className="flex items-center gap-1 text-[10px] text-stone-400 font-bold uppercase">
                  <Calendar size={10} />
                  {journey?.date ? new Date(journey.date).toLocaleDateString() : 'Chargement...'}
                </div>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-all">
            <X size={24} />
          </button>
        </div>

        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-4 bg-stone-50"
        >
          {messages.map((msg) => (
            <div 
              key={msg.id}
              className={`flex ${msg.senderId === currentUserId ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] p-4 rounded-2xl shadow-sm space-y-1 ${
                msg.senderId === currentUserId 
                  ? 'bg-emerald-600 text-white rounded-tr-none' 
                  : 'bg-white text-stone-900 border border-stone-100 rounded-tl-none'
              }`}>
                {msg.senderId !== currentUserId && (
                  <p className="text-[8px] font-black uppercase tracking-widest opacity-60 mb-1">{msg.senderName}</p>
                )}
                <p className="text-sm font-medium leading-relaxed">{msg.text}</p>
                <div className="flex justify-end">
                  <span className={`text-[8px] font-bold ${msg.senderId === currentUserId ? 'text-white/60' : 'text-stone-400'}`}>
                    {msg.createdAt ? toDate(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--:--'}
                  </span>
                </div>
              </div>
            </div>
          ))}
          {!isLoading && messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 p-12">
              <div className="w-16 h-16 bg-stone-100 rounded-[1.5rem] flex items-center justify-center text-stone-300">
                <Clock size={32} />
              </div>
              <div>
                <p className="font-black text-stone-900 text-sm">Pas encore de messages</p>
                <p className="text-xs text-stone-500 font-medium">Posez vos questions ici pour mieux préparer votre voyage.</p>
              </div>
            </div>
          )}
        </div>

        <form 
          onSubmit={handleSendMessage}
          className="p-6 bg-white border-t border-stone-100"
        >
          <div className="relative flex items-center gap-3">
            <input 
              className="flex-1 bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-stone-900 transition-all pr-14"
              placeholder="Écrivez votre message..."
              value={newMessage}
              onChange={e => setNewMessage(e.target.value)}
            />
            <button 
              type="submit"
              disabled={!newMessage.trim()}
              className="absolute right-2 p-3 bg-stone-900 text-white rounded-xl hover:bg-stone-800 disabled:bg-stone-100 disabled:text-stone-300 transition-all shadow-lg active:scale-95"
            >
              <Send size={18} />
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, where, onSnapshot, orderBy, getDoc, doc } from 'firebase/firestore';
import { db } from '../../firebase';
import { Message, Reservation, Journey } from '../../types';
import { MessageCircle, Search, Clock, ArrowRight, User, Compass, Calendar } from 'lucide-react';
import { handleFirestoreError, OperationType, toDate } from '../../lib/firestoreUtils';
import { ChatModal } from './ChatModal';
import { PremiumLoading } from '../shared/UI';

interface MessagesViewProps {
  currentUserId: string;
  currentUserName: string;
  userRole: 'ROLE_CLIENT' | 'ROLE_GUIDE';
  initialReservationId?: string | null;
  onClearInitial?: () => void;
}

interface Conversation {
  reservationId: string;
  lastMessage: Message;
  reservation?: Reservation;
  journey?: Journey;
  participantName: string;
  unreadCount: number;
}

export const MessagesView: React.FC<MessagesViewProps> = ({ currentUserId, currentUserName, userRole, initialReservationId, onClearInitial }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRes, setSelectedRes] = useState<Reservation | null>(null);

  useEffect(() => {
    if (initialReservationId) {
      const fetchInitial = async () => {
        try {
          const resSnap = await getDoc(doc(db, 'reservations', initialReservationId));
          if (resSnap.exists()) {
            setSelectedRes({ id: resSnap.id, ...resSnap.data() } as Reservation);
          }
        } catch (e) {
          console.error('Error fetching initial reservation for chat:', e);
        } finally {
          onClearInitial?.();
        }
      };
      fetchInitial();
    }
  }, [initialReservationId]);

  useEffect(() => {
    const q = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', currentUserId),
      orderBy('lastMessageAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      try {
        const convDocs = snapshot.docs;
        
        const detailedConvs = await Promise.all(convDocs.map(async (docSnap) => {
          try {
            const data = docSnap.data();
            const resId = data.reservationId;
            
            const resSnap = await getDoc(doc(db, 'reservations', resId));
            if (resSnap.exists()) {
              const resData = { id: resSnap.id, ...resSnap.data() } as Reservation;
              const journeySnap = await getDoc(doc(db, 'journeys', resData.journeyId));
              
              let participantName = 'Utilisateur';
              if (userRole === 'ROLE_CLIENT') {
                const uSnap = await getDoc(doc(db, 'users', resData.guideId));
                participantName = uSnap.exists() ? uSnap.data().displayName : 'Guide Malitrek';
              } else {
                participantName = resData.fullname;
              }

              if (journeySnap.exists()) {
                // Mock a message object for compatibility with the existing UI
                const lastMsg: Message = {
                  id: 'last',
                  conversationId: docSnap.id,
                  senderId: '', // We don't necessarily know who sent it from the conv object alone without more fields
                  text: data.lastMessage,
                  createdAt: data.lastMessageAt,
                  readBy: []
                } as any;

                return {
                  reservationId: resId,
                  lastMessage: lastMsg,
                  reservation: resData,
                  journey: { id: journeySnap.id, ...journeySnap.data() } as Journey,
                  participantName,
                  unreadCount: (data.unreadCountByUser && data.unreadCountByUser[currentUserId]) || 0
                };
              }
            }
          } catch (e) {
            console.error('Error fetching conversation details:', e);
          }
          return null;
        }));

        setConversations(detailedConvs.filter((c): c is Conversation & { reservation: Reservation; journey: Journey } => 
          c !== null && c.reservation !== undefined && c.journey !== undefined
        ));
      } catch (error) {
        console.error('Error in messages snapshot listener:', error);
      } finally {
        setIsLoading(false);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'conversations');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [currentUserId, userRole]);

  const filtered = conversations.filter(c => 
    c.journey?.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.participantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.reservation?.qrCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-3xl font-black text-stone-900 tracking-tight">Messages</h1>
          <p className="text-stone-500 font-medium">Suivez vos échanges avec vos {userRole === 'ROLE_CLIENT' ? 'guides' : 'clients'}.</p>
        </div>
        <div className="relative w-full md:w-72">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
          <input 
            type="text"
            placeholder="Rechercher une discussion..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-stone-200 rounded-2xl pl-12 pr-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-stone-900 transition-all text-sm"
          />
        </div>
      </div>

      <div className="bg-white rounded-[3rem] border border-stone-200 overflow-hidden shadow-2xl">
        {isLoading ? (
          <PremiumLoading message="Chargement des discussions secrètes..." />
        ) : filtered.length > 0 ? (
          <div className="divide-y divide-stone-100">
            {filtered.map((conv) => (
              <button 
                key={conv.reservationId}
                onClick={() => setSelectedRes(conv.reservation!)}
                className="w-full p-8 flex items-center gap-6 hover:bg-stone-50 transition-all text-left group"
              >
                <div className="relative">
                  <div className="w-16 h-16 bg-stone-100 rounded-2xl flex items-center justify-center text-stone-400">
                    {conv.journey?.image ? (
                      <img src={conv.journey.image} className="w-full h-full object-cover rounded-2xl" referrerPolicy="no-referrer" />
                    ) : (
                      <Compass size={32} />
                    )}
                  </div>
                  {conv.unreadCount > 0 && (
                    <motion.div 
                      initial={{ scale: 0.5 }}
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                      className="absolute -top-2 -right-2 bg-rose-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black border-2 border-white shadow-lg"
                    >
                      {conv.unreadCount}
                    </motion.div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex justify-between items-start">
                    <h3 className="font-black text-stone-900 group-hover:text-emerald-600 transition-colors truncate tracking-tight pr-4">
                      {conv.journey?.title}
                    </h3>
                    <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest shrink-0 whitespace-nowrap">
                      {conv.lastMessage.createdAt ? toDate(conv.lastMessage.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--:--'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mb-1">
                     <div className="flex items-center gap-1">
                       <User size={10} className="text-stone-300" />
                       <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">
                          {conv.participantName}
                       </span>
                     </div>
                     <span className="text-stone-200">|</span>
                     <div className="flex items-center gap-1">
                        <Calendar size={10} className="text-stone-300" />
                        <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">
                           {conv.journey?.date ? new Date(conv.journey.date).toLocaleDateString() : 'Date à venir'}
                        </span>
                     </div>
                     <span className="text-stone-200">|</span>
                     <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">
                        Ref: {conv.reservation?.qrCode.split('-')[1]}
                     </span>
                  </div>
                  <p className={`text-sm font-medium line-clamp-1 ${conv.unreadCount > 0 ? 'text-stone-900 font-black' : 'text-stone-500'}`}>
                    {conv.lastMessage.senderId === currentUserId ? 'Vous: ' : ''}{conv.lastMessage.text}
                  </p>
                </div>

                <div className="shrink-0 text-stone-300 group-hover:text-emerald-500 transition-all group-hover:translate-x-1">
                  <ArrowRight size={24} />
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="py-32 text-center space-y-6">
            <div className="w-24 h-24 bg-stone-50 rounded-[2rem] flex items-center justify-center mx-auto text-stone-300">
              <MessageCircle size={48} />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-black text-stone-900">Aucune discussion</h3>
              <p className="text-stone-500 font-medium max-w-sm mx-auto px-6">
                {userRole === 'ROLE_CLIENT' 
                  ? "Réservez un voyage pour commencer à discuter avec nos guides certifiés."
                  : "Vous n'avez pas encore de messages de la part de vos clients."}
              </p>
            </div>
          </div>
        )}
      </div>

      {selectedRes && (
        <ChatModal 
          reservation={selectedRes}
          currentUserId={currentUserId}
          currentUserName={currentUserName}
          onClose={() => setSelectedRes(null)}
        />
      )}
    </div>
  );
};

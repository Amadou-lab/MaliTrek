import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Navigation, 
  Users, 
  MessageCircle, 
  Map, 
  MapPin,
  Compass,
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Phone,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { Journey, Reservation, UserRole, UserProfile } from '../../types';
import { trekService } from '../../services/trekService';
import toast from 'react-hot-toast';

interface ActiveJourneyBlockProps {
  journey: Journey;
  reservations: Reservation[];
  userRole: UserRole;
  currentUserId: string;
  guideProfile?: UserProfile;
  onAction?: (action: string, payload?: any) => void;
}

export const ActiveJourneyBlock: React.FC<ActiveJourneyBlockProps> = ({
  journey,
  reservations,
  userRole,
  currentUserId,
  guideProfile,
  onAction
}) => {
  const [isReporting, setIsReporting] = useState(false);
  const [incidentType, setIncidentType] = useState('Autre');
  const [incidentDetails, setIncidentDetails] = useState('');

  const isGuide = userRole === 'ROLE_GUIDE';
  
  // Find self reservation for client
  const myRes = !isGuide ? reservations.find(r => r.userId === currentUserId && r.journeyId === journey.id) : null;
  const contactPhone = isGuide ? reservations[0]?.phone : (guideProfile?.phone || reservations[0]?.phone); // Fallback to any phone found

  const handleCheckIn = async () => {
    if (!myRes) return;
    const loading = toast.loading('Confirmation de présence...');
    try {
      await trekService.clientCheckIn(myRes.id, currentUserId);
      toast.success('Présence confirmée !', { id: loading });
    } catch (e) {
      toast.error('Erreur lors du check-in', { id: loading });
    }
  };

  const handleMarkPresence = async (resId: string, status: 'present' | 'absent') => {
    const loading = toast.loading('Mise à jour...');
    try {
      await trekService.guideMarkPresence(resId, currentUserId, status);
      toast.success('Statut mis à jour', { id: loading });
    } catch (e) {
      toast.error('Erreur', { id: loading });
    }
  };

  const handleReportIncident = async () => {
    if (!incidentDetails) return;
    const loading = toast.loading('Signalement en cours...');
    try {
      await trekService.reportIncident({
        journeyId: journey.id,
        reservationId: myRes?.id,
        userId: currentUserId,
        userName: isGuide ? (guideProfile?.displayName || 'Guide') : (myRes?.fullname || 'Client'),
        type: incidentType,
        description: incidentDetails,
        urgency: 'high' // Default high urgency from active block
      });
      toast.success('Incident signalé à l\'administration.', { id: loading });
      setIsReporting(false);
    } catch (e) {
      toast.error('Erreur lors du signalement', { id: loading });
    }
  };

  const handleEndJourney = async () => {
     if (window.confirm('Voulez-vous vraiment terminer ce trajet ?')) {
       const loading = toast.loading('Clôture en cours...');
       try {
         await trekService.completeJourney(journey.id, currentUserId);
         toast.success('Trajet terminé !', { id: loading });
         onAction?.('journey_completed');
       } catch (e) {
         toast.error('Erreur', { id: loading });
       }
     }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-emerald-primary text-white rounded-3xl md:rounded-[4rem] p-6 md:p-14 shadow-2xl shadow-emerald-900/40 relative overflow-hidden"
    >
      {/* Background Decor */}
      <div className="absolute top-0 right-0 p-6 md:p-12 opacity-[0.03] pointer-events-none">
        <Navigation size={400} />
      </div>

      <div className="relative z-10 space-y-8 md:space-y-12">
        <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6 md:gap-10">
          <div className="space-y-4 md:space-y-6">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-accent w-2 h-2 md:w-3 md:h-3 rounded-full animate-ping" />
              <div className="bg-emerald-accent w-1.5 h-1.5 md:w-2 md:h-2 rounded-full absolute ml-0.25 md:ml-0.5" />
              <span className="text-[8px] md:text-[9px] font-black uppercase tracking-[0.4em] text-emerald-accent">Expédition en cours</span>
            </div>
            <h2 className="text-3xl md:text-6xl font-serif italic font-black tracking-tight leading-tight text-white">{journey.title}</h2>
            <div className="flex flex-wrap items-center gap-4 md:gap-10 text-white/40 font-bold text-[9px] md:text-[10px] uppercase tracking-[0.3em]">
              <div className="flex items-center gap-2">
                <MapPin size={14} className="text-emerald-accent" />
                <span className="truncate max-w-[150px] md:max-w-none">{journey.meetingPoint}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={14} className="text-emerald-accent" />
                {journey.time}
              </div>
              <div className="flex items-center gap-2">
                <Users size={14} className="text-emerald-accent" />
                {journey.activeParticipantsCount || 0}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 min-[400px]:grid-cols-4 lg:flex lg:flex-wrap gap-2 md:gap-4 w-full md:w-auto">
            <button 
              onClick={() => onAction?.('open_chat')}
              className="h-12 md:h-16 px-4 md:px-10 bg-white/5 hover:bg-white/10 backdrop-blur-md border border-white/5 rounded-2xl md:rounded-3xl flex items-center justify-center lg:justify-start gap-2 md:gap-4 transition-all"
            >
              <MessageCircle size={14} className="text-emerald-accent" />
              <span className="font-black text-[8px] md:text-[10px] uppercase tracking-widest">Chat</span>
            </button>
            <button 
               onClick={() => onAction?.('view_itinerary')}
               className="h-12 md:h-16 px-4 md:px-10 bg-white/5 hover:bg-white/10 backdrop-blur-md border border-white/5 rounded-2xl md:rounded-3xl flex items-center justify-center lg:justify-start gap-2 md:gap-4 transition-all"
            >
              <Compass size={14} className="text-emerald-accent" />
              <span className="font-black text-[8px] md:text-[10px] uppercase tracking-widest">Tracé</span>
            </button>
            <button 
               onClick={() => onAction?.('open_map')}
               className="h-12 md:h-16 px-4 md:px-10 bg-white/5 hover:bg-white/10 backdrop-blur-md border border-white/5 rounded-2xl md:rounded-3xl flex items-center justify-center lg:justify-start gap-2 md:gap-4 transition-all"
            >
              <Map size={14} className="text-emerald-accent" />
              <span className="font-black text-[8px] md:text-[10px] uppercase tracking-widest">Carte</span>
            </button>
            <button 
               onClick={() => setIsReporting(true)}
               className="h-12 md:h-16 px-4 md:px-8 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/10 rounded-2xl md:rounded-3xl flex items-center justify-center gap-2 transition-all"
            >
              <ShieldAlert size={14} />
            </button>
            {isGuide && (
              <button 
                onClick={() => onAction?.('open_console')}
                className="col-span-full md:col-auto h-12 md:h-16 px-6 md:px-10 bg-emerald-accent text-emerald-900 rounded-2xl md:rounded-3xl font-black text-[8px] md:text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg"
              >
                <Navigation size={14} />
                CONSOLE
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-start">
          {/* Status Section */}
          <div className="bg-white/5 rounded-[2rem] md:rounded-[3rem] p-6 md:p-12 space-y-6 md:space-y-10 border border-white/5">
            <h3 className="text-white/20 text-[8px] md:text-[9px] font-black uppercase tracking-[0.4em]">
              {isGuide ? 'Équipage & Voyageurs' : 'Progression'}
            </h3>

            {!isGuide ? (
              <div className="space-y-8 md:space-y-10">
                {myRes?.clientCheckInStatus === 'checked_in' ? (
                  <div className="bg-emerald-accent/10 border border-emerald-accent/20 rounded-2xl md:rounded-[2.5rem] p-6 md:p-10 flex flex-col gap-6 md:gap-8 text-emerald-accent shadow-inner">
                    <div className="flex items-center gap-4 md:gap-6">
                      <div className="bg-emerald-accent p-3 md:p-4 rounded-xl md:rounded-2xl text-emerald-primary">
                        <CheckCircle2 className="w-6 h-6 md:w-8 md:h-8" />
                      </div>
                      <div>
                        <p className="font-black text-xs md:text-sm uppercase tracking-[0.1em] md:tracking-[0.2em]">Présence Validée</p>
                        <p className="text-[10px] md:text-xs text-emerald-accent/50 italic mt-1 leading-tight">Bienvenue au Maliba.</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white/5 border border-white/10 rounded-2xl md:rounded-[2.5rem] p-6 md:p-10 flex flex-col gap-6 md:gap-10">
                    <div className="flex flex-col min-[400px]:flex-row items-center justify-between gap-6 md:gap-8">
                      <div className="space-y-1 text-center min-[400px]:text-left">
                        <p className="font-black text-xs md:text-sm uppercase tracking-widest text-emerald-accent">Activation</p>
                        <p className="text-[10px] md:text-xs text-white/40 italic">Signalez votre arrivée au point de départ.</p>
                      </div>
                      <button 
                        onClick={handleCheckIn}
                        className="w-full min-[400px]:w-auto bg-emerald-accent text-emerald-900 px-6 md:px-10 h-12 md:h-16 rounded-xl md:rounded-2xl font-black text-[10px] uppercase tracking-widest"
                      >
                        ARRIVÉ ?
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-6 md:space-y-8 pl-4 md:pl-6">
                  {[
                    { label: 'Héritage Débloqué', status: 'done' },
                    { label: 'Identité Validée', status: myRes?.clientCheckInStatus === 'checked_in' ? 'done' : 'active' },
                    { label: 'Immersion', status: 'active' },
                  ].map((step, i) => (
                    <div key={i} className="flex gap-6 md:gap-8">
                      <div className="flex flex-col items-center">
                        <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl md:rounded-2xl flex items-center justify-center border-2 ${
                            step.status === 'done' ? 'bg-emerald-accent border-emerald-accent text-emerald-900' : 
                            step.status === 'active' ? 'border-emerald-accent shadow-[0_0_20px_rgba(16,185,129,0.2)]' : 'border-white/10'
                        }`}>
                          {step.status === 'done' ? <CheckCircle2 size={14} /> : <div className="w-2 h-2 bg-emerald-accent rounded-full animate-pulse" />}
                        </div>
                        {i < 2 && <div className={`w-0.5 h-10 md:h-16 ${step.status === 'done' ? 'bg-emerald-accent' : 'bg-white/5'}`} />}
                      </div>
                      <div className="pt-1.5 md:pt-2">
                        <p className={`text-[9px] md:text-[11px] font-black uppercase tracking-widest ${
                            step.status === 'upcoming' ? 'text-white/20' : 'text-white'
                        }`}>{step.label}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4 max-h-[300px] md:max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                {reservations.map(res => (
                  <div key={res.id} className="bg-white/5 p-4 md:p-8 rounded-2xl md:rounded-[2.5rem] flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4 md:gap-6">
                      <div className="bg-stone-50 w-12 h-12 md:w-16 md:h-16 rounded-xl md:rounded-[1.5rem] flex items-center justify-center font-serif italic font-black text-emerald-primary text-xl overflow-hidden">
                        {res.userPhoto ? <img src={res.userPhoto} className="w-full h-full object-cover" /> : res.fullname[0]}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-black text-sm md:text-lg tracking-tight">{res.fullname}</p>
                          {res.clientCheckInStatus === 'checked_in' && (
                            <span className="px-1.5 py-0.5 bg-emerald-accent/20 text-emerald-accent text-[6px] md:text-[8px] font-bold rounded">ICI</span>
                          )}
                        </div>
                        <p className="text-[8px] md:text-[10px] text-white/30 font-bold uppercase tracking-widest">{res.passengers} Voyageurs</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 md:gap-3">
                       {!res.guidePresenceStatus ? (
                         <div className="grid grid-cols-2 gap-2 w-full md:w-auto">
                            <button 
                              onClick={() => handleMarkPresence(res.id, 'present')}
                              className="px-4 md:px-6 h-10 md:h-12 bg-emerald-accent text-emerald-900 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase tracking-widest"
                            >
                              Valider
                            </button>
                            <button 
                              onClick={() => handleMarkPresence(res.id, 'absent')}
                              className="px-4 md:px-6 h-10 md:h-12 bg-white/5 text-rose-400 border border-white/5 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase tracking-widest"
                            >
                              Absent
                            </button>
                         </div>
                       ) : (
                         <div className={`px-4 md:px-6 h-10 md:h-12 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 border w-full md:w-auto ${
                            res.guidePresenceStatus === 'absent' ? 'bg-rose-500/10 text-rose-400 border-rose-500/10' : 'bg-emerald-accent/10 text-emerald-accent border-emerald-accent/10'
                         }`}>
                           {res.guidePresenceStatus === 'absent' ? 'ABSENT' : 'CONFIRMÉ'}
                         </div>
                       )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right Info Section */}
          <div className="space-y-6 md:space-y-12">
            <div className="bg-white/5 rounded-[2rem] md:rounded-[3rem] p-6 md:p-12 space-y-8 md:space-y-10 border border-white/5">
               <h3 className="text-white/20 text-[8px] md:text-[9px] font-black uppercase tracking-[0.4em]">Résumé</h3>
               <div className="grid grid-cols-2 gap-4 md:gap-8">
                  <div className="bg-emerald-accent/5 p-6 md:p-10 rounded-2xl md:rounded-[2.5rem] space-y-2 border border-white/5">
                    <p className="text-white/30 text-[8px] md:text-[9px] font-bold uppercase tracking-widest">Équipage</p>
                    <p className="text-3xl md:text-5xl font-serif italic font-black text-emerald-accent">
                      {journey.checkedInCount || 0}<span className="text-xs md:text-sm opacity-30 font-sans not-italic">/{journey.activeParticipantsCount || 0}</span>
                    </p>
                  </div>
                  <div className="bg-white/5 p-6 md:p-10 rounded-2xl md:rounded-[2.5rem] space-y-2 border border-white/5">
                    <p className="text-white/30 text-[8px] md:text-[9px] font-bold uppercase tracking-widest">Alertes</p>
                    <p className={`text-3xl md:text-5xl font-serif italic font-black ${journey.incidentCount && journey.incidentCount > 0 ? 'text-amber-500' : 'text-white/20'}`}>
                      {journey.incidentCount || 0}
                    </p>
                  </div>
               </div>
            </div>

            <a 
              href={`tel:${contactPhone}`}
              className="w-full h-16 md:h-24 bg-white/5 hover:bg-white/10 p-4 md:p-6 rounded-[1.5rem] md:rounded-[3rem] flex items-center justify-center gap-4 md:gap-8 transition-all border border-white/5 group"
            >
              <div className="w-10 h-10 md:w-12 md:h-12 bg-emerald-accent rounded-xl md:rounded-2xl flex items-center justify-center shadow-lg">
                <Phone size={18} className="text-emerald-primary" />
              </div>
              <div className="text-left">
                <span className="font-black text-[9px] md:text-[11px] uppercase tracking-[0.2em] md:tracking-[0.4em] text-white/50 block">Urgence</span>
                <span className="text-[8px] text-white/20 font-bold uppercase tracking-widest mt-0.5 block">Ligne Directe</span>
              </div>
            </a>
          </div>
        </div>
      </div>

      {/* Incident Modal */}
      <AnimatePresence>
        {isReporting && (
          <div className="fixed inset-0 bg-slate-900/90 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white text-slate-900 rounded-[3rem] p-10 w-full max-w-lg space-y-8"
              onClick={e => e.stopPropagation()}
            >
              <div className="space-y-2">
                <h3 className="text-3xl font-black tracking-tight">Signaler un Incident</h3>
                <p className="text-slate-500 font-medium italic">Une équipe d'admin sera notifiée immédiatement.</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Type d'incident</label>
                  <select 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none ring-slate-900 focus:ring-2 appearance-none"
                    value={incidentType}
                    onChange={e => setIncidentType(e.target.value)}
                  >
                    <option>Sécurité</option>
                    <option>Retard important</option>
                    <option>Blessure / Santé</option>
                    <option>Problème technique (Véhicule, etc.)</option>
                    <option>Comportement inapproprié</option>
                    <option>Autre</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Détails</label>
                  <textarea 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none ring-slate-900 focus:ring-2 min-h-[120px]"
                    placeholder="Décrivez brièvement la situation..."
                    value={incidentDetails}
                    onChange={e => setIncidentDetails(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  onClick={handleReportIncident}
                  disabled={!incidentDetails}
                  className="flex-1 bg-slate-900 text-white p-5 rounded-2xl font-black uppercase tracking-widest text-[10px] disabled:opacity-50 transition-all active:scale-95"
                >
                  Envoyer le signalement
                </button>
                <button 
                  onClick={() => setIsReporting(false)}
                  className="px-8 bg-slate-100 text-slate-400 p-5 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all"
                >
                  Annuler
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

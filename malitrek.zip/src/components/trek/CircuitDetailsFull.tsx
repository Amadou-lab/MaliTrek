import React from 'react';
import { motion } from 'motion/react';
import { 
  MapPin, 
  Clock, 
  Users, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Calendar, 
  Tag, 
  Info,
  ChevronRight,
  Star,
  Map as MapIcon,
  ShieldCheck,
  Ban,
  ArrowRight,
  Compass
} from 'lucide-react';
import { Circuit, Journey, UserRole, ItineraryStep } from '../../types';
import { ItineraryOverview } from './ItineraryOverview';

interface CircuitDetailsFullProps {
  circuit: Circuit;
  role: UserRole;
  onClose: () => void;
  availableJourneys?: Journey[];
  isAdmin?: boolean;
  onApprove?: () => void;
  onReject?: (reason: string) => void;
  onBook?: (journeyId: string) => void;
  onEdit?: () => void;
  onToggleStatus?: () => void;
}

export const CircuitDetailsFull: React.FC<CircuitDetailsFullProps> = ({
  circuit,
  role,
  onClose,
  availableJourneys = [],
  isAdmin = false,
  onApprove,
  onReject,
  onBook,
  onEdit,
  onToggleStatus
}) => {
  const [rejectReason, setRejectReason] = React.useState('');
  const [showRejectForm, setShowRejectForm] = React.useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-emerald-accent/20 text-emerald-accent';
      case 'pending_admin_validation': return 'bg-amber-100 text-amber-700';
      case 'rejected': return 'bg-rose-100 text-rose-700';
      case 'draft': return 'bg-stone-100 text-stone-700';
      default: return 'bg-stone-100 text-stone-700';
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 md:space-y-12 pb-32 pt-0 md:pt-10">
      {/* Hero Section */}
      <div className="relative h-[350px] md:h-[500px] md:rounded-[3.5rem] overflow-hidden premium-card group">
        <img 
          src={circuit.image || 'https://images.unsplash.com/photo-1489440543227-a6d3d9369952?auto=format&fit=crop&q=80'} 
          alt={circuit.title}
          className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary via-emerald-primary/20 to-transparent" />
        
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 md:top-8 md:right-8 z-20 glass-card !rounded-xl md:rounded-2xl p-2.5 md:p-3 text-white hover:bg-white/20 transition-all active:scale-90"
        >
          <XCircle className="w-5 h-5 md:w-6 md:h-6" />
        </button>

        <div className="absolute bottom-10 md:bottom-16 left-6 md:left-12 right-6 md:right-12 stagger-in">
          <div className="flex flex-wrap items-center gap-2 md:gap-3 mb-4 md:mb-6">
            <span className={`px-2.5 py-1 text-[8px] md:text-[10px] font-bold uppercase tracking-widest rounded-lg ${getStatusColor(circuit.status)}`}>
              {circuit.status.replace('_', ' ')}
            </span>
            <span className="px-2.5 py-1 bg-white/20 text-white backdrop-blur-md rounded-lg text-[8px] md:text-[10px] font-bold uppercase tracking-widest">
              {circuit.category}
            </span>
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-accent text-emerald-900 rounded-lg text-[8px] md:text-[10px] font-bold uppercase tracking-widest">
              <Star className="w-3 h-3 fill-current" />
              {circuit.averageRating || 'Premium'}
            </div>
          </div>
          <h1 className="text-3xl md:text-8xl font-serif font-black text-white tracking-tighter mb-4 md:mb-6 capitalize leading-none">
            {circuit.title}
          </h1>
          <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-8 text-white/90">
            <div className="flex items-center gap-2 md:gap-3">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-emerald-accent/20 backdrop-blur-md flex items-center justify-center border border-white/10">
                <MapPin className="w-4 h-4 md:w-5 md:h-5 text-emerald-accent" />
              </div>
              <span className="font-bold text-sm md:text-lg">{circuit.location}</span>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-emerald-accent/20 backdrop-blur-md flex items-center justify-center border border-white/10">
                <Clock className="w-4 h-4 md:w-5 md:h-5 text-emerald-accent" />
              </div>
              <span className="font-bold text-sm md:text-lg">{circuit.duration}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12 px-4 md:px-2">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-10 md:space-y-16">
          {/* Description */}
          <section className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] border border-stone-200 shadow-sm">
            <h2 className="text-xl md:text-2xl font-serif font-bold text-stone-premium mb-4 md:mb-6 flex items-center gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-accent" />
              Une immersion exclusive
            </h2>
            <p className="text-stone-premium/70 text-base md:text-lg leading-relaxed whitespace-pre-wrap font-medium">
              {circuit.description || "Aucune description détaillée n'a été fournie pour ce circuit."}
            </p>
          </section>

          {/* Itinerary */}
          <section>
            <div className="flex items-center justify-between mb-6 md:mb-10">
              <h2 className="text-2xl md:text-3xl font-serif font-black text-stone-premium tracking-tight flex items-center gap-3 md:gap-4">
                <MapIcon className="w-6 h-6 md:w-8 md:h-8 text-emerald-accent" />
                L'âme du parcours
              </h2>
              <span className="px-3 py-1 bg-stone-100 text-stone-400 rounded-lg text-[9px] md:text-xs font-bold uppercase">
                {circuit.itinerary?.length || 0} Étapes
              </span>
            </div>
            {circuit.itinerary && circuit.itinerary.length > 0 ? (
               <ItineraryOverview itinerary={circuit.itinerary} />
            ) : (
              <div className="bg-stone-50 border border-dashed border-stone-200 p-10 md:p-16 rounded-3xl md:rounded-[3rem] text-center">
                 <MapIcon className="w-10 h-10 text-stone-200 mx-auto mb-4" />
                 <h3 className="text-lg font-serif font-bold text-stone-400">Itinéraire bientôt disponible</h3>
              </div>
            )}
          </section>

          {/* Inclusions & Conditions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
             <section className="bg-emerald-accent/5 p-6 md:p-10 rounded-3xl md:rounded-[3rem] border border-emerald-accent/10">
                <h3 className="text-lg md:text-xl font-serif font-bold text-emerald-primary mb-6 md:mb-8 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-accent" />
                  Privilèges inclus
                </h3>
                <ul className="space-y-4 md:space-y-6">
                  {circuit.inclus?.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 md:gap-4 text-stone-premium/80 text-sm md:text-base font-medium">
                      <div className="w-1.5 h-1.5 bg-emerald-accent rounded-full mt-2 flex-shrink-0" />
                      {item}
                    </li>
                  )) || <li className="text-stone-300 italic">Non spécifié</li>}
                </ul>
             </section>

             <section className="bg-stone-50 p-6 md:p-10 rounded-3xl md:rounded-[3rem] border border-stone-100">
                <h3 className="text-lg md:text-xl font-serif font-bold text-stone-premium mb-6 md:mb-8 flex items-center gap-3">
                  <XCircle className="w-5 h-5 text-stone-300" />
                  À prévoir
                </h3>
                <ul className="space-y-4 md:space-y-6">
                  {circuit.nonInclus?.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 md:gap-4 text-stone-premium/60 text-sm md:text-base font-medium">
                      <div className="w-1.5 h-1.5 bg-stone-200 rounded-full mt-2 flex-shrink-0" />
                      {item}
                    </li>
                  )) || <li className="text-stone-300 italic">Non spécifié</li>}
                </ul>
             </section>
          </div>

          <section className="bg-white p-6 md:p-10 rounded-3xl md:rounded-[3rem] border border-stone-200 shadow-sm">
            <h3 className="text-lg font-serif font-bold text-stone-premium mb-4 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Politique de flexibilité
            </h3>
            <p className="text-stone-premium/60 text-sm md:text-base leading-relaxed font-medium">
              {circuit.cancellationPolicy || "Politique Prestige : Annulation gratuite jusqu'à 72h avant le départ pour une tranquillité totale."}
            </p>
          </section>
        </div>

        {/* Sidebar */}
        <div className="space-y-6 md:space-y-8">
          {/* Price Card */}
          <div className="bg-emerald-primary p-8 md:p-10 rounded-3xl md:rounded-[3.5rem] text-white overflow-hidden relative shadow-2xl shadow-emerald-900/20">
            <Compass className="absolute -right-4 -top-4 w-24 h-24 md:w-32 md:h-32 text-white/5 -rotate-12" />
            
            <div className="relative z-10">
              <span className="px-3 py-1 bg-white/10 text-emerald-accent text-[9px] md:text-xs font-bold uppercase rounded-lg mb-4 inline-block tracking-widest">Investissement Voyage</span>
              <div className="flex items-baseline gap-2 md:gap-3 mb-8 md:mb-10">
                <span className="text-4xl md:text-5xl font-black">
                  {(circuit.basePrice || 0).toLocaleString()}
                </span>
                <span className="text-xs font-bold text-white/50">CFA <span className="text-[10px] ml-1 opacity-50">/ invité</span></span>
              </div>

              {role === 'ROLE_CLIENT' && (
                <div className="space-y-4 md:space-y-6">
                  <h4 className="text-[9px] md:text-[10px] font-bold uppercase tracking-widest text-white/30 border-b border-white/5 pb-3 md:pb-4">
                     Planifier votre départ
                  </h4>
                  {availableJourneys.length > 0 ? (
                    <div className="space-y-2 md:space-y-3">
                      {availableJourneys.map(j => (
                        <button
                          key={j.id}
                          onClick={() => onBook?.(j.id)}
                          className="w-full flex items-center justify-between p-4 md:p-5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl md:rounded-2xl transition-all group active:scale-[0.98]"
                        >
                          <div className="text-left">
                            <div className="text-xs md:text-sm font-bold">{new Date(j.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}</div>
                            <div className="text-[8px] md:text-[10px] text-emerald-accent font-bold uppercase tracking-wider">{j.availableSeats} places exclusives</div>
                          </div>
                          <ArrowRight size={16} className="text-emerald-accent group-hover:translate-x-1 transition-all" />
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="p-5 bg-white/5 rounded-xl border border-dashed border-white/10 text-center">
                       <p className="text-[10px] md:text-xs text-white/30 font-medium italic">Aucun créneau immédiat.<br />Inscrivez-vous en liste d'attente.</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Admin Controls */}
            {isAdmin && (
              <div className="space-y-4 pt-8 border-t border-white/10 mt-10 relative z-10">
                {!showRejectForm ? (
                  <div className="space-y-3">
                    {circuit.status === 'pending_admin_validation' && (
                      <button 
                        onClick={onApprove}
                        className="btn-premium w-full !bg-emerald-accent !text-emerald-900 !h-14 font-black uppercase text-xs tracking-widest hover:!bg-emerald-400"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        Publier le circuit
                      </button>
                    )}
                    {circuit.status === 'pending_admin_validation' && (
                      <button 
                        onClick={() => setShowRejectForm(true)}
                        className="w-full h-14 bg-rose-500/10 text-rose-300 border border-rose-500/20 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-rose-500/20 transition-all flex items-center justify-center gap-2"
                      >
                        <AlertTriangle className="w-4 h-4" />
                        Demander révision
                      </button>
                    )}
                    {circuit.status === 'approved' && (
                       <button 
                        onClick={onToggleStatus}
                        className="w-full h-14 bg-white/5 text-white/40 rounded-2xl font-bold uppercase text-[10px] tracking-widest hover:bg-white/10 transition-all"
                      >
                        Retirer de la vente
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                    <textarea 
                      placeholder="Expliquez les points à améliorer..."
                      className="w-full p-5 bg-white/5 rounded-2xl text-xs font-bold text-white placeholder:text-white/20 border-white/10 focus:ring-1 ring-emerald-accent outline-none"
                      rows={4}
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <button 
                        onClick={() => setShowRejectForm(false)}
                        className="h-12 bg-white/5 text-white/60 rounded-xl text-[10px] font-bold uppercase"
                      >
                        Annuler
                      </button>
                      <button 
                        onClick={() => onReject?.(rejectReason)}
                        className="h-12 bg-rose-500 text-white rounded-xl text-[10px] font-black uppercase shadow-lg shadow-rose-500/20"
                        disabled={!rejectReason}
                      >
                        Confirmer
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Guide Controls */}
            {role === 'ROLE_GUIDE' && circuit.guideId === (circuit as any).guideId && (
              <div className="mt-10 pt-8 border-t border-white/10">
                <button 
                  onClick={onEdit}
                  className="w-full h-14 bg-white text-emerald-900 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-emerald-accent transition-all"
                >
                  Ouvrir l'éditeur
                </button>
              </div>
            )}
          </div>

          {/* Social Proof / Trust Indicators */}
          <div className="bg-white p-10 rounded-[3.5rem] border border-stone-200 space-y-8 shadow-sm">
            <div>
               <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-stone-300 mb-6 flex items-center gap-3">
                 <Users className="w-3 h-3 text-emerald-accent" />
                 Confiance & Groupe
               </h4>
               <div className="space-y-4">
                 <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-stone- premium/60">Taille de l'expédition</span>
                    <span className="text-lg font-serif font-bold text-emerald-primary">
                      {circuit.minParticipants}—{circuit.maxParticipants || '12'} <span className="text-[10px] uppercase font-bold text-stone-300 ml-1">Personnes</span>
                    </span>
                 </div>
                 <div className="h-1.5 bg-stone-100 rounded-full overflow-hidden">
                    <motion.div 
                       initial={{ width: 0 }}
                       whileInView={{ width: '40%' }}
                       className="h-full bg-emerald-accent rounded-full" 
                    />
                 </div>
               </div>
            </div>

            <div className="pt-8 border-t border-stone-100">
               <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-stone-300 mb-6 font-display">
                 Expertise Terrain
               </h4>
               <div className="flex items-center gap-4 p-4 bg-stone-50 rounded-[2rem] border border-stone-100">
                 <div className="w-14 h-14 bg-emerald-primary rounded-2xl flex items-center justify-center text-emerald-accent font-serif italic font-black text-2xl shadow-md rotate-3">
                   {circuit.guideId.substring(0, 1).toUpperCase()}
                 </div>
                 <div>
                   <div className="text-xs font-bold text-stone-premium">Explorateur Certifié</div>
                   <div className="text-[10px] font-bold text-emerald-accent uppercase tracking-widest mt-1">Griot Moderne</div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

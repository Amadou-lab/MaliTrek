import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Clock, CheckCircle2, ChevronRight, Activity, Map as MapIcon } from 'lucide-react';
import { ItineraryStep } from '../../types';

interface ItineraryOverviewProps {
  itinerary: ItineraryStep[];
  currentStepIndex?: number;
  isGuide?: boolean;
  onMarkComplete?: (index: number) => void;
}

export const ItineraryOverview: React.FC<ItineraryOverviewProps> = ({
  itinerary,
  currentStepIndex = -1,
  isGuide = false,
  onMarkComplete
}) => {
  if (!itinerary || itinerary.length === 0) return null;

  return (
    <div className="space-y-12 py-8">
      {itinerary.map((step, index) => {
        const isCompleted = index <= currentStepIndex;
        const isActive = index === currentStepIndex + 1;
        const isPast = index <= currentStepIndex;

        return (
          <div key={step.id || index} className="relative flex gap-8">
            {/* Timeline connectors */}
            {index !== itinerary.length - 1 && (
              <div className={`absolute left-6 top-12 bottom-0 w-1 ${isPast ? 'bg-emerald-500' : 'bg-stone-100'} transition-colors`} />
            )}

            {/* Day Indicator */}
            <div className="relative flex-shrink-0">
               <motion.div 
                initial={false}
                animate={{ 
                  backgroundColor: isPast ? '#10b981' : (isActive ? '#000000' : '#f5f5f4'),
                  scale: isActive ? 1.1 : 1
                }}
                className="w-12 h-12 rounded-2xl flex items-center justify-center z-10 relative overflow-hidden"
               >
                  {isPast ? (
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  ) : (
                    <span className={`text-sm font-black ${isActive ? 'text-white' : 'text-stone-400'}`}>
                      {step.day || index + 1}
                    </span>
                  )}
               </motion.div>
            </div>

            {/* Content Card */}
            <div className="flex-grow">
              <motion.div 
                initial={{ opacity: 0, x: 10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className={`p-8 rounded-[2rem] border-2 transition-all ${
                  isActive 
                    ? 'bg-white border-emerald-500 shadow-xl ring-4 ring-emerald-50' 
                    : 'bg-stone-50 border-stone-100'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-lg ${
                        isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-200 text-stone-500'
                      }`}>
                        JOUR {step.day || index + 1}
                      </span>
                      {step.estimatedTime && (
                         <div className="flex items-center gap-1 text-stone-400 font-bold text-[10px] uppercase">
                            <Clock className="w-3 h-3" />
                            {step.estimatedTime}
                         </div>
                      )}
                    </div>
                    <h3 className={`text-2xl font-black tracking-tight ${isActive ? 'text-stone-900' : 'text-stone-400'}`}>
                      {step.title}
                    </h3>
                  </div>
                  
                  {step.locationName && (
                    <div className="flex items-center gap-2 px-4 py-2 bg-white border border-stone-100 rounded-xl shadow-sm">
                      <MapPin className="w-4 h-4 text-emerald-500" />
                      <span className="text-xs font-bold text-stone-600">{step.locationName}</span>
                    </div>
                  )}
                </div>

                <p className={`text-sm leading-relaxed mb-6 ${isActive ? 'text-stone-600' : 'text-stone-400'}`}>
                  {step.description}
                </p>

                {/* Activities Overlay */}
                {step.activities && step.activities.length > 0 && (
                  <div className="space-y-3 mb-6">
                    <span className="text-[10px] font-black uppercase tracking-widest text-stone-400 flex items-center gap-2">
                       <Activity className="w-3 h-3" />
                       Activités au programme
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {step.activities.map((act, i) => (
                        <span key={i} className="px-3 py-1.5 bg-stone-100 rounded-lg text-[10px] font-bold text-stone-600 border border-stone-200">
                          {act}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Progress Controls (Guide only) */}
                {isGuide && isActive && onMarkComplete && (
                  <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
                     <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-lg">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                        <span className="text-[10px] font-black uppercase tracking-widest">Étape en cours</span>
                     </div>
                     <button
                      onClick={() => onMarkComplete(index)}
                      className="flex items-center gap-2 px-6 py-3 bg-stone-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-stone-800 transition-all active:scale-95"
                    >
                      Terminer cette étape
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {isPast && !isActive && (
                  <div className="flex items-center gap-2 text-emerald-500 font-bold text-[10px] uppercase tracking-widest">
                    <CheckCircle2 className="w-4 h-4" />
                    Complété
                  </div>
                )}
              </motion.div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      let errorMessage = "Une erreur inattendue est survenue.";
      let isFirebaseError = false;

      try {
        const parsedError = JSON.parse(this.state.error?.message || '{}');
        if (parsedError.error) {
          errorMessage = parsedError.error;
          isFirebaseError = true;
        }
      } catch (e) {
        errorMessage = this.state.error?.message || errorMessage;
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-stone-50 p-4">
          <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 text-center space-y-6 border border-stone-100">
            <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto text-red-500">
              <AlertTriangle size={40} />
            </div>
            
            <div className="space-y-2">
              <h1 className="text-2xl font-bold text-stone-900">Oups ! Quelque chose a mal tourné</h1>
              <p className="text-stone-500 text-sm">
                {isFirebaseError 
                  ? "Erreur de connexion à la base de données. Veuillez vérifier votre configuration Firebase."
                  : errorMessage}
              </p>
            </div>

            {isFirebaseError && (
              <div className="bg-stone-50 p-4 rounded-2xl text-left">
                <p className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">Détails techniques</p>
                <code className="text-xs text-red-600 break-all block bg-white p-2 rounded border border-red-100">
                  {errorMessage}
                </code>
              </div>
            )}

            <button
              onClick={this.handleReset}
              className="w-full flex items-center justify-center gap-2 bg-stone-900 text-white py-4 rounded-2xl font-bold hover:bg-stone-800 transition-all"
            >
              <RefreshCcw size={18} /> Recharger l'application
            </button>
            
            <p className="text-xs text-stone-400">
              Si le problème persiste, assurez-vous que Firestore est activé dans votre console Firebase.
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

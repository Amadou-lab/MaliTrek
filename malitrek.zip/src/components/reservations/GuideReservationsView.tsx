import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, User, MapPin, ChevronRight, CheckCircle2, AlertCircle, Phone, ArrowUpRight } from 'lucide-react';
import { Reservation, Journey } from '../../types';
import { Card, Badge } from '../shared/UI';
import { ReservationStatusBadge } from './ReservationStatusBadge';

interface GuideReservationsViewProps {
  reservations: (Reservation & { journey?: Journey })[];
  onSelectDetail: (reservation: Reservation) => void;
}

export const GuideReservationsView: React.FC<GuideReservationsViewProps> = ({
  reservations,
  onSelectDetail
}) => {
  const [activeTab, setActiveTab] = React.useState<string>('new');
  const tabs = [
    { id: 'all', label: 'Toutes' },
    { id: 'confirmed', label: 'Confirmées' },
    { id: 'in_progress', label: 'En cours' },
    { id: 'awaiting_client_validation', label: 'À valider' },
    { id: 'completed', label: 'Terminées' },
    { id: 'disputed', label: 'Litiges' },
    { id: 'cancelled', label: 'Annulées' }
  ];

  const filtered = reservations.filter(r => {
    if (activeTab === 'all') return true;
    return r.status === activeTab;
  });

  React.useEffect(() => {
    setActiveTab('all');
  }, []);

  return (
    <div className="space-y-10">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-stone-900 dark:text-white tracking-tight leading-none mb-3">Réservations Clients</h1>
          <p className="text-stone-500 font-medium">Gérez vos voyageurs et le déblocage de vos paiements.</p>
        </div>

        <div className="flex bg-stone-100 dark:bg-stone-900 p-1.5 rounded-2xl overflow-x-auto no-scrollbar">
          {tabs.map(tab => {
            const count = reservations.filter(r => {
              if (tab.id === 'all') return true;
              return r.status === tab.id;
            }).length;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all flex items-center gap-2 ${
                  activeTab === tab.id 
                    ? 'bg-white dark:bg-stone-800 text-emerald-600 shadow-xl shadow-stone-200/50 dark:shadow-none' 
                    : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                {tab.label}
                {count > 0 && (
                  <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] ${
                    activeTab === tab.id ? 'bg-emerald-600 text-white' : 'bg-stone-200 dark:bg-stone-700 text-stone-500'
                  }`}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="bg-white dark:bg-stone-900 rounded-[3rem] border border-stone-100 dark:border-stone-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-stone-50/50 dark:bg-stone-900/50">
                <th className="px-8 py-6 text-[10px] font-black text-stone-400 uppercase tracking-widest">Client / Contact</th>
                <th className="px-8 py-6 text-[10px] font-black text-stone-400 uppercase tracking-widest">Circuit / Journey</th>
                <th className="px-8 py-6 text-[10px] font-black text-stone-400 uppercase tracking-widest">Progression / Escrow</th>
                <th className="px-8 py-6 text-[10px] font-black text-stone-400 uppercase tracking-widest">Gains</th>
                <th className="px-8 py-6 text-[10px] font-black text-stone-400 uppercase tracking-widest">Statut</th>
                <th className="px-8 py-6 text-[10px] font-black text-stone-400 uppercase tracking-widest">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-50 dark:divide-stone-800/50">
              <AnimatePresence mode="popLayout">
                {filtered.map((res) => {
                  const validatedSteps = (res.itineraryProgress || []).filter(s => s.status === 'validé' || s.status === 'payé').length;
                  const totalSteps = (res.itineraryProgress || []).length;
                  const progressPct = totalSteps > 0 ? (validatedSteps / totalSteps) * 100 : 0;
                  
                  return (
                    <motion.tr 
                      key={res.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="hover:bg-stone-50/50 dark:hover:bg-stone-800/30 transition-all cursor-pointer group"
                      onClick={() => onSelectDetail(res)}
                    >
                      <td className="px-8 py-7">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-stone-100 dark:bg-stone-800 rounded-2xl flex items-center justify-center text-stone-500 font-black text-lg">
                            {(res.clientName || res.fullname || 'C')[0]}
                          </div>
                          <div>
                            <p className="text-sm font-black text-stone-900 dark:text-stone-100 uppercase tracking-tight">{res.clientName || res.fullname}</p>
                            <div className="flex items-center gap-2 text-stone-400 mt-1">
                              <Phone size={10} />
                              <span className="text-[10px] font-bold">{res.clientPhone || res.phone}</span>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-7">
                        <div>
                          <p className="text-sm font-black text-stone-800 dark:text-stone-300 truncate max-w-[200px]">{res.journey?.title || 'Voyage'}</p>
                          <div className="flex items-center gap-2 text-stone-400 mt-1">
                            <Calendar size={10} />
                            <span className="text-[10px] font-bold">{res.journey?.date ? new Date(res.journey.date).toLocaleDateString('fr-FR') : '-'}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-7">
                        <div className="w-32">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-[9px] font-black uppercase tracking-widest text-stone-400">{validatedSteps}/{totalSteps} Etapes</span>
                            <span className="text-[9px] font-black text-emerald-600">{Math.round(progressPct)}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-stone-100 dark:bg-stone-800 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${progressPct}%` }}
                              className="h-full bg-emerald-500 rounded-full"
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-7">
                        <div>
                          <p className="text-sm font-black text-stone-900 dark:text-stone-100">{(res.guideShare || 0).toLocaleString()} <span className="text-[10px]">CFA</span></p>
                          <p className={`text-[9px] font-black uppercase tracking-widest ${res.paymentStatus === 'released' ? 'text-emerald-500' : 'text-amber-500'} mt-1`}>
                            {res.paymentStatus === 'released' ? 'Entièrement reçu' : 'En attente'}
                          </p>
                        </div>
                      </td>
                      <td className="px-8 py-7">
                        <ReservationStatusBadge status={res.status} />
                      </td>
                      <td className="px-8 py-7">
                        <button className="w-10 h-10 rounded-xl bg-stone-50 dark:bg-stone-800 flex items-center justify-center text-stone-400 group-hover:bg-emerald-600 group-hover:text-white transition-all active:scale-90">
                          <ArrowUpRight size={20} />
                        </button>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-24 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 bg-stone-50 dark:bg-stone-800 rounded-3xl flex items-center justify-center text-stone-200">
                        <AlertCircle size={32} />
                      </div>
                      <p className="text-stone-400 font-black uppercase tracking-widest text-xs">Aucune réservation à traiter ici.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

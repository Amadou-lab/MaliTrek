import React from 'react';
import { motion } from 'motion/react';
import { 
  X, MapPin, Calendar, Users, ShieldCheck, Clock, CheckCircle2, 
  HelpCircle, MessageCircle, Phone, ArrowLeft, QrCode, Ticket, ExternalLink,
  ChevronRight, AlertTriangle, Star, ShieldAlert, ArrowRight
} from 'lucide-react';
import { Reservation, Journey, Circuit, UserProfile, UserRole } from '../../types';
import { Card, Badge } from '../shared/UI';
import { ReservationStatusBadge } from './ReservationStatusBadge';
import { ReservationTimeline } from './ReservationTimeline';
import { ActiveJourneyBlock } from '../trek/ActiveJourneyBlock';
import { AdvancedMap } from '../shared/AdvancedMap';

interface ReservationDetailsProps {
  reservation: Reservation & { journey?: Journey, circuit?: Circuit };
  userRole: 'ROLE_CLIENT' | 'ROLE_GUIDE';
  onClose: () => void;
  onAction?: (action: string, payload?: any) => Promise<void>;
  guideProfile?: UserProfile;
  clientProfile?: UserProfile;
}

export const ReservationDetails: React.FC<ReservationDetailsProps> = ({
  reservation,
  userRole,
  onClose,
  onAction,
  guideProfile,
  clientProfile
}) => {
  const isClient = userRole === 'ROLE_CLIENT';
  const journey = reservation.journey;
  const circuit = reservation.circuit;

  const validatedSteps = (reservation.itineraryProgress || []).filter(s => s.status === 'validé' || s.status === 'payé').length;
  const totalSteps = (reservation.itineraryProgress || []).length;
  const progressPct = totalSteps > 0 ? (validatedSteps / totalSteps) * 100 : 0;

  const isAwaitingValidation = reservation.status === 'awaiting_client_validation';
  
  const deadlineDate = React.useMemo(() => {
    if (!reservation.validationDeadline) return null;
    return reservation.validationDeadline.toDate ? reservation.validationDeadline.toDate() : new Date(reservation.validationDeadline);
  }, [reservation.validationDeadline]);

  const [timeLeft, setTimeLeft] = React.useState<string>('');
  const deadlineTime = deadlineDate?.getTime();

  React.useEffect(() => {
    if (!deadlineTime || !isAwaitingValidation) return;
    
    const interval = setInterval(() => {
      const now = new Date();
      const diff = deadlineTime - now.getTime();
      if (diff <= 0) {
        setTimeLeft('Validation imminente...');
        clearInterval(interval);
      } else {
        const h = Math.floor(diff / (1000 * 60 * 60));
        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setTimeLeft(`${h}h ${m}m`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [deadlineTime, isAwaitingValidation]);

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex items-center justify-between gap-4 p-4 md:p-12 border-b border-stone-50">
        <div className="flex items-center gap-3 md:gap-6">
          <button 
            onClick={onClose}
            className="w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-stone-100 flex items-center justify-center text-stone-500 hover:text-emerald-primary transition-all active:scale-95"
          >
            <ArrowLeft size={20} className="md:w-6 md:h-6" />
          </button>
          <div className="stagger-in">
             <p className="text-[8px] md:text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-0.5 md:mb-1">Dossier Voyage</p>
             <h2 className="text-xl md:text-3xl font-serif font-black text-emerald-primary tracking-tighter italic">Détails Signature</h2>
          </div>
        </div>
        <div className="md:block scale-75 md:scale-100 origin-right">
           <ReservationStatusBadge status={reservation.status} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 md:px-12 py-6 md:py-10 space-y-8 md:space-y-12 custom-scrollbar">
        {reservation.status === 'in_progress' && journey && (
          <ActiveJourneyBlock 
            journey={journey}
            reservations={[reservation]}
            userRole={userRole as UserRole}
            currentUserId={isClient ? reservation.userId : reservation.guideId}
            guideProfile={guideProfile}
            onAction={onAction}
          />
        )}

        {/* Live Journey Map */}
        {(['confirmed', 'in_progress', 'awaiting_client_validation', 'completed'].includes(reservation.status)) && journey && (
          <div className="space-y-4 md:space-y-6 stagger-in">
            <div className="flex items-center justify-between px-2">
               <h3 className="text-[10px] md:text-sm font-black text-emerald-primary uppercase tracking-[0.2em] md:tracking-[0.3em]">Tracé de l'Expédition</h3>
               {reservation.status === 'in_progress' && (
                 <div className="flex items-center gap-2 text-emerald-accent bg-emerald-accent/5 px-3 md:px-4 py-1 md:py-1.5 rounded-full border border-emerald-accent/10">
                    <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-emerald-accent rounded-full animate-ping" />
                    <span className="text-[8px] md:text-[9px] font-black uppercase tracking-widest whitespace-nowrap">Temps Réel</span>
                 </div>
               )}
            </div>
            <div className="h-[300px] md:h-[450px] w-full rounded-[2.5rem] md:rounded-[3.5rem] overflow-hidden border border-emerald-accent/10 shadow-2xl relative group">
              <AdvancedMap 
                itinerary={journey.itinerarySnapshot || circuit?.itinerary || []}
                userLocation={journey.currentPosition ? [journey.currentPosition.lat, journey.currentPosition.lng] : undefined}
                showPolyline={true}
              />
              {reservation.status === 'in_progress' && (
                  <div className="absolute top-4 left-4 md:top-8 md:left-8 z-40 glass-card p-4 md:p-6 border border-white/20 shadow-sahara max-w-[180px] md:max-w-[240px]">
                      <p className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-emerald-accent mb-1 md:mb-2">Étape Actuelle</p>
                      <p className="text-xs md:text-sm font-serif italic font-black text-emerald-primary leading-tight">{journey.itinerarySnapshot?.[journey.currentStepIndex || 0]?.title || 'Au cœur du trajet'}</p>
                  </div>
              )}
            </div>
          </div>
        )}

        {/* Main Status Card */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2 premium-card overflow-hidden !p-0"
          >
            <div className="flex flex-col md:flex-row h-full">
              <div className="w-full md:w-64 h-48 md:h-auto overflow-hidden shrink-0">
                <img 
                  src={journey?.image || circuit?.image || 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?w=800&q=80'} 
                  alt={journey?.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]"
                />
              </div>
              <div className="flex-1 p-6 md:p-10 flex flex-col justify-between">
                <div className="space-y-4 md:space-y-6">
                  <div className="flex items-center gap-3 md:gap-4">
                    <Badge variant="stone">{reservation.paymentStatus}</Badge>
                    <span className="text-[8px] md:text-[10px] font-bold text-stone-premium/30 uppercase tracking-widest italic">RÉF: {reservation.id.slice(0, 8)}</span>
                  </div>
                  <h3 className="text-2xl md:text-4xl font-serif font-black text-emerald-primary leading-tight">
                    {journey?.title || 'Expérience Signature'}
                  </h3>
                  <div className="flex flex-wrap items-center gap-4 md:gap-8 text-stone-premium/50">
                    <div className="flex items-center gap-2 md:gap-3">
                      <MapPin className="w-3.5 h-3.5 md:w-4 md:h-4 text-emerald-accent" />
                      <span className="text-[10px] md:text-xs font-black uppercase tracking-widest">{journey?.location || 'Terres du Mali'}</span>
                    </div>
                    <div className="flex items-center gap-2 md:gap-3">
                      <Calendar className="w-3.5 h-3.5 md:w-4 md:h-4 text-emerald-accent" />
                      <span className="text-[10px] md:text-xs font-black uppercase tracking-widest">
                        {journey?.date ? new Date(journey.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : 'Exploration Unique'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 md:gap-6 pt-6 md:pt-10 border-t border-stone-50 mt-6 md:mt-10">
                   <div className="space-y-0.5 md:space-y-1">
                     <p className="text-[8px] md:text-[9px] font-bold uppercase tracking-widest text-stone-premium/30 italic">Engagement Financier</p>
                    <p className="text-xl md:text-3xl font-serif italic font-black text-emerald-primary">{(reservation.totalPaid || 0).toLocaleString()} <span className="text-[10px] font-sans not-italic font-bold opacity-30">CFA</span></p>
                   </div>
                   <div className="space-y-0.5 md:space-y-1">
                     <p className="text-[8px] md:text-[9px] font-bold uppercase tracking-widest text-stone-premium/30 italic">Effectif Voyageur</p>
                     <p className="text-xl md:text-3xl font-serif italic font-black text-emerald-primary">{reservation.passengers} <span className="text-[10px] font-sans not-italic font-bold opacity-30 italic">Pôles</span></p>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1 space-y-8"
          >
            <div className="premium-card !bg-emerald-primary text-white border-none shadow-2xl relative overflow-hidden h-full flex flex-col">
               <div className="relative z-10 p-2 h-full flex flex-col justify-between">
                 <div>
                   <h4 className="text-[9px] font-black uppercase tracking-[0.3em] text-emerald-accent mb-10 flex items-center gap-3 italic">
                     <ShieldCheck size={18} /> ESCROW PRIVILÈGE
                   </h4>
                   
                   <div className="space-y-8">
                     <div className="flex justify-between items-center">
                       <span className="text-white/40 text-[10px] font-bold uppercase tracking-widest">État du flux</span>
                       <span className="text-emerald-accent font-black uppercase text-[10px] tracking-widest">{reservation.paymentStatus}</span>
                     </div>
                     <div className="flex justify-between items-center">
                       <span className="text-white/40 text-[10px] font-bold uppercase tracking-widest italic">Captation sécurisée</span>
                       <span className="text-white text-xl font-serif italic font-black">{((reservation.paymentStatus === 'paid' ? (isClient ? reservation.totalPaid : reservation.guideShare) : 0) || 0).toLocaleString()} <span className="text-[10px] font-sans not-italic opacity-30">CFA</span></span>
                     </div>

                     <div className="pt-10 border-t border-white/5">
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-accent italic">PROGRESSION</span>
                          <motion.span 
                            animate={reservation.itineraryProgress?.some(s => s.status === 'en_attente_validation_client') ? { scale: [1, 1.1, 1], color: ['#10b981', '#fcd34d', '#10b981'] } : {}}
                            transition={{ duration: 2, repeat: Infinity }}
                            className="text-lg font-serif italic font-black text-white"
                          >
                            {Math.round(progressPct)}%
                          </motion.span>
                        </div>
                        <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden p-[1px]">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${progressPct}%` }}
                            className={`h-full rounded-full transition-all duration-[2s] ${reservation.status === 'awaiting_client_validation' ? 'bg-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.5)]' : 'bg-emerald-accent shadow-[0_0_15px_rgba(16,185,129,0.5)]'}`} 
                          />
                        </div>
                     </div>
                   </div>
                 </div>

                 <div className="mt-12 pt-10 border-t border-white/5 flex items-center gap-6">
                    <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center text-emerald-accent font-black shadow-inner border border-white/5 text-2xl font-serif italic">
                      {isClient ? (guideProfile?.displayName?.[0] || 'G') : (clientProfile?.displayName?.[0] || (reservation.clientName || reservation.fullname || 'C')[0])}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[9px] font-bold uppercase tracking-widest text-white/30 mb-1">{isClient ? 'Explorateur Expert' : 'Client Privilégié'}</p>
                      <p className="text-md font-black text-white truncate">
                        {isClient ? guideProfile?.displayName || 'Guide MaliTrek' : clientProfile?.displayName || reservation.clientName || reservation.fullname}
                      </p>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onAction?.('message_person');
                      }}
                      className="w-12 h-12 bg-emerald-accent rounded-xl text-emerald-primary hover:scale-110 transition-all shadow-xl shadow-emerald-900/20 active:scale-95 flex items-center justify-center"
                    >
                      <MessageCircle size={20} />
                    </button>
                 </div>
               </div>
            </div>
          </motion.div>
        </div>

        {/* Itinerary Progress Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 pb-20">
           <div className="lg:col-span-2 space-y-10">
             <div className="flex items-center justify-between px-2 stagger-in">
               <h3 className="text-sm font-black text-emerald-primary uppercase tracking-[0.3em]">Chronologie de l'Immersion</h3>
               <Badge variant="stone">{validatedSteps} / {totalSteps} consolidés</Badge>
             </div>
             
             <div className="premium-card bg-stone-50 border border-stone-100/50">
               <ReservationTimeline 
                 reservation={reservation} 
                 journey={journey} 
               />
               
               {!isClient && reservation.status === 'confirmed' && (
                 <div className="mt-12 pt-12 border-t border-stone-100 flex gap-6">
                   <button 
                     onClick={() => {
                       const nextStep = (reservation.itineraryProgress || []).find(s => s.status !== 'validé' && s.status !== 'payé');
                       if (nextStep) {
                         onAction?.('mark_step_complete', { stepId: nextStep.stepId });
                       }
                     }}
                     className="flex-1 btn-premium !bg-emerald-primary !text-white h-16 shadow-2xl shadow-emerald-primary/10 flex items-center justify-center gap-4"
                   >
                     <CheckCircle2 size={18} /> VALIDER L'ÉCHÉANCE SUIVANTE
                   </button>
                 </div>
               )}
             </div>
           </div>

           <div className="lg:col-span-1 space-y-10">
             <h3 className="text-sm font-black text-emerald-primary uppercase tracking-[0.3em] px-2 stagger-in">Actions Dossier</h3>
             
             <div className="space-y-6">
                {isClient && (
                  <div className="space-y-6">
                    {/* Primary Action: Validation */}
                    {isAwaitingValidation && reservation.paymentStatus !== 'released' && (
                      <motion.div 
                        initial={{ scale: 0.95 }}
                        animate={{ scale: 1 }}
                        className="bg-emerald-accent/10 p-8 rounded-[2.5rem] border border-emerald-accent/20 shadow-sahara"
                      >
                        <div className="flex justify-between items-center mb-4">
                           <span className="text-[10px] font-black uppercase tracking-widest text-emerald-accent italic">Action Requise</span>
                           <div className="flex items-center gap-2 text-emerald-primary font-black text-xs">
                              <div className="w-2 h-2 bg-emerald-accent rounded-full animate-pulse" />
                              {timeLeft}
                           </div>
                        </div>
                        <p className="text-xs font-serif font-medium text-emerald-900/60 mb-8 italic leading-relaxed">
                          L'expérience a touché à sa fin. Confirmez-vous la pleine satisfaction de votre exploration ?
                        </p>
                        <button 
                          onClick={() => onAction?.('validate_experience')}
                          className="w-full btn-premium !bg-emerald-primary !text-white h-16 shadow-2xl shadow-emerald-primary/20 flex items-center justify-center gap-3"
                        >
                          <ShieldCheck size={20} /> VALIDER LE VOYAGE
                        </button>
                      </motion.div>
                    )}

                    {/* Other Actions based on status */}
                    {reservation.status === 'confirmed' && (
                      <button 
                        onClick={() => onAction?.('view_boarding_pass')}
                        className="w-full premium-button-action"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-emerald-accent/10 flex items-center justify-center text-emerald-accent group-hover:bg-emerald-accent group-hover:text-white transition-all">
                             <Ticket size={20} />
                          </div>
                          <span className="text-xs font-black uppercase tracking-widest text-emerald-primary">Carte d'Embarquement</span>
                        </div>
                        <ChevronRight size={18} className="text-stone-300" />
                      </button>
                    )}

                    {reservation.status === 'completed' && (
                       <button 
                         onClick={() => !reservation.reviewId && onAction?.('rate_trip')}
                         disabled={!!reservation.reviewId}
                         className={`w-full flex items-center justify-between p-6 rounded-[2rem] transition-all border-2 ${
                           reservation.reviewId 
                             ? 'bg-stone-50 border-stone-100 text-stone-300 cursor-default shadow-inner' 
                             : 'bg-white border-emerald-accent text-emerald-primary shadow-xl shadow-emerald- accent/5 hover:bg-emerald-accent/5'
                         }`}
                       >
                         <div className="flex items-center gap-4">
                           <Star size={20} fill={reservation.reviewId ? 'none' : '#10b981'} className={reservation.reviewId ? 'text-stone-200' : 'text-emerald-accent'} />
                           <span className="text-xs font-black uppercase tracking-widest">
                             {reservation.reviewId ? 'Avis Consigné' : 'Évaluer l\'Expérience'}
                           </span>
                         </div>
                         {!reservation.reviewId && <ChevronRight size={18} />}
                         {reservation.reviewId && <CheckCircle2 size={20} className="text-emerald-accent" />}
                       </button>
                    )}

                    <button 
                       onClick={() => onAction?.('message_person')}
                       className="w-full premium-button-action"
                     >
                       <div className="flex items-center gap-4">
                         <div className="w-10 h-10 rounded-xl bg-emerald-accent/10 flex items-center justify-center text-emerald-accent group-hover:bg-emerald-accent group-hover:text-white transition-all">
                            <MessageCircle size={20} />
                         </div>
                         <span className="text-xs font-black uppercase tracking-widest text-emerald-primary">Ligne Directe Guide</span>
                       </div>
                       <ChevronRight size={18} className="text-stone-300" />
                    </button>

                    {['pending_payment', 'confirmed'].includes(reservation.status) && (
                      <button 
                        onClick={() => onAction?.('cancel_reservation')}
                        className="w-full flex items-center justify-between p-6 bg-white border border-rose-100 rounded-[2rem] transition-all group hover:bg-rose-50"
                      >
                        <div className="flex items-center gap-4 text-stone-400 group-hover:text-rose-500">
                          <X size={20} />
                          <span className="text-xs font-black uppercase tracking-widest italic">Annuler l'Expédition</span>
                        </div>
                        <ChevronRight size={18} className="text-stone-200" />
                      </button>
                    )}

                    {reservation.status === 'disputed' && (
                       <div className="bg-rose-50 p-8 rounded-[2.5rem] border border-rose-100 shadow-inner">
                          <div className="flex items-center gap-4 text-rose-600 mb-4">
                             <ShieldAlert size={22} />
                             <h4 className="text-[11px] font-black uppercase tracking-widest italic">Arbitrage MaliTrek</h4>
                          </div>
                          <p className="text-[11px] font-medium text-rose-800 leading-relaxed italic font-serif">
                             Un protocole d'arbitrage est actif sur ce dossier. Nos experts analysent les faits pour une résolution équitable.
                          </p>
                       </div>
                    )}

                    {['completed', 'awaiting_client_validation', 'confirmed'].includes(reservation.status) && reservation.status !== 'disputed' && (
                      <button 
                        onClick={() => onAction?.('report_issue')}
                        className="w-full flex items-center justify-between p-6 bg-rose-50 rounded-[2rem] transition-all group hover:bg-rose-100"
                      >
                        <div className="flex items-center gap-4 text-rose-600 font-bold uppercase tracking-widest text-[10px]">
                          <AlertTriangle size={18} />
                          Signaler un Différend
                        </div>
                        <ChevronRight size={18} className="text-rose-300" />
                      </button>
                    )}
                  </div>
                )}

                {!isClient && (
                  <div className="space-y-6">
                    <button 
                       onClick={() => onAction?.('message_person')}
                       className="w-full premium-button-action"
                     >
                       <div className="flex items-center gap-4">
                         <div className="w-10 h-10 rounded-xl bg-emerald-accent/10 flex items-center justify-center text-emerald-accent group-hover:bg-emerald-accent group-hover:text-white transition-all">
                            <MessageCircle size={20} />
                         </div>
                         <span className="text-xs font-black uppercase tracking-widest text-emerald-primary">Canal de Liaison Client</span>
                       </div>
                       <ChevronRight size={18} className="text-stone-300" />
                    </button>
                    <button 
                      onClick={() => {
                        if (reservation.phone) window.open(`tel:${reservation.phone}`);
                      }}
                      className="w-full premium-button-action"
                    >
                       <div className="flex items-center gap-4">
                         <div className="w-10 h-10 rounded-xl bg-emerald-accent/10 flex items-center justify-center text-emerald-accent group-hover:bg-emerald-accent group-hover:text-white transition-all">
                            <Phone size={20} />
                         </div>
                         <span className="text-xs font-black uppercase tracking-widest text-emerald-primary">Ligne Téléphonique</span>
                       </div>
                       <ChevronRight size={18} className="text-stone-300" />
                    </button>
                  </div>
                )}

                <div className="bg-stone-50 p-10 rounded-[3rem] space-y-8 border border-stone-100/50 shadow-inner">
                   <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-premium/30 italic">Logistique & Survie</h4>
                   <div className="space-y-6">
                      <div className="flex items-center gap-5">
                         <div className="w-11 h-11 rounded-xl bg-white border border-stone-100 flex items-center justify-center text-emerald-accent">
                            <Clock size={20} />
                         </div>
                         <div className="flex-1">
                            <p className="text-[9px] font-black uppercase tracking-widest text-stone-premium/40">Point de Temps</p>
                            <p className="text-sm font-black text-emerald-primary uppercase">{journey?.meetingTime || '08:00'}</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-5">
                         <div className="w-11 h-11 rounded-xl bg-white border border-stone-100 flex items-center justify-center text-emerald-accent">
                            <ExternalLink size={20} />
                         </div>
                         <div className="flex-1">
                            <p className="text-[9px] font-black uppercase tracking-widest text-stone-premium/40">Rendez-vous GPS</p>
                            <a 
                              href={journey?.meetingLink} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-sm font-black text-emerald-accent hover:underline flex items-center gap-2 group/link"
                            >
                              GOOGLE MAPS <ArrowRight size={12} className="group-hover/link:translate-x-1 transition-transform" />
                            </a>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

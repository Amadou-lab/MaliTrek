import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, Camera, X, MessageSquare, CheckCircle2, Loader2, Sparkles } from 'lucide-react';
import { trekService } from '../../services/trekService';
import { Reservation, UserProfile } from '../../types';
import toast from 'react-hot-toast';

interface ReviewModalProps {
  reservation: Reservation;
  profile: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const ProfessionalReviewModal: React.FC<ReviewModalProps> = ({
  reservation,
  profile,
  isOpen,
  onClose,
  onSuccess
}) => {
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [isLoading, setIsLoading] = useState(false);
  const [ratings, setRatings] = useState({
    global: 0,
    guide: 0,
    experience: 0,
    punctuality: 0,
    value: 0
  });
  const [comment, setComment] = useState('');
  const [hoveredRating, setHoveredRating] = useState<Record<string, number>>({});

  const criteria = [
    { id: 'guide', label: 'Qualité du guide', icon: '👤' },
    { id: 'experience', label: 'Respect du programme', icon: '🗺️' },
    { id: 'punctuality', label: 'Ponctualité', icon: '🕒' },
    { id: 'value', label: 'Rapport qualité/prix', icon: '💰' }
  ];

  const handleSubmit = async () => {
    if (ratings.global === 0) {
      toast.error('Veuillez donner une note globale');
      return;
    }
    if (comment.length < 10) {
      toast.error('Votre commentaire doit faire au moins 10 caractères');
      return;
    }

    setIsLoading(true);
    try {
      await trekService.submitReview({
        reservationId: reservation.id,
        clientId: profile.uid,
        userName: profile.displayName,
        userPhoto: profile.photoURL,
        ratingGlobal: ratings.global,
        ratingGuide: ratings.guide || ratings.global,
        ratingExperience: ratings.experience || ratings.global,
        ratingPunctuality: ratings.punctuality || ratings.global,
        ratingValue: ratings.value || ratings.global,
        comment,
        images: []
      });
      setStep('success');
      onSuccess();
    } catch (error) {
      toast.error('Erreur lors de l\'envoi de l\'avis');
    } finally {
      setIsLoading(false);
    }
  };

  const renderStars = (criterion: string, size = "w-6 h-6") => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onMouseEnter={() => setHoveredRating({ ...hoveredRating, [criterion]: star })}
            onMouseLeave={() => setHoveredRating({ ...hoveredRating, [criterion]: 0 })}
            onClick={() => setRatings({ ...ratings, [criterion]: star })}
            className="transition-transform active:scale-95"
          >
            <Star
              className={`${size} ${
                (hoveredRating[criterion] || (ratings as any)[criterion]) >= star
                  ? 'fill-amber-400 text-amber-400'
                  : 'text-stone-200'
              } transition-colors`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-stone-900/60 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
          >
            {step === 'form' ? (
              <div className="p-8 md:p-12">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h2 className="text-3xl font-black text-stone-900 tracking-tight">Votre expérience</h2>
                    <p className="text-stone-500 font-medium">Partagez votre aventure avec la communauté</p>
                  </div>
                  <button onClick={onClose} className="p-2 hover:bg-stone-100 rounded-full transition-colors">
                    <X className="w-6 h-6 text-stone-400" />
                  </button>
                </div>

                <div className="space-y-8">
                  {/* Global Rating */}
                  <div className="flex flex-col items-center justify-center p-6 bg-amber-50 rounded-3xl border border-amber-100">
                    <span className="text-[10px] font-black uppercase tracking-widest text-amber-600 mb-4">Note globale</span>
                    {renderStars('global', 'w-10 h-10')}
                  </div>

                  {/* Sub criteria */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {criteria.map((criterion) => (
                      <div key={criterion.id} className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{criterion.icon}</span>
                          <span className="text-xs font-bold text-stone-600 uppercase tracking-wide">{criterion.label}</span>
                        </div>
                        {renderStars(criterion.id)}
                      </div>
                    ))}
                  </div>

                  {/* Comment */}
                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-widest text-stone-400">Commentaire</label>
                    <div className="relative">
                      <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Qu'est-ce qui vous a le plus plu ? Le guide était-il au top ?"
                        rows={4}
                        className="w-full px-6 py-4 bg-stone-50 border-2 border-stone-100 rounded-2xl focus:border-emerald-500 focus:bg-white outline-none transition-all resize-none font-medium"
                      />
                      <div className="absolute bottom-4 right-4 text-[10px] font-bold text-stone-400">
                        {comment.length} caractères (min 10)
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleSubmit}
                    disabled={isLoading || ratings.global === 0}
                    className="w-full h-16 bg-stone-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 group"
                  >
                    {isLoading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        Publier mon avis
                        <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-12 text-center space-y-8">
                <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-3xl font-black text-stone-900 tracking-tight">Merci pour votre avis !</h3>
                  <p className="text-stone-500 font-medium px-8 leading-relaxed">
                    Vos retours aident les autres voyageurs à choisir les meilleures aventures et permettent à nos guides de s'améliorer.
                  </p>
                </div>
                <div className="pt-4">
                   <button 
                    onClick={onClose}
                    className="px-10 h-14 bg-stone-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-stone-800 transition-all"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, AlertTriangle, Send, Camera, ShieldAlert } from 'lucide-react';
import { trekService } from '../../services/trekService';
import { Reservation, Journey, UserProfile } from '../../types';
import toast from 'react-hot-toast';

interface ReportIncidentModalProps {
  reservation?: Reservation & { journey?: Journey };
  journey?: Journey;
  profile: UserProfile;
  onClose: () => void;
  onSuccess: () => void;
}

export const ReportIncidentModal: React.FC<ReportIncidentModalProps> = ({
  reservation,
  journey,
  profile,
  onClose,
  onSuccess
}) => {
  const [type, setType] = useState<'delay' | 'hazard' | 'technical' | 'injury' | 'other' | 'conflict'>('other');
  const [urgency, setUrgency] = useState<'low' | 'medium' | 'high' | 'critical'>('low');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      toast.error('Veuillez décrire le problème.');
      return;
    }

    setIsSubmitting(true);
    const loading = toast.loading('Envoi du signalement...');

    try {
      await trekService.reportIncident({
        journeyId: (reservation?.journeyId || journey?.id)!,
        reservationId: reservation?.id,
        userId: profile.uid,
        userName: profile.displayName || 'Utilisateur',
        type,
        description,
        urgency
      });

      toast.success('Incident signalé. L\'équipe MaliTrek a été prévenue.', { id: loading });
      onSuccess();
    } catch (error) {
      toast.error('Erreur lors de l\'envoi du signalement.', { id: loading });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] overflow-hidden w-full max-w-xl shadow-2xl">
      <div className="bg-rose-600 p-8 text-white flex justify-between items-start">
        <div className="space-y-1">
          <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
            <ShieldAlert size={28} /> Signaler un Incident
          </h2>
          <p className="text-rose-100 text-[10px] font-black uppercase tracking-widest pl-9">Sécurité & Support MaliTrek</p>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-all">
          <X size={24} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Type de problème</label>
            <select 
              value={type}
              onChange={e => setType(e.target.value as any)}
              className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-4 py-3 font-bold text-sm outline-none focus:ring-2 focus:ring-rose-500"
            >
              <option value="delay">Retard important</option>
              <option value="hazard">Danger sur la route</option>
              <option value="technical">Problème technique (véhicule)</option>
              <option value="injury">Blessure / Santé</option>
              <option value="conflict">Conflit / Comportement</option>
              <option value="other">Autre</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Urgence</label>
            <div className="flex gap-2">
              {(['low', 'medium', 'high', 'critical'] as const).map(u => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setUrgency(u)}
                  className={`flex-1 py-3 rounded-xl border font-black text-[9px] uppercase tracking-widest transition-all ${
                    urgency === u 
                      ? 'bg-rose-600 border-rose-600 text-white shadow-lg' 
                      : 'bg-white border-stone-100 text-stone-400 hover:border-rose-200'
                  }`}
                >
                  {u === 'critical' ? 'Urgent' : u}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Description des faits</label>
          <textarea 
            className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 font-medium outline-none focus:ring-2 focus:ring-rose-500 min-h-[120px] text-sm"
            placeholder="Détaillez le problème rencontré pour une intervention rapide..."
            value={description}
            onChange={e => setDescription(e.target.value)}
          />
        </div>

        <div className="bg-rose-50 border border-rose-100 rounded-2xl p-6 flex items-start gap-4">
           <AlertTriangle size={20} className="text-rose-600 shrink-0 mt-1" />
           <div className="space-y-1">
             <p className="text-xs font-black text-rose-900 uppercase tracking-tight">Intervention MaliTrek</p>
             <p className="text-[10px] font-medium text-rose-800 leading-relaxed">
               En cas d'urgence vitale, contactez d'abord les services de secours locaux. Ce signalement alerte nos administrateurs pour une résolution rapide du litige ou de la situation.
             </p>
           </div>
        </div>

        <div className="flex gap-4 pt-4">
          <button 
            type="button"
            className="flex-1 bg-stone-100 text-stone-600 py-4 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-stone-200 transition-all flex items-center justify-center gap-2"
          >
            <Camera size={14} /> Ajouter Photo
          </button>
          <button 
            type="submit"
            disabled={isSubmitting || !description.trim()}
            className="flex-[2] bg-rose-600 text-white py-4 rounded-xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-rose-600/20 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Send size={14} /> Envoyer Signalement
          </button>
        </div>
      </form>
    </div>
  );
};

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, ShieldAlert, X, ChevronRight } from 'lucide-react';
import { trekService } from '../../services/trekService';
import toast from 'react-hot-toast';

interface DisputeFormProps {
  reservationId: string;
  journeyId: string;
  userId: string;
  userRole: string;
  onClose: () => void;
  onSuccess: () => void;
}

export const DisputeForm: React.FC<DisputeFormProps> = ({
  reservationId,
  journeyId,
  userId,
  userRole,
  onClose,
  onSuccess
}) => {
  const [type, setType] = useState('Service non conforme');
  const [details, setDetails] = useState('');
  const [urgency, setUrgency] = useState<'normal' | 'urgent' | 'critical'>('normal');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!details) {
      toast.error('Veuillez fournir des détails sur le problème.');
      return;
    }

    setIsSubmitting(true);
    const loading = toast.loading('Ouverture du litige...');
    try {
      await trekService.openDispute({
        reservationId,
        journeyId,
        userId,
        role: userRole,
        type,
        details,
        urgency
      });
      toast.success('Litige ouvert. L\'administration a été notifiée.', { id: loading });
      onSuccess();
    } catch (error) {
      toast.error('Erreur lors de l\'ouverture du litige.', { id: loading });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] p-10 max-w-xl w-full space-y-8">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <div className="bg-rose-100 text-rose-600 w-12 h-12 rounded-2xl flex items-center justify-center mb-4">
            <ShieldAlert size={24} />
          </div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Signaler un Problème</h2>
          <p className="text-slate-500 font-medium italic">Un litige bloque temporairement le paiement au guide jusqu'à résolution.</p>
        </div>
        <button onClick={onClose} className="p-3 bg-slate-100 rounded-xl hover:bg-slate-200 transition-all">
          <X size={20} />
        </button>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Type d'incident</label>
          <select 
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none ring-slate-900 focus:ring-2 appearance-none"
            value={type}
            onChange={e => setType(e.target.value)}
          >
            <option>Service non conforme</option>
            <option>Comportement du guide</option>
            <option>Sécurité / Accident</option>
            <option>Itinéraire non respecté</option>
            <option>Problème de paiement</option>
            <option>Autre</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Urgence</label>
          <div className="flex gap-2">
            {(['normal', 'urgent', 'critical'] as const).map(u => (
              <button
                key={u}
                onClick={() => setUrgency(u)}
                className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                  urgency === u 
                  ? 'bg-slate-900 text-white border-slate-900' 
                  : 'bg-white text-slate-400 border-slate-100 hover:border-slate-300'
                }`}
              >
                {u}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Détails de la plainte</label>
          <textarea 
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none ring-slate-900 focus:ring-2 min-h-[120px]"
            placeholder="Soyez précis : dates, faits, témoins éventuels..."
            value={details}
            onChange={e => setDetails(e.target.value)}
          />
        </div>

        <button 
          onClick={handleSubmit}
          disabled={isSubmitting || !details}
          className="w-full bg-rose-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-rose-600/20 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-3"
        >
          Ouvrir le litige <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
};

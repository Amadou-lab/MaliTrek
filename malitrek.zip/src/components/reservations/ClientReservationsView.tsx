import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, User, MapPin, ChevronRight, QrCode, ShieldCheck, HelpCircle, MessageSquare, AlertCircle, Clock, CheckCircle } from 'lucide-react';
import { Reservation, Journey, Circuit } from '../../types';
import { Card, Badge } from '../shared/UI';
import { ReservationStatusBadge } from './ReservationStatusBadge';
import { ReservationTimeline } from './ReservationTimeline';
import { trekService } from '../../services/trekService';
import { useAuth } from '../../contexts/AuthContext';
import { toDate } from '../../lib/firestoreUtils';
import toast from 'react-hot-toast';
import { ReviewModal } from '../Reviews/ReviewModal';

interface ClientReservationsViewProps {
  reservations: (Reservation & { journey?: Journey, circuit?: Circuit })[];
  onSelectDetail: (reservation: Reservation) => void;
  onViewChange?: (view: string) => void;
}

export const ClientReservationsView: React.FC<ClientReservationsViewProps> = ({
  reservations,
  onSelectDetail,
  onViewChange
}) => {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = React.useState<string>('all');
  const [reviewResId, setReviewResId] = useState<string | null>(null);

  const tabs = [
    { id: 'all', label: 'Toutes' },
    { id: 'pending_payment', label: 'À payer' },
    { id: 'confirmed', label: 'Confirmées' },
    { id: 'in_progress', label: 'En cours' },
    { id: 'awaiting_client_validation', label: 'À valider' },
    { id: 'completed', label: 'Terminées' },
    { id: 'disputed', label: 'Litiges' },
    { id: 'cancelled', label: 'Annulées' }
  ];

  const handleValidate = async (e: React.MouseEvent, resId: string) => {
    e.stopPropagation();
    const confirm = window.confirm('Confirmez-vous que le voyage s’est bien terminé ?');
    if (confirm) {
        const loading = toast.loading('Validation en cours...');
        try {
          await trekService.validateExperience(resId, profile!.uid);
          toast.success('Voyage validé !', { id: loading });
          
          // Check if already reviewed before opening modal
          const res = reservations.find(r => r.id === resId);
          if (res && !res.reviewId) {
            setReviewResId(resId);
          }
        } catch (error) {
          toast.error('Erreur lors de la validation', { id: loading });
        }
    }
  };

  const handleReport = (e: React.MouseEvent, resId: string) => {
    e.stopPropagation();
    // For now toast, or handle it properly
    toast('Veuillez signaler le problème dans le détail de la réservation.');
  };

  const getAutoValidationTime = (deadline: any) => {
    if (!deadline) return '';
    const d = toDate(deadline);
    const now = new Date();
    const diff = d.getTime() - now.getTime();
    if (diff <= 0) return 'Validation imminente';
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `Auto-validation dans ${hours}h ${minutes}m`;
  };

  const filtered = reservations.filter(r => {
    if (activeTab === 'all') return true;
    return r.status === activeTab;
  });

  return (
    <div className="space-y-8 md:space-y-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 md:gap-10">
        <div className="stagger-in">
          <p className="text-[9px] md:text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-2 md:mb-4">Gestion des Voyages</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter leading-none italic">Historique & Suivi</h2>
        </div>

        <div className="flex bg-stone-100 p-1.5 rounded-2xl overflow-x-auto no-scrollbar border border-stone-200/50 -mx-4 px-4 md:mx-0 md:px-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 md:px-6 py-2.5 md:py-3 rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all duration-500 ${
                activeTab === tab.id 
                  ? 'bg-emerald-primary text-emerald-accent shadow-lg' 
                  : 'text-stone-400 hover:bg-stone-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10 pb-20">
        <AnimatePresence mode="popLayout">
          {filtered.map((res) => (
            <motion.div
              key={res.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="group bg-white rounded-3xl md:rounded-[2.5rem] border border-stone-100 flex flex-col p-6 md:p-10 hover:shadow-xl transition-all cursor-pointer relative overflow-hidden"
              onClick={() => onSelectDetail(res)}
            >
              <div className="absolute top-0 right-0 p-6 md:p-8 opacity-[0.03] pointer-events-none -rotate-12 group-hover:rotate-12 transition-transform duration-[2s]">
                <QrCode className="w-20 h-20 md:w-32 md:h-32" />
              </div>

              <div className="flex justify-between items-start mb-6 md:mb-8 relative z-10">
                <ReservationStatusBadge status={res.status} />
                <div className="text-right">
                  <p className="text-[8px] md:text-[10px] font-bold text-stone-premium/30 uppercase tracking-widest mb-1">Montant</p>
                  <p className="text-xl md:text-2xl font-serif italic font-black text-emerald-primary">{(res.totalPaid || 0).toLocaleString()} <span className="text-[10px] font-sans not-italic font-bold opacity-30">CFA</span></p>
                </div>
              </div>

              <div className="flex gap-4 md:gap-8 items-center mb-8 md:mb-10 relative z-10">
                <div className="w-16 h-16 md:w-24 md:h-24 rounded-2xl md:rounded-[1.5rem] bg-stone-100 overflow-hidden shrink-0 shadow-inner">
                  <img 
                    src={res.journey?.image || res.circuit?.image || 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?w=400&q=80'} 
                    alt={res.journey?.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[8px] font-bold text-emerald-accent uppercase tracking-widest mb-1 italic">RÉF: {res.id.slice(0, 8).toUpperCase()}</p>
                  <h3 className="text-lg md:text-2xl font-serif font-black text-emerald-primary leading-tight truncate">
                    {res.journey?.title || 'Voyage MaliTrek'}
                  </h3>
                  <div className="flex flex-wrap items-center gap-3 md:gap-4 mt-2 md:mt-3">
                    <div className="flex items-center gap-1.5 text-stone-premium/40">
                      <Calendar size={12} className="text-emerald-accent" />
                      <span className="text-[9px] font-black uppercase tracking-widest">{res.journey?.date ? new Date(res.journey.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : 'À définir'}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-stone-premium/40">
                      <MapPin size={12} className="text-emerald-accent" />
                      <span className="text-[9px] font-black uppercase tracking-widest truncate">{res.journey?.location || 'Mali'}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 md:gap-4 pb-6 md:pb-10 border-b border-stone-50 mb-6 md:mb-10 relative z-10">
                <div className="bg-stone-50 p-4 md:p-6 rounded-2xl md:rounded-[1.5rem] flex flex-col gap-1 md:gap-2">
                  <p className="text-[8px] font-bold uppercase tracking-widest text-stone-premium/30">Configuration</p>
                  <div className="flex items-center gap-2">
                    <User size={12} className="text-emerald-accent" />
                    <span className="text-[10px] md:text-xs font-black text-emerald-primary">{res.passengers} Voyageurs</span>
                  </div>
                </div>
                <div className="bg-stone-50 p-4 md:p-6 rounded-2xl md:rounded-[1.5rem] flex flex-col gap-1 md:gap-2">
                  <p className="text-[8px] font-bold uppercase tracking-widest text-stone-premium/30">Paiement</p>
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={12} className="text-emerald-accent" />
                    <span className="text-[10px] md:text-xs font-black text-emerald-primary uppercase tracking-tighter truncate">{res.paymentStatus}</span>
                  </div>
                </div>
              </div>

              {res.status === 'awaiting_client_validation' && (
                <div className="mb-8 md:mb-10 space-y-4 md:space-y-6 relative z-10">
                  <div className="flex items-center gap-3 text-emerald-accent bg-emerald-accent/5 p-4 md:p-6 rounded-2xl md:rounded-[1.5rem] border border-emerald-accent/10">
                    <Clock size={16} className="animate-pulse" />
                    <span className="text-[9px] font-black uppercase tracking-widest italic">{getAutoValidationTime(res.validationDeadline)}</span>
                  </div>
                  <div className="flex gap-3">
                    <button 
                      onClick={(e) => handleValidate(e, res.id)}
                      className="flex-1 bg-emerald-primary text-white h-14 md:h-16 rounded-xl md:rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center justify-center gap-2"
                    >
                      VALIDER
                    </button>
                    <button 
                       onClick={(e) => handleReport(e, res.id)}
                       className="w-14 h-14 md:w-16 md:h-16 bg-rose-50 text-rose-500 rounded-xl md:rounded-2xl border border-rose-100 flex items-center justify-center shrink-0"
                    >
                       <AlertCircle size={18} />
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-auto flex items-center justify-between relative z-10">
                <div className="flex -space-x-2">
                  {(res.itineraryProgress || []).slice(0, 5).map((step, i) => (
                    <div 
                      key={i}
                      className={`w-5 h-5 rounded-full border-2 border-white shadow-sm flex items-center justify-center ${
                        step.status === 'validé' || step.status === 'payé' ? 'bg-emerald-accent' : 'bg-stone-200'
                      }`}
                    >
                      {(step.status === 'validé' || step.status === 'payé') && <CheckCircle size={8} className="text-emerald-primary" />}
                    </div>
                  ))}
                </div>
                <button className="flex items-center gap-2 text-emerald-accent font-black text-[9px] md:text-[10px] uppercase tracking-widest">
                  DÉTAILS <ChevronRight size={12} />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {filtered.length === 0 && (
          <div className="col-span-full py-20 md:py-48 bg-stone-50/50 rounded-3xl md:rounded-[4rem] text-center flex flex-col items-center gap-6 md:gap-10 border border-stone-100 px-6">
            <div className="w-20 h-20 md:w-32 md:h-32 bg-white rounded-2xl md:rounded-[2.5rem] flex items-center justify-center text-emerald-accent shadow-md">
               <Calendar size={32} className="opacity-20" />
            </div>
            <div className="space-y-4">
               <p className="text-2xl md:text-4xl font-serif italic font-black text-emerald-primary">Aucun voyage archivé ici.</p>
               <p className="text-[9px] md:text-[11px] font-black text-stone-premium/30 uppercase tracking-[0.4em] max-w-xs mx-auto">Votre prochaine destination signature attend d'être tracée.</p>
            </div>
            <button 
              onClick={() => onViewChange?.('all_circuits')}
              className="px-8 md:px-12 h-14 md:h-16 bg-emerald-primary text-white rounded-xl md:rounded-2xl font-black text-[10px] uppercase tracking-widest"
            >
              EXPLORER LE CATALOGUE
            </button>
          </div>
        )}
      </div>

      <ReviewModal 
        isOpen={!!reviewResId}
        onClose={() => setReviewResId(null)}
        reservationId={reviewResId || ''}
        userId={profile?.uid || ''}
        userName={profile?.displayName || 'Client MaliTrek'}
      />
    </div>
  );
};

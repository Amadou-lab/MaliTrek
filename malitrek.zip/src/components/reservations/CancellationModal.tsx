import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, AlertTriangle, ChevronRight, Info } from 'lucide-react';
import { trekService } from '../../services/trekService';
import { Reservation, Journey } from '../../types';
import toast from 'react-hot-toast';

interface CancellationModalProps {
  reservation: Reservation & { journey?: Journey };
  onClose: () => void;
  onSuccess: () => void;
}

export const CancellationModal: React.FC<CancellationModalProps> = ({
  reservation,
  onClose,
  onSuccess
}) => {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [policyInfo, setPolicyInfo] = useState<{ refundPct: number, message: string } | null>(null);

  useEffect(() => {
    if (!reservation.journey) return;
    const journeyDate = new Date(reservation.journey.date);
    const now = new Date();
    const diffHours = (journeyDate.getTime() - now.getTime()) / (1000 * 60 * 60);

    if (diffHours >= 48) {
      setPolicyInfo({ 
        refundPct: 100, 
        message: "Annulation anticipée (>= 48h) : Remboursement intégral de 100%." 
      });
    } else if (diffHours >= 24) {
      setPolicyInfo({ 
        refundPct: 50, 
        message: "Annulation tardive (24h-48h) : Remboursement partiel de 50%." 
      });
    } else {
      setPolicyInfo({ 
        refundPct: 0, 
        message: "Annulation critique (< 24h) : Remboursement soumis à examen administratif." 
      });
    }
  }, [reservation]);

  const handleCancel = async () => {
    if (!reason) {
      toast.error('Veuillez indiquer un motif d\'annulation.');
      return;
    }

    setIsSubmitting(true);
    const loading = toast.loading('Traitement de l\'annulation...');
    try {
      const result = await trekService.cancelReservation(reservation.id, reservation.userId, reason);
      if (result) {
        toast.success(`Réservation annulée. Remboursement : ${result.refundAmount.toLocaleString()} CFA (${result.refundType === 'full' ? '100%' : result.refundType === 'partial' ? '50%' : '0%'})`, { id: loading });
      } else {
        toast.success('Réservation annulée.', { id: loading });
      }
      onSuccess();
    } catch (error) {
      toast.error('Erreur lors de l\'annulation.', { id: loading });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] p-10 max-w-xl w-full space-y-8">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Annuler ma place</h2>
          <p className="text-slate-500 font-medium italic">Nous sommes désolés que vous ne puissiez plus venir.</p>
        </div>
        <button onClick={onClose} className="p-3 bg-slate-100 rounded-xl hover:bg-slate-200 transition-all">
          <X size={20} />
        </button>
      </div>

      <div className="space-y-6">
        {policyInfo && (
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-slate-900 font-black text-xs uppercase tracking-widest">
              <Info size={16} className="text-emerald-500" /> Politique de remboursement
            </div>
            <p className="text-sm font-medium text-slate-600 leading-relaxed">
              {policyInfo.message}
            </p>
            <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
              <span className="text-[10px] font-black uppercase text-slate-400">Estimation remboursement</span>
              <span className="text-xl font-black text-emerald-600">
                {((reservation.totalPaid * policyInfo.refundPct) / 100).toLocaleString()} CFA
              </span>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Motif de l'annulation</label>
          <textarea 
            className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold outline-none ring-slate-900 focus:ring-2 min-h-[120px]"
            placeholder="Dites-nous pourquoi (Optionnel mais apprécié)..."
            value={reason}
            onChange={e => setReason(e.target.value)}
          />
        </div>

        <div className="bg-rose-50 border border-rose-100 rounded-2xl p-6 flex items-start gap-4">
           <AlertTriangle size={20} className="text-rose-600 shrink-0 mt-1" />
           <p className="text-xs font-medium text-rose-800 leading-relaxed">
             Cette action est irréversible. Vos places seront immédiatement libérées pour d'autres voyageurs.
           </p>
        </div>

        <button 
          onClick={handleCancel}
          disabled={isSubmitting || !reason}
          className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-slate-900/20 active:scale-95 transition-all disabled:opacity-50"
        >
          Confirmer l'annulation
        </button>
      </div>
    </div>
  );
};

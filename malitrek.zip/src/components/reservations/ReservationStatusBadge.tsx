import React from 'react';
import { Badge } from '../shared/UI';

interface ReservationStatusBadgeProps {
  status: string;
}

export const ReservationStatusBadge: React.FC<ReservationStatusBadgeProps> = ({ status }) => {
  const getVariant = () => {
    switch (status) {
      case 'confirmed':
      case 'released':
        return 'success';
      case 'pending_payment':
      case 'awaiting_client_validation':
      case 'in_progress':
        return 'warning';
      case 'cancelled':
        return 'neutral';
      case 'disputed':
        return 'error';
      case 'refunded':
      case 'partially_refunded':
        return 'info';
      case 'completed':
        return 'success';
      default:
        return 'neutral';
    }
  };

  const getLabel = () => {
    switch (status) {
      case 'confirmed': return 'Confirmé';
      case 'pending_payment': return 'Paiement en attente';
      case 'in_progress': return 'Voyage en cours';
      case 'cancelled': return 'Annulé';
      case 'completed': return 'Terminé';
      case 'disputed': return 'Litige en cours';
      case 'awaiting_client_validation': return 'À valider';
      case 'released': return 'Paiement libéré';
      case 'refunded': return 'Remboursé';
      case 'partially_refunded': return 'Remboursement partiel';
      default: return status.split('_').join(' ').toUpperCase();
    }
  };

  return <Badge variant={getVariant()}>{getLabel()}</Badge>;
};

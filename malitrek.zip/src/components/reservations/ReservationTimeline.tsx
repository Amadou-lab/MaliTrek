import React from 'react';
import { Reservation, Journey, ReservationStatus, PaymentStatus } from '../../types';
import { CheckCircle2, Circle, Clock, Info, AlertTriangle } from 'lucide-react';
import { toDate } from '../../lib/firestoreUtils';

interface ReservationTimelineProps {
  reservation: Reservation;
  journey?: Journey;
}

export const ReservationTimeline: React.FC<ReservationTimelineProps> = ({ reservation, journey }) => {
  const steps = [
    { 
      id: 'created', 
      label: 'Réservation créée', 
      isDone: !!reservation.createdAt, 
      date: reservation.createdAt,
      description: 'Demande reçue et traitée.'
    },
    { 
      id: 'paid', 
      label: 'Paiement confirmé', 
      isDone: ['paid', 'released'].includes(reservation.paymentStatus),
      isActive: reservation.paymentStatus === 'unpaid' && reservation.status !== 'cancelled',
      description: 'Fonds sécurisés par MaliTrek.'
    },
    { 
      id: 'started', 
      label: 'Voyage démarré', 
      isDone: ['in_progress', 'awaiting_client_validation', 'completed'].includes(reservation.status) || (journey?.status === 'in_progress'),
      isActive: reservation.status === 'confirmed' && journey?.status === 'in_progress',
      description: 'Le voyage a commencé.'
    },
    { 
      id: 'checkin', 
      label: 'Check-in / Présence', 
      isDone: reservation.clientCheckInStatus === 'checked_in' || reservation.guidePresenceStatus === 'present',
      isActive: reservation.status === 'in_progress' && !reservation.clientCheckInStatus && !reservation.guidePresenceStatus,
      description: reservation.presenceConflict ? 'Conflit de présence à résoudre' : 'Présence confirmée.'
    },
    { 
      id: 'completed_guide', 
      label: 'Fin du trajet (Guide)', 
      isDone: ['awaiting_client_validation', 'completed'].includes(reservation.status) || (journey?.status === 'completed'),
      isActive: reservation.status === 'in_progress' && journey?.status === 'completed',
      date: reservation.completedAt,
      description: 'Marqué terminé par le guide.'
    },
    { 
      id: 'waiting_validation', 
      label: 'Attente validation client', 
      isDone: ['completed'].includes(reservation.status) && reservation.experienceValidated === true,
      isActive: reservation.status === 'awaiting_client_validation',
      description: 'Vérification en cours par vous.'
    },
    { 
      id: 'validated', 
      label: 'Expérience validée', 
      isDone: reservation.experienceValidated === true,
      date: reservation.validatedAt,
      description: 'Confirmation de satisfaction.'
    },
    { 
      id: 'released', 
      label: 'Paiement libéré', 
      isDone: reservation.paymentStatus === 'released',
      description: 'Gains transférés au guide.'
    }
  ];

  const isDisputed = reservation.status === 'disputed';

  return (
    <div className="relative space-y-6 pt-2">
      {isDisputed && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3">
          <AlertTriangle className="text-rose-600 shrink-0" size={20} />
          <p className="text-xs font-black text-rose-800 uppercase tracking-tight">Bloqué par litige en cours</p>
        </div>
      )}

      <div className="relative space-y-8 pl-8 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-stone-100 dark:before:bg-stone-800">
        {steps.map((step, index) => (
          <div key={step.id} className="relative group">
            <div className={`absolute -left-8 w-6 h-6 rounded-full flex items-center justify-center z-10 transition-all ${
              step.isDone
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
                : step.isActive
                ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20 animate-pulse'
                : 'bg-white dark:bg-stone-900 border-2 border-stone-100 dark:border-stone-800 text-stone-200'
            }`}>
              {step.isDone ? (
                <CheckCircle2 size={14} />
              ) : step.isActive ? (
                <Clock size={12} />
              ) : (
                <div className="w-2 h-2 rounded-full bg-current opacity-40" />
              )}
            </div>
            
            <div className="flex flex-col">
              <div className="flex justify-between items-center h-6">
                <span className={`text-[11px] font-black uppercase tracking-widest ${
                  step.isDone ? 'text-stone-900 dark:text-stone-100' : 
                  step.isActive ? 'text-amber-600' : 'text-stone-300'
                }`}>
                  {step.label}
                </span>
                {step.date && (
                  <span className="text-[9px] font-bold text-stone-400">
                    {new Date(toDate(step.date)).toLocaleDateString('fr-FR')}
                  </span>
                )}
              </div>
              <p className={`text-[10px] font-medium leading-tight mt-1 ${
                step.isDone || step.isActive ? 'text-stone-500' : 'text-stone-300'
              }`}>
                {step.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

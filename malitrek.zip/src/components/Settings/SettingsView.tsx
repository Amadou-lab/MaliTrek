import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { UserProfile } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { useSettings } from '../../contexts/SettingsContext';
import { db } from '../../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../../lib/firestoreUtils';
import { 
  User, 
  Bell, 
  Shield, 
  Globe, 
  Moon, 
  Sun,
  HelpCircle, 
  ChevronRight, 
  LogOut, 
  Smartphone, 
  CreditCard,
  Camera,
  Lock,
  Trash2,
  X
} from 'lucide-react';
import toast from 'react-hot-toast';

export const SettingsView: React.FC = () => {
  const { profile, logout, updateProfileInfo, changePassword } = useAuth();
  const { language, setLanguage, theme, setTheme, t } = useSettings();
  
  const [isEditingPhoto, setIsEditingPhoto] = useState(false);
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isEditingPrefs, setIsEditingPrefs] = useState(false);
  const [isEditingPayments, setIsEditingPayments] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState<UserProfile['paymentMethods']>(profile?.paymentMethods || []);
  const [newPayment, setNewPayment] = useState<{
    type: 'orange_money' | 'moov_money' | 'wave' | 'bank_transfer';
    number: string;
    accountName: string;
    bankName?: string;
    iban?: string;
  }>({
    type: 'orange_money',
    number: '',
    accountName: profile?.displayName || ''
  });

  const [photoURL, setPhotoURL] = useState(profile?.photoURL || '');
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [yearsOfExperience, setYearsOfExperience] = useState<number>(profile?.yearsOfExperience || 0);
  const [specialties, setSpecialties] = useState(profile?.specialties?.join(', ') || '');
  const [prefs, setPrefs] = useState(profile?.preferences || { notifications: true, language: 'fr', theme: 'light' });
  
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  useEffect(() => {
    if (profile) {
      setPhotoURL(profile.photoURL || '');
      setDisplayName(profile.displayName || '');
      setPhone(profile.phone || '');
      setBio(profile.bio || '');
      setYearsOfExperience(profile.yearsOfExperience || 0);
      setSpecialties(profile.specialties?.join(', ') || '');
      setPaymentMethods(profile.paymentMethods || []);
      if (profile.preferences) {
        setPrefs(profile.preferences);
      }
    }
  }, [profile?.uid]);

  const handleAddPaymentMethod = async () => {
    if ((newPayment.type !== 'bank_transfer' && !newPayment.number) || (newPayment.type === 'bank_transfer' && !newPayment.iban)) {
      toast.error('Veuillez remplir les informations requises');
      return;
    }

    const updatedMethods = [...paymentMethods, newPayment];
    const loadingToast = toast.loading('Ajout de la méthode de paiement...');
    try {
      await updateDoc(doc(db, 'users', profile.uid), { paymentMethods: updatedMethods });
      setPaymentMethods(updatedMethods);
      setNewPayment({ type: 'orange_money', number: '', accountName: profile.displayName });
      toast.success('Méthode ajoutée !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de l\'ajout', { id: loadingToast });
    }
  };

  const handleDeletePaymentMethod = async (index: number) => {
    const updatedMethods = paymentMethods.filter((_, i) => i !== index);
    const loadingToast = toast.loading('Suppression...');
    try {
      await updateDoc(doc(db, 'users', profile.uid), { paymentMethods: updatedMethods });
      setPaymentMethods(updatedMethods);
      toast.success('Supprimé !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la suppression', { id: loadingToast });
    }
  };

  if (!profile) return null;

  const handleUpdatePhoto = async () => {
    if (!photoURL) return;
    const loadingToast = toast.loading('Mise à jour de la photo...');
    try {
      await updateProfileInfo({ photoURL });
      setIsEditingPhoto(false);
      toast.success('Photo mise à jour !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la mise à jour', { id: loadingToast });
    }
  };

  const handleUpdateInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    const loadingToast = toast.loading('Mise à jour des informations...');
    try {
      const specialtiesArray = specialties.split(',').map(s => s.trim()).filter(s => s !== '');
      await updateProfileInfo({ 
        displayName, 
        phone, 
        bio, 
        yearsOfExperience: Number(yearsOfExperience), 
        specialties: specialtiesArray 
      });
      setIsEditingInfo(false);
      toast.success('Profil mis à jour !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la mise à jour', { id: loadingToast });
    }
  };

  const handleUpdatePrefs = async (newPrefs: any) => {
    const loadingToast = toast.loading('Mise à jour des préférences...');
    try {
      await updateDoc(doc(db, 'users', profile.uid), { preferences: newPrefs });
      setPrefs(newPrefs);
      toast.success('Préférences mises à jour !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la mise à jour', { id: loadingToast });
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass !== confirmPass) {
      toast.error('Les mots de passe ne correspondent pas');
      return;
    }
    const loadingToast = toast.loading('Changement du mot de passe...');
    try {
      await changePassword(currentPass, newPass);
      setIsChangingPassword(false);
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      toast.success('Mot de passe changé !', { id: loadingToast });
    } catch (error: any) {
      toast.error(error.message || 'Erreur lors du changement', { id: loadingToast });
    }
  };

  const sections = [
    {
      title: 'Compte',
      items: [
        { icon: User, label: 'Informations personnelles', desc: 'Nom, email, numéro de téléphone', action: () => setIsEditingInfo(true) },
        { icon: Camera, label: 'Photo de profil', desc: 'Changer votre avatar', action: () => setIsEditingPhoto(true) },
        { icon: CreditCard, label: 'Méthodes de paiement', desc: `${paymentMethods.length} compte(s) enregistré(s)`, action: () => setIsEditingPayments(true) },
        { icon: Shield, label: 'Sécurité', desc: 'Mot de passe, double authentification', action: () => setIsChangingPassword(true) },
      ]
    },
    {
      title: 'Préférences',
      items: [
        { 
          icon: Bell, 
          label: 'Notifications', 
          desc: prefs.notifications ? 'Activées' : 'Désactivées', 
          action: () => handleUpdatePrefs({ ...prefs, notifications: !prefs.notifications }) 
        },
        { 
          icon: Globe, 
          label: 'Langue', 
          desc: language === 'fr' ? 'Français (Mali)' : 'English', 
          action: () => setLanguage(language === 'fr' ? 'en' : 'fr') 
        },
        { 
          icon: theme === 'light' ? Moon : Sun, 
          label: 'Thème', 
          desc: theme === 'light' ? 'Clair' : 'Sombre', 
          action: () => setTheme(theme === 'light' ? 'dark' : 'light') 
        },
      ]
    },
    {
      title: 'Support',
      items: [
        { icon: HelpCircle, label: 'Aide & FAQ', desc: 'Centre d\'assistance MaliTrek', action: () => toast.success('Bientôt disponible !') },
        { icon: Smartphone, label: 'À propos', desc: 'Version 2.4.0 (Premium)', action: () => toast.success('MaliTrek v2.4.0') },
      ]
    }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-12 pb-20">
      <div>
        <h1 className="text-4xl font-black text-stone-900 tracking-tight mb-2">Paramètres</h1>
        <p className="text-stone-500 font-medium">Gérez vos préférences et la sécurité de votre compte.</p>
      </div>

      <div className="space-y-10">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-4">
            <h2 className="text-[10px] font-black text-stone-400 uppercase tracking-[0.25em] ml-6">{section.title}</h2>
            <div className="bg-white rounded-[2.5rem] border border-stone-100 shadow-sm overflow-hidden divide-y divide-stone-50">
              {section.items.map((item, i) => (
                <button 
                  key={i}
                  onClick={() => item.action && item.action()}
                  className="w-full flex items-center gap-6 p-6 hover:bg-stone-50 transition-all group"
                >
                  <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center text-stone-400 group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-all">
                    <item.icon size={22} />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-black text-stone-900 tracking-tight">{item.label}</p>
                    <p className="text-xs text-stone-400 font-medium">{item.desc}</p>
                  </div>
                  <ChevronRight size={18} className="text-stone-300 group-hover:text-emerald-600 transition-all" />
                </button>
              ))}
            </div>
          </div>
        ))}

        <button 
          onClick={() => {
            toast.promise(logout(), {
              loading: 'Déconnexion...',
              success: 'À bientôt !',
              error: 'Erreur lors de la déconnexion'
            });
          }}
          className="w-full flex items-center justify-center gap-3 p-6 bg-rose-50 text-rose-500 rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-rose-100 transition-all"
        >
          <LogOut size={20} />
          Déconnexion du compte
        </button>
      </div>

      {/* Modals */}
      {isEditingPhoto && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingPhoto(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Modifier la photo</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">URL de l'image</label>
                <input 
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  placeholder="https://..."
                  value={photoURL}
                  onChange={e => setPhotoURL(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button onClick={handleUpdatePhoto} className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-600/20">Valider</button>
                <button onClick={() => setIsEditingPhoto(false)} className="flex-1 bg-stone-100 text-stone-400 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px]">Annuler</button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {isEditingInfo && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingInfo(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Modifier les infos</h3>
            <form onSubmit={handleUpdateInfo} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Nom complet</label>
                <input 
                  required
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Téléphone</label>
                <input 
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                />
              </div>

              {profile.role === 'ROLE_GUIDE' && (
                <>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Bio / À propos</label>
                    <textarea 
                      className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-medium text-stone-900 transition-all min-h-[120px] resize-none"
                      placeholder="Décrivez votre expérience et votre passion pour le Mali..."
                      value={bio}
                      onChange={e => setBio(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Expérience (Années)</label>
                      <input 
                        type="number"
                        className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                        value={yearsOfExperience}
                        onChange={e => setYearsOfExperience(Number(e.target.value))}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Spécialités</label>
                      <input 
                        className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                        placeholder="Randonnée, Histoire..."
                        value={specialties}
                        onChange={e => setSpecialties(e.target.value)}
                      />
                    </div>
                  </div>
                </>
              )}
              
              <div className="flex gap-4 pt-4">
                <button type="submit" className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-600/20">Enregistrer</button>
                <button type="button" onClick={() => setIsEditingInfo(false)} className="flex-1 bg-stone-100 text-stone-400 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px]">Annuler</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {isChangingPassword && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsChangingPassword(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Changer le mot de passe</h3>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Mot de passe actuel</label>
                <input 
                  required
                  type="password"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={currentPass}
                  onChange={e => setCurrentPass(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Nouveau mot de passe</label>
                <input 
                  required
                  type="password"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={newPass}
                  onChange={e => setNewPass(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Confirmer le mot de passe</label>
                <input 
                  required
                  type="password"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={confirmPass}
                  onChange={e => setConfirmPass(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="submit" className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-600/20">Changer</button>
                <button type="button" onClick={() => setIsChangingPassword(false)} className="flex-1 bg-stone-100 text-stone-400 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px]">Annuler</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {isEditingPrefs && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingPrefs(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Langue de l'application</h3>
            <div className="space-y-3">
              {[
                { id: 'fr', label: 'Français' },
                { id: 'en', label: 'English' }
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => {
                    handleUpdatePrefs({ ...prefs, language: lang.id });
                    setIsEditingPrefs(false);
                  }}
                  className={`w-full p-6 rounded-2xl border-2 transition-all text-left flex justify-between items-center ${
                    prefs.language === lang.id ? 'border-emerald-500 bg-emerald-50' : 'border-stone-100 hover:border-stone-200'
                  }`}
                >
                  <span className="font-black text-stone-900">{lang.label}</span>
                  {prefs.language === lang.id && <div className="w-3 h-3 bg-emerald-500 rounded-full" />}
                </button>
              ))}
              <button 
                onClick={() => setIsEditingPrefs(false)}
                className="w-full mt-4 py-4 text-stone-400 font-black uppercase tracking-widest text-[10px]"
              >
                Fermer
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {isEditingPayments && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 overflow-y-auto" onClick={() => setIsEditingPayments(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-xl shadow-2xl my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-black text-stone-900">Méthodes de paiement</h3>
              <button onClick={() => setIsEditingPayments(false)} className="text-stone-400">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-8">
              {/* Existing Methods */}
              <div className="space-y-4">
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Comptes enregistrés</p>
                {paymentMethods.length === 0 ? (
                  <div className="p-10 text-center border-2 border-dashed border-stone-100 rounded-[2rem] text-stone-400">
                    <CreditCard size={32} className="mx-auto mb-4 opacity-20" />
                    <p className="text-sm font-medium">Aucun compte enregistré</p>
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {paymentMethods.map((method, i) => (
                      <div key={i} className="p-6 bg-stone-50 rounded-2xl border border-stone-100 flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-white ${
                            method.type === 'orange_money' ? 'bg-orange-500' :
                            method.type === 'moov_money' ? 'bg-blue-600' :
                            method.type === 'wave' ? 'bg-sky-400' : 'bg-stone-900'
                          }`}>
                            {method.type === 'orange_money' ? 'OM' :
                             method.type === 'moov_money' ? 'MM' :
                             method.type === 'wave' ? 'WV' : 'Bank'}
                          </div>
                          <div>
                            <p className="text-sm font-black text-stone-900">
                              {method.type === 'bank_transfer' ? method.bankName : method.number}
                            </p>
                            <p className="text-[10px] text-stone-400 font-bold uppercase">{method.accountName}</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => handleDeletePaymentMethod(i)}
                          className="p-2 text-rose-500 opacity-0 group-hover:opacity-100 transition-all hover:bg-rose-50 rounded-lg"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Add New Method */}
              <div className="p-8 bg-emerald-50 rounded-[2.5rem] border border-emerald-100 space-y-6">
                <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest text-center">Ajouter un nouveau compte</p>
                
                <div className="grid grid-cols-2 gap-3">
                  {['orange_money', 'moov_money', 'wave', 'bank_transfer'].map((type) => (
                    <button
                      key={type}
                      onClick={() => setNewPayment({ ...newPayment, type: type as any })}
                      className={`p-4 rounded-xl border-2 transition-all text-[10px] font-black uppercase tracking-widest ${
                        newPayment.type === type ? 'bg-white border-emerald-500 text-emerald-600 shadow-sm' : 'bg-white/50 border-transparent text-stone-400 hover:bg-white'
                      }`}
                    >
                      {type.replace('_', ' ')}
                    </button>
                  ))}
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Nom du compte</label>
                    <input 
                      className="w-full bg-white border border-emerald-100 rounded-xl px-5 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-stone-900 text-sm"
                      value={newPayment.accountName}
                      onChange={e => setNewPayment({ ...newPayment, accountName: e.target.value })}
                    />
                  </div>

                  {newPayment.type === 'bank_transfer' ? (
                    <>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Nom de la banque</label>
                        <input 
                          className="w-full bg-white border border-emerald-100 rounded-xl px-5 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-stone-900 text-sm"
                          value={newPayment.bankName}
                          onChange={e => setNewPayment({ ...newPayment, bankName: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">RIB / IBAN</label>
                        <input 
                          className="w-full bg-white border border-emerald-100 rounded-xl px-5 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-stone-900 text-sm"
                          value={newPayment.iban}
                          onChange={e => setNewPayment({ ...newPayment, iban: e.target.value })}
                        />
                      </div>
                    </>
                  ) : (
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Numéro de téléphone</label>
                      <input 
                        className="w-full bg-white border border-emerald-100 rounded-xl px-5 py-3 outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-stone-900 text-sm"
                        placeholder="70 00 00 00"
                        value={newPayment.number}
                        onChange={e => setNewPayment({ ...newPayment, number: e.target.value })}
                      />
                    </div>
                  )}

                  <button 
                    onClick={handleAddPaymentMethod}
                    className="w-full bg-stone-900 text-white py-4 rounded-xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-stone-900/20 active:scale-95 transition-all mt-4"
                  >
                    Confirmer l'ajout
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

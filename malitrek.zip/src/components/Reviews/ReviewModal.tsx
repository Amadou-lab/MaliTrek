import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, Camera, X, MessageSquare, CheckCircle2, Loader2, Sparkles, User, ShieldCheck } from 'lucide-react';
import { trekService } from '../../services/trekService';
import toast from 'react-hot-toast';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  reservationId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({ 
  isOpen, 
  onClose, 
  reservationId, 
  userId, 
  userName,
  userPhoto 
}) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // Ratings
  const [ratingGlobal, setRatingGlobal] = useState(5);
  const [ratingGuide, setRatingGuide] = useState(5);
  const [ratingExperience, setRatingExperience] = useState(5);
  const [ratingPunctuality, setRatingPunctuality] = useState(5);
  const [ratingValue, setRatingValue] = useState(5);
  const [comment, setComment] = useState('');

  const [hoveredRating, setHoveredRating] = useState<number | null>(null);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await trekService.submitReview({
        reservationId,
        clientId: userId,
        userName,
        userPhoto,
        ratingGlobal,
        ratingGuide,
        ratingExperience,
        ratingPunctuality,
        ratingValue,
        comment
      });
      setSuccess(true);
      setTimeout(() => {
        onClose();
        setSuccess(false);
        setStep(1);
      }, 3000);
    } catch (error: any) {
      const errorMessage = error instanceof Error ? error.message : "Erreur lors de l'envoi de l'avis";
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const RatingStars = ({ value, onChange, label }: { value: number, onChange: (v: number) => void, label: string }) => (
    <div className="space-y-3">
      <div className="flex justify-between items-center px-1">
         <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">{label}</span>
         <span className="text-xs font-black text-stone-900">{value}/5</span>
      </div>
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onMouseEnter={() => setHoveredRating(star)}
            onMouseLeave={() => setHoveredRating(null)}
            onClick={() => onChange(star)}
            className={`transition-all duration-200 transform ${
              (hoveredRating || value) >= star ? 'scale-110 text-amber-400' : 'text-stone-100 hover:text-amber-200'
            }`}
          >
            <Star 
              size={24} 
              fill={(hoveredRating || value) >= star ? 'currentColor' : 'none'} 
              strokeWidth={2.5}
            />
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-stone-950/80 backdrop-blur-xl"
        onClick={onClose}
      />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 40 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 40 }}
        className="relative bg-white w-full max-w-lg rounded-[3rem] shadow-2xl overflow-hidden"
      >
        <AnimatePresence mode="wait">
          {success ? (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-16 text-center space-y-6"
            >
              <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                <CheckCircle2 size={48} />
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-black text-stone-900 tracking-tight">Merci, {userName.split(' ')[0]} !</h2>
                <p className="text-stone-500 font-medium">Votre avis a été publié avec succès. Vous aidez la communauté à voyager mieux.</p>
              </div>
              <div className="pt-4 flex justify-center gap-2">
                 {[1, 2, 3].map(i => (
                    <div key={i} className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: `${i * 0.1}s` }} />
                 ))}
              </div>
            </motion.div>
          ) : (
            <div className="flex flex-col h-auto md:h-[700px]">
              {/* Header */}
              <div className="p-8 md:p-10 pb-0 flex justify-between items-start">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-stone-100 rounded-2xl flex items-center justify-center text-stone-400 overflow-hidden">
                      {userPhoto ? <img src={userPhoto} className="w-full h-full object-cover" /> : <User size={24} />}
                   </div>
                   <div>
                      <h2 className="text-2xl font-black text-stone-900 tracking-tight leading-none mb-1">Votre expérience</h2>
                      <p className="text-stone-400 font-bold text-[10px] uppercase tracking-widest">Partagez votre retour</p>
                   </div>
                </div>
                <button onClick={onClose} className="p-2 text-stone-300 hover:text-stone-900 transition-colors">
                  <X size={24} />
                </button>
              </div>

              {/* Progress */}
              <div className="px-10 py-6">
                 <div className="flex justify-between relative px-2">
                    <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-stone-100 -translate-y-1/2" />
                    {[1, 2].map(s => (
                       <div 
                        key={s} 
                        className={`relative z-10 w-8 h-8 rounded-full border-4 border-white flex items-center justify-center font-black text-xs transition-all ${
                          step >= s ? 'bg-stone-900 text-white shadow-xl translate-y-[-2px]' : 'bg-stone-100 text-stone-400'
                        }`}
                       >
                         {s}
                       </div>
                    ))}
                 </div>
              </div>

              {/* Steps */}
              <div className="flex-1 p-8 md:p-10 pt-0 overflow-y-auto custom-scrollbar">
                <AnimatePresence mode="wait">
                  {step === 1 ? (
                    <motion.div 
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-8"
                    >
                       <div className="text-center p-8 bg-stone-50 rounded-[2rem] space-y-4">
                          <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Note Globale</p>
                          <div className="flex justify-center gap-3">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                onClick={() => setRatingGlobal(star)}
                                className={`transition-all duration-300 transform ${
                                  ratingGlobal >= star ? 'scale-125 text-amber-400' : 'text-stone-200'
                                }`}
                              >
                                <Star 
                                  size={40} 
                                  fill={ratingGlobal >= star ? 'currentColor' : 'none'} 
                                  strokeWidth={2}
                                />
                              </button>
                            ))}
                          </div>
                          <p className="text-xs font-black text-stone-900">
                             {ratingGlobal === 5 ? 'Excellent !' : ratingGlobal === 4 ? 'Très bien' : ratingGlobal === 3 ? 'Correct' : ratingGlobal === 2 ? 'Moyen' : 'Décevant'}
                          </p>
                       </div>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <RatingStars label="Qualité du Guide" value={ratingGuide} onChange={setRatingGuide} />
                          <RatingStars label="Respect du Programme" value={ratingExperience} onChange={setRatingExperience} />
                          <RatingStars label="Ponctualité" value={ratingPunctuality} onChange={setRatingPunctuality} />
                          <RatingStars label="Rapport Qualité/Prix" value={ratingValue} onChange={setRatingValue} />
                       </div>
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-6"
                    >
                       <div className="space-y-3">
                          <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2 flex items-center gap-2">
                             <MessageSquare size={12} className="text-stone-900" />
                             Racontez-nous votre aventure
                          </label>
                          <textarea 
                            rows={8}
                            className="w-full bg-stone-50 border-2 border-stone-50 rounded-[2rem] p-8 text-sm font-medium focus:ring-4 focus:ring-stone-900/5 focus:border-stone-900 outline-none transition-all placeholder:text-stone-300 resize-none leading-relaxed"
                            placeholder="Points forts, points d'amélioration, moments marquants..."
                            value={comment}
                            onChange={e => setComment(e.target.value)}
                          />
                       </div>

                       <div className="p-6 bg-emerald-50 rounded-[1.5rem] border border-emerald-100 flex gap-4">
                          <Sparkles className="w-6 h-6 text-emerald-600 flex-shrink-0" />
                          <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-wide leading-relaxed">
                             Conseil : Un avis détaillé aide les futurs voyageurs à choisir leur circuit et valorise le travail des meilleurs guides.
                          </p>
                       </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Footer Actions */}
              <div className="p-8 md:p-10 bg-stone-50 flex gap-4">
                {step === 1 ? (
                  <>
                    <button 
                      onClick={onClose}
                      className="flex-1 py-4 text-stone-400 font-black uppercase text-[10px] tracking-widest hover:text-stone-600 transition-colors"
                    >
                      Plus tard
                    </button>
                    <button 
                      onClick={() => setStep(2)}
                      className="flex-[2] bg-stone-900 text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      Suivant <Sparkles size={14} />
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      onClick={() => setStep(1)}
                      className="flex-1 py-4 text-stone-400 font-black uppercase text-[10px] tracking-widest hover:text-stone-600 transition-colors"
                    >
                      Retour
                    </button>
                    <button 
                      disabled={loading}
                      onClick={handleSubmit}
                      className="flex-[2] bg-stone-900 text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl shadow-stone-900/10 hover:bg-stone-800 transition-all active:scale-95 flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {loading ? (
                        <>
                          <Loader2 size={16} className="animate-spin" />
                          Publication...
                        </>
                      ) : (
                        <>
                          Publier l'avis
                          <CheckCircle2 size={16} />
                        </>
                      )}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { useNotifications } from '../contexts/NotificationContext';
import { Sidebar } from './navigation/Sidebar';
import { MobileHeader } from './navigation/MobileHeader';
import { MobileBottomNav } from './navigation/MobileBottomNav';
import { NAV_ITEMS } from './navigation/navItems';
import { Map as MapIcon } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeView: string;
  onViewChange: (view: string) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeView, onViewChange }) => {
  const { profile, logout } = useAuth();
  const { language, setLanguage, theme, setTheme, t } = useSettings();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const { unreadCount, unreadMessagesCount } = useNotifications();

  const allNavItems = NAV_ITEMS(t);
  const currentNav = profile ? allNavItems[profile.role] : allNavItems.GUEST;

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark bg-stone-950' : 'bg-stone-50'} flex flex-col md:flex-row font-sans selection:bg-emerald-100 selection:text-emerald-900 transition-colors duration-500`}>
      <MobileHeader 
        onViewChange={onViewChange}
        unreadCount={unreadCount}
        unreadMessagesCount={unreadMessagesCount}
        setIsMenuOpen={setIsMenuOpen}
      />

      <Sidebar 
        profile={profile}
        activeView={activeView}
        onViewChange={onViewChange}
        items={currentNav}
        onLogout={logout}
        language={language}
        setLanguage={setLanguage}
        theme={theme}
        setTheme={setTheme}
        isMenuOpen={isMenuOpen}
        setIsMenuOpen={setIsMenuOpen}
        unreadCount={unreadCount}
        unreadMessagesCount={unreadMessagesCount}
      />

      <main className={`flex-1 p-4 md:p-12 max-w-7xl mx-auto w-full relative ${profile?.role !== 'ROLE_ADMIN' ? 'pb-32' : 'pb-12'} md:pb-12`}>
        <div className="absolute top-0 right-0 p-12 opacity-[0.03] dark:opacity-[0.01] pointer-events-none hidden lg:block">
          <MapIcon size={500} className="text-stone-900 dark:text-white" />
        </div>
        <div className="relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {profile?.role !== 'ROLE_ADMIN' && (
        <MobileBottomNav 
          items={currentNav}
          activeView={activeView}
          onViewChange={onViewChange}
          unreadCount={unreadCount}
          unreadMessagesCount={unreadMessagesCount}
          setIsMenuOpen={setIsMenuOpen}
        />
      )}

      {isMenuOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-stone-950/40 backdrop-blur-sm z-[65] md:hidden"
          onClick={() => setIsMenuOpen(false)}
        />
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { UserProfile, Circuit, Review } from '../../types';
import { db } from '../../firebase';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { MapPin, Star, Languages, Award, Shield, MessageCircle, Calendar, ArrowLeft, Trophy, Compass, ArrowRight } from 'lucide-react';
import { handleFirestoreError, OperationType, toDate } from '../../lib/firestoreUtils';
import { calculateGuideBadges } from '../../lib/rankingUtils';
import { sortByDateDesc } from '../../lib/firestoreUtils';
import { PremiumLoading } from '../shared/UI';

interface PublicProfileViewProps {
  guideId: string;
  onBack: () => void;
  onSelectCircuit: (circuit: Circuit) => void;
}

export const PublicProfileView: React.FC<PublicProfileViewProps> = ({ guideId, onBack, onSelectCircuit }) => {
  const [guide, setGuide] = useState<UserProfile | null>(null);
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const guideSnap = await getDoc(doc(db, 'users', guideId));
        if (guideSnap.exists()) {
          setGuide({ uid: guideSnap.id, ...guideSnap.data() } as UserProfile);
        }

        const circuitsQuery = query(collection(db, 'circuits'), where('guideId', '==', guideId), where('status', '==', 'approved'));
        const circuitsSnap = await getDocs(circuitsQuery);
        setCircuits(circuitsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Circuit)));

        const reviewsQuery = query(collection(db, 'reviews'), where('guideId', '==', guideId));
        // Note: Logic for guideId in reviews might need sync if it's currently on circuit
        const reviewsSnap = await getDocs(reviewsQuery);
        setReviews(reviewsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Review)));

      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${guideId}`);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [guideId]);

  if (isLoading) {
    return (
      <div className="py-40">
        <PremiumLoading message="Consultation des registres d'exception..." />
      </div>
    );
  }

  if (!guide) {
    return (
      <div className="py-32 text-center">
        <h3 className="text-2xl font-black text-stone-900">Guide non trouvé</h3>
        <button onClick={onBack} className="mt-4 text-emerald-600 font-bold uppercase tracking-widest text-xs underline">Retour</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-12 md:space-y-16 px-4 md:px-6 py-8 md:py-12">
      <button 
        onClick={onBack}
        className="w-12 h-12 md:w-14 md:h-14 flex items-center justify-center bg-white border border-stone-100 rounded-[1rem] md:rounded-2xl text-stone-premium/30 hover:bg-emerald-accent hover:text-white hover:border-emerald-accent transition-all group shadow-sahara active:scale-95"
      >
        <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-16">
        {/* Sidebar Info (Luxury Card) */}
        <div className="lg:col-span-4 space-y-8 md:space-y-10">
          <div className="premium-card p-8 md:p-12 bg-white relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-accent/5 rounded-full -translate-x-1/2 -translate-y-1/2 group-hover:scale-150 transition-transform duration-[2s]" />
            
            <div className="relative z-10 text-center">
              <div className="relative w-40 h-40 mx-auto mb-8">
                <img 
                  src={guide.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${guide.displayName}`} 
                  alt={guide.displayName}
                  className="w-full h-full rounded-[3rem] object-cover ring-8 ring-stone-50 shadow-sahara group-hover:rotate-3 transition-transform duration-[2s]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute -bottom-4 -right-4 bg-emerald-primary text-emerald-accent p-3.5 rounded-2xl shadow-sahara border-4 border-white">
                  <Shield size={20} />
                </div>
              </div>
              
              <h2 className="text-4xl font-serif font-black text-emerald-primary mb-2 italic tracking-tight">{guide.displayName}</h2>
              <p className="text-[10px] font-black text-stone-premium/30 uppercase tracking-[0.3em] mb-8 italic">Maître de Terrain Certifié</p>
              
              <div className="flex flex-wrap justify-center gap-2 mb-10">
                {calculateGuideBadges(guide, circuits.length).map(badge => (
                  <span key={badge} className="px-4 py-1.5 bg-stone-50 text-emerald-accent rounded-xl text-[9px] font-black uppercase tracking-widest border border-stone-100 shadow-sm flex items-center gap-2 italic">
                    <Trophy size={10} /> {badge}
                  </span>
                ))}
              </div>

              <div className="grid grid-cols-3 gap-4 py-10 border-y border-stone-50 mb-10">
                <div>
                  <p className="text-2xl font-serif font-black text-emerald-primary italic">{guide.yearsOfExperience || 8}</p>
                  <p className="text-[8px] font-black text-stone-premium/30 uppercase tracking-widest mt-1">Ans Exp.</p>
                </div>
                <div className="border-x border-stone-50">
                  <p className="text-2xl font-serif font-black text-emerald-primary italic">{circuits.length}</p>
                  <p className="text-[8px] font-black text-stone-premium/30 uppercase tracking-widest mt-1">Circuits</p>
                </div>
                <div>
                  <p className="text-2xl font-serif font-black text-emerald-primary italic flex items-center gap-1 justify-center">
                    {reviews.length > 0 
                      ? (reviews.reduce((acc, r) => acc + r.ratingGlobal, 0) / reviews.length).toFixed(1) 
                      : '4.9'
                    } 
                    <Star size={18} fill="currentColor" className="text-emerald-accent" />
                  </p>
                  <p className="text-[8px] font-black text-stone-premium/30 uppercase tracking-widest mt-1">Note ({reviews.length})</p>
                </div>
              </div>

              <div className="space-y-6 text-left pt-2">
                <div className="flex items-center gap-5 text-stone-premium/60">
                  <div className="w-10 h-10 rounded-xl bg-stone-50 flex items-center justify-center text-emerald-accent"><Languages size={18} /></div>
                  <span className="text-xs font-bold uppercase tracking-widest">{guide.languages?.join(', ') || 'Français, Bambara, Songhaï'}</span>
                </div>
                <div className="flex items-center gap-5 text-stone-premium/60">
                  <div className="w-10 h-10 rounded-xl bg-stone-50 flex items-center justify-center text-emerald-accent"><MapPin size={18} /></div>
                  <span className="text-xs font-bold uppercase tracking-widest">{guide.location || 'Bamako, Mali'}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-emerald-primary rounded-[3rem] p-12 text-white relative overflow-hidden group shadow-sahara">
             <Compass className="absolute -right-10 -bottom-10 w-48 h-48 text-white/5 -rotate-12 group-hover:rotate-0 transition-transform duration-[3s]" />
             <div className="relative z-10 space-y-8">
                <h3 className="text-3xl font-serif font-black tracking-tight leading-tight italic">Confiez votre <br /><span className="text-emerald-accent">itinéraire</span></h3>
                <p className="text-emerald-100/60 text-sm font-medium leading-relaxed italic">
                  Chaque voyage est une pièce unique, sculptée par l'expertise et la passion de nos guides d'exception.
                </p>
                <ul className="space-y-5">
                  <li className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest">
                    <Shield size={20} className="text-emerald-accent" /> Garantie Sécurité MaliTrek
                  </li>
                  <li className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest">
                    <MessageCircle size={20} className="text-emerald-accent" /> Conciergerie 24/7
                  </li>
                  <li className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest">
                    <Award size={20} className="text-emerald-accent" /> Savoir-Faire Local
                  </li>
                </ul>
             </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-8 space-y-20">
          <div className="premium-card p-16 bg-white border border-stone-50 shadow-sahara">
            <p className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-6 italic">Le Manifeste</p>
            <h3 className="text-4xl font-serif font-black text-emerald-primary tracking-tight mb-8">Philosophie de voyage</h3>
            <p className="text-stone-premium/60 font-serif italic text-2xl leading-[1.6] font-medium border-l-4 border-emerald-accent pl-10 pr-6 py-2">
              "{guide.bio || "Passionné par l'héritage vivant du Mali, je conçois chaque expédition comme une immersion sensorielle. Mon rôle est de lever le voile sur les secrets de notre terre, en harmonie avec ses peuples et son histoire séculaire."}"
            </p>
          </div>

          <div className="space-y-12">
            <div className="flex justify-between items-end border-b border-stone-100 pb-8">
              <div>
                 <p className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-2 italic">Portfolio Exclusive</p>
                 <h3 className="text-5xl font-serif font-black text-emerald-primary tracking-tighter italic">Circuits <span className="text-stone-300">Signatures</span></h3>
              </div>
              <p className="text-[10px] font-black text-stone-200 uppercase tracking-widest">{circuits.length} Odyssées</p>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-12">
              {circuits.map(circuit => (
                <motion.div 
                  key={circuit.id}
                  whileHover={{ y: -12 }}
                  className="premium-card bg-white group cursor-pointer overflow-hidden border border-stone-50 shadow-sahara hover:shadow-2xl transition-all duration-700"
                  onClick={() => onSelectCircuit(circuit)}
                >
                  <div className="h-64 relative overflow-hidden">
                    <img src={circuit.image} alt={circuit.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary/40 to-transparent opacity-40" />
                    <div className="absolute top-6 left-6 px-4 py-1.5 bg-white/90 backdrop-blur-md rounded-xl text-[9px] font-black uppercase text-emerald-accent tracking-widest shadow-xl border border-stone-100">{circuit.category}</div>
                  </div>
                  <div className="p-10 space-y-6">
                    <h4 className="text-2xl font-serif font-black text-emerald-primary leading-tight italic tracking-tight">{circuit.title}</h4>
                    <div className="flex justify-between items-end pt-6 border-t border-stone-50">
                      <div>
                         <p className="text-[8px] font-bold text-stone-premium/30 uppercase tracking-widest mb-1 italic">Tarif Private</p>
                         <p className="text-3xl font-serif italic font-black text-emerald-primary">{(circuit.basePrice || 0).toLocaleString()} <span className="text-xs font-sans not-italic font-bold opacity-30">CFA</span></p>
                      </div>
                      <div className="w-12 h-12 bg-emerald-primary text-white rounded-xl flex items-center justify-center group-hover:bg-emerald-accent group-hover:text-emerald-primary transition-all shadow-xl -rotate-12 group-hover:rotate-0 duration-500">
                        <ArrowRight size={20} />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Reviews Section */}
          <div className="space-y-12">
            <div className="flex justify-between items-end border-b border-stone-100 pb-8">
              <div>
                 <p className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-2 italic">Témoignages</p>
                 <h3 className="text-5xl font-serif font-black text-emerald-primary tracking-tighter italic">Retour <span className="text-stone-300">d'Expériences</span></h3>
              </div>
              <p className="text-[10px] font-black text-stone-200 uppercase tracking-widest">{reviews.length} Avis</p>
            </div>

            {reviews.length > 0 ? (
              <div className="grid gap-10">
                {reviews.sort(sortByDateDesc).map((review, idx) => (
                  <motion.div 
                    key={review.id}
                    initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    className="bg-white p-12 rounded-[4rem] border border-stone-50 shadow-sahara relative group overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-12 text-stone-premium/5 group-hover:text-emerald-accent/10 transition-colors pointer-events-none">
                       <Star size={100} className="fill-current" />
                    </div>
                    
                    <div className="relative z-10 flex flex-col md:flex-row justify-between items-start gap-8 mb-8">
                      <div className="flex items-center gap-6">
                        <img 
                          src={review.userPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${review.userName}`} 
                          alt={review.userName}
                          className="w-16 h-16 rounded-[1.5rem] object-cover ring-4 ring-stone-50 shadow-xl group-hover:rotate-6 transition-transform"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <h4 className="text-lg font-black text-emerald-primary tracking-tight">{review.userName}</h4>
                          <p className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.2em] italic mt-1">
                            {review.createdAt ? toDate(review.createdAt).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }) : 'Date inconnue'}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1.5 text-emerald-accent">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} size={18} className="fill-current" style={{ opacity: i < review.ratingGlobal ? 1 : 0.1 }} />
                        ))}
                      </div>
                    </div>
                    <p className="relative z-10 text-stone-premium/60 font-serif italic text-xl leading-relaxed font-medium">
                      "{review.comment}"
                    </p>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="bg-stone-50/50 rounded-[4rem] py-32 text-center border-2 border-dashed border-stone-100 stagger-in">
                <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center mx-auto text-stone-100 mb-10 shadow-xl border border-stone-50">
                   <MessageCircle size={32} />
                </div>
                <p className="text-stone-premium/20 font-black uppercase tracking-[0.4em] text-[10px] italic">L'aventure attend son premier récit...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

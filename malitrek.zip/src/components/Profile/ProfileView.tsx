import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { db } from '../../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType, toDate } from '../../lib/firestoreUtils';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  Shield, 
  Calendar, 
  Camera, 
  Settings, 
  Bell, 
  Lock, 
  LogOut,
  ChevronRight,
  Globe,
  CreditCard,
  X,
  Star
} from 'lucide-react';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';

export const ProfileView: React.FC = () => {
  const { profile, logout, updateProfileInfo, changePassword } = useAuth();
  const [isEditingPhoto, setIsEditingPhoto] = useState(false);
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isEditingPrefs, setIsEditingPrefs] = useState(false);
  const [isEditingPayments, setIsEditingPayments] = useState(false);
  
  const [photoURL, setPhotoURL] = useState(profile?.photoURL || '');
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [yearsOfExperience, setYearsOfExperience] = useState(profile?.yearsOfExperience || 0);
  const [specialties, setSpecialties] = useState<string[]>(profile?.specialties || []);
  const [newSpecialty, setNewSpecialty] = useState('');
  
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const currentPrefs = profile?.preferences || {
    notifications: true,
    language: 'fr',
    theme: 'light'
  };

  const [prefs, setPrefs] = useState(currentPrefs);

  useEffect(() => {
    if (profile) {
      setPhotoURL(profile.photoURL || '');
      setDisplayName(profile.displayName || '');
      setPhone(profile.phone || '');
      setBio(profile.bio || '');
      setYearsOfExperience(profile.yearsOfExperience || 0);
      setSpecialties(profile.specialties || []);
      if (profile.preferences) {
        setPrefs(profile.preferences);
      }
    }
  }, [profile?.uid]);

  if (!profile) return null;

  const handleUpdatePhoto = async () => {
    if (!photoURL) return;
    const loadingToast = toast.loading('Mise à jour de la photo...');
    try {
      await updateProfileInfo({ photoURL });
      setIsEditingPhoto(false);
      toast.success('Photo mise à jour !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la mise à jour', { id: loadingToast });
    }
  };

  const handleUpdateInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    const loadingToast = toast.loading('Mise à jour des informations...');
    try {
      await updateProfileInfo({ 
        displayName, 
        phone, 
        bio, 
        yearsOfExperience, 
        specialties 
      });
      setIsEditingInfo(false);
      toast.success('Profil mis à jour !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la mise à jour', { id: loadingToast });
    }
  };

  const handleUpdatePrefs = async (newPrefs: any) => {
    const loadingToast = toast.loading('Mise à jour des préférences...');
    try {
      await updateDoc(doc(db, 'users', profile.uid), { preferences: newPrefs });
      setPrefs(newPrefs);
      toast.success('Préférences mises à jour !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la mise à jour', { id: loadingToast });
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass !== confirmPass) {
      toast.error('Les mots de passe ne correspondent pas');
      return;
    }
    const loadingToast = toast.loading('Changement du mot de passe...');
    try {
      await changePassword(currentPass, newPass);
      setIsChangingPassword(false);
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      toast.success('Mot de passe changé !', { id: loadingToast });
    } catch (error: any) {
      toast.error(error.message || 'Erreur lors du changement', { id: loadingToast });
    }
  };

  const sections = [
    {
      title: 'Compte',
      items: [
        { icon: Mail, label: 'Email', value: profile.email, color: 'text-blue-500', action: () => setIsEditingInfo(true) },
        { icon: Phone, label: 'Téléphone', value: profile.phone || 'Non renseigné', color: 'text-emerald-500', action: () => setIsEditingInfo(true) },
        ...(profile.role === 'ROLE_ADMIN' ? [{ icon: Shield, label: 'Rôle', value: profile.role.replace('ROLE_', ''), color: 'text-amber-500', action: null }] : []),
        { icon: Calendar, label: 'Membre depuis', value: profile.createdAt ? toDate(profile.createdAt).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' }) : 'Date Inconnue', color: 'text-purple-500', action: null },
      ]
    },
    ...(profile.role === 'ROLE_GUIDE' ? [{
      title: 'Expertise Guide',
      items: [
        { icon: UserIcon, label: 'Bio', value: profile.bio ? (profile.bio.substring(0, 30) + '...') : 'Non renseignée', color: 'text-amber-600', action: () => setIsEditingInfo(true) },
        { icon: Star, label: 'Expérience', value: `${profile.yearsOfExperience || 0} ans`, color: 'text-blue-600', action: () => setIsEditingInfo(true) },
        { icon: Settings, label: 'Spécialités', value: profile.specialties?.join(', ') || 'Aucune', color: 'text-emerald-600', action: () => setIsEditingInfo(true) },
      ]
    }] : []),
    {
      title: 'Préférences',
      items: [
        { icon: Bell, label: 'Notifications', value: currentPrefs.notifications ? 'Activées' : 'Désactivées', color: 'text-pink-500', action: () => handleUpdatePrefs({ ...currentPrefs, notifications: !currentPrefs.notifications }) },
        { icon: Globe, label: 'Langue', value: currentPrefs.language === 'fr' ? 'Français' : 'English', color: 'text-indigo-500', action: () => setIsEditingPrefs(true) },
        { icon: CreditCard, label: 'Paiements', value: 'Gérer les méthodes', color: 'text-cyan-500', action: () => setIsEditingPayments(true) },
      ]
    },
    {
      title: 'Sécurité',
      items: [
        { icon: Lock, label: 'Mot de passe', value: '••••••••', color: 'text-stone-500', action: () => setIsChangingPassword(true) },
        { icon: Settings, label: 'Réglages avancés', value: 'Accéder', color: 'text-stone-500', action: () => toast.success('Bientôt disponible !') },
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-20">
      {/* Header Profile */}
      <div className="relative">
        <div className="h-48 bg-stone-900 rounded-[3rem] overflow-hidden relative">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cubes.png')" }} />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-transparent to-transparent" />
        </div>
        
        <div className="px-10 -mt-20 flex flex-col md:flex-row items-end gap-8 relative z-10">
          <div className="relative group">
            <div className="w-40 h-40 bg-white rounded-[3rem] p-2 shadow-2xl">
              <div className="w-full h-full bg-stone-100 rounded-[2.5rem] flex items-center justify-center text-stone-400 overflow-hidden relative">
                {profile.photoURL ? (
                  <img src={profile.photoURL} alt={profile.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <UserIcon size={64} />
                )}
                <button 
                  onClick={() => setIsEditingPhoto(true)}
                  className="absolute inset-0 bg-black/40 text-white opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                >
                  <Camera size={24} />
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex-1 pb-4 text-center md:text-left">
            <h1 className="text-4xl font-black text-stone-900 tracking-tight mb-2">{profile.displayName}</h1>
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              {profile.role === 'ROLE_ADMIN' && (
                <span className="px-4 py-1.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-black uppercase tracking-widest">
                  {profile.role.replace('ROLE_', '')}
                </span>
              )}
              <span className="text-stone-400 font-bold text-sm flex items-center gap-2">
                <Mail size={14} /> {profile.email}
              </span>
            </div>
          </div>

          <div className="pb-4">
            <button 
              onClick={() => setIsEditingInfo(true)}
              className="px-8 py-4 bg-stone-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-stone-800 transition-all shadow-xl shadow-stone-900/20"
            >
              Modifier le profil
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      {isEditingPhoto && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingPhoto(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Modifier la photo</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">URL de l'image</label>
                <input 
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  placeholder="https://..."
                  value={photoURL}
                  onChange={e => setPhotoURL(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button onClick={handleUpdatePhoto} className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-600/20">Valider</button>
                <button onClick={() => setIsEditingPhoto(false)} className="flex-1 bg-stone-100 text-stone-400 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px]">Annuler</button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {isEditingInfo && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingInfo(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Modifier les infos</h3>
            <form onSubmit={handleUpdateInfo} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Nom complet</label>
                <input 
                  required
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Téléphone</label>
                <input 
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                />
              </div>

              {profile.role === 'ROLE_GUIDE' && (
                <>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Biographie</label>
                    <textarea 
                      rows={3}
                      className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                      placeholder="Parlez-nous de vous..."
                      value={bio}
                      onChange={e => setBio(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Années d'expérience</label>
                    <input 
                      type="number"
                      className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                      value={yearsOfExperience}
                      onChange={e => setYearsOfExperience(parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Spécialités</label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {specialties.map((s, i) => (
                        <span key={i} className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-black flex items-center gap-2">
                          {s}
                          <button type="button" onClick={() => setSpecialties(specialties.filter((_, idx) => idx !== i))} className="hover:text-emerald-800"><X size={12} /></button>
                        </span>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <input 
                        className="flex-1 bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all text-xs"
                        placeholder="Ex: Pays Dogon, Safari..."
                        value={newSpecialty}
                        onChange={e => setNewSpecialty(e.target.value)}
                      />
                      <button 
                        type="button"
                        onClick={() => {
                          if (newSpecialty) {
                            setSpecialties([...specialties, newSpecialty]);
                            setNewSpecialty('');
                          }
                        }}
                        className="px-4 py-2 bg-stone-900 text-white rounded-xl font-black text-[10px] uppercase"
                      >
                        Ajouter
                      </button>
                    </div>
                  </div>
                </>
              )}
              <div className="flex gap-4 pt-4">
                <button type="submit" className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-600/20">Enregistrer</button>
                <button type="button" onClick={() => setIsEditingInfo(false)} className="flex-1 bg-stone-100 text-stone-400 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px]">Annuler</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {isChangingPassword && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsChangingPassword(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Changer le mot de passe</h3>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Mot de passe actuel</label>
                <input 
                  required
                  type="password"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={currentPass}
                  onChange={e => setCurrentPass(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Nouveau mot de passe</label>
                <input 
                  required
                  type="password"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={newPass}
                  onChange={e => setNewPass(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-2">Confirmer le mot de passe</label>
                <input 
                  required
                  type="password"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 transition-all"
                  value={confirmPass}
                  onChange={e => setConfirmPass(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="submit" className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-emerald-600/20">Changer</button>
                <button type="button" onClick={() => setIsChangingPassword(false)} className="flex-1 bg-stone-100 text-stone-400 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px]">Annuler</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {isEditingPrefs && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingPrefs(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Langue de l'application</h3>
            <div className="space-y-3">
              {[
                { id: 'fr', label: 'Français' },
                { id: 'en', label: 'English' }
              ].map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => {
                    handleUpdatePrefs({ ...prefs, language: lang.id });
                    setIsEditingPrefs(false);
                  }}
                  className={`w-full p-6 rounded-2xl border-2 transition-all text-left flex justify-between items-center ${
                    prefs.language === lang.id ? 'border-emerald-500 bg-emerald-50' : 'border-stone-100 hover:border-stone-200'
                  }`}
                >
                  <span className="font-black text-stone-900">{lang.label}</span>
                  {prefs.language === lang.id && <div className="w-3 h-3 bg-emerald-500 rounded-full" />}
                </button>
              ))}
              <button 
                onClick={() => setIsEditingPrefs(false)}
                className="w-full mt-4 py-4 text-stone-400 font-black uppercase tracking-widest text-[10px]"
              >
                Fermer
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {isEditingPayments && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4" onClick={() => setIsEditingPayments(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white rounded-[3rem] p-10 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-2xl font-black text-stone-900 mb-6">Méthodes de paiement</h3>
            <div className="space-y-4">
              <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100 flex items-center gap-4">
                <div className="w-12 h-8 bg-stone-200 rounded flex items-center justify-center text-[8px] font-black text-stone-400 uppercase">VISA</div>
                <div className="flex-1">
                  <p className="text-sm font-black text-stone-900">•••• 4242</p>
                  <p className="text-[10px] text-stone-400 font-bold uppercase">Expire 12/26</p>
                </div>
              </div>
              <button className="w-full py-6 border-2 border-dashed border-stone-200 rounded-2xl text-stone-400 font-black uppercase tracking-widest text-[10px] hover:border-stone-300 hover:text-stone-500 transition-all">
                + Ajouter une carte
              </button>
              <button 
                onClick={() => setIsEditingPayments(false)}
                className="w-full mt-4 py-4 text-stone-400 font-black uppercase tracking-widest text-[10px]"
              >
                Fermer
              </button>
            </div>
          </motion.div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {[
          { label: 'Voyages', value: '12' },
          { label: 'Favoris', value: profile.favorites?.length || '0' },
          { label: 'Avis', value: '5' },
          { label: 'Points', value: '450' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-[2rem] border border-stone-100 shadow-sm text-center">
            <div className="text-2xl font-black text-stone-900 mb-1">{stat.value}</div>
            <div className="text-[10px] font-black text-stone-400 uppercase tracking-widest">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Sections */}
      <div className="grid md:grid-cols-2 gap-10">
        {sections.map((section, i) => (
          <div key={i} className="space-y-6">
            <h3 className="text-sm font-black text-stone-400 uppercase tracking-[0.2em] ml-4">{section.title}</h3>
            <div className="bg-white rounded-[2.5rem] border border-stone-100 shadow-sm overflow-hidden divide-y divide-stone-50">
              {section.items.map((item, j) => (
                <button 
                  key={j} 
                  onClick={() => item.action && item.action()}
                  className="w-full flex items-center justify-between p-6 hover:bg-stone-50 transition-all group"
                >
                  <div className="flex items-center gap-5">
                    <div className={`w-12 h-12 rounded-2xl bg-stone-50 flex items-center justify-center ${item.color} group-hover:scale-110 transition-transform`}>
                      <item.icon size={20} />
                    </div>
                    <div className="text-left">
                      <div className="text-xs font-black text-stone-400 uppercase tracking-widest mb-0.5">{item.label}</div>
                      <div className="text-stone-900 font-bold">{item.value}</div>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-stone-300 group-hover:text-stone-900 group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Danger Zone */}
        <div className="space-y-6">
          <h3 className="text-sm font-black text-red-400 uppercase tracking-[0.2em] ml-4">Zone de danger</h3>
          <div className="bg-red-50 rounded-[2.5rem] border border-red-100 shadow-sm overflow-hidden">
            <button 
              onClick={() => {
                toast.promise(logout(), {
                  loading: 'Déconnexion...',
                  success: 'À bientôt !',
                  error: 'Erreur lors de la déconnexion'
                });
              }}
              className="w-full flex items-center justify-between p-6 hover:bg-red-100 transition-all group"
            >
              <div className="flex items-center gap-5">
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-red-600 shadow-sm group-hover:scale-110 transition-transform">
                  <LogOut size={20} />
                </div>
                <div className="text-left">
                  <div className="text-xs font-black text-red-400 uppercase tracking-widest mb-0.5">Session</div>
                  <div className="text-red-900 font-bold">Se déconnecter</div>
                </div>
              </div>
              <ChevronRight size={18} className="text-red-300 group-hover:text-red-900 group-hover:translate-x-1 transition-all" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Modal } from './Modal';
import { AlertTriangle } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'warning' | 'info';
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  title, 
  message, 
  confirmLabel = 'Confirmer', 
  cancelLabel = 'Annuler',
  variant = 'danger'
}) => {
  const colors = {
    danger: 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/20 text-white',
    warning: 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20 text-white',
    info: 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20 text-white'
  };

  const iconColors = {
    danger: 'bg-rose-100 text-rose-600',
    warning: 'bg-amber-100 text-amber-600',
    info: 'bg-emerald-100 text-emerald-600'
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} maxWidth="max-w-md">
      <div className="space-y-8">
        <div className="flex items-start gap-6">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${iconColors[variant]}`}>
            <AlertTriangle size={28} />
          </div>
          <p className="text-stone-500 font-medium leading-relaxed">
            {message}
          </p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={onClose}
            className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-600 font-black py-4 rounded-2xl transition-all uppercase tracking-widest text-xs"
          >
            {cancelLabel}
          </button>
          <button 
            onClick={() => { onConfirm(); onClose(); }}
            className={`flex-1 font-black py-4 rounded-2xl transition-all uppercase tracking-widest text-xs shadow-xl active:scale-95 ${colors[variant]}`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </Modal>
  );
};

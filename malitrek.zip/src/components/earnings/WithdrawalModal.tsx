import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { WithdrawRequestForm } from './WithdrawRequestForm';

interface WithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  onSubmit: (amount: number, method: string, phone: string) => Promise<void>;
}

export const WithdrawalModal: React.FC<WithdrawalModalProps> = ({
  isOpen,
  onClose,
  balance,
  onSubmit
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 bg-stone-950/60 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-[3rem] w-full max-w-lg p-10 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <WithdrawRequestForm 
              balance={balance} 
              onClose={onClose} 
              onSubmit={onSubmit} 
            />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

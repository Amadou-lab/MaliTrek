import React from 'react';
import { CreditCard, TrendingUp, Filter } from 'lucide-react';
import { Badge } from '../shared/UI';

interface Transaction {
  id: string;
  date: string;
  type: string;
  amount: number;
  status: string;
  isWithdrawal: boolean;
  description?: string;
}

interface TransactionsTableProps {
  transactions: Transaction[];
  onExport: () => void;
}

export const TransactionsTable: React.FC<TransactionsTableProps> = ({
  transactions,
  onExport
}) => {
  const [filter, setFilter] = React.useState<'all' | 'income' | 'withdrawal'>('all');

  const filtered = transactions.filter(t => {
    if (filter === 'income') return !t.isWithdrawal;
    if (filter === 'withdrawal') return t.isWithdrawal;
    return true;
  });

  return (
    <div className="bg-white dark:bg-stone-900 rounded-[3rem] border border-stone-100 dark:border-stone-800 shadow-sm overflow-hidden">
      <div className="p-8 border-b border-stone-100 dark:border-stone-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-xl font-black text-stone-900 dark:text-white tracking-tight">Historique des transactions</h3>
          <p className="text-xs text-stone-500 font-medium mt-1">Détail de vos flux financiers entrant et sortant.</p>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="flex bg-stone-100 dark:bg-stone-800 p-1 rounded-xl">
            {(['all', 'income', 'withdrawal'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${
                  filter === f 
                    ? 'bg-white dark:bg-stone-700 text-emerald-600 shadow-sm' 
                    : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                {f === 'all' ? 'Tout' : f === 'income' ? 'Gains' : 'Retraits'}
              </button>
            ))}
          </div>
          <button 
            onClick={onExport}
            className="p-3 text-stone-400 hover:text-emerald-600 transition-colors"
            title="Exporter en Excel"
          >
            <Filter size={20} />
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-stone-50/50 dark:bg-stone-900/50">
              <th className="px-8 py-5 text-[10px] font-black text-stone-400 uppercase tracking-widest border-b border-stone-100 dark:border-stone-800">Date</th>
              <th className="px-8 py-5 text-[10px] font-black text-stone-400 uppercase tracking-widest border-b border-stone-100 dark:border-stone-800">Type / Description</th>
              <th className="px-8 py-5 text-[10px] font-black text-stone-400 uppercase tracking-widest border-b border-stone-100 dark:border-stone-800">Montant</th>
              <th className="px-8 py-5 text-[10px] font-black text-stone-400 uppercase tracking-widest border-b border-stone-100 dark:border-stone-800">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
            {filtered.map((item) => (
              <tr key={item.id} className="hover:bg-stone-50/50 dark:hover:bg-stone-800/30 transition-colors">
                <td className="px-8 py-6">
                  <p className="text-sm font-bold text-stone-900 dark:text-stone-200">{new Date(item.date).toLocaleDateString('fr-FR')}</p>
                  <p className="text-[10px] text-stone-400 mt-1">{new Date(item.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
                </td>
                <td className="px-8 py-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.isWithdrawal ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600' : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600'}`}>
                      {item.isWithdrawal ? <CreditCard size={18} /> : <TrendingUp size={18} />}
                    </div>
                    <div>
                      <p className="text-sm font-black text-stone-800 dark:text-stone-300">{item.type}</p>
                      {item.description && <p className="text-[10px] text-stone-400 font-medium truncate max-w-xs">{item.description}</p>}
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <p className={`text-sm font-black ${item.isWithdrawal ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {item.amount > 0 ? '+' : ''}{(item.amount || 0).toLocaleString()} CFA
                  </p>
                </td>
                <td className="px-8 py-6">
                  <Badge 
                    variant={
                      item.status === 'Confirmé' || item.status === 'Validé' || item.status === 'approved' ? 'success' : 
                      item.status === 'En attente' || item.status === 'À venir' || item.status === 'pending' ? 'warning' : 
                      'error'
                    }
                  >
                    {item.status}
                  </Badge>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={4} className="p-20 text-center text-stone-400 font-bold">Aucune transaction trouvée.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

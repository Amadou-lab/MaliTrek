import React from 'react';
import { Download, Wallet, Ticket, Zap, ShieldCheck } from 'lucide-react';
import { Card, Badge } from '../shared/UI';
import { EarningsStatsCards } from './EarningsStatsCards';
import { TransactionsTable } from './TransactionsTable';

interface GuideEarningsOverviewProps {
  earnings: {
    available: number;
    pending: number;
    blocked: number;
    totalBrut: number;
    totalWithdrawn: number;
    escrowLocked: number;
  };
  transactions: any[];
  onWithdraw: () => void;
  onExport: () => void;
}

export const GuideEarningsOverview: React.FC<GuideEarningsOverviewProps> = ({
  earnings,
  transactions,
  onWithdraw,
  onExport
}) => {
  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-4xl font-black text-stone-900 dark:text-white tracking-tight leading-none mb-3">Mes Gains</h1>
          <p className="text-stone-500 font-medium">Gérez vos revenus, suivez l'escrow et demandez vos retraits.</p>
        </div>
        <button 
          onClick={onWithdraw}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center gap-3 transition-all shadow-xl shadow-emerald-600/20 active:scale-95"
        >
          <Download size={18} />
          Effectuer un retrait
        </button>
      </div>

      <EarningsStatsCards 
        available={earnings.available}
        pending={earnings.pending}
        blocked={earnings.blocked}
        totalCa={earnings.totalBrut}
      />

      {/* Hero Info Box */}
      <div className="bg-stone-900 rounded-[3rem] p-10 text-white relative overflow-hidden group border border-white/5">
        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700 pointer-events-none">
          <Zap size={150} />
        </div>
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          <div className="flex gap-6">
            <div className="w-16 h-16 bg-emerald-600 rounded-3xl flex items-center justify-center text-white shrink-0 shadow-xl shadow-emerald-600/20">
              <ShieldCheck size={32} />
            </div>
            <div>
              <h4 className="text-xl font-black tracking-tight mb-2">Paiement Sécurisé</h4>
              <p className="text-stone-400 text-sm leading-relaxed">Vos fonds sont protégés par notre système d'escrow et libérés au fur et à mesure.</p>
            </div>
          </div>
          
          <div className="flex flex-col justify-center">
            <div className="flex gap-4">
              <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-3xl border border-white/10">
                <p className="text-[10px] font-black uppercase tracking-widest text-emerald-400 mb-1">Votre part</p>
                <p className="text-2xl font-black">80%</p>
              </div>
              <div className="bg-white/5 backdrop-blur-md px-6 py-4 rounded-3xl border border-white/10">
                <p className="text-[10px] font-black uppercase tracking-widest text-stone-500 mb-1">MaliTrek</p>
                <p className="text-2xl font-black text-stone-300">20%</p>
              </div>
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10">
             <div className="flex justify-between items-center mb-4">
               <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">Escrow Actuel</span>
               <Badge variant="warning">Verrouillé</Badge>
             </div>
             <p className="text-2xl font-black">{(earnings.escrowLocked || 0).toLocaleString()} <span className="text-xs">CFA</span></p>
             <div className="w-full h-1 bg-white/10 rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-amber-500 w-[60%] rounded-full" />
             </div>
          </div>
        </div>
      </div>

      <TransactionsTable 
        transactions={transactions}
        onExport={onExport}
      />
    </div>
  );
};

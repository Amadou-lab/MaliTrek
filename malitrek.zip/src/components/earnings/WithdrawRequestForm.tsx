import React from 'react';
import { Download, Landmark, Smartphone, X, CheckCircle2 } from 'lucide-react';
import { Card } from '../shared/UI';

interface WithdrawRequestFormProps {
  balance: number;
  onClose: () => void;
  onSubmit: (amount: number, method: any, accountNumber: string) => Promise<void>;
}

export const WithdrawRequestForm: React.FC<WithdrawRequestFormProps> = ({
  balance,
  onClose,
  onSubmit
}) => {
  const [amount, setAmount] = React.useState<string>('');
  const [method, setMethod] = React.useState<string>('orange_money');
  const [accountNumber, setAccountNumber] = React.useState<string>('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [success, setSuccess] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0 || numAmount > balance) return;
    if (!accountNumber) return;

    setIsSubmitting(true);
    try {
      await onSubmit(numAmount, method, accountNumber);
      setSuccess(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="text-center py-12 px-6">
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-6">
          <CheckCircle2 size={40} />
        </div>
        <h3 className="text-2xl font-black text-stone-900 mb-2">Demande Envoyée !</h3>
        <p className="text-stone-500 font-medium mb-8">Votre demande de retrait de {(Number(amount) || 0).toLocaleString()} CFA est en cours de traitement par l'administration.</p>
        <button 
          onClick={onClose}
          className="w-full bg-stone-900 text-white font-black py-4 rounded-2xl uppercase tracking-widest text-xs"
        >
          Fermer
        </button>
      </div>
    );
  }

  return (
    <div className="relative">
      <button onClick={onClose} className="absolute -top-12 -right-4 md:-right-12 p-2 text-stone-400 hover:text-white transition-colors">
        <X size={24} />
      </button>

      <div className="mb-8">
        <h2 className="text-2xl font-black text-stone-900 tracking-tight">Retirer mes fonds</h2>
        <p className="text-stone-500 font-medium text-sm">Transfert sécurisé vers votre compte personnel.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 mb-6">
          <p className="text-[10px] font-black uppercase tracking-widest text-emerald-600 mb-1">Montant disponible</p>
          <p className="text-2xl font-black text-emerald-900">{(balance || 0).toLocaleString()} CFA</p>
        </div>

        <div className="space-y-4">
          <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-4">Montant à retirer</label>
          <div className="relative">
            <input 
              required
              type="number"
              min="1000"
              max={balance}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-emerald-500 outline-none font-black text-stone-900 text-xl"
              placeholder="Ex: 5000"
            />
            <span className="absolute right-6 top-1/2 -translate-y-1/2 font-black text-stone-400">CFA</span>
          </div>
        </div>

        <div className="space-y-4">
          <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-4">Mode de retrait</label>
          <div className="grid grid-cols-2 gap-4">
            {[
              { id: 'orange_money', label: 'Orange Money', icon: Smartphone },
              { id: 'moov_money', label: 'Moov Money', icon: Smartphone },
              { id: 'wave', label: 'Wave', icon: Smartphone },
              { id: 'bank_transfer', label: 'Virement', icon: Landmark }
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                className={`flex flex-col items-center gap-3 p-4 rounded-3xl border transition-all ${
                  method === m.id 
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-600 ring-4 ring-emerald-50' 
                    : 'border-stone-100 bg-stone-50 text-stone-500 hover:bg-stone-100/50'
                }`}
              >
                <m.icon size={20} />
                <span className="text-[9px] font-black uppercase tracking-widest">{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest ml-4">
            {method === 'bank_transfer' ? 'Numéro de compte / IBAN' : 'Numéro de téléphone / Identifiant'}
          </label>
          <input 
            required
            type="text"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900"
            placeholder={method === 'bank_transfer' ? "RIB ou IBAN international" : "00 223 7X XX XX XX"}
          />
        </div>

        <button 
          type="submit"
          disabled={isSubmitting || !amount || Number(amount) <= 0 || Number(amount) > balance || !accountNumber}
          className="w-full bg-stone-900 hover:bg-stone-800 disabled:bg-stone-200 text-white font-black py-5 rounded-[2rem] uppercase tracking-widest text-xs transition-all flex items-center justify-center gap-3 shadow-xl shadow-stone-900/10 active:scale-95"
        >
          {isSubmitting ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <Download size={18} />
              Confirmer le retrait
            </>
          )}
        </button>
      </form>
    </div>
  );
};

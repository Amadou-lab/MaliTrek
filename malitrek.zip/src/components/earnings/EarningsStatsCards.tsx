import React from 'react';
import { CreditCard, Clock, Compass, AlertCircle } from 'lucide-react';
import { Card } from '../shared/UI';

interface EarningsStatsCardsProps {
  available: number;
  pending: number;
  blocked: number;
  totalCa: number;
}

export const EarningsStatsCards: React.FC<EarningsStatsCardsProps> = ({
  available,
  pending,
  blocked,
  totalCa
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="border-emerald-100 dark:border-emerald-900/30 bg-emerald-50/30 dark:bg-emerald-900/5">
        <div className="flex justify-between items-start mb-6">
          <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <CreditCard size={24} />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest bg-emerald-600 text-white px-3 py-1 rounded-full">Disponible</span>
        </div>
        <h3 className="text-xs font-black uppercase tracking-widest text-emerald-900/60 dark:text-emerald-400/60 mb-1">Solde Retirable</h3>
        <p className="text-3xl font-black text-stone-900 dark:text-white tracking-tight">{(available || 0).toLocaleString()} <span className="text-sm">CFA</span></p>
      </Card>

      <Card className="border-amber-100 dark:border-amber-900/30 bg-amber-50/30 dark:bg-amber-900/5">
        <div className="flex justify-between items-start mb-6">
          <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
            <Clock size={24} />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest bg-amber-500 text-white px-3 py-1 rounded-full">À Venir</span>
        </div>
        <h3 className="text-xs font-black uppercase tracking-widest text-amber-900/60 dark:text-amber-400/60 mb-1">Gains en Attente</h3>
        <p className="text-3xl font-black text-stone-900 dark:text-white tracking-tight">{(pending || 0).toLocaleString()} <span className="text-sm">CFA</span></p>
      </Card>

      <Card className="border-rose-100 dark:border-rose-900/30 bg-rose-50/30 dark:bg-rose-900/5">
        <div className="flex justify-between items-start mb-6">
          <div className="w-12 h-12 bg-rose-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-rose-500/20">
            <AlertCircle size={24} />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest bg-rose-500 text-white px-3 py-1 rounded-full">Bloqué</span>
        </div>
        <h3 className="text-xs font-black uppercase tracking-widest text-rose-900/60 dark:text-rose-400/60 mb-1">Litiges / Suspendu</h3>
        <p className="text-3xl font-black text-stone-900 dark:text-white tracking-tight">{(blocked || 0).toLocaleString()} <span className="text-sm">CFA</span></p>
      </Card>

      <Card className="border-stone-100 dark:border-stone-800 bg-white dark:bg-stone-900">
        <div className="flex justify-between items-start mb-6">
          <div className="w-12 h-12 bg-stone-900 dark:bg-stone-800 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-stone-900/20">
            <Compass size={24} />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 px-3 py-1 rounded-full">Historique</span>
        </div>
        <h3 className="text-xs font-black uppercase tracking-widest text-stone-400 mb-1">Chiffre d'Affaires Brut</h3>
        <p className="text-3xl font-black text-stone-900 dark:text-white tracking-tight">{(totalCa || 0).toLocaleString()} <span className="text-sm">CFA</span></p>
      </Card>
    </div>
  );
};

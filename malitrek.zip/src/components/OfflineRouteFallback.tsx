import React from 'react';
import { MapPin, Navigation, Flag, Info, Clock, CheckCircle2 } from 'lucide-react';
import { Journey } from '../types';

interface OfflineRouteFallbackProps {
  journey: Journey;
  currentStepIndex: number;
}

export const OfflineRouteFallback: React.FC<OfflineRouteFallbackProps> = ({ journey, currentStepIndex }) => {
  const steps = journey.itinerarySnapshot || [];
  const currentStep = currentStepIndex >= 0 ? steps[currentStepIndex] : null;
  const nextStep = currentStepIndex + 1 < steps.length ? steps[currentStepIndex + 1] : null;

  return (
    <div className="bg-[#0A1931]/80 backdrop-blur-2xl border border-white/5 rounded-[3.5rem] p-10 space-y-10 animate-in fade-in slide-in-from-bottom-4 shadow-2xl">
      <div className="flex items-start gap-6">
        <div className="w-14 h-14 bg-[#C06014]/20 text-[#C06014] rounded-2xl flex items-center justify-center shadow-inner">
          <Info className="w-7 h-7" />
        </div>
        <div>
          <h4 className="text-xl font-serif italic font-black tracking-tight text-white">Carte Indisponible</h4>
          <p className="text-[9px] text-[#C06014] font-black uppercase tracking-[0.4em] mt-1">
            Mode Hors-Ligne • Itinéraire de Secours
          </p>
        </div>
      </div>

      <div className="space-y-8">
        {/* Active Segment */}
        <div className="relative pl-10 border-l border-dashed border-white/10 space-y-10">
          {/* Timeline Ornaments */}
          <div className="absolute -left-[3.5px] top-0 w-1.5 h-1.5 rounded-full bg-[#C06014]" />
          
          <div className="space-y-8">
            {currentStep ? (
              <div className="bg-white/5 border border-white/5 rounded-[2.5rem] p-8 relative group hover:bg-white/10 transition-colors">
                <div className="absolute -left-[51.5px] top-1/2 -translate-y-1/2 w-8 h-8 bg-[#FDE68A] rounded-xl flex items-center justify-center text-[#0A1931] shadow-lg shadow-[#FDE68A]/20">
                  <Navigation className="w-4 h-4 fill-current" strokeWidth={3} />
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-[9px] font-black uppercase tracking-[0.3em] text-[#FDE68A]">Position Actuelle</span>
                </div>
                <h5 className="text-2xl font-serif italic font-black text-white">{currentStep.title}</h5>
                <p className="text-xs text-white/40 mt-3 leading-relaxed font-serif italic italic">{currentStep.description}</p>
              </div>
            ) : (
              <div className="p-8 bg-white/5 rounded-[2.5rem] border border-white/5 border-dashed">
                <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em] text-center">En attente du départ</p>
              </div>
            )}

            {nextStep && (
              <div className="bg-white/5 border border-white/5 rounded-[2.5rem] p-8 relative opacity-40 group hover:opacity-60 transition-opacity">
                <div className="absolute -left-[51.5px] top-1/2 -translate-y-1/2 w-8 h-8 bg-white/10 rounded-xl flex items-center justify-center text-white/40 border border-white/5">
                  <Clock className="w-4 h-4" />
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/50">Point Suivant</span>
                </div>
                <h5 className="text-xl font-black text-white">{nextStep.title}</h5>
                <p className="text-[10px] text-[#FDE68A] font-black uppercase tracking-widest mt-2">{nextStep.estimatedTime || 'N/A'}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="pt-6 border-t border-white/5 flex flex-col gap-4">
        <button className="w-full h-16 bg-white/5 hover:bg-white/10 text-white rounded-[1.8rem] font-black uppercase tracking-[0.3em] text-[10px] flex items-center justify-center gap-4 transition-all border border-white/5 active:scale-95">
          <MapPin className="w-5 h-5 text-[#FDE68A]" /> Coordonnées GPS
        </button>
        <div className="flex items-center justify-center gap-6 py-4 opacity-10">
          <div className="w-16 h-px bg-white" />
          <Flag className="w-5 h-5" />
          <div className="w-16 h-px bg-white" />
        </div>
      </div>
    </div>
  );
};

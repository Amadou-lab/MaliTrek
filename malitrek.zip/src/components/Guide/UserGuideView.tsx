import React from 'react';
import { motion } from 'motion/react';
import { 
  BookOpen, 
  User as UserIcon, 
  Map, 
  Shield, 
  Smartphone, 
  CreditCard, 
  CheckCircle2, 
  HelpCircle,
  ArrowRight,
  Compass,
  Ticket
} from 'lucide-react';

export const UserGuideView: React.FC = () => {
  const roles = [
    {
      role: 'Voyageur (Client)',
      icon: UserIcon,
      color: 'bg-emerald-100 text-emerald-600',
      features: [
        'Explorer les circuits touristiques à travers le Mali.',
        'Réserver des trajets avec paiement mobile simulé (Orange, Moov, Wave).',
        'Gérer ses réservations et accéder à son QR code de voyage.',
        'Ajouter des circuits en favoris pour une consultation ultérieure.'
      ]
    },
    {
      role: 'Guide Touristique',
      icon: Map,
      color: 'bg-amber-100 text-amber-600',
      features: [
        'Créer et proposer de nouveaux circuits touristiques.',
        'Gérer les réservations des clients pour ses trajets.',
        'Exporter les listes de passagers au format Excel.',
        'Suivre ses revenus et statistiques d\'activité.'
      ]
    },
    {
      role: 'Administrateur',
      icon: Shield,
      color: 'bg-purple-100 text-purple-600',
      features: [
        'Valider ou rejeter les nouveaux circuits proposés par les guides.',
        'Gérer l\'ensemble des utilisateurs et leurs rôles.',
        'Superviser toutes les réservations et les flux financiers.',
        'Mode Sandbox pour tester l\'application avec des données fictives.'
      ]
    }
  ];

  const steps = [
    { title: 'Connexion', desc: 'Choisissez votre rôle et connectez-vous via Google, Email ou Téléphone.', icon: Smartphone },
    { title: 'Exploration', desc: 'Recherchez une destination ou un circuit qui vous passionne.', icon: Compass },
    { title: 'Réservation', desc: 'Remplissez vos informations et payez via votre mobile.', icon: CreditCard },
    { title: 'Voyage', desc: 'Présentez votre QR code au guide le jour du départ.', icon: Ticket }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-16 pb-20">
      {/* Hero Section */}
      <div className="text-center space-y-6">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-20 h-20 bg-stone-900 rounded-[2rem] flex items-center justify-center mx-auto shadow-2xl"
        >
          <BookOpen className="text-white" size={32} />
        </motion.div>
        <h1 className="text-5xl font-black text-stone-900 tracking-tight">Guide d'Utilisation MaliTrek</h1>
        <p className="text-stone-500 font-medium text-xl max-w-2xl mx-auto">
          Tout ce que vous devez savoir pour naviguer et profiter pleinement de la plateforme MaliTrek.
        </p>
      </div>

      {/* Roles Section */}
      <div className="grid md:grid-cols-3 gap-8">
        {roles.map((role, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-8 rounded-[3rem] border border-stone-100 shadow-sm hover:shadow-xl transition-all"
          >
            <div className={`w-16 h-16 ${role.color} rounded-2xl flex items-center justify-center mb-6 shadow-sm`}>
              <role.icon size={28} />
            </div>
            <h3 className="text-xl font-black text-stone-900 mb-6">{role.role}</h3>
            <ul className="space-y-4">
              {role.features.map((feature, j) => (
                <li key={j} className="flex items-start gap-3 text-sm text-stone-500 font-medium leading-relaxed">
                  <CheckCircle2 size={18} className="text-emerald-500 shrink-0 mt-0.5" />
                  {feature}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      {/* Workflow Section */}
      <div className="bg-stone-900 rounded-[4rem] p-12 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cubes.png')" }} />
        <div className="relative z-10">
          <h2 className="text-3xl font-black mb-12 text-center tracking-tight">Comment ça marche ?</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
            {steps.map((step, i) => (
              <div key={i} className="relative text-center space-y-4">
                <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center mx-auto mb-6 border border-white/10">
                  <step.icon size={28} className="text-emerald-400" />
                </div>
                <h4 className="text-lg font-black">{step.title}</h4>
                <p className="text-stone-400 text-sm font-medium leading-relaxed">{step.desc}</p>
                {i < steps.length - 1 && (
                  <ArrowRight className="hidden lg:block absolute top-8 -right-5 text-stone-700" size={20} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ / Support */}
      <div className="bg-white rounded-[3rem] border border-stone-100 p-12 shadow-sm">
        <div className="flex items-center gap-4 mb-10">
          <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center">
            <HelpCircle size={24} />
          </div>
          <h2 className="text-2xl font-black text-stone-900 tracking-tight">Besoin d'aide ?</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-4">
            <h4 className="font-black text-stone-900">Comment devenir guide ?</h4>
            <p className="text-stone-500 text-sm font-medium leading-relaxed">
              Inscrivez-vous en choisissant le rôle "Guide". Votre profil sera examiné par nos administrateurs avant que vous ne puissiez proposer vos premiers circuits.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="font-black text-stone-900">Les paiements sont-ils réels ?</h4>
            <p className="text-stone-500 text-sm font-medium leading-relaxed">
              Pour le moment, MaliTrek utilise une simulation de paiement mobile sécurisée pour faciliter les tests et la démonstration de la plateforme.
            </p>
          </div>
        </div>
      </div>

      {/* Credentials Info */}
      <div className="bg-amber-50 border border-amber-100 rounded-[3rem] p-10">
        <h3 className="text-amber-900 font-black mb-4 flex items-center gap-2">
          <Shield size={20} /> Accès de Test (Sandbox)
        </h3>
        <p className="text-amber-800 text-sm font-medium mb-6">
          Pour tester les différentes fonctionnalités, vous pouvez utiliser les comptes suivants ou créer les vôtres :
        </p>
        <div className="grid sm:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-amber-200">
            <p className="text-[10px] font-black text-amber-500 uppercase tracking-widest mb-2">Administrateur</p>
            <p className="text-stone-900 font-bold text-sm">diabateamadou88@gmail.com</p>
            <p className="text-stone-400 text-xs mt-1">Accès complet à la gestion</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-amber-200">
            <p className="text-[10px] font-black text-amber-500 uppercase tracking-widest mb-2">Nouveaux Utilisateurs</p>
            <p className="text-stone-900 font-bold text-sm">Inscription libre</p>
            <p className="text-stone-400 text-xs mt-1">Choisissez votre rôle à l'inscription</p>
          </div>
        </div>
      </div>
    </div>
  );
};

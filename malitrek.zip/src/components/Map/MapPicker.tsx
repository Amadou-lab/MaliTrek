import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Target, MapPinIcon } from 'lucide-react';

// Fix for default marker icon in Leaflet
const DefaultIcon = L.icon({
    iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

interface MapPickerProps {
    initialLat: number;
    initialLng: number;
    onLocationSelect: (lat: number, lng: number) => void;
}

const LocationMarker = ({ position, setPosition }: { position: L.LatLng, setPosition: (pos: L.LatLng) => void }) => {
    const map = useMap();
    
    useMapEvents({
        click(e) {
            setPosition(e.latlng);
        },
    });

    React.useEffect(() => {
        map.setView(position);
    }, [position, map]);

    return (
        <Marker position={position} icon={DefaultIcon} />
    );
};

export const MapPicker: React.FC<MapPickerProps> = ({ initialLat, initialLng, onLocationSelect }) => {
    const [position, setPosition] = useState<L.LatLng>(new L.LatLng(initialLat, initialLng));

    const handleLocateMe = () => {
        if (!navigator.geolocation) {
            alert("La géolocalisation n'est pas supportée par votre navigateur");
            return;
        }

        navigator.geolocation.getCurrentPosition((pos) => {
            const newPos = new L.LatLng(pos.coords.latitude, pos.coords.longitude);
            setPosition(newPos);
            onLocationSelect(newPos.lat, newPos.lng);
        }, (err) => {
            console.error(err);
        });
    };

    return (
        <div className="space-y-4">
            <div className="relative h-64 rounded-[2rem] overflow-hidden border-2 border-stone-100 shadow-xl group">
                <MapContainer center={position} zoom={6} style={{ height: '100%', width: '100%', zIndex: 10 }}>
                    <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    />
                    <LocationMarker position={position} setPosition={(pos) => {
                        setPosition(pos);
                        onLocationSelect(pos.lat, pos.lng);
                    }} />
                </MapContainer>
                
                <button 
                    type="button"
                    onClick={handleLocateMe}
                    className="absolute top-4 right-4 z-[400] bg-white p-3 rounded-2xl shadow-lg border border-stone-100 text-stone-600 hover:text-emerald-600 hover:scale-110 active:scale-95 transition-all"
                    title="Utiliser ma position"
                >
                    <Target size={20} />
                </button>

                <div className="absolute bottom-4 left-4 right-4 z-[400] flex justify-center">
                    <div className="bg-stone-900/80 backdrop-blur-md text-white text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-full flex items-center gap-2">
                        <MapPinIcon size={12} className="text-emerald-400" />
                        Point sélectionné
                    </div>
                </div>
            </div>

            <div className="flex justify-between items-center px-4">
                <div className="flex gap-6">
                    <div className="flex flex-col">
                        <span className="text-[10px] font-black text-stone-300 uppercase tracking-widest">Latitude</span>
                        <span className="text-xs font-black text-stone-900 font-mono">{position.lat.toFixed(6)}</span>
                    </div>
                    <div className="flex flex-col">
                        <span className="text-[10px] font-black text-stone-300 uppercase tracking-widest">Longitude</span>
                        <span className="text-xs font-black text-stone-900 font-mono">{position.lng.toFixed(6)}</span>
                    </div>
                </div>
                <div className="text-right">
                    <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Aide</p>
                    <p className="text-[10px] font-bold text-stone-500">Cliquez sur la carte pour définir le point principal</p>
                </div>
            </div>
        </div>
    );
};

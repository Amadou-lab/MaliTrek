import React from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface MapPickerProps {
  initialLat: number;
  initialLng: number;
  onLocationSelect: (lat: number, lng: number) => void;
}

function LocationMarker({ lat, lng, onSelect }: { lat: number, lng: number, onSelect: (lat: number, lng: number) => void }) {
  const map = useMapEvents({
    click(e) {
      onSelect(e.latlng.lat, e.latlng.lng);
    },
  });

  return (
    <Marker position={[lat, lng]} />
  );
}

export const MapPicker: React.FC<MapPickerProps> = ({ initialLat, initialLng, onLocationSelect }) => {
  return (
    <div className="h-64 w-full rounded-2xl overflow-hidden border-2 border-stone-100 relative group">
      <MapContainer 
        center={[initialLat, initialLng]} 
        zoom={10} 
        scrollWheelZoom={false}
        className="h-full w-full"
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        />
        <LocationMarker lat={initialLat} lng={initialLng} onSelect={onLocationSelect} />
      </MapContainer>
      <div className="absolute top-4 right-4 z-[400] bg-white/90 backdrop-blur px-3 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest text-stone-500 shadow-sm">
        Cliquez pour placer le marqueur
      </div>
    </div>
  );
};

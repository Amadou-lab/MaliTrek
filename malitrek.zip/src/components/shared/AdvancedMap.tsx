import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Circuit, Journey, POI, ItineraryStep } from '../../types';
import { MapPin, Navigation, Map as MapIcon, Star, Clock } from 'lucide-react';

// Fix for default marker icons in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface AdvancedMapProps {
  center?: [number, number];
  zoom?: number;
  circuits?: Circuit[];
  journeys?: Journey[];
  pois?: POI[];
  itinerary?: ItineraryStep[];
  selectedId?: string;
  onMarkerClick?: (id: string, type: 'circuit' | 'journey' | 'poi' | 'step') => void;
  interactive?: boolean;
  onMapClick?: (lat: number, lng: number) => void;
  showPolyline?: boolean;
  userLocation?: [number, number];
  className?: string;
}

// Component to handle map centering and auto-zoom
function MapController({ center, zoom, bounds }: { center?: [number, number], zoom?: number, bounds?: L.LatLngBoundsExpression }) {
  const map = useMap();
  
  useEffect(() => {
    if (bounds) {
      map.fitBounds(bounds, { padding: [50, 50] });
    } else if (center) {
      map.setView(center, zoom || map.getZoom());
    }
  }, [center, zoom, bounds, map]);

  return null;
}

// Component to handle click events on the map
function ClickHandler({ onClick }: { onClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export const AdvancedMap: React.FC<AdvancedMapProps> = ({
  center = [12.6392, -8.0029], // Bamako default
  zoom = 12,
  circuits = [],
  journeys = [],
  pois = [],
  itinerary = [],
  selectedId,
  onMarkerClick,
  interactive = true,
  onMapClick,
  showPolyline = true,
  userLocation,
  className = "h-full w-full"
}) => {
  const [bounds, setBounds] = useState<L.LatLngBoundsExpression | undefined>(undefined);

  // Calculate bounds if we have multiple points
  useEffect(() => {
    const points: [number, number][] = [];
    circuits.forEach(c => { 
      const bLat = c.lat || c.itinerary?.[0]?.lat;
      const bLng = c.lng || c.itinerary?.[0]?.lng;
      if (bLat && bLng) points.push([bLat, bLng]); 
    });
    journeys.forEach(j => { 
        // We look for circuit data in the journey or itinerary
        if (j.currentPosition) points.push([j.currentPosition.lat, j.currentPosition.lng]);
    });
    pois.forEach(p => points.push([p.lat, p.lng]));
    itinerary.forEach(s => { if (s.lat && s.lng) points.push([s.lat, s.lng]); });

    if (points.length > 1) {
      const b = L.latLngBounds(points);
      const newBounds = b.pad(0.1);
      
      // Use JSON.stringify or a similar check to avoid reference-only updates if possible, 
      // or just compare with previous bounds if we want to be very safe.
      // Leaflet bounds don't have a simple way to compare without the object instance unless we use getCenter/getNorthEast etc.
      // But we can just use a simple check on the corners.
      setBounds(prev => {
        if (!prev) return newBounds;
        // @ts-ignore - Leaflet LatLngBounds has methods to compare
        if (prev.equals(newBounds)) return prev;
        return newBounds;
      });
    }
  }, [circuits, journeys, pois, itinerary]);

  const createIcon = (color: string, icon: React.ReactNode) => {
    return L.divIcon({
      className: 'custom-marker-icon',
      html: `
        <div class="relative flex items-center justify-center">
          <div class="absolute w-10 h-10 bg-${color}-500/20 rounded-full animate-ping"></div>
          <div class="relative w-8 h-8 bg-${color}-500 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white">
            ${L.Util.template('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>', { inner: '' })}
          </div>
          <div class="absolute -bottom-1 w-2 h-2 bg-${color}-500 rotate-45 border-b border-r border-white"></div>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
    });
  };

  const circuitIcon = L.divIcon({
    className: 'custom-marker-icon',
    html: '<div class="w-8 h-8 bg-emerald-primary rounded-full border-2 border-white shadow-lg flex items-center justify-center text-emerald-accent"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-map-pin"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg></div>',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
  });

  const poiIcon = L.divIcon({
    className: 'custom-marker-icon',
    html: '<div class="w-8 h-8 bg-black rounded-full border-2 border-white shadow-lg flex items-center justify-center text-emerald-accent"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-camera"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg></div>',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
  });

  const stepIcon = (num: number) => L.divIcon({
    className: 'custom-marker-icon',
    html: `<div class="w-7 h-7 bg-emerald-900 rounded-full border-2 border-white shadow-lg flex items-center justify-center text-emerald-accent font-black text-[10px] italic">${num}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });

  const userIcon = L.divIcon({
    className: 'custom-marker-icon',
    html: '<div class="w-6 h-6 bg-emerald-accent rounded-full border-2 border-white shadow-lg relative"><div class="absolute inset-0 bg-emerald-accent rounded-full animate-ping opacity-50"></div></div>',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });

  const polylinePositions = itinerary
    .filter(s => s.lat && s.lng)
    .sort((a, b) => a.day - b.day)
    .map(s => [s.lat!, s.lng!] as [number, number]);

  return (
    <div className={className}>
      <MapContainer 
        center={center} 
        zoom={zoom} 
        scrollWheelZoom={interactive}
        zoomControl={interactive}
        attributionControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
          subdomains="abcd"
          maxZoom={20}
        />
        
        <MapController center={center} zoom={zoom} bounds={bounds} />
        {onMapClick && <ClickHandler onClick={onMapClick} />}

        {/* User Location */}
        {userLocation && (
          <Marker position={userLocation} icon={userIcon}>
            <Popup>Vous êtes ici</Popup>
          </Marker>
        )}

        {/* Circuits */}
        {circuits.map(circuit => {
          const displayLat = circuit.lat || circuit.itinerary?.[0]?.lat;
          const displayLng = circuit.lng || circuit.itinerary?.[0]?.lng;
          
          if (!displayLat || !displayLng) return null;

          return (
            <Marker 
              key={circuit.id} 
              position={[displayLat, displayLng]} 
              icon={circuitIcon}
              eventHandlers={{
                click: () => onMarkerClick?.(circuit.id, 'circuit'),
              }}
            >
              <Popup className="custom-popup">
                <div className="w-48 space-y-2">
                  <img src={circuit.image} alt={circuit.title} className="w-full h-24 object-cover rounded-lg" />
                  <h3 className="font-black text-xs text-stone-900 leading-tight">{circuit.title}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-emerald-600">{circuit.basePrice.toLocaleString()} CFA</span>
                    <div className="flex items-center gap-1">
                      <Star size={10} className="text-amber-400 fill-amber-400" />
                      <span className="text-[10px] font-bold">{circuit.averageRating?.toFixed(1) || 'N/A'}</span>
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}

        {/* POIs */}
        {pois.map(poi => (
          <Marker 
            key={poi.id} 
            position={[poi.lat, poi.lng]} 
            icon={poiIcon}
            eventHandlers={{
                click: () => onMarkerClick?.(poi.id, 'poi'),
            }}
          >
            <Popup>
              <div className="w-40 space-y-1">
                {poi.image && <img src={poi.image} className="w-full h-20 object-cover rounded-lg" />}
                <p className="font-black text-xs">{poi.name}</p>
                <p className="text-[9px] text-stone-500 uppercase">{poi.category}</p>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* Itinerary Steps */}
        {itinerary.map((step, idx) => (
          step.lat && step.lng && (
            <Marker 
              key={step.id} 
              position={[step.lat, step.lng]} 
              icon={stepIcon(idx + 1)}
              eventHandlers={{
                click: () => onMarkerClick?.(step.id, 'step'),
              }}
            >
              <Popup>
                <div className="w-40">
                  <p className="font-black text-xs">Étape {idx + 1}: {step.title}</p>
                  <p className="text-[9px] text-stone-500">{step.duration || 'Durée non spécifiée'}</p>
                </div>
              </Popup>
            </Marker>
          )
        ))}

        {/* Polylines */}
        {showPolyline && polylinePositions.length > 1 && (
          <Polyline 
            positions={polylinePositions} 
            color="#10b981" 
            weight={4} 
            dashArray="10, 15" 
            opacity={0.8}
          />
        )}
      </MapContainer>
    </div>
  );
};

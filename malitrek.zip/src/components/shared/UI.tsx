import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ children, className = '', onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={`bg-white dark:bg-stone-900 rounded-[2.5rem] p-8 border border-stone-100 dark:border-stone-800 shadow-sm ${className} ${onClick ? 'cursor-pointer active:scale-[0.98] transition-all' : ''}`}
    >
      {children}
    </div>
  );
};

export const Badge: React.FC<{ children: React.ReactNode; variant?: 'success' | 'warning' | 'error' | 'info' | 'neutral' | 'stone'; className?: string }> = ({ children, variant = 'neutral', className = '' }) => {
  const variants = {
    success: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
    warning: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
    error: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400',
    info: 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-400',
    neutral: 'bg-stone-100 text-stone-700 dark:bg-stone-800 dark:text-stone-400',
    stone: 'bg-stone-100 text-stone-700 border border-stone-200'
  };

  return (
    <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.2em] ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
};

export const PremiumLoading: React.FC<{ message?: string }> = ({ message = "Préparation de l'expédition..." }) => {
  return (
    <div className="flex flex-col items-center justify-center gap-10 py-32">
       <div className="relative">
          <div className="w-24 h-24 bg-emerald-accent/20 rounded-[2rem] animate-ping absolute inset-0" />
          <div className="w-24 h-24 bg-emerald-primary rounded-[2rem] flex items-center justify-center relative shadow-2xl rotate-3">
             <div className="w-8 h-8 rounded-full border-4 border-emerald-accent border-t-transparent animate-spin" />
          </div>
       </div>
       <div className="text-center space-y-3">
          <p className="text-sm font-black text-emerald-primary uppercase tracking-[0.5em]">{message}</p>
          <div className="flex justify-center gap-1.5">
             {[0, 1, 2].map(i => (
                <div key={i} className="w-1.5 h-1.5 bg-emerald-accent rounded-full animate-bounce" style={{ animationDelay: `${i * 0.2}s` }} />
             ))}
          </div>
       </div>
    </div>
  );
};

export const BottomSheet: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  title: string; 
  children: React.ReactNode 
}> = ({ isOpen, onClose, title, children }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-stone-950/40 backdrop-blur-sm z-[70] md:hidden"
            onClick={onClose}
          />
          <motion.div 
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 bg-white dark:bg-stone-900 z-[75] rounded-t-[3rem] shadow-2xl pb-safe md:hidden max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-white/80 dark:bg-stone-900/80 backdrop-blur-md px-8 py-6 border-b border-stone-100 dark:border-stone-800 flex justify-between items-center z-10">
              <h3 className="text-xl font-serif font-black text-emerald-primary tracking-tight italic">{title}</h3>
              <button onClick={onClose} className="w-10 h-10 rounded-full bg-stone-50 dark:bg-stone-800 flex items-center justify-center text-stone-400">
                <span className="sr-only">Fermer</span>
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-8 pb-32">
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

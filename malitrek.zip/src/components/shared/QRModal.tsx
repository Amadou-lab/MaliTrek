import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, QrCode, ShieldCheck, Ticket } from 'lucide-react';

interface QRModalProps {
  isOpen: boolean;
  onClose: () => void;
  reservationId: string;
  itemName: string;
  passengers: number;
  date: string;
}

export const QRModal: React.FC<QRModalProps> = ({ 
  isOpen, 
  onClose, 
  reservationId, 
  itemName, 
  passengers,
  date 
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative bg-white rounded-[3rem] w-full max-w-sm overflow-hidden shadow-2xl"
          >
            <div className="bg-stone-900 p-8 text-center space-y-2">
               <div className="flex justify-between items-center mb-4">
                  <Ticket className="text-emerald-500" size={24} />
                  <button onClick={onClose} className="p-2 bg-white/10 rounded-xl text-white hover:bg-white/20 transition-all">
                    <X size={20} />
                  </button>
               </div>
               <h3 className="text-white text-xl font-black tracking-tight">{itemName}</h3>
               <p className="text-stone-400 text-[10px] font-black uppercase tracking-[0.2em]">Carte d'embarquement MaliTrek</p>
            </div>

            <div className="p-8 space-y-8 bg-white relative">
              {/* Ticket cut-out simulation */}
              <div className="absolute top-0 left-0 right-0 h-px bg-stone-100 flex justify-between px-6 -translate-y-px">
                 <div className="w-8 h-8 rounded-full bg-stone-900 -mt-4 -ml-12" />
                 <div className="w-8 h-8 rounded-full bg-stone-900 -mt-4 -mr-12" />
              </div>

              <div className="flex justify-center py-4">
                <div className="p-6 bg-stone-50 rounded-[2.5rem] border-2 border-dashed border-stone-200">
                   <QrCode size={160} className="text-stone-900" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-1">
                    <p className="text-[9px] font-black uppercase tracking-widest text-stone-400">Date</p>
                    <p className="text-xs font-black text-stone-900">{date}</p>
                 </div>
                 <div className="space-y-1 text-right">
                    <p className="text-[9px] font-black uppercase tracking-widest text-stone-400">Passagers</p>
                    <p className="text-xs font-black text-stone-900">{passengers}</p>
                 </div>
              </div>

              <div className="pt-6 border-t border-stone-50 flex flex-col items-center gap-3">
                 <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-4 py-2 rounded-full border border-emerald-100">
                    <ShieldCheck size={14} />
                    <span className="text-[10px] font-black uppercase tracking-widest">Paiement Sécurisé</span>
                 </div>
                 <p className="text-[8px] font-bold text-stone-400 uppercase tracking-widest text-center leading-relaxed">
                   ID: {reservationId.substring(0, 8).toUpperCase()}<br/>
                   Présentez ce QR Code au guide au départ.
                 </p>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React, { useEffect } from 'react';
import { offlineService } from '../../services/offlineService';
import { trekService } from '../../services/trekService';
import { OfflineAction, UserProfile } from '../../types';
import { useAuth } from '../../contexts/AuthContext'; // Assuming context exists or using profile

export const SyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { profile } = useAuth() as { profile: UserProfile | null };

  useEffect(() => {
    if (!profile) return;

    const handleSyncAction = async (e: any) => {
      const action = e.detail as OfflineAction;
      console.log(`[SyncProvider] Processing background sync: ${action.type}`);
      
      try {
        switch (action.type) {
          case 'CHECK_IN':
            await trekService.guideMarkPresence(action.payload.resId, profile.uid, action.payload.status);
            break;
          case 'NEXT_STEP':
            await trekService.advanceJourneyStep(action.payload.journeyId, action.payload.currentIndex);
            break;
          case 'INCIDENT':
            await trekService.reportIncident(action.payload.data);
            break;
          case 'PAUSE':
            await trekService.pauseJourney(action.payload.journeyId, action.payload.reason);
            break;
          case 'RESUME':
            await trekService.resumeJourney(action.payload.journeyId);
            break;
          case 'START':
            await trekService.startJourney(action.payload.journeyId, action.payload.guideId);
            break;
        }
      } catch (err) {
        console.error(`[SyncProvider] Background sync failed for ${action.id}:`, err);
        throw err; // Allow offlineService to catch and stop queue
      }
    };

    window.addEventListener('malitrek_sync_action', handleSyncAction);
    
    // Background sync check every 30s
    const intv = setInterval(() => {
      if (navigator.onLine) {
        offlineService.sync();
      }
    }, 30000);

    return () => {
      window.removeEventListener('malitrek_sync_action', handleSyncAction);
      clearInterval(intv);
    };
  }, [profile?.uid]);

  return <>{children}</>;
};

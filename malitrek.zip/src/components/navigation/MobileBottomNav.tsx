import React from 'react';
import { Menu, Map } from 'lucide-react';
import { motion } from 'motion/react';

interface MobileBottomNavProps {
  items: any[];
  activeView: string;
  onViewChange: (view: string) => void;
  unreadCount: number;
  unreadMessagesCount: number;
  setIsMenuOpen: (open: boolean) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  items,
  activeView,
  onViewChange,
  unreadCount,
  unreadMessagesCount,
  setIsMenuOpen
}) => {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 h-20 bg-white/95 dark:bg-stone-900/95 backdrop-blur-xl border-t border-stone-200/60 flex justify-around items-center z-[60] px-2 pb-safe shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
      {items.slice(0, 5).map((item) => (
        <button 
          key={item.id}
          onClick={() => onViewChange(item.id)}
          className={`flex-1 flex flex-col items-center justify-center gap-1 transition-all relative h-full ${
            activeView === item.id ? 'text-emerald-primary' : 'text-stone-400 hover:text-emerald-primary/60'
          }`}
        >
          <div className="relative p-1">
            <item.icon size={20} strokeWidth={activeView === item.id ? 2.5 : 2} />
            {(item.id === 'notifications' && unreadCount > 0) || (item.id === 'messages' && unreadMessagesCount > 0) || (item.id === 'dashboard' && unreadCount > 0) ? (
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-accent rounded-full border-2 border-white dark:border-stone-900" />
            ) : null}
          </div>
          <span className={`text-[9px] font-black uppercase tracking-tighter transition-all ${
            activeView === item.id ? 'opacity-100 scale-100' : 'opacity-60 scale-95'
          }`}>
            {item.label.split(' ')[0]}
          </span>
          {activeView === item.id && (
            <motion.div 
              layoutId="mobileActiveNavIndicator"
              className="absolute top-0 inset-x-4 h-0.5 bg-emerald-primary rounded-b-full shadow-[0_4px_12px_rgba(16,185,129,0.3)]"
            />
          )}
        </button>
      ))}
      <button 
        onClick={() => setIsMenuOpen(true)}
        className="flex-1 flex flex-col items-center justify-center gap-1 text-stone-400 h-full"
      >
        <div className="p-1">
          <Menu size={20} />
        </div>
        <span className="text-[9px] font-black uppercase tracking-tighter opacity-60">Plus</span>
      </button>
    </nav>
  );
};

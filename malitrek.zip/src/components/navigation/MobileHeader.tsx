import React from 'react';
import { Map as MapIcon, Bell, Menu } from 'lucide-react';

interface MobileHeaderProps {
  onViewChange: (view: string) => void;
  unreadCount: number;
  unreadMessagesCount: number;
  setIsMenuOpen: (open: boolean) => void;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  onViewChange,
  unreadCount,
  unreadMessagesCount,
  setIsMenuOpen
}) => {
  return (
    <header className="md:hidden bg-sable-light/80 backdrop-blur-xl border-b border-stone-200/60 h-20 p-4 px-6 flex justify-between items-center sticky top-0 z-[55]">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-emerald-primary rounded-xl flex items-center justify-center shadow-lg shadow-emerald-900/10 rotate-3">
          <MapIcon className="text-emerald-accent w-5 h-5" />
        </div>
        <span className="font-serif italic font-black text-emerald-primary text-2xl tracking-tight">MaliTrek</span>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={() => onViewChange('notifications')}
          className="relative w-10 h-10 rounded-full flex items-center justify-center text-stone-premium/40 hover:text-emerald-primary transition-colors"
        >
          <Bell size={20} />
          {unreadCount > 0 && (
            <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-emerald-accent rounded-full border-2 border-sable-light" />
          )}
        </button>
        <button 
          onClick={() => setIsMenuOpen(true)}
          className="w-10 h-10 bg-emerald-primary/5 rounded-xl flex items-center justify-center text-emerald-primary border border-emerald-primary/10"
        >
          <Menu size={20} />
        </button>
      </div>
    </header>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { Map as MapIcon, LogOut, Sun, Moon, Globe, X } from 'lucide-react';
import { UserProfile } from '../../types';

interface SidebarProps {
  profile: UserProfile | null;
  activeView: string;
  onViewChange: (view: string) => void;
  items: any[];
  onLogout: () => void;
  language: string;
  setLanguage: (lang: string) => void;
  theme: string;
  setTheme: (theme: string) => void;
  isMenuOpen: boolean;
  setIsMenuOpen: (open: boolean) => void;
  unreadCount: number;
  unreadMessagesCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  profile,
  activeView,
  onViewChange,
  items,
  onLogout,
  language,
  setLanguage,
  theme,
  setTheme,
  isMenuOpen,
  setIsMenuOpen,
  unreadCount,
  unreadMessagesCount
}) => {
  return (
    <aside className={`
      fixed inset-0 z-[70] bg-sable-light dark:bg-stone-950 md:relative md:translate-x-0 transition-transform duration-700 ease-in-out
      ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      md:w-80 md:border-r md:border-stone-200/60 flex flex-col shadow-2xl md:shadow-none
    `}>
      <div className="flex items-center justify-between p-8 md:p-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-primary rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-900/20 rotate-3">
            <MapIcon className="text-emerald-accent w-7 h-7" />
          </div>
          <div>
            <span className="font-serif italic font-black text-2xl text-emerald-primary dark:text-white tracking-tight block leading-none">MaliTrek</span>
            <span className="text-[8px] font-bold text-emerald-accent uppercase tracking-[0.3em] mt-1 block">Prestige Edition</span>
          </div>
        </div>
        <button onClick={() => setIsMenuOpen(false)} className="md:hidden p-2 text-stone-300 hover:text-emerald-accent transition-colors">
          <X size={24} />
        </button>
      </div>

      <nav className="flex-1 px-6 py-4 space-y-2 overflow-y-auto custom-scrollbar">
        <p className="text-[9px] font-bold text-stone-300 uppercase tracking-[0.3em] mb-4 ml-4">Tableau de Bord</p>
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              onViewChange(item.id);
              setIsMenuOpen(false);
            }}
            className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all duration-300 group relative overflow-hidden active:scale-95 ${
              activeView === item.id 
                ? 'bg-emerald-primary text-white shadow-lg shadow-emerald-900/10' 
                : 'text-stone-premium/50 hover:bg-emerald-primary/5 hover:text-emerald-primary'
            }`}
          >
            <div className="relative">
              <item.icon size={18} className={`transition-transform duration-500 ${activeView === item.id ? 'scale-110 text-emerald-accent' : 'group-hover:scale-110'}`} />
              {(item.id === 'notifications' && unreadCount > 0) || (item.id === 'messages' && unreadMessagesCount > 0) ? (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-accent rounded-full border-2 border-sable-light dark:border-stone-950" />
              ) : null}
            </div>
            <span className="font-bold text-[11px] uppercase tracking-wider">{item.label}</span>
            {activeView === item.id && (
              <motion.div 
                layoutId="activeNav"
                className="absolute left-0 w-1 h-1/2 bg-emerald-accent rounded-full"
              />
            )}
          </button>
        ))}
      </nav>

      {profile?.uid && (
        <div className="p-8 border-t border-stone-200/60 bg-stone-50/50">
          <div className="flex gap-3 mb-6">
            <button 
              onClick={() => setLanguage(language === 'fr' ? 'en' : 'fr')}
              className="flex-1 h-10 bg-white border border-stone-200 rounded-xl flex items-center justify-center gap-2 hover:bg-stone-50 transition-all text-xs font-bold uppercase tracking-widest text-stone-premium/60"
            >
              <Globe size={12} />
              <span>{language}</span>
            </button>
            <button 
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="flex-1 h-10 bg-white border border-stone-200 rounded-xl flex items-center justify-center gap-2 hover:bg-stone-50 transition-all text-xs font-bold uppercase tracking-widest text-stone-premium/60"
            >
              {theme === 'light' ? <Sun size={12} /> : <Moon size={12} />}
              <span>{theme}</span>
            </button>
          </div>

          <div className="flex items-center gap-4 p-4 mb-6 rounded-2xl bg-white border border-stone-200 shadow-sm">
            <div className="w-12 h-12 bg-emerald-accent/10 rounded-xl flex items-center justify-center text-emerald-primary font-serif italic font-black text-xl overflow-hidden border border-emerald-accent/20">
              {profile?.photoURL ? (
                <img src={profile.photoURL} alt={profile.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                profile?.displayName?.[0] || profile?.email?.[0]?.toUpperCase()
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-stone-premium truncate">{profile?.displayName}</p>
              <p className="text-[8px] text-emerald-accent uppercase tracking-[0.2em] font-bold truncate mt-0.5">
                {profile?.role.replace('ROLE_', '').toLowerCase()}
              </p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full h-12 flex items-center justify-center gap-3 text-stone-300 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all font-bold text-[10px] uppercase tracking-widest active:scale-95 border border-transparent hover:border-rose-100"
          >
            <LogOut size={16} />
            <span>Déconnexion</span>
          </button>
        </div>
      )}
    </aside>
  );
};

import { motion, AnimatePresence } from 'motion/react';
import { X, Compass, ShieldCheck, Users, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Journey, Reservation } from '../../types';

interface JourneyStepManagerModalProps {
  journey: Journey | null;
  reservations: Reservation[];
  onClose: () => void;
  onCompleteStep: (journeyId: string, stepId: string) => void;
}

export const JourneyStepManagerModal: React.FC<JourneyStepManagerModalProps> = ({
  journey,
  reservations,
  onClose,
  onCompleteStep
}) => {
  return (
    <AnimatePresence>
      {journey && (() => {
        const journeyRes = reservations.filter(r => r.journeyId === journey.id);
        return (
          <div 
            className="fixed inset-0 bg-stone-950/60 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto"
            onClick={onClose}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }} 
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white dark:bg-stone-900 rounded-[3rem] w-full max-w-2xl my-auto shadow-2xl border border-white/20 flex flex-col overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="bg-stone-900 p-10 text-white relative">
                 <button 
                   onClick={onClose}
                   className="absolute top-8 right-8 text-stone-400 hover:text-white transition-all"
                 >
                   <X size={24} />
                 </button>
                 <div className="flex items-center gap-6">
                   <div className="w-16 h-16 bg-emerald-600 rounded-[2rem] flex items-center justify-center shadow-inner">
                     <Compass size={32} />
                   </div>
                   <div>
                     <h3 className="text-3xl font-black tracking-tight leading-none mb-2">Gestion Individuelle</h3>
                     <p className="text-stone-400 font-bold uppercase tracking-widest text-xs">
                       {journey.title} • {journey.date ? new Date(journey.date).toLocaleDateString('fr-FR') : 'Date non définie'}
                     </p>
                   </div>
                 </div>
              </div>
              
              <div className="p-10 space-y-8 overflow-y-auto max-h-[60vh]">
                <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-3xl border border-emerald-100 dark:border-emerald-800 flex items-center gap-4">
                  <ShieldCheck size={24} className="text-emerald-600 shrink-0" />
                  <p className="text-xs font-bold text-emerald-800 dark:text-emerald-400 leading-relaxed italic">
                    "Marquez chaque étape comme atteinte pour informer vos clients de votre progression. La validation finale et le déblocage des fonds se feront à la fin du trajet."
                  </p>
                </div>

                <div className="space-y-6">
                  {(journey.itinerarySnapshot || []).map((step, index) => {
                    const stepParticipations = journeyRes.length;
                    const validatedCount = journeyRes.filter(r => 
                      r.itineraryProgress?.find(s => s.stepId === step.id && ['payé', 'validé'].includes(s.status))
                    ).length;
                    
                    const isFinishedByAll = validatedCount === stepParticipations && stepParticipations > 0;
                    const isMarkedByGuide = journeyRes.some(r => 
                      r.itineraryProgress?.find(s => s.stepId === step.id && s.status === 'en_attente_validation_client')
                    );

                    return (
                      <div key={step.id} className="bg-stone-50 dark:bg-stone-800 p-6 rounded-[2.5rem] border border-stone-100 dark:border-stone-700 group transition-all">
                         <div className="flex items-center gap-6 mb-6">
                           <div className="w-10 h-10 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl flex items-center justify-center text-xs font-black text-stone-400">
                             0{index + 1}
                           </div>
                           <div className="flex-1 min-w-0">
                             <h4 className="text-sm font-black text-stone-900 dark:text-white uppercase tracking-tight truncate">{step.title}</h4>
                             <div className="flex items-center gap-3 mt-1">
                                <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest flex items-center gap-1">
                                  <Users size={10} /> {validatedCount}/{stepParticipations} validés
                                </span>
                                {isMarkedByGuide && !isFinishedByAll && (
                                  <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest flex items-center gap-1">
                                    <RefreshCw size={10} className="animate-spin" /> En attente clients
                                  </span>
                                )}
                                {isFinishedByAll && (
                                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1">
                                    <CheckCircle2 size={10} /> Payé par tous
                                  </span>
                                )}
                             </div>
                           </div>
                           
                           {!isMarkedByGuide && !isFinishedByAll && stepParticipations > 0 && (
                             <button 
                               onClick={() => onCompleteStep(journey.id, step.id)}
                               className="bg-stone-900 dark:bg-emerald-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:bg-stone-800 shadow-lg shadow-stone-900/10 active:scale-95"
                             >
                               Marquer Atteint
                             </button>
                           )}
                           
                           {isFinishedByAll && (
                             <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 rounded-xl flex items-center justify-center">
                               <CheckCircle2 size={20} />
                             </div>
                           )}
                         </div>

                         {stepParticipations > 0 && (
                           <div className="w-full bg-stone-200 dark:bg-stone-700 h-1.5 rounded-full overflow-hidden">
                             <div 
                               className="bg-emerald-500 h-full transition-all duration-500"
                               style={{ width: `${(validatedCount / stepParticipations) * 100}%` }}
                             />
                           </div>
                         )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-10 border-t border-stone-50 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950">
                 <button 
                   onClick={onClose}
                   className="w-full bg-stone-900 dark:bg-stone-800 text-white py-5 rounded-[1.5rem] font-black uppercase tracking-widest text-[10px] shadow-xl shadow-stone-900/10 active:scale-95 transition-all"
                 >
                   Retour au dashboard
                 </button>
              </div>
            </motion.div>
          </div>
        );
      })()}
    </AnimatePresence>
  );
};

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MapPin, Compass, Zap, Tag, ShieldCheck, Star, Users } from 'lucide-react';
import { Circuit } from '../../types';
import { ItineraryOverview } from '../trek/ItineraryOverview';

interface CircuitDetailsModalProps {
  circuit: Circuit | null;
  onClose: () => void;
}

export const CircuitDetailsModal: React.FC<CircuitDetailsModalProps> = ({
  circuit,
  onClose
}) => {
  if (!circuit) return null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 bg-stone-950/60 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }} 
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white dark:bg-stone-900 rounded-[3rem] w-full max-w-5xl my-auto shadow-2xl border border-white/20 flex flex-col md:flex-row overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-full md:w-5/12 h-64 md:h-auto relative">
            <img 
              src={circuit.image || 'https://picsum.photos/seed/mali/1200/800'} 
              alt={circuit.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute top-8 left-8 flex gap-2">
              <div className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-xl backdrop-blur-md ${
                circuit.status === 'approved' ? 'bg-emerald-500/90 text-white' :
                circuit.status === 'rejected' ? 'bg-rose-500/90 text-white' :
                'bg-amber-500/90 text-white'
              }`}>
                {circuit.status === 'approved' ? 'Vérifié MaliTrek' : circuit.status}
              </div>
              <div className="px-4 py-2 bg-stone-900/40 backdrop-blur-md text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center gap-2">
                 <Star size={10} className="text-amber-400" />
                 {circuit.averageRating?.toFixed(1) || '0.0'} ({circuit.reviewCount || 0})
              </div>
            </div>
          </div>
          <div className="p-10 md:p-12 md:w-7/12 space-y-10 overflow-y-auto max-h-[70vh] md:max-h-[85vh] custom-scrollbar">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-4xl font-black text-stone-900 dark:text-white tracking-tight mb-3 leading-none">{circuit.title}</h2>
                <div className="flex items-center gap-4 text-stone-400 font-bold text-sm">
                  <span className="flex items-center gap-1.5"><MapPin size={16} className="text-emerald-600" /> {circuit.location}</span>
                  <span className="flex items-center gap-1.5"><Tag size={16} className="text-blue-500" /> {circuit.category}</span>
                </div>
              </div>
              <button onClick={onClose} className="p-3 bg-stone-100 dark:bg-stone-800 rounded-2xl text-stone-300 hover:text-stone-900 dark:hover:text-white transition-all">
                <X size={24} />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="bg-stone-50 dark:bg-stone-800 p-6 rounded-[2rem] border border-stone-100 dark:border-stone-700/50">
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-2">Tarif conseillé</p>
                <p className="text-2xl font-black text-stone-900 dark:text-white">{(circuit.basePrice || 0).toLocaleString()} <span className="text-xs">CFA</span></p>
              </div>
              <div className="bg-stone-50 dark:bg-stone-800 p-6 rounded-[2rem] border border-stone-100 dark:border-stone-700/50">
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-2">Durée estimée</p>
                <p className="text-2xl font-black text-stone-900 dark:text-white font-sans">{circuit.duration}</p>
              </div>
              <div className="bg-stone-50 dark:bg-stone-800 p-6 rounded-[2rem] border border-stone-100 dark:border-stone-700/50">
                <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-2">Membres min.</p>
                <div className="flex items-center gap-2">
                  <p className="text-2xl font-black text-stone-900 dark:text-white">{circuit.minParticipants || 1}</p>
                  <Users size={16} className="text-stone-400" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest">À propos du circuit</h4>
              <p className="text-lg font-medium text-stone-600 dark:text-stone-300 leading-relaxed">
                {circuit.description}
              </p>
            </div>

            <div className="space-y-6">
               <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest flex items-center gap-2">
                 <Compass size={14} className="text-emerald-500" /> Plan du voyage ({circuit.itinerary?.length || 0} étapes)
               </h4>
               <div className="bg-stone-50 dark:bg-stone-800/50 p-8 rounded-[2.5rem] border border-stone-100 dark:border-stone-800">
                  <ItineraryOverview itinerary={circuit.itinerary || []} currentStepIndex={-1} />
               </div>
            </div>

            <div className="pt-10 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <ShieldCheck size={20} className="text-emerald-500" />
                 <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-stone-900 dark:text-white">Garantie MaliTrek</p>
                    <p className="text-[10px] font-bold text-stone-400">Circuit validé et conforme aux normes de sécurité.</p>
                 </div>
              </div>
              <p className="text-[9px] font-mono text-stone-300">ID: {circuit.id}</p>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

import React from 'react';
import { Reservation } from '../../types';

interface ClientsListViewProps {
  reservations: Reservation[];
}

export const ClientsListView: React.FC<ClientsListViewProps> = ({
  reservations
}) => {
  const clients = Array.from(new Set(reservations.map(r => r.userId))).map(clientId => {
    const clientReservations = reservations.filter(r => r.userId === clientId);
    const lastRes = clientReservations[0];
    const totalPassengers = clientReservations.reduce((acc, curr) => acc + (curr.passengers || 0), 0);
    return {
      clientId,
      fullname: lastRes.clientName || lastRes.fullname || 'Client Inconnu',
      email: lastRes.userEmail,
      photo: lastRes.userPhoto,
      phone: lastRes.clientPhone || lastRes.phone || 'Non renseigné',
      lastDate: lastRes.createdAt,
      totalPassengers
    };
  });

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-stone-900 dark:text-white tracking-tight">Mes Clients</h2>
          <p className="text-stone-500 font-medium text-sm">Liste unique des voyageurs ayant réservé vos circuits.</p>
        </div>
      </div>

      <div className="bg-white dark:bg-stone-900 rounded-[2.5rem] shadow-sm border border-stone-100 dark:border-stone-800 overflow-hidden overflow-x-auto">
        <table className="w-full text-left min-w-[600px]">
          <thead>
            <tr className="bg-stone-50/50 dark:bg-stone-950/50 text-stone-400 text-[10px] font-black uppercase tracking-widest">
              <th className="px-8 py-5">Client</th>
              <th className="px-8 py-5">Contact</th>
              <th className="px-8 py-5">Dernière Reservation</th>
              <th className="px-8 py-5 text-center">Total Voyageurs</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-50 dark:divide-stone-800">
            {clients.map((client) => (
              <tr key={client.clientId} className="hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-all">
                <td className="px-8 py-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-stone-100 dark:bg-stone-800 rounded-xl overflow-hidden flex items-center justify-center text-stone-500 font-black">
                      {client.photo ? (
                        <img src={client.photo} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                      ) : (
                        client.fullname[0]
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-black text-stone-900 dark:text-white">{client.fullname}</p>
                      <p className="text-[10px] font-medium text-stone-400">{client.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <p className="text-sm font-medium text-stone-500">{client.phone}</p>
                </td>
                <td className="px-8 py-6">
                  <p className="text-xs font-bold text-stone-600 dark:text-stone-400">
                     {new Date(client.lastDate).toLocaleDateString('fr-FR')}
                  </p>
                </td>
                <td className="px-8 py-6 text-center">
                  <span className="bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                    {client.totalPassengers} Pers.
                  </span>
                </td>
              </tr>
            ))}
            {clients.length === 0 && (
              <tr>
                <td colSpan={4} className="p-20 text-center text-stone-400 font-bold">Aucun client pour le moment.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

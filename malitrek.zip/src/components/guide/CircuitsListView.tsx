import React from 'react';
import { motion } from 'motion/react';
import { Plus, MapPin, Calendar, Eye, Edit, Trash2, Image as ImageIcon } from 'lucide-react';
import { Circuit } from '../../types';

interface CircuitsListViewProps {
  circuits: Circuit[];
  onAdd: () => void;
  onPlanJourney: (circuit: Circuit) => void;
  onViewDetails: (circuit: Circuit) => void;
  onEdit: (circuit: Circuit) => void;
  onDelete: (id: string) => void;
  onSubmitForValidation: (id: string) => void;
  onClose: (id: string) => void;
  onReopen: (id: string) => void;
  onDisable?: (id: string) => void;
  onEnable?: (id: string) => void;
  isAdmin?: boolean;
}

export const CircuitsListView: React.FC<CircuitsListViewProps> = ({
  circuits,
  onAdd,
  onPlanJourney,
  onViewDetails,
  onEdit,
  onDelete,
  onSubmitForValidation,
  onClose,
  onReopen,
  onDisable,
  onEnable,
  isAdmin = false
}) => {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-stone-900 tracking-tight">Mes Circuits</h2>
          <p className="text-stone-500 font-medium text-sm">Gérez vos offres de voyage.</p>
        </div>
        <button 
          onClick={onAdd}
          className="w-12 h-12 bg-emerald-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
        >
          <Plus size={24} />
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {circuits.map(circuit => (
          <motion.div 
            key={circuit.id} 
            className="bg-white dark:bg-stone-900 rounded-[2.5rem] shadow-sm border border-stone-100 dark:border-stone-800 overflow-hidden flex flex-col sm:flex-row h-full sm:h-auto"
          >
            <div className="w-full sm:w-48 h-48 sm:h-auto relative">
              <img 
                src={circuit.image || 'https://picsum.photos/seed/mali/600/400'} 
                alt={circuit.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest shadow-xl ${
                circuit.status === 'approved' ? 'bg-emerald-500 text-white' :
                circuit.status === 'rejected' ? 'bg-rose-500 text-white' :
                circuit.status === 'pending_admin_validation' ? 'bg-amber-500 text-white' :
                circuit.status === 'closed' ? 'bg-stone-800 text-white' :
                circuit.status === 'disabled' ? 'bg-rose-950 text-white' :
                'bg-stone-500 text-white'
              }`}>
                {circuit.status === 'approved' ? 'Approuvé' : 
                 circuit.status === 'rejected' ? 'Rejeté' : 
                 circuit.status === 'pending_admin_validation' ? 'En attente' : 
                 circuit.status === 'closed' ? 'Fermé' :
                 circuit.status === 'disabled' ? 'Désactivé' : 'Brouillon'}
              </div>
            </div>
            <div className="p-8 flex-1 flex flex-col justify-between">
              <div className="w-full">
                <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-black text-stone-900 dark:text-white mb-2">{circuit.title}</h3>
                    <p className="text-xs text-stone-500 font-bold flex items-center gap-2">
                       <MapPin size={14} className="text-emerald-600" /> {circuit.location}, {circuit.region}
                    </p>
                    {(circuit.status === 'rejected' && circuit.rejectionReason) && (
                      <div className="mt-4 p-4 bg-rose-50 rounded-2xl border border-rose-100">
                        <p className="text-[10px] text-rose-600 font-black uppercase tracking-widest mb-1">Raison du refus</p>
                        <p className="text-xs text-rose-700 font-medium">{circuit.rejectionReason}</p>
                      </div>
                    )}
                    {circuit.status === 'closed' && (
                      <div className="mt-4 p-4 bg-stone-50 rounded-2xl border border-stone-100">
                        <p className="text-[10px] text-stone-600 font-black uppercase tracking-widest mb-1">Circuit Fermé</p>
                        <p className="text-xs text-stone-700 font-medium">{circuit.closedReason || 'Fermé par le guide.'}</p>
                      </div>
                    )}
                    {circuit.status === 'disabled' && (
                      <div className="mt-4 p-4 bg-rose-50 rounded-2xl border border-rose-200">
                        <p className="text-[10px] text-rose-900 font-black uppercase tracking-widest mb-1">Désactivé par l'Admin</p>
                        <p className="text-xs text-rose-800 font-medium">{circuit.disabledReason || 'Contactez le support.'}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {circuit.status === 'approved' && (
                      <>
                        <button 
                          onClick={() => onPlanJourney(circuit)}
                          className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-all flex items-center gap-2 border border-emerald-100 dark:border-emerald-800"
                        >
                          <Calendar size={14} /> Planifier un départ
                        </button>
                        <button 
                          onClick={() => onClose(circuit.id)}
                          className="bg-stone-100 text-stone-600 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-stone-200 transition-all border border-stone-200"
                        >
                          Fermer
                        </button>
                      </>
                    )}
                    {circuit.status === 'closed' && (
                      <button 
                        onClick={() => onReopen(circuit.id)}
                        className="bg-emerald-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
                      >
                        Réouvrir le circuit
                      </button>
                    )}
                    {isAdmin && circuit.status === 'disabled' && (
                      <button 
                        onClick={() => onEnable?.(circuit.id)}
                        className="bg-emerald-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
                      >
                        Réactiver
                      </button>
                    )}
                    {isAdmin && circuit.status !== 'disabled' && (
                      <button 
                        onClick={() => onDisable?.(circuit.id)}
                        className="bg-rose-50 text-rose-600 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-100 transition-all border border-rose-100"
                      >
                        Désactiver (Admin)
                      </button>
                    )}
                    {(circuit.status === 'draft' || circuit.status === 'rejected') && (
                      <button 
                        onClick={() => onSubmitForValidation(circuit.id)}
                        className="bg-stone-900 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all flex items-center gap-2"
                      >
                        Soumettre pour validation
                      </button>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row justify-between items-center pt-6 border-t border-stone-50 dark:border-stone-800 gap-4">
                <div className="flex flex-col">
                  <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest mb-1">Tarif de base</span>
                  <span className="font-black text-xl text-stone-900 dark:text-white leading-none">{(circuit.basePrice || 0).toLocaleString()} CFA</span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => onViewDetails(circuit)}
                    className="p-3 text-stone-400 hover:text-stone-900 dark:hover:text-white bg-stone-50 dark:bg-stone-800 hover:bg-stone-100 rounded-2xl transition-all"
                    title="Voir les détails"
                  >
                    <Eye size={20} />
                  </button>
                  {(circuit.status === 'draft' || circuit.status === 'rejected') && (
                    <>
                      <button 
                        onClick={() => onEdit(circuit)}
                        className="p-3 text-emerald-600 hover:text-white hover:bg-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl transition-all border border-emerald-100 dark:border-emerald-800"
                        title="Modifier"
                      >
                        <Edit size={20} />
                      </button>
                      <button 
                        onClick={() => onDelete(circuit.id)}
                        className="p-3 text-rose-500 hover:text-white hover:bg-rose-500 bg-rose-50 dark:bg-rose-900/20 rounded-2xl transition-all border border-rose-100 dark:border-rose-800"
                        title="Supprimer"
                      >
                        <Trash2 size={20} />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
        {circuits.length === 0 && (
          <div className="py-32 text-center bg-white dark:bg-stone-900 rounded-[3rem] border border-dashed border-stone-100 dark:border-stone-800">
            <div className="w-20 h-20 bg-stone-50 dark:bg-stone-800 rounded-3xl flex items-center justify-center mx-auto mb-6 text-stone-300">
               <ImageIcon size={40} />
            </div>
            <h3 className="text-xl font-black text-stone-900 dark:text-white mb-2">Aucun circuit créé</h3>
            <p className="text-stone-400 font-bold text-sm">Commencez par créer votre premier circuit template.</p>
            <button 
              onClick={onAdd}
              className="mt-8 bg-stone-900 dark:bg-emerald-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] active:scale-95 transition-all"
            >
              Créer mon premier circuit
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

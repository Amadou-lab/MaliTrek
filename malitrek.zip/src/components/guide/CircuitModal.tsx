import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Compass, Zap, Clock, Image as ImageIcon, MapPin, ArrowRight, ShieldCheck, CreditCard, Users, Calendar, Plus, Trash2, Star, ArrowUp, ArrowDown, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import { Circuit, ItineraryStep } from '../../types';
import { MapPicker } from '../shared/MapPicker';
import toast from 'react-hot-toast';

interface CircuitModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialData?: Circuit | null;
  onSubmit: (data: any) => void;
}

export const CircuitModal: React.FC<CircuitModalProps> = ({
  isOpen,
  onClose,
  initialData,
  onSubmit
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [durationValue, setDurationValue] = useState('');
  const [durationUnit, setDurationUnit] = useState('jours');
  
  const [formData, setFormData] = useState({
    title: '',
    location: '',
    basePrice: 0,
    duration: '',
    description: '',
    image: '',
    lat: 12.6392,
    lng: -8.0029,
    category: 'Culture' as 'Culture' | 'Nature' | 'Aventure' | 'Histoire' | 'Artisanat',
    maxParticipants: 15,
    minParticipants: 1,
    status: 'draft' as const,
    itinerary: [] as ItineraryStep[],
    inclus: [] as string[],
    nonInclus: [] as string[],
    cancellationPolicy: 'Annulation gratuite jusqu\'à 48h avant le départ.'
  });

  const [newItineraryStep, setNewItineraryStep] = useState<Partial<ItineraryStep>>({
    title: '',
    description: '',
    day: 1,
    estimatedTime: '08:00',
    activities: [],
    locationName: '',
    lat: 12.6392,
    lng: -8.0029,
    duration: '2h',
    notes: '',
    order: 0
  });

  const [currentActivity, setCurrentActivity] = useState('');

  useEffect(() => {
    if (initialData) {
      setFormData({
        ...initialData,
        lat: initialData.lat ?? 12.6392,
        lng: initialData.lng ?? -8.0029,
        itinerary: (initialData.itinerary || []).sort((a, b) => a.order - b.order)
      } as any); 
      // Parse duration if possible
      const match = initialData.duration?.match(/^(\d+)\s*(.*)$/);
      if (match) {
        setDurationValue(match[1]);
        setDurationUnit(match[2].toLowerCase());
      }
    } else {
      setFormData({
        title: '',
        location: '',
        basePrice: 0,
        duration: '',
        description: '',
        image: '',
        lat: 12.6392,
        lng: -8.0029,
        category: 'Culture',
        maxParticipants: 15,
        minParticipants: 4,
        status: 'draft',
        itinerary: [],
        inclus: [],
        nonInclus: [],
        cancellationPolicy: 'Annulation gratuite jusqu\'à 48h avant le départ.'
      });
      setCurrentStep(1);
    }
  }, [initialData, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentStep < 5) {
      setCurrentStep(prev => prev + 1);
      return;
    }
    
    if (formData.itinerary.length === 0) {
      return toast.error('Au moins une étape d\'itinéraire est obligatoire');
    }

    onSubmit({
      ...formData,
      duration: `${durationValue} ${durationUnit}`,
      maxParticipants: formData.maxParticipants,
      minParticipants: formData.minParticipants
    });
  };

  const addItineraryStep = () => {
    if (!newItineraryStep.title) return toast.error('Titre requis');
    if (!newItineraryStep.locationName) return toast.error('Localisation requise');

    const stepToAdd: ItineraryStep = {
      ...newItineraryStep,
      id: Math.random().toString(36).substr(2, 9),
      order: formData.itinerary.length,
      status: 'pending'
    } as ItineraryStep;

    setFormData({
      ...formData,
      itinerary: [
        ...formData.itinerary,
        stepToAdd
      ].sort((a, b) => a.order - b.order)
    });

    setNewItineraryStep({
      title: '',
      description: '',
      day: newItineraryStep.day || 1,
      estimatedTime: '08:00',
      activities: [],
      locationName: '',
      lat: newItineraryStep.lat,
      lng: newItineraryStep.lng,
      duration: '2h',
      notes: '',
      order: formData.itinerary.length + 1
    });
    toast.success('Étape ajoutée');
  };

  const moveStep = (index: number, direction: 'up' | 'down') => {
    const newItinerary = [...formData.itinerary];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newItinerary.length) return;

    [newItinerary[index], newItinerary[targetIndex]] = [newItinerary[targetIndex], newItinerary[index]];
    
    // Re-assign orders
    const updatedItinerary = newItinerary.map((s, i) => ({ ...s, order: i }));
    setFormData({ ...formData, itinerary: updatedItinerary });
  };

  const addActivity = () => {
    if (!currentActivity) return;
    setNewItineraryStep({
      ...newItineraryStep,
      activities: [...(newItineraryStep.activities || []), currentActivity]
    });
    setCurrentActivity('');
  };

  const removeItineraryStep = (id: string) => {
    setFormData({
      ...formData,
      itinerary: formData.itinerary.filter(s => s.id !== id)
    });
  };

  const steps = [
    { id: 1, label: 'Général', icon: <Zap size={18} />, color: 'emerald' },
    { id: 2, label: 'Pratique', icon: <Clock size={18} />, color: 'amber' },
    { id: 3, label: 'Détails', icon: <ImageIcon size={18} />, color: 'blue' },
    { id: 4, label: 'Lieu', icon: <MapPin size={18} />, color: 'rose' },
    { id: 5, label: 'Itinéraire', icon: <Compass size={18} />, color: 'emerald' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[150] flex items-center justify-center p-4 overflow-y-auto"
          onClick={onClose}
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 40 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 40 }}
            className="bg-white dark:bg-stone-900 rounded-[3.5rem] w-full max-w-4xl my-auto shadow-2xl border border-white/20 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col md:flex-row h-auto md:h-[750px]">
              {/* Sidebar Progress */}
              <div className="w-full md:w-80 bg-stone-50 dark:bg-stone-950 p-8 md:p-12 flex flex-col justify-between border-b md:border-b-0 md:border-r border-stone-100 dark:border-stone-800">
                <div className="space-y-12">
                  <div>
                    <div className="bg-emerald-600 w-12 h-12 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg shadow-emerald-600/20">
                      <Compass size={24} />
                    </div>
                    <h2 className="text-3xl font-black text-stone-900 dark:text-white tracking-tight leading-none">{initialData ? 'Modifier' : 'Créer'} un circuit</h2>
                    <p className="text-stone-400 font-bold text-sm mt-4">Partagez votre expertise avec le monde.</p>
                  </div>

                  <div className="hidden md:block space-y-6">
                    {steps.map((step) => (
                      <div key={step.id} className="flex items-center gap-4 group">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                          currentStep === step.id 
                            ? `bg-stone-900 text-white shadow-lg` 
                            : 'bg-stone-200/50 dark:bg-stone-800 text-stone-400'
                        }`}>
                          {step.icon}
                        </div>
                        <div className="flex flex-col">
                          <span className={`text-[10px] font-black uppercase tracking-widest ${currentStep === step.id ? `text-emerald-600` : 'text-stone-300'}`}>Étape 0{step.id}</span>
                          <span className={`text-sm font-bold ${currentStep === step.id ? 'text-stone-900 dark:text-white' : 'text-stone-400'}`}>{step.label}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="hidden md:block bg-stone-100 dark:bg-stone-800/50 p-6 rounded-3xl border border-stone-200/50 dark:border-stone-700">
                  <div className="flex items-center gap-3 mb-2">
                    <ShieldCheck size={16} className="text-emerald-600" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Sécurisé</span>
                  </div>
                  <p className="text-[10px] text-stone-500 leading-relaxed font-bold italic">Vos informations seront vérifiées par l'équipe avant publication.</p>
                </div>
              </div>

              {/* Main Content Area */}
              <form onSubmit={handleSubmit} className="flex-1 flex flex-col bg-white dark:bg-stone-900 overflow-hidden">
                <div className="p-8 md:p-12 flex-1 overflow-y-auto">
                  <AnimatePresence mode="wait">
                    {currentStep === 1 && (
                      <motion.div 
                        key="step1"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-10"
                      >
                        <div>
                          <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-widest rounded-full">🟢 Informations générales</span>
                          <h3 className="text-2xl font-black text-stone-900 dark:text-white mt-4 tracking-tight">Commençons par l'essentiel</h3>
                        </div>

                        <div className="space-y-8">
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2 flex items-center gap-2">
                              Nom du circuit <ArrowRight size={10} className="text-emerald-500" />
                            </label>
                            <input 
                              required
                              className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-[1.25rem] px-8 py-5 focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none font-bold text-stone-900 dark:text-white transition-all text-lg"
                              placeholder="ex: Aventure au Pays Dogon en 3 jours"
                              value={formData.title}
                              onChange={e => setFormData({...formData, title: e.target.value})}
                            />
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Catégorie d'expérience</label>
                            <div className="grid grid-cols-3 gap-3">
                              {['Culture', 'Nature', 'Aventure', 'Histoire', 'Artisanat'].map((cat) => (
                                <button
                                  key={cat}
                                  type="button"
                                  onClick={() => setFormData({...formData, category: cat as any})}
                                  className={`py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                    formData.category === cat 
                                      ? 'bg-stone-900 text-white shadow-xl scale-105' 
                                      : 'bg-stone-50 dark:bg-stone-800 text-stone-400 hover:bg-stone-100 border border-stone-100 dark:border-stone-700'
                                  }`}
                                >
                                  {cat}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {currentStep === 2 && (
                      <motion.div 
                        key="step2"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-10"
                      >
                        <div>
                          <span className="px-3 py-1 bg-amber-100 text-amber-700 text-[10px] font-black uppercase tracking-widest rounded-full">🟡 Détails pratiques</span>
                          <h3 className="text-2xl font-black text-stone-900 dark:text-white mt-4 tracking-tight">Logistique et budget</h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Lieu principal</label>
                            <div className="relative">
                              <MapPin size={18} className="absolute left-6 top-1/2 -translate-y-1/2 text-stone-400" />
                              <input 
                                required
                                className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl pl-14 pr-6 py-4 focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 outline-none font-bold text-stone-900 dark:text-white transition-all"
                                placeholder="ex: Bandiagara, Mopti"
                                value={formData.location}
                                onChange={e => setFormData({...formData, location: e.target.value})}
                              />
                            </div>
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Prix de base par personne (CFA)</label>
                            <div className="relative">
                              <CreditCard size={18} className="absolute left-6 top-1/2 -translate-y-1/2 text-stone-400" />
                              <input 
                                required
                                type="number"
                                className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl pl-14 pr-6 py-4 focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 outline-none font-bold text-stone-900 dark:text-white transition-all"
                                value={formData.basePrice}
                                onChange={e => setFormData({...formData, basePrice: Number(e.target.value)})}
                              />
                            </div>
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Durée</label>
                            <div className="flex gap-2">
                              <input 
                                required
                                type="number"
                                className="flex-1 bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 outline-none font-bold text-stone-900 dark:text-white transition-all text-center"
                                placeholder="ex: 3"
                                value={durationValue}
                                onChange={e => setDurationValue(e.target.value)}
                              />
                              <select
                                className="bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl px-4 py-4 font-bold text-stone-900 dark:text-white outline-none focus:ring-4 focus:ring-amber-500/10 transition-all appearance-none"
                                value={durationUnit}
                                onChange={e => setDurationUnit(e.target.value)}
                              >
                                <option value="heures">Heures</option>
                                <option value="jours">Jours</option>
                                <option value="semaines">Semaines</option>
                              </select>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Min participants</label>
                            <input 
                              required
                              type="number"
                              min="1"
                              className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 outline-none font-bold text-stone-900 dark:text-white transition-all text-center"
                              value={formData.minParticipants}
                              onChange={e => setFormData({...formData, minParticipants: Number(e.target.value)})}
                            />
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Max participants</label>
                            <input 
                              required
                              type="number"
                              className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 outline-none font-bold text-stone-900 dark:text-white transition-all text-center"
                              value={formData.maxParticipants}
                              onChange={e => setFormData({...formData, maxParticipants: Number(e.target.value)})}
                            />
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {currentStep === 3 && (
                      <motion.div 
                        key="step3"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-10"
                      >
                        <div>
                          <span className="px-3 py-1 bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-widest rounded-full">🔵 Description & détails</span>
                          <h3 className="text-2xl font-black text-stone-900 dark:text-white mt-4 tracking-tight">Détails de l'offre</h3>
                        </div>

                        <div className="space-y-8">
                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Description du circuit</label>
                            <textarea 
                              required
                              rows={4}
                              className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-[2.5rem] px-8 py-6 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-stone-900 dark:text-white transition-all resize-none leading-relaxed text-sm"
                              placeholder="Décrivez l'expérience..."
                              value={formData.description}
                              onChange={e => setFormData({...formData, description: e.target.value})}
                            />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2 flex items-center gap-2">
                                <CheckCircle2 size={12} className="text-emerald-500" /> Ce qui est inclus
                              </label>
                              <div className="space-y-2">
                                {formData.inclus.map((item, i) => (
                                  <div key={i} className="flex gap-2">
                                    <input 
                                      className="flex-1 bg-stone-50 dark:bg-stone-800 border border-stone-100 dark:border-stone-700 rounded-xl px-4 py-2 text-xs font-bold"
                                      value={item}
                                      onChange={e => {
                                        const newInclus = [...formData.inclus];
                                        newInclus[i] = e.target.value;
                                        setFormData({...formData, inclus: newInclus});
                                      }}
                                    />
                                    <button type="button" onClick={() => setFormData({...formData, inclus: formData.inclus.filter((_, idx) => idx !== i)})} className="p-2 text-stone-300 hover:text-rose-500"><Trash2 size={14} /></button>
                                  </div>
                                ))}
                                <button type="button" onClick={() => setFormData({...formData, inclus: [...formData.inclus, '']})} className="text-[10px] font-black uppercase text-emerald-600 flex items-center gap-2 hover:bg-emerald-50 p-2 rounded-lg transition-all w-full border border-dashed border-emerald-200">
                                  <Plus size={12} /> Ajouter inclus
                                </button>
                              </div>
                            </div>

                            <div className="space-y-4">
                              <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2 flex items-center gap-2">
                                <XCircle size={12} className="text-rose-500" /> Non inclus
                              </label>
                              <div className="space-y-2">
                                {formData.nonInclus.map((item, i) => (
                                  <div key={i} className="flex gap-2">
                                    <input 
                                      className="flex-1 bg-stone-50 dark:bg-stone-800 border border-stone-100 dark:border-stone-700 rounded-xl px-4 py-2 text-xs font-bold"
                                      value={item}
                                      onChange={e => {
                                        const newNonInclus = [...formData.nonInclus];
                                        newNonInclus[i] = e.target.value;
                                        setFormData({...formData, nonInclus: newNonInclus});
                                      }}
                                    />
                                    <button type="button" onClick={() => setFormData({...formData, nonInclus: formData.nonInclus.filter((_, idx) => idx !== i)})} className="p-2 text-stone-300 hover:text-rose-500"><Trash2 size={14} /></button>
                                  </div>
                                ))}
                                <button type="button" onClick={() => setFormData({...formData, nonInclus: [...formData.nonInclus, '']})} className="text-[10px] font-black uppercase text-rose-600 flex items-center gap-2 hover:bg-rose-50 p-2 rounded-lg transition-all w-full border border-dashed border-rose-200">
                                  <Plus size={12} /> Ajouter non-inclus
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2 flex items-center gap-2">
                              URL de l'image <ImageIcon size={12} className="text-blue-500" />
                            </label>
                            <input 
                              className="w-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-100 dark:border-stone-800 rounded-2xl px-8 py-4 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-stone-900 dark:text-white transition-all"
                              placeholder="https://..."
                              value={formData.image}
                              onChange={e => setFormData({...formData, image: e.target.value})}
                            />
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {currentStep === 4 && (
                      <motion.div 
                        key="step4"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-10"
                      >
                        <div>
                           <span className="px-3 py-1 bg-rose-100 text-rose-700 text-[10px] font-black uppercase tracking-widest rounded-full">📍 Localisation</span>
                           <h3 className="text-2xl font-black text-stone-900 dark:text-white mt-4 tracking-tight">Où commence l'aventure ?</h3>
                        </div>
                        <MapPicker 
                          initialLat={formData.lat} 
                          initialLng={formData.lng} 
                          onLocationSelect={(lat, lng) => setFormData({...formData, lat, lng})} 
                        />
                      </motion.div>
                    )}

                    {currentStep === 5 && (
                      <motion.div 
                        key="step5"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-10"
                      >
                         <div>
                            <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase tracking-widest rounded-full">🟢 Itinéraire détaillé</span>
                            <h3 className="text-2xl font-black text-stone-900 dark:text-white mt-4 tracking-tight">Détaillez les étapes de votre expérience</h3>
                         </div>
 
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 h-[550px]">
                            {/* Form Column */}
                            <div className="space-y-6 overflow-y-auto pr-4 no-scrollbar pb-12 font-sans font-medium tracking-tight text-gray-900">
                               <div className="bg-stone-50 dark:bg-stone-800/50 p-8 rounded-[2.5rem] border border-stone-100 dark:border-stone-800 space-y-6">
                                 <h4 className="text-xs font-black text-stone-900 dark:text-white uppercase tracking-widest flex items-center gap-2">
                                   <Plus size={16} className="text-emerald-600" /> Nouvelle étape
                                 </h4>
                                 
                                 <div className="grid grid-cols-2 gap-4">
                                   <div className="space-y-2">
                                     <label className="text-[9px] uppercase font-black text-stone-400 tracking-widest ml-2">Jour</label>
                                     <input type="number" min="1" className="w-full bg-white dark:bg-stone-800 rounded-2xl px-5 py-4 outline-none border-2 border-stone-100 dark:border-stone-700 font-bold text-sm" value={newItineraryStep.day || 1} onChange={e => setNewItineraryStep({...newItineraryStep, day: Number(e.target.value)})} />
                                   </div>
                                   <div className="space-y-2">
                                     <label className="text-[9px] uppercase font-black text-stone-400 tracking-widest ml-2">Heure estimée</label>
                                     <input type="time" className="w-full bg-white dark:bg-stone-800 rounded-2xl px-5 py-4 outline-none border-2 border-stone-100 dark:border-stone-700 font-bold text-sm" value={newItineraryStep.estimatedTime || '08:00'} onChange={e => setNewItineraryStep({...newItineraryStep, estimatedTime: e.target.value})} />
                                   </div>
                                 </div>
 
                                 <div className="space-y-2">
                                     <label className="text-[9px] uppercase font-black text-stone-400 tracking-widest ml-2">Titre de l'étape</label>
                                     <input placeholder="ex: Levée de soleil sur les falaises" className="w-full bg-white dark:bg-stone-800 rounded-2xl px-5 py-4 outline-none border-2 border-stone-100 dark:border-stone-700 font-bold text-sm" value={newItineraryStep.title || ''} onChange={e => setNewItineraryStep({...newItineraryStep, title: e.target.value})} />
                                 </div>
 
                                 <div className="space-y-2">
                                     <label className="text-[9px] uppercase font-black text-stone-400 tracking-widest ml-2">Lieu / Destination</label>
                                     <div className="relative">
                                       <MapPin size={14} className="absolute left-5 top-1/2 -translate-y-1/2 text-stone-400" />
                                       <input placeholder="ex: Sangha, Pays Dogon" className="w-full bg-white dark:bg-stone-800 rounded-2xl pl-12 pr-5 py-4 outline-none border-2 border-stone-100 dark:border-stone-700 font-bold text-sm" value={newItineraryStep.locationName || ''} onChange={e => setNewItineraryStep({...newItineraryStep, locationName: e.target.value})} />
                                     </div>
                                 </div>
 
                                 <div className="space-y-2">
                                     <label className="text-[9px] uppercase font-black text-stone-400 tracking-widest ml-2">Description de l'étape</label>
                                     <textarea rows={3} placeholder="Que vont faire les clients ?" className="w-full bg-white dark:bg-stone-800 rounded-2xl px-5 py-4 outline-none border-2 border-stone-100 dark:border-stone-700 font-bold text-sm resize-none" value={newItineraryStep.description || ''} onChange={e => setNewItineraryStep({...newItineraryStep, description: e.target.value})} />
                                 </div>

                                 <div className="space-y-4">
                                     <label className="text-[9px] uppercase font-black text-stone-400 tracking-widest ml-2 flex items-center gap-2">Activités</label>
                                     <div className="flex gap-2">
                                       <input 
                                         placeholder="Ajouter une activité..." 
                                         className="flex-1 bg-white dark:bg-stone-800 rounded-xl px-4 py-3 outline-none border border-stone-100 dark:border-stone-700 font-bold text-xs"
                                         value={currentActivity}
                                         onChange={e => setCurrentActivity(e.target.value)}
                                         onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addActivity())}
                                       />
                                       <button type="button" onClick={addActivity} className="p-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors"><Plus size={16} /></button>
                                     </div>
                                     <div className="flex flex-wrap gap-2">
                                       {(newItineraryStep.activities || []).map((act, i) => (
                                         <span key={i} className="px-3 py-1 bg-white dark:bg-stone-700 border border-stone-100 dark:border-stone-600 text-stone-600 dark:text-stone-200 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-2">
                                           {act}
                                           <button type="button" onClick={() => setNewItineraryStep({...newItineraryStep, activities: newItineraryStep.activities?.filter((_, idx) => idx !== i)})} className="hover:text-rose-500"><X size={10} /></button>
                                         </span>
                                       ))}
                                     </div>
                                 </div>
 
                                 <button type="button" onClick={addItineraryStep} className="w-full bg-stone-900 text-white py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-stone-800 transition-all shadow-xl shadow-stone-900/10">Ajouter cette étape</button>
                               </div>
                            </div>
 
                            {/* Steps List Column */}
                            <div className="space-y-6 overflow-y-auto pr-2 no-scrollbar pb-12 font-sans font-medium tracking-tight text-gray-900">
                               <div className="flex items-center justify-between px-2">
                                 <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Programme ({formData.itinerary.length} étapes)</h4>
                                 {formData.itinerary.length === 0 && (
                                   <div className="flex items-center gap-2 text-rose-500 animate-pulse">
                                     <AlertCircle size={14} />
                                     <span className="text-[8px] font-black uppercase">Obligatoire</span>
                                   </div>
                                 )}
                               </div>
 
                               <div className="space-y-4 relative">
                                 {/* Vertical Line */}
                                 <div className="absolute left-8 top-8 bottom-8 w-1 bg-stone-100 dark:bg-stone-800 rounded-full" />
 
                                 {formData.itinerary.length === 0 ? (
                                   <div className="bg-stone-50 dark:bg-stone-800/30 border-2 border-dashed border-stone-100 dark:border-stone-800 rounded-[2.5rem] p-12 text-center">
                                      <Compass size={48} className="mx-auto text-stone-200 mb-4" />
                                      <p className="text-stone-400 font-bold text-xs">Ajoutez les étapes de votre circuit pour aider les voyageurs à comprendre l’expérience.</p>
                                   </div>
                                 ) : (
                                   formData.itinerary.map((step, idx) => (
                                     <div key={step.id} className="relative pl-16 group">
                                       {/* Marker */}
                                       <div className="absolute left-5 top-12 -translate-x-1/2 w-8 h-8 rounded-xl bg-white dark:bg-stone-900 border-4 border-emerald-500 z-10 flex items-center justify-center text-[10px] font-black text-emerald-600 shadow-lg">
                                         {idx + 1}
                                       </div>
 
                                       <div className="bg-white dark:bg-stone-900 p-6 rounded-3xl border-2 border-stone-100 dark:border-stone-800 group-hover:border-emerald-200 transition-all shadow-sm group-hover:shadow-xl group-hover:-translate-y-1">
                                         <div className="flex justify-between items-start mb-4">
                                           <div className="flex-1 min-w-0 pr-4">
                                             <div className="flex items-center gap-2 mb-1">
                                               <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-lg text-[8px] font-black uppercase tracking-widest">Jour {step.day}</span>
                                               <span className="text-stone-400 text-[10px] font-bold">{step.estimatedTime}</span>
                                             </div>
                                             <h5 className="text-sm font-black text-stone-900 dark:text-white leading-tight truncate">{step.title}</h5>
                                             <p className="text-[10px] font-bold text-stone-400 flex items-center gap-1 uppercase tracking-widest mt-1">
                                               <MapPin size={10} className="text-rose-500" /> {step.locationName}
                                             </p>
                                           </div>
                                           <div className="flex gap-2">
                                              <div className="flex flex-col gap-1">
                                                <button type="button" onClick={() => moveStep(idx, 'up')} disabled={idx === 0} className="p-1.5 hover:bg-stone-100 rounded-lg text-stone-400 disabled:opacity-0 mx-auto"><ArrowUp size={14} /></button>
                                                <button type="button" onClick={() => moveStep(idx, 'down')} disabled={idx === formData.itinerary.length - 1} className="p-1.5 hover:bg-stone-100 rounded-lg text-stone-400 disabled:opacity-0 mx-auto"><ArrowDown size={14} /></button>
                                              </div>
                                              <button type="button" onClick={() => removeItineraryStep(step.id)} className="p-3 bg-stone-50 hover:bg-rose-50 text-stone-300 hover:text-rose-500 rounded-2xl transition-colors shrink-0">
                                                <Trash2 size={16} />
                                              </button>
                                           </div>
                                         </div>
                                         <p className="text-xs text-stone-500 italic line-clamp-2 leading-relaxed font-sans mb-3 font-medium">"{step.description}"</p>
                                         
                                         {step.activities && step.activities.length > 0 && (
                                           <div className="flex flex-wrap gap-2 pt-2 border-t border-stone-50 dark:border-stone-800">
                                             {step.activities.map((act, i) => (
                                               <span key={i} className="text-[8px] font-black uppercase tracking-widest text-stone-400 flex items-center gap-1">
                                                 <CheckCircle2 size={8} className="text-emerald-500" /> {act}
                                               </span>
                                             ))}
                                           </div>
                                         )}
                                       </div>
                                     </div>
                                   ))
                                 )}
                               </div>
                            </div>
                          </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="p-8 md:p-12 bg-stone-50 dark:bg-stone-950 flex justify-between gap-4">
                  {currentStep > 1 && (
                    <button 
                      type="button" 
                      onClick={() => setCurrentStep(prev => prev - 1)}
                      className="px-8 py-4 bg-white dark:bg-stone-800 rounded-2xl text-stone-600 dark:text-stone-400 font-bold text-sm shadow-sm transition-all active:scale-95"
                    >
                      Retour
                    </button>
                  )}
                  <div className="flex-1" />
                  <button 
                    type="submit"
                    className="px-12 py-4 bg-stone-900 dark:bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-stone-900/10 active:scale-95 transition-all"
                  >
                    {currentStep === 5 ? 'Terminer' : 'Suivant'}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

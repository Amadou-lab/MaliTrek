import React from 'react';
import { Plus, Calendar, ShieldCheck, CheckCircle2, Compass, X, Clock, MapPin } from 'lucide-react';
import { Card } from '../shared/UI';
import { Journey, Reservation } from '../../types';

interface JourneysListViewProps {
  journeys: Journey[];
  reservations: Reservation[];
  onAddJourney: () => void;
  onManageSteps: (journey: Journey) => void;
  onCompleteJourney: (journey: Journey) => void;
  onPublishJourney: (journey: Journey) => void;
  onViewItinerary: (journey: Journey) => void;
  onCancelJourney: (journey: Journey) => void;
}

export const JourneysListView: React.FC<JourneysListViewProps> = ({
  journeys,
  reservations,
  onAddJourney,
  onManageSteps,
  onCompleteJourney,
  onPublishJourney,
  onViewItinerary,
  onCancelJourney
}) => {
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-stone-900 tracking-tight">Mes Trajets</h2>
          <p className="text-stone-500 font-medium text-sm">Instances planifiées de vos circuits.</p>
        </div>
        <button 
          onClick={onAddJourney}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
        >
          <Plus size={14} /> Ajouter un trajet
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {journeys.map(journey => {
          const journeyRes = reservations.filter(r => r.journeyId === journey.id);
          const totalPass = journeyRes.reduce((sum, r) => sum + (r.passengers || 0), 0);
          const maxS = journey.totalSeats || 12;
          const minP = journey.minParticipants || 1;
          const isFull = totalPass >= maxS;
          const minReached = totalPass >= minP;

          return (
            <Card key={journey.id} className={`group overflow-hidden p-0 border-2 transition-all ${isFull ? 'border-amber-200' : 'border-transparent'}`}>
              <div className="h-48 relative">
                <img src={journey.image} alt={journey.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                
                {/* Badges */}
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                   <span className={`px-2 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest ${
                     journey.status === 'in_progress' ? 'bg-emerald-500 text-white animate-pulse' :
                     journey.status === 'completed' ? 'bg-blue-500 text-white' :
                     journey.status === 'cancelled' ? 'bg-rose-500 text-white' :
                     'bg-stone-900/60 text-white backdrop-blur-md'
                   }`}>
                     {journey.status === 'in_progress' ? 'En cours' : 
                      journey.status === 'completed' ? 'Terminé' : journey.status}
                   </span>
                </div>

                <div className="absolute bottom-4 left-6 right-6">
                  <p className="text-white font-black text-lg leading-tight mb-1">{journey.title}</p>
                  <div className="flex items-center gap-3 text-stone-300 text-[9px] font-bold uppercase tracking-widest">
                     <span className="flex items-center gap-1"><MapPin size={10} /> {journey.location}</span>
                     <span className="flex items-center gap-1"><Clock size={10} /> {journey.time}</span>
                  </div>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Stats */}
                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-1">
                      <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest">Remplissage</p>
                      <p className={`text-lg font-black ${isFull ? 'text-amber-500' : 'text-stone-900'}`}>
                        {totalPass} <span className="text-stone-300 text-xs text-normal">/ {maxS}</span>
                      </p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest">Seuil de départ</p>
                      <div className="flex items-center gap-2">
                         <p className={`text-lg font-black ${minReached ? 'text-emerald-500' : 'text-stone-400'}`}>
                           {minReached ? 'Atteint' : `${totalPass}/${minP}`}
                         </p>
                         {minReached && <CheckCircle2 size={14} className="text-emerald-500" />}
                      </div>
                   </div>
                </div>

                {/* Progress Bar for Min Participants */}
                <div className="space-y-2">
                   <div className="flex justify-between items-center text-[8px] font-black uppercase tracking-widest">
                      <span className="text-stone-400">Progression minimum</span>
                      <span className={minReached ? 'text-emerald-500' : 'text-stone-400'}>
                        {Math.min(100, Math.round((totalPass / minP) * 100))}%
                      </span>
                   </div>
                   <div className="h-1.5 w-full bg-stone-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${minReached ? 'bg-emerald-500' : 'bg-stone-300'}`}
                        style={{ width: `${Math.min(100, (totalPass / minP) * 100)}%` }}
                      />
                   </div>
                </div>

                <div className="flex flex-wrap gap-2 pt-2">
                  {journey.status === 'draft' ? (
                    <button 
                      onClick={() => onPublishJourney(journey)}
                      className="flex-1 bg-purple-600 text-white h-12 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-purple-500 transition-all active:scale-95 flex items-center justify-center gap-2 shadow-lg shadow-purple-500/10"
                    >
                      <CheckCircle2 size={14} /> Publier
                    </button>
                  ) : journey.status === 'open' || journey.status === 'full' ? (
                    <button 
                      onClick={() => onManageSteps(journey)}
                      className="flex-1 bg-emerald-600 text-white h-12 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-500 transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      <Plus size={14} /> Démarrer
                    </button>
                  ) : journey.status === 'in_progress' ? (
                    <button 
                      onClick={() => onCompleteJourney(journey)}
                      className="flex-1 bg-blue-600 text-white h-12 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-500 transition-all active:scale-95 flex items-center justify-center gap-2"
                    >
                      <ShieldCheck size={14} /> Terminer
                    </button>
                  ) : null}
                  
                  <button 
                    onClick={() => onManageSteps(journey)}
                    className="flex-1 bg-stone-900 text-white h-12 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-stone-800 transition-all active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Compass size={14} /> Gérer
                  </button>
                  
                  <button 
                    onClick={() => onCancelJourney(journey)}
                    className="w-12 h-12 flex items-center justify-center rounded-xl bg-stone-50 text-stone-400 hover:bg-rose-50 hover:text-rose-500 transition-all"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>
            </Card>
          );
        })}
        {journeys.length === 0 && (
          <div className="col-span-full py-20 text-center bg-white dark:bg-stone-900 rounded-[3rem] border border-stone-100 dark:border-stone-800 border-dashed">
            <Compass size={48} className="mx-auto text-stone-200 mb-4" />
            <p className="text-stone-400 font-bold">Aucun trajet planifié. Planifiez un départ depuis la vue "Circuits".</p>
          </div>
        )}
      </div>
    </div>
  );
};

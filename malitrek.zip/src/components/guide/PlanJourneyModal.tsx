import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';
import { Circuit } from '../../types';

interface PlanJourneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  circuits: Circuit[];
  selectedCircuit: Circuit | null;
  onPlan: (journeyData: any) => void;
}

export const PlanJourneyModal: React.FC<PlanJourneyModalProps> = ({
  isOpen,
  onClose,
  circuits,
  selectedCircuit,
  onPlan
}) => {
  const [date, setDate] = useState('');
  const [availableSeats, setAvailableSeats] = useState(12);
  const [meetingTime, setMeetingTime] = useState('08:00');
  const [meetingLink, setMeetingLink] = useState('');
  const [internalSelection, setInternalSelection] = useState<Circuit | null>(selectedCircuit);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalCircuit = internalSelection || selectedCircuit;
    if (!finalCircuit) return;

    onPlan({
      circuitId: finalCircuit.id,
      date,
      time: meetingTime,
      availableSeats,
      totalSeats: availableSeats,
      meetingTime,
      meetingLink,
      meetingPoint: finalCircuit.location, // Default to circuit location if not specified
      title: finalCircuit.title, 
      location: finalCircuit.location,
      image: finalCircuit.image,
      pricePerPerson: finalCircuit.basePrice,
      category: finalCircuit.category,
      minParticipants: finalCircuit.minParticipants || 1,
      itinerary: finalCircuit.itinerary || [],
      status: 'open'
    });
    
    // Reset
    setDate('');
    setMeetingLink('');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white dark:bg-stone-900 rounded-[3rem] w-full max-w-lg my-auto shadow-2xl border border-white/20 p-8"
          >
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Planifier un départ</h2>
                <p className="text-slate-500 font-medium text-sm">
                  {internalSelection || selectedCircuit ? (internalSelection || selectedCircuit)?.title : 'Sélectionnez un circuit template'}
                </p>
              </div>
              <button onClick={onClose} className="text-slate-400 hover:text-slate-900 dark:hover:text-white p-2">
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {!(internalSelection || selectedCircuit) && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Choisir le Circuit Template</label>
                  <select 
                    required
                    className="w-full bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-900 dark:text-white appearance-none"
                    onChange={e => {
                      const circuit = circuits.find(c => c.id === e.target.value);
                      if (circuit) setInternalSelection(circuit);
                    }}
                    value={internalSelection?.id || ''}
                  >
                    <option value="">Sélectionner un circuit...</option>
                    {circuits.filter(c => c.status === 'approved').map(c => (
                      <option key={c.id} value={c.id}>{c.title} ({c.location})</option>
                    ))}
                  </select>
                </div>
              )}

              <div className={!(internalSelection || selectedCircuit) ? 'opacity-40 grayscale pointer-events-none' : 'space-y-6'}>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Date du voyage</label>
                  <input 
                    required
                    type="date"
                    className="w-full bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-900 dark:text-white"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Places disponibles</label>
                    <input 
                      required
                      type="number"
                      min="1"
                      className="w-full bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-900 dark:text-white"
                      value={availableSeats}
                      onChange={e => setAvailableSeats(Number(e.target.value))}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Heure de rendez-vous</label>
                    <input 
                      required
                      type="time"
                      className="w-full bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-900 dark:text-white"
                      value={meetingTime}
                      onChange={e => setMeetingTime(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Lien de rencontre (Google Maps)</label>
                  <input 
                    required
                    className="w-full bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-900 dark:text-white"
                    placeholder="https://maps.google.com/..."
                    value={meetingLink}
                    onChange={e => setMeetingLink(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={onClose}
                  className="flex-1 bg-slate-100 dark:bg-stone-800 hover:bg-slate-200 dark:hover:bg-stone-700 text-slate-600 dark:text-stone-400 font-bold py-4 rounded-2xl transition-all"
                >
                  Annuler
                </button>
                <button 
                  type="submit"
                  disabled={!(internalSelection || selectedCircuit)}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold py-4 rounded-2xl shadow-xl shadow-emerald-600/20 transition-all"
                >
                  Planifier
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

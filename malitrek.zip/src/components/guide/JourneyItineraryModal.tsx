import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Compass, MapPin, Zap } from 'lucide-react';
import { Journey } from '../../types';

interface JourneyItineraryModalProps {
  journey: Journey | null;
  onClose: () => void;
}

export const JourneyItineraryModal: React.FC<JourneyItineraryModalProps> = ({
  journey,
  onClose
}) => {
  return (
    <AnimatePresence>
      {journey && (
        <div 
          className="fixed inset-0 bg-stone-950/40 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto"
          onClick={onClose}
        >
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }} 
            animate={{ scale: 1, opacity: 1, y: 0 }} 
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="bg-white dark:bg-stone-900 rounded-[3rem] w-full max-w-2xl my-auto shadow-2xl border border-white/20 flex flex-col overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-stone-900 p-10 text-white relative">
               <button 
                 onClick={onClose}
                 className="absolute top-8 right-8 text-stone-400 hover:text-white transition-all"
               >
                 <X size={24} />
               </button>
               <div className="flex items-center gap-6">
                 <div className="w-16 h-16 bg-emerald-600 rounded-[2rem] flex items-center justify-center shadow-inner">
                   <Compass size={32} />
                 </div>
                 <div>
                   <h3 className="text-3xl font-black tracking-tight leading-none mb-2">Itinéraire du Trajet</h3>
                   <p className="text-stone-400 font-bold uppercase tracking-widest text-xs">
                     {journey.title} • {new Date(journey.date).toLocaleDateString('fr-FR')}
                   </p>
                 </div>
               </div>
            </div>
            
            <div className="p-10 space-y-8 overflow-y-auto max-h-[60vh]">
              <div className="space-y-4">
                {journey.itinerarySnapshot?.map((step, index) => (
                  <div key={step.id || index} className="relative pl-10 group">
                    {/* Timeline bar */}
                    {index !== journey.itinerarySnapshot!.length - 1 && (
                      <div className="absolute left-[11px] top-6 bottom-0 w-0.5 bg-stone-100 dark:bg-stone-800 group-hover:bg-emerald-100 transition-colors" />
                    )}
                    
                    {/* Timeline point */}
                    <div className="absolute left-0 top-0 w-6 h-6 rounded-full bg-stone-50 dark:bg-stone-800 border-2 border-stone-200 dark:border-stone-700 flex items-center justify-center group-hover:border-emerald-500 group-hover:scale-110 transition-all">
                      <div className="w-2 h-2 rounded-full bg-stone-300 dark:bg-stone-600 group-hover:bg-emerald-500" />
                    </div>
                    
                    <div className="bg-stone-50 dark:bg-stone-800/50 group-hover:bg-white dark:group-hover:bg-stone-800 border border-stone-100 dark:border-stone-700 group-hover:border-stone-200 dark:group-hover:border-stone-600 group-hover:shadow-xl transition-all p-6 rounded-[2rem] space-y-4">
                      <div className="flex justify-between items-start">
                        <h4 className="text-sm font-black text-stone-900 dark:text-white uppercase tracking-tight">{step.title}</h4>
                        <span className="bg-white dark:bg-stone-900 px-3 py-1 rounded-xl text-[10px] font-black text-stone-400 border border-stone-100 dark:border-stone-700 uppercase tracking-widest group-hover:text-emerald-600 group-hover:border-emerald-100">
                           {step.duration || `Jour ${step.day}`}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-700 flex items-center justify-center text-stone-400">
                          <MapPin size={14} />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black text-stone-400 uppercase tracking-widest">Lieu</span>
                          <span className="text-[10px] font-bold text-stone-700 dark:text-stone-300">{step.locationName || 'Sur le trajet'}</span>
                        </div>
                      </div>

                      <p className="text-[11px] text-stone-600 dark:text-stone-400 font-medium leading-relaxed italic">
                        "{step.description}"
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-10 border-t border-stone-50 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950">
               <button 
                 onClick={onClose}
                 className="w-full bg-stone-900 dark:bg-stone-800 text-white py-5 rounded-[1.5rem] font-black uppercase tracking-widest text-[10px] shadow-xl shadow-stone-900/10 active:scale-95 transition-all"
               >
                 Fermer l'itinéraire
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

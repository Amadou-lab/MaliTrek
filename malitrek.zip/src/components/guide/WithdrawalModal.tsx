import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

interface WithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  onSubmit: (amount: number, method: string) => Promise<void>;
}

export const WithdrawalModal: React.FC<WithdrawalModalProps> = ({
  isOpen,
  onClose,
  balance,
  onSubmit
}) => {
  const [amount, setAmount] = useState(balance);
  const [method, setMethod] = useState('Orange Money');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await onSubmit(amount, method);
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-stone-950/60 backdrop-blur-md z-[100] flex items-center justify-center p-4 overflow-y-auto"
          onClick={onClose}
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white dark:bg-stone-900 rounded-[3rem] w-full max-w-md my-auto shadow-2xl border border-white/20"
            onClick={(e) => e.stopPropagation()}
          >
            <form onSubmit={handleSubmit} className="p-10 space-y-8">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-black text-stone-900 dark:text-white tracking-tight leading-none mb-2">Retrait</h2>
                  <p className="text-stone-500 font-medium text-sm">Retirez vos gains MaliTrek.</p>
                </div>
                <button type="button" onClick={onClose} className="text-stone-400 hover:text-stone-900 dark:hover:text-white transition-all p-2">
                  <X size={28} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-3xl border border-emerald-100 dark:border-emerald-900/30">
                  <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Solde disponible</p>
                  <p className="text-3xl font-black text-emerald-700 dark:text-emerald-500">{(balance || 0).toLocaleString()} CFA</p>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-stone-400 uppercase tracking-widest ml-2">Montant à retirer (CFA)</label>
                  <input 
                    required
                    type="number"
                    min="1000"
                    max={balance}
                    className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 dark:text-white transition-all"
                    value={amount}
                    onChange={e => setAmount(Number(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-stone-400 uppercase tracking-widest ml-2">Méthode de retrait</label>
                  <select 
                    className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 dark:text-white transition-all appearance-none"
                    value={method}
                    onChange={e => setMethod(e.target.value)}
                  >
                    <option>Orange Money</option>
                    <option>Moov Money</option>
                    <option>Virement Bancaire</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <button 
                  type="submit"
                  disabled={isLoading || balance < 1000}
                  className="w-full bg-emerald-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-emerald-600/20 active:scale-95 transition-all text-xs uppercase tracking-widest disabled:opacity-50 disabled:active:scale-100"
                >
                  {isLoading ? 'Traitement...' : 'Confirmer le retrait'}
                </button>
                <button 
                  type="button"
                  onClick={onClose}
                  className="w-full text-stone-400 hover:text-stone-900 dark:hover:text-white font-black py-2 text-[10px] uppercase tracking-widest transition-all"
                >
                  Annuler
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

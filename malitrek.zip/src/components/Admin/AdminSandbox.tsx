import React, { useState } from 'react';
import { motion } from 'motion/react';
import { FlaskConical, Trash2, Zap, ShieldCheck, Database, RefreshCw, AlertTriangle, Bomb } from 'lucide-react';
import { seedDatabase, clearTestData, clearAllDatabase } from '../../lib/seedData';
import toast from 'react-hot-toast';
import { ConfirmModal } from '../ui/ConfirmModal';

export const AdminSandbox: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleSeed = async () => {
    setIsGenerating(true);
    try {
      await seedDatabase();
      toast.success('Données de test générées avec succès !');
    } catch (error) {
      toast.error('Erreur lors de la génération');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleClear = async () => {
    setIsClearing(true);
    try {
      await clearTestData();
      toast.success('Données de test supprimées.');
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    } finally {
      setIsClearing(false);
    }
  };

  const handleClearAll = async () => {
    if (!window.confirm('ATTENTION: Cette action va supprimer TOUTES les données (circuits, trajets, réservations) de TOUS les utilisateurs. Confirmer ?')) return;
    setIsClearing(true);
    try {
      await clearAllDatabase();
      toast.success('Base de données totalement vidée.');
    } catch (error) {
      toast.error('Erreur lors du nettoyage complet');
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="space-y-10">
      <ConfirmModal 
        isOpen={showClearConfirm}
        onClose={() => setShowClearConfirm(false)}
        onConfirm={handleClear}
        title="Nettoyer la Sandbox"
        message="Êtes-vous sûr de vouloir supprimer TOUTES les données de test ? Cette action est irréversible."
        confirmLabel="Tout supprimer"
      />
      <div className="bg-amber-50 border border-amber-200 p-8 rounded-[2.5rem] flex items-start gap-6">
        <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 shrink-0">
          <AlertTriangle size={28} />
        </div>
        <div>
          <h2 className="text-2xl font-black text-amber-900 mb-2">Mode Sandbox Admin</h2>
          <p className="text-amber-700 font-medium leading-relaxed">
            Cet espace vous permet de manipuler des données de test sans affecter les données réelles de production. 
            Toutes les données générées ici portent le badge <span className="bg-amber-200 px-2 py-0.5 rounded-md font-bold text-[10px] uppercase">TEST</span>.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-10 rounded-[3rem] border border-stone-100 shadow-sm"
        >
          <div className="w-16 h-16 bg-emerald-100 rounded-3xl flex items-center justify-center text-emerald-600 mb-8">
            <Zap size={32} />
          </div>
          <h3 className="text-2xl font-black text-stone-900 mb-4">Générer des données</h3>
          <p className="text-stone-500 font-medium mb-8 leading-relaxed">
            Créez instantanément des circuits, trajets, réservations et utilisateurs fictifs pour tester les flux de l'application.
          </p>
          <button 
            onClick={handleSeed}
            disabled={isGenerating}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 transition-all disabled:opacity-50 shadow-xl shadow-emerald-600/20"
          >
            {isGenerating ? <RefreshCw className="animate-spin" size={18} /> : <Database size={18} />}
            {isGenerating ? 'Génération...' : 'Générer le Seed'}
          </button>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-10 rounded-[3rem] border border-stone-100 shadow-sm"
        >
          <div className="w-16 h-16 bg-rose-100 rounded-3xl flex items-center justify-center text-rose-600 mb-8">
            <Trash2 size={32} />
          </div>
          <h3 className="text-2xl font-black text-stone-900 mb-4">Nettoyer la Sandbox</h3>
          <p className="text-stone-500 font-medium mb-8 leading-relaxed">
            Supprimez toutes les données marquées comme "test" de la base de données Firestore.
          </p>
          <button 
            onClick={() => setShowClearConfirm(true)}
            disabled={isClearing}
            className="w-full bg-rose-600 hover:bg-rose-700 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 transition-all disabled:opacity-50 shadow-xl shadow-rose-600/20"
          >
            {isClearing ? <RefreshCw className="animate-spin" size={18} /> : <Trash2 size={18} />}
            {isClearing ? 'Nettoyage...' : 'Supprimer Tests'}
          </button>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-10 rounded-[3rem] border border-orange-100 shadow-sm"
        >
          <div className="w-16 h-16 bg-orange-100 rounded-3xl flex items-center justify-center text-orange-600 mb-8">
            <Bomb size={32} />
          </div>
          <h3 className="text-2xl font-black text-stone-900 mb-4">Effacer Toute la Base</h3>
          <p className="text-stone-500 font-medium mb-8 leading-relaxed">
            Supprimez TOUTES les données de la base (Circuits réels et tests). Action irréversible.
          </p>
          <button 
            onClick={handleClearAll}
            disabled={isClearing}
            className="w-full bg-orange-600 hover:bg-orange-700 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 transition-all disabled:opacity-50 shadow-xl shadow-orange-600/20"
          >
            {isClearing ? <RefreshCw className="animate-spin" size={18} /> : <Bomb size={18} />}
            {isClearing ? 'Nettoyage...' : 'Tout Nettoyer'}
          </button>
        </motion.div>
      </div>

      <div className="bg-stone-900 text-white p-12 rounded-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-10">
          <ShieldCheck size={200} />
        </div>
        <div className="relative z-10 max-w-2xl">
          <h3 className="text-3xl font-black mb-6">Sécurité & Intégrité</h3>
          <p className="text-stone-400 font-medium leading-relaxed mb-8">
            Le mode sandbox est conçu pour être totalement isolé. Les emails de test ne reçoivent pas de vraies notifications et les paiements simulés ne débitent aucun compte réel.
          </p>
          <div className="flex gap-4">
            <div className="px-6 py-3 bg-white/10 rounded-xl text-xs font-black uppercase tracking-widest">Isolation Totale</div>
            <div className="px-6 py-3 bg-white/10 rounded-xl text-xs font-black uppercase tracking-widest">Zéro Risque</div>
          </div>
        </div>
      </div>
    </div>
  );
};

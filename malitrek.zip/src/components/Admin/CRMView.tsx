import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useNotifications } from '../../contexts/NotificationContext';
import { useSettings } from '../../contexts/SettingsContext';
import { Bell, Send, Users, ShieldCheck, MapPin, Zap } from 'lucide-react';
import toast from 'react-hot-toast';

export const CRMView: React.FC = () => {
  const { sendPushNotification } = useNotifications();
  const { t } = useSettings();
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [segment, setSegment] = useState<'all' | 'clients' | 'guides'>('all');
  const [isSending, setIsSending] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !message) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    setIsSending(true);
    await sendPushNotification(segment, title, message);
    setTitle('');
    setMessage('');
    setIsSending(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-stone-900 dark:text-white tracking-tight">{t('crm.title')}</h1>
          <p className="text-stone-500 font-medium tracking-tight">Engagez votre communauté avec des messages ciblés.</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-900/20 px-4 py-2 rounded-2xl border border-emerald-100 dark:border-emerald-800">
          <ShieldCheck size={16} className="text-emerald-600" />
          <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Admin Secured</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          <form onSubmit={handleSend} className="bg-white dark:bg-stone-900 p-10 rounded-[3rem] border border-stone-100 dark:border-stone-800 shadow-2xl space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">{t('crm.segment')}</label>
                <div className="flex gap-2">
                  {(['all', 'clients', 'guides'] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSegment(s)}
                      className={`flex-1 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                        segment === s 
                          ? 'bg-stone-900 text-white shadow-xl shadow-stone-900/20' 
                          : 'bg-stone-50 dark:bg-stone-800 text-stone-400 hover:text-stone-900 dark:hover:text-white border border-stone-100 dark:border-stone-700'
                      }`}
                    >
                      {t(`crm.${s}`)}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Titre de la notification</label>
              <input 
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="ex: Nouvelle mise à jour disponible !"
                className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-100 dark:border-stone-700 rounded-2xl px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 dark:text-white transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] ml-2">Message de contenu</label>
              <textarea 
                rows={4}
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Décrivez l'annonce ici..."
                className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-100 dark:border-stone-700 rounded-[2rem] px-6 py-4 focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-stone-900 dark:text-white transition-all resize-none"
              />
            </div>

            <button 
              type="submit"
              disabled={isSending}
              className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-200 text-white py-6 rounded-[2rem] font-black uppercase tracking-[0.2em] text-xs shadow-xl shadow-emerald-600/20 transition-all active:scale-95 flex items-center justify-center gap-3"
            >
              <Send size={18} />
              {isSending ? 'Envoi en cours...' : 'Diffuser la notification'}
            </button>
          </form>
        </div>

        <div className="space-y-6">
          <div className="bg-stone-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:scale-110 transition-transform duration-700">
              <Zap size={80} />
            </div>
            <div className="relative z-10">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-6">
                <Bell size={24} className="text-white" />
              </div>
              <h3 className="text-xl font-black tracking-tight mb-2">Simulateur Push</h3>
              <p className="text-stone-400 text-sm font-medium leading-relaxed">
                Les notifications apparaissent instantanément dans l'inbox des utilisateurs ciblés.
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-stone-900 p-8 rounded-[2.5rem] border border-stone-100 dark:border-stone-800 space-y-6">
            <h4 className="text-xs font-black text-stone-400 uppercase tracking-widest">{t('crm.segment')} Insight</h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-stone-50 dark:bg-stone-800 rounded-2xl border border-stone-100 dark:border-stone-700">
                <div className="flex items-center gap-3">
                  <Users size={16} className="text-stone-400" />
                  <span className="text-sm font-black text-stone-900 dark:text-white">Portée Totale</span>
                </div>
                <span className="text-xs font-black text-emerald-600">Calculée au clic</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNotifications } from '../../contexts/NotificationContext';
import { Bell, Heart, CreditCard, Compass, Zap, Check, CheckCircle2, FlaskConical, AlertTriangle, MessageSquare, ExternalLink, ShieldCheck, AlertCircle } from 'lucide-react';
import { useSettings } from '../../contexts/SettingsContext';
import { toDate } from '../../lib/firestoreUtils';
import { trekService } from '../../services/trekService';
import { useAuth } from '../../contexts/AuthContext';
import toast from 'react-hot-toast';
import { ReviewModal } from '../Reviews/ReviewModal';
import { useNavigation } from '../../contexts/NavigationContext';

export const NotificationInbox: React.FC = () => {
  const { notifications, markAsRead, markAllAsRead, unreadCount } = useNotifications();
  const { profile } = useAuth();
  const { t } = useSettings();
  const { navigateTo } = useNavigation();

  const [reviewResId, setReviewResId] = useState<string | null>(null);

  const getIcon = (type: string) => {
    switch (type) {
      case 'reservation': return <Compass className="text-blue-500" />;
      case 'payment': return <CreditCard className="text-emerald-500" />;
      case 'system': return <Zap className="text-amber-500" />;
      case 'promotion': return <Heart className="text-rose-500" />;
      default: return <Bell className="text-stone-400" />;
    }
  };

  const handleAction = async (notif: any) => {
    if (notif.actionType === 'validate_experience') {
      const confirm = window.confirm('Confirmez-vous que le voyage s’est bien terminé ?');
      if (confirm) {
        const loading = toast.loading('Validation en cours...');
        try {
          await trekService.validateExperience(notif.reservationId, profile!.uid);
          toast.success('Voyage validé !', { id: loading });
          setReviewResId(notif.reservationId);
          markAsRead(notif.id);
        } catch (error) {
          toast.error('Erreur lors de la validation', { id: loading });
        }
      }
    } else if (notif.actionType === 'open_chat' || notif.actionType === 'message_received') {
       markAsRead(notif.id);
       navigateTo('messages', { conversationId: notif.conversationId });
    } else if (notif.actionType === 'open_reservation' || notif.actionType === 'view_reservation') {
       markAsRead(notif.id);
       navigateTo('reservations', { reservationId: notif.reservationId });
    } else if (notif.actionType === 'open_journey') {
       markAsRead(notif.id);
       navigateTo('journeys', { journeyId: notif.journeyId });
    } else if (notif.actionType === 'open_circuit') {
       markAsRead(notif.id);
       navigateTo('circuits', { circuitId: notif.circuitId });
    } else if (notif.actionType === 'open_dispute') {
       markAsRead(notif.id);
       navigateTo('disputes', { disputeId: notif.disputeId });
    } else {
       markAsRead(notif.id);
       toast('Notification consultée.');
    }
  };

  const [activeType, setActiveType] = React.useState<string>('all');
  const types = [
    { id: 'all', label: 'Toutes' },
    { id: 'reservation', label: 'Réservations' },
    { id: 'payment', label: 'Paiements' },
    { id: 'system', label: 'Système' },
    { id: 'promotion', label: 'Promotions' }
  ];

  const filtered = notifications.filter(n => {
    if (activeType === 'all') return true;
    return n.type === activeType;
  });

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-800 p-8 rounded-[3rem] shadow-xl space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-black text-stone-900 dark:text-white tracking-tight leading-none mb-2">{t('notif.title')}</h1>
            <p className="text-stone-500 font-medium tracking-tight">
              Vous avez <span className="font-black text-emerald-600 px-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">{unreadCount}</span> messages non lus.
            </p>
          </div>
          {unreadCount > 0 && (
            <button 
              onClick={markAllAsRead}
              className="bg-stone-50 dark:bg-stone-800 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300 px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border border-stone-100 dark:border-stone-700 flex items-center gap-2"
            >
              <Check size={14} /> Tout marquer comme lu
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
          {types.map(type => (
            <button
              key={type.id}
              onClick={() => setActiveType(type.id)}
              className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                activeType === type.id 
                  ? 'bg-stone-900 text-white shadow-xl shadow-stone-900/20' 
                  : 'bg-stone-50 text-stone-500 hover:bg-stone-100'
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <AnimatePresence mode="popLayout">
          {filtered.length > 0 ? (
            filtered.map((notif) => (
              <motion.div
                layout
                key={notif.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`group relative bg-white dark:bg-stone-900 p-8 rounded-[2.5rem] border transition-all ${
                  !notif.read 
                    ? 'border-emerald-100 dark:border-emerald-800 shadow-xl shadow-emerald-600/5' 
                    : 'border-stone-100 dark:border-stone-800 opacity-80 backdrop-blur-sm'
                }`}
                onClick={() => !notif.read && markAsRead(notif.id)}
              >
                {!notif.read && (
                  <div className="absolute top-8 right-8 w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-lg shadow-emerald-500/50" />
                )}
                
                <div className="flex gap-6">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-inner ${
                    !notif.read ? 'bg-emerald-50 dark:bg-emerald-900/10' : 'bg-stone-50 dark:bg-stone-800'
                  }`}>
                    {getIcon(notif.type)}
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between items-start">
                      <h3 className={`text-lg font-black tracking-tight ${!notif.read ? 'text-stone-900 dark:text-white' : 'text-stone-500 dark:text-stone-400'}`}>
                        {notif.title}
                      </h3>
                      <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest tabular-nums">
                        {toDate(notif.createdAt).toLocaleDateString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className={`text-sm leading-relaxed ${!notif.read ? 'text-stone-700 dark:text-stone-300 font-medium' : 'text-stone-500 dark:text-stone-500'}`}>
                      {notif.message}
                    </p>
                    
                    {notif.actionType && (
                      <div className="pt-4 flex flex-wrap gap-3">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAction(notif);
                          }}
                          className="bg-stone-900 dark:bg-white text-white dark:text-stone-900 px-5 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-stone-800 transition-all shadow-lg shadow-stone-900/10"
                        >
                          {notif.actionType === 'validate_experience' && <ShieldCheck size={14} />}
                          {notif.actionLabel || 'Voir'}
                        </button>
                        {notif.actionType === 'validate_experience' && (
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              // Open dispute logic or navigation
                              toast('Signalez le problème dans le détail de votre réservation');
                            }}
                            className="bg-rose-50 text-rose-600 px-5 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-rose-100 transition-all border border-rose-100"
                          >
                            <AlertCircle size={14} /> Signaler un problème
                          </button>
                        )}
                      </div>
                    )}

                    {!notif.read && (
                      <div className="pt-4 flex justify-end">
                        <button className="text-[10px] font-black text-emerald-600 uppercase tracking-widest hover:underline">
                          Marquer comme lu
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="py-48 bg-stone-50 rounded-[4rem] text-center flex flex-col items-center gap-10 stagger-in border border-stone-100/50 shadow-inner">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1 }}
                className="w-32 h-32 rounded-[2.5rem] bg-white flex items-center justify-center text-emerald-accent shadow-xl border border-stone-100"
              >
                 <Bell size={48} strokeWidth={1.5} className="opacity-20" />
              </motion.div>
              <div className="space-y-4 px-12">
                 <p className="text-4xl font-serif italic font-black text-emerald-primary leading-tight">Le silence est d'or.</p>
                 <p className="text-[11px] font-black text-stone-premium/30 uppercase tracking-[0.4em] leading-relaxed max-w-xs mx-auto">Toutes vos transmissions ont été archivées. Rien ne nécessite votre attention immédiate.</p>
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>

      <ReviewModal 
        isOpen={!!reviewResId}
        onClose={() => setReviewResId(null)}
        reservationId={reviewResId || ''}
        userId={profile?.uid || ''}
        userName={profile?.displayName || 'Client MaliTrek'}
      />
    </div>
  );
};

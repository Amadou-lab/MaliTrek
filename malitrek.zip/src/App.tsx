import React from 'react';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginView } from './views/Auth/LoginView';
import { Layout } from './components/Layout';
import { AdminDashboard } from './views/Admin/AdminDashboard';
import { GuideDashboard } from './views/Guide/GuideDashboard';
import { ClientDashboard } from './views/Client/ClientDashboard';
import { trekService } from './services/trekService';
import { PremiumLoading } from './components/shared/UI';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SettingsProvider } from './contexts/SettingsContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { SyncProvider } from './components/providers/SyncProvider';
import { NavigationProvider, useNavigation } from './contexts/NavigationContext';

const AppContent: React.FC = () => {
  const { user, profile, loading } = useAuth();
  const { activeView, navigateTo } = useNavigation();

  // Background auto-validation check
  React.useEffect(() => {
    if (!profile?.uid) return;
    
    // Check on login/mount
    trekService.checkAutoValidations(profile);
    
    // Periodically check every 5 minutes
    const interval = setInterval(() => {
      trekService.checkAutoValidations(profile);
    }, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [profile?.uid]);

  // Reset view when role changes
  React.useEffect(() => {
    if (profile?.role === 'ROLE_ADMIN') navigateTo('dashboard');
    else if (profile?.role === 'ROLE_GUIDE') navigateTo('dashboard');
    else navigateTo('home');
  }, [profile?.role, navigateTo]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-sable-light">
        <PremiumLoading message="Chargement des Terres du Mali..." />
      </div>
    );
  }

  const isGuest = !user || !profile;

  return (
    <Layout activeView={activeView} onViewChange={navigateTo}>
      {activeView === 'login' && isGuest ? (
        <LoginView />
      ) : isGuest ? (
        <ClientDashboard activeView={activeView} onViewChange={navigateTo} />
      ) : (
        <>
          {profile.role === 'ROLE_ADMIN' && <AdminDashboard activeView={activeView} onViewChange={navigateTo} />}
          {profile.role === 'ROLE_GUIDE' && <GuideDashboard activeView={activeView} onViewChange={navigateTo} />}
          {profile.role === 'ROLE_CLIENT' && <ClientDashboard activeView={activeView} onViewChange={navigateTo} />}
        </>
      )}
    </Layout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <NavigationProvider>
          <SyncProvider>
            <SettingsProvider>
              <NotificationProvider>
                <Toaster position="top-center" reverseOrder={false} />
                <AppContent />
              </NotificationProvider>
            </SettingsProvider>
          </SyncProvider>
        </NavigationProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

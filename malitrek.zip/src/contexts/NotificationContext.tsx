import React, { createContext, useContext, useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy, updateDoc, doc, addDoc, getDocs, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType, toDate } from '../lib/firestoreUtils';
import { useAuth } from './AuthContext';
import { Notification, UserProfile } from '../types';
import toast from 'react-hot-toast';

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  unreadMessagesCount: number;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  sendPushNotification: (target: 'all' | 'clients' | 'guides', title: string, message: string) => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { profile } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);

  useEffect(() => {
    if (!profile?.uid) {
      setNotifications([]);
      setUnreadCount(0);
      setUnreadMessagesCount(0);
      return;
    }

    // Notifications Listener
    const qNotifs = query(
      collection(db, 'notifications'),
      where('userId', '==', profile.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeNotifs = onSnapshot(qNotifs, (snapshot) => {
      const notifs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      setNotifications(notifs);
      setUnreadCount(notifs.filter(n => !n.read).length);
      
      // Real-time browser notification simulation
      snapshot.docChanges().forEach(change => {
        if (change.type === 'added' && !change.doc.data().read) {
          const data = change.doc.data() as Notification;
          const createdAt = toDate(data.createdAt).getTime();
          
          if (Date.now() - createdAt < 10000) {
            toast.custom((t) => (
              <div className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-md w-full bg-white dark:bg-stone-900 shadow-2xl rounded-[1.5rem] pointer-events-auto flex ring-1 ring-black ring-opacity-5 p-6 border-l-4 border-emerald-500`}>
                <div className="flex-1 w-0">
                  <p className="text-sm font-black text-stone-900 dark:text-white">{data.title}</p>
                  <p className="mt-1 text-xs font-medium text-stone-500">{data.message}</p>
                  {data.actionType && (
                    <button 
                      onClick={() => {
                        toast.dismiss(t.id);
                        if (data.actionRoute) {
                          window.location.hash = data.actionRoute; // Simplified navigation for now
                        }
                        markAsRead(change.doc.id);
                      }}
                      className="mt-3 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all active:scale-95"
                    >
                      {data.actionLabel || 'Voir'}
                    </button>
                  )}
                </div>
                <div className="ml-4 flex-shrink-0 flex">
                  <button
                    onClick={() => toast.dismiss(t.id)}
                    className="rounded-full inline-flex text-stone-400 hover:text-stone-500 focus:outline-none"
                  >
                    <span className="sr-only">Fermer</span>
                    <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </button>
                </div>
              </div>
            ), { duration: 8000 });
          }
        }
      });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'notifications');
    });

    // Conversations Listener for unread messages count
    const qConvs = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', profile.uid)
    );

    const unsubscribeConvs = onSnapshot(qConvs, (snapshot) => {
      let totalUnread = 0;
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (data.unreadCountByUser && profile.uid) {
          totalUnread += (data.unreadCountByUser[profile.uid] || 0);
        }
      });
      setUnreadMessagesCount(totalUnread);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'conversations');
    });

    return () => {
      unsubscribeNotifs();
      unsubscribeConvs();
    };
  }, [profile?.uid]);

  const markAsRead = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const batch = writeBatch(db);
      notifications.filter(n => !n.read).forEach(n => {
        batch.update(doc(db, 'notifications', n.id), { read: true });
      });
      await batch.commit();
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  const sendPushNotification = async (target: 'all' | 'clients' | 'guides', title: string, message: string) => {
    if (!profile || profile.role !== 'ROLE_ADMIN') return;

    const loading = toast.loading('Calcul des cibles et envoi...');
    try {
      let usersQuery = query(collection(db, 'users'));
      if (target === 'clients') {
        usersQuery = query(collection(db, 'users'), where('role', '==', 'ROLE_CLIENT'));
      } else if (target === 'guides') {
        usersQuery = query(collection(db, 'users'), where('role', '==', 'ROLE_GUIDE'));
      }

      const userSnaps = await getDocs(usersQuery);
      const batch = writeBatch(db);

      userSnaps.forEach(userDoc => {
        const notifRef = doc(collection(db, 'notifications'));
        batch.set(notifRef, {
          userId: userDoc.id,
          title,
          message,
          type: 'system',
          read: false,
          createdAt: serverTimestamp()
        });
      });

      await batch.commit();
      toast.success(`Notification envoyée à ${userSnaps.size} utilisateurs !`, { id: loading });
    } catch (error) {
      console.error('CRM Error:', error);
      toast.error('Erreur lors de l\'envoi global', { id: loading });
    }
  };

  return (
    <NotificationContext.Provider value={{ notifications, unreadCount, unreadMessagesCount, markAsRead, markAllAsRead, sendPushNotification }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) throw new Error('useNotifications must be used within a NotificationProvider');
  return context;
};

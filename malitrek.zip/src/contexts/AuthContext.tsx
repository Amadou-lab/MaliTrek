import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  onAuthStateChanged, 
  User, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
  getMultiFactorResolver,
  MultiFactorResolver,
  PhoneAuthProvider,
  PhoneMultiFactorGenerator,
  PhoneMultiFactorInfo,
  updateProfile,
  updatePassword,
  EmailAuthProvider,
  reauthenticateWithCredential
} from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, updateDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { UserProfile, UserRole } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  login: (role?: UserRole) => Promise<void>;
  loginWithEmail: (email: string, pass: string, role: UserRole) => Promise<void>;
  registerWithEmail: (email: string, pass: string, role: UserRole, displayName: string) => Promise<void>;
  signInWithPhone: (phoneNumber: string, verifier: RecaptchaVerifier) => Promise<ConfirmationResult>;
  logout: () => Promise<void>;
  createProfile: (firebaseUser: User, role: UserRole, customDisplayName?: string) => Promise<void>;
  updateProfileInfo: (data: { 
    displayName?: string; 
    phone?: string; 
    photoURL?: string;
    bio?: string;
    yearsOfExperience?: number;
    specialties?: string[];
  }) => Promise<void>;
  changePassword: (currentPass: string, newPass: string) => Promise<void>;
  mfaResolver: MultiFactorResolver | null;
  sendMfaCode: (verifier: RecaptchaVerifier) => Promise<void>;
  resolveMfa: (code: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [mfaResolver, setMfaResolver] = useState<MultiFactorResolver | null>(null);
  const [pendingRole, setPendingRole] = useState<UserRole | null>(null);
  const [mfaVerificationId, setMfaVerificationId] = useState<string | null>(null);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      // Cleanup previous profile listener if it exists
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      setUser(firebaseUser);
      if (firebaseUser) {
        const docRef = doc(db, 'users', firebaseUser.uid);
        
        // Use onSnapshot for real-time updates
        unsubscribeProfile = onSnapshot(docRef, (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data() as UserProfile;
            setProfile({
              ...data,
              favorites: data.favorites || [] // Ensure favorites is always an array
            });
          } else {
            setProfile(null);
          }
          setLoading(false);
        }, (error) => {
          // Only report error if we are still authenticated as this user
          // to avoid "permission-denied" noise on logout
          if (auth.currentUser?.uid === firebaseUser.uid) {
            handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
          }
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const createProfile = async (firebaseUser: User, role: UserRole, customDisplayName?: string) => {
    try {
      const docRef = doc(db, 'users', firebaseUser.uid);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        let finalRole = role;
        if (firebaseUser.email === 'diabateamadou88@gmail.com') {
          finalRole = 'ROLE_ADMIN';
          // Ensure admin document exists for rules exists() check
          const adminRef = doc(db, 'admins', firebaseUser.uid);
          await setDoc(adminRef, { uid: firebaseUser.uid, email: firebaseUser.email, updatedAt: serverTimestamp() }, { merge: true });
        }

        const newProfile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          displayName: customDisplayName || firebaseUser.displayName || firebaseUser.phoneNumber || 'Voyageur MaliTrek',
          phone: firebaseUser.phoneNumber || '',
          role: finalRole,
          createdAt: serverTimestamp(),
          favorites: []
        } as any;
        await setDoc(docRef, newProfile);
        setProfile(newProfile);
      } else {
        setProfile(docSnap.data() as UserProfile);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${firebaseUser.uid}`);
    }
  };

  const login = async (selectedRole?: UserRole) => {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (selectedRole) {
        await createProfile(result.user, selectedRole);
      } else {
        // If no role selected, try to fetch existing
        const docRef = doc(db, 'users', result.user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setProfile(docSnap.data() as UserProfile);
        }
      }
    } catch (error: any) {
      if (error.code === 'auth/multi-factor-auth-required') {
        const resolver = getMultiFactorResolver(auth, error);
        setMfaResolver(resolver);
        if (selectedRole) setPendingRole(selectedRole);
        throw error;
      }
      throw error;
    }
  };

  const loginWithEmail = async (email: string, pass: string, role: UserRole) => {
    try {
      const result = await signInWithEmailAndPassword(auth, email, pass);
      await createProfile(result.user, role);
    } catch (error: any) {
      if (error.code === 'auth/multi-factor-auth-required') {
        const resolver = getMultiFactorResolver(auth, error);
        setMfaResolver(resolver);
        setPendingRole(role);
        throw error; // Re-throw to let UI handle the state change
      }
      throw error;
    }
  };

  const sendMfaCode = async (verifier: RecaptchaVerifier) => {
    if (!mfaResolver) return;
    const hint = mfaResolver.hints[0];
    if (hint.factorId !== 'phone') {
      throw new Error('Seule l\'authentification par téléphone est supportée pour le moment.');
    }
    
    const phoneAuthProvider = new PhoneAuthProvider(auth);
    const phoneInfoOptions = {
      multiFactorHint: hint as PhoneMultiFactorInfo,
      session: mfaResolver.session
    };
    const vId = await phoneAuthProvider.verifyPhoneNumber(phoneInfoOptions, verifier);
    setMfaVerificationId(vId);
  };

  const resolveMfa = async (code: string) => {
    if (!mfaResolver || !pendingRole || !mfaVerificationId) return;

    const cred = PhoneAuthProvider.credential(mfaVerificationId, code);
    const multiFactorAssertion = PhoneMultiFactorGenerator.assertion(cred);
    const result = await mfaResolver.resolveSignIn(multiFactorAssertion);
    
    await createProfile(result.user, pendingRole);
    setMfaResolver(null);
    setMfaVerificationId(null);
    setPendingRole(null);
  };

  const registerWithEmail = async (email: string, pass: string, role: UserRole, displayName: string) => {
    const result = await createUserWithEmailAndPassword(auth, email, pass);
    await createProfile(result.user, role, displayName);
  };

  const signInWithPhone = async (phoneNumber: string, verifier: RecaptchaVerifier) => {
    return await signInWithPhoneNumber(auth, phoneNumber, verifier);
  };

  const updateProfileInfo = async (data: { 
    displayName?: string; 
    phone?: string; 
    photoURL?: string;
    bio?: string;
    yearsOfExperience?: number;
    specialties?: string[];
  }) => {
    if (!user) return;
    try {
      // Update Auth Profile if displayName or photoURL is provided
      if (data.displayName || data.photoURL) {
        await updateProfile(user, {
          displayName: data.displayName || user.displayName,
          photoURL: data.photoURL || user.photoURL
        });
      }

      // Update Firestore Profile
      const docRef = doc(db, 'users', user.uid);
      await updateDoc(docRef, data);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
      throw error;
    }
  };

  const changePassword = async (currentPass: string, newPass: string) => {
    if (!user || !user.email) return;
    try {
      const credential = EmailAuthProvider.credential(user.email, currentPass);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, newPass);
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      login, 
      loginWithEmail, 
      registerWithEmail, 
      signInWithPhone,
      logout,
      createProfile,
      updateProfileInfo,
      changePassword,
      mfaResolver,
      sendMfaCode,
      resolveMfa
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

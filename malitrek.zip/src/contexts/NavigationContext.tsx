import React, { createContext, useContext, useState, useCallback } from 'react';
import toast from 'react-hot-toast';

export type ViewType = 
  // Shared/Common
  | 'home' | 'login' | 'register' | 'profile' | 'settings' | 'notifications' | 'messages' | 'leaderboard' | 'contact' | 'terms'
  // Client specific
  | 'explore' | 'circuits' | 'my_reservations' | 'favorites' 
  // Guide specific
  | 'dashboard' | 'journeys' | 'reservations' | 'clients' | 'wallet' | 'reports' | 'terrain_console'
  // Admin specific
  | 'users' | 'guides' | 'disputes' | 'transactions' | 'finance' | 'terrain_supervision' | 'analytics' | 'content';

interface NavigationParams {
  circuitId?: string;
  journeyId?: string;
  reservationId?: string;
  conversationId?: string;
  disputeId?: string;
  guideId?: string;
  userId?: string;
  [key: string]: any;
}

interface NavigationContextType {
  activeView: string;
  params: NavigationParams;
  navigateTo: (view: string, params?: NavigationParams) => void;
  goBack: () => void;
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

export const NavigationProvider: React.FC<{ children: React.ReactNode, initialView?: string }> = ({ 
  children, 
  initialView = 'home' 
}) => {
  const [navState, setNavState] = useState<{
    history: { view: string; params: NavigationParams }[];
    currentIndex: number;
  }>({
    history: [{ view: initialView, params: {} }],
    currentIndex: 0
  });

  const activeView = navState.history[navState.currentIndex]?.view || initialView;
  const params = navState.history[navState.currentIndex]?.params || {};

  const navigateTo = useCallback((view: string, newParams: NavigationParams = {}) => {
    // Basic validation
    if (!view) return;

    // Special handling for missing IDs if required by view
    if (view.includes('detail') || view.includes('chat') || view.includes('profile_view')) {
      const idKeys = ['circuitId', 'journeyId', 'reservationId', 'conversationId', 'disputeId', 'guideId', 'userId'];
      const hasId = idKeys.some(key => !!newParams[key]);
      
      if (!hasId && view !== 'home' && view !== 'dashboard' && view !== 'explore') {
        process.env.NODE_ENV === 'development' && console.warn(`Navigation to ${view} without ID params`, newParams);
      }
    }

    setNavState(prev => {
      const newHistory = prev.history.slice(0, prev.currentIndex + 1);
      return {
        history: [...newHistory, { view, params: newParams }],
        currentIndex: prev.currentIndex + 1
      };
    });
    
    // Auto scroll to top on navigation
    window.scrollTo(0, 0);
  }, []);

  const goBack = useCallback(() => {
    setNavState(prev => {
      if (prev.currentIndex > 0) {
        return { ...prev, currentIndex: prev.currentIndex - 1 };
      }
      return prev;
    });
  }, []);

  return (
    <NavigationContext.Provider value={{ activeView, params, navigateTo, goBack }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used within a NavigationProvider');
  }
  return context;
};

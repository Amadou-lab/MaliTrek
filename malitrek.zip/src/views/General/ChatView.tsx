import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  doc, 
  getDoc,
  limit
} from 'firebase/firestore';
import { db } from '../../firebase';
import { handleFirestoreError, OperationType } from '../../lib/firestoreUtils';
import { useAuth } from '../../contexts/AuthContext';
import { Conversation, Message, UserProfile } from '../../types';
import { trekService } from '../../services/trekService';
import { 
  Send, 
  Search, 
  MoreVertical, 
  Phone, 
  Video, 
  ArrowLeft,
  MessageSquare,
  User
} from 'lucide-react';
import { toDate } from '../../lib/firestoreUtils';

interface ChatViewProps {
  initialConversationId?: string | null;
  onBack?: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({ initialConversationId, onBack }) => {
  const { user, profile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConv, setSelectedConv] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [otherPerson, setOtherPerson] = useState<UserProfile | null>(null);
  const [convLoading, setConvLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', user?.uid || ''),
      orderBy('updatedAt', 'desc')
    );

    const unsub = onSnapshot(q, (snap) => {
      const docs = snap.docs.map(d => ({ id: d.id, ...d.data() } as Conversation));
      setConversations(docs);
      setConvLoading(false);

      if (initialConversationId) {
        setSelectedConv(prev => {
          if (prev?.id === initialConversationId) {
            // Keep current selection but update data if needed (though we might want to keep the object stable)
            const updated = docs.find(c => c.id === initialConversationId);
            return updated || prev;
          }
          const found = docs.find(c => c.id === initialConversationId);
          return found || null;
        });
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'conversations');
      setConvLoading(false);
    });

    return () => unsub();
  }, [user, initialConversationId]);

  useEffect(() => {
    if (!selectedConv || !user) return;

    const q = query(
      collection(db, 'messages'),
      where('conversationId', '==', selectedConv.id),
      orderBy('createdAt', 'asc'),
      limit(100)
    );

    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() } as Message)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'messages');
    });

    // Mark as read when selected
    trekService.markConversationAsRead(selectedConv.id, user?.uid || '');

    return () => unsub();
  }, [selectedConv, user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConv || !user) return;

    const text = newMessage;
    setNewMessage('');
    await trekService.sendMessage(selectedConv.id, user?.uid || '', text);
  };

  if (!user) return null;

  return (
    <div className="h-[calc(100vh-160px)] md:h-[calc(100vh-100px)] flex bg-white dark:bg-stone-900 rounded-[2.5rem] overflow-hidden border border-stone-100 dark:border-stone-800 shadow-xl">
      {/* Sidebar - Conversations List */}
      <div className={`w-full md:w-80 lg:w-96 border-r border-stone-100 dark:border-stone-800 flex flex-col ${selectedConv ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-6 border-b border-stone-100 dark:border-stone-800">
           <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-black text-stone-900 dark:text-white tracking-tight uppercase">Messages</h2>
              <button className="p-2 hover:bg-stone-50 dark:hover:bg-stone-800 rounded-xl transition-colors">
                 <MoreVertical size={20} className="text-stone-400" />
              </button>
           </div>
           <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={16} />
              <input 
                placeholder="Rechercher une discussion..."
                className="w-full pl-10 pr-4 py-3 bg-stone-50 dark:bg-stone-800 border-none rounded-2xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-400 transition-all shadow-inner"
              />
           </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
           {conversations.map(c => {
             const isActive = selectedConv?.id === c.id;
             const isGuide = profile?.role === 'ROLE_GUIDE';
             const partnerName = isGuide ? c.clientName : c.guideName;
             const partnerRole = isGuide ? 'Client' : 'Guide';
             const unreadCount = c.unreadCountByUser?.[user?.uid || ''] || 0;

             return (
               <button 
                 key={c.id}
                 onClick={() => setSelectedConv(c)}
                 className={`w-full p-4 rounded-[1.5rem] flex items-center gap-4 transition-all relative ${isActive ? 'bg-emerald-50 dark:bg-emerald-900/20 ring-1 ring-emerald-100 dark:ring-emerald-900/50' : 'hover:bg-stone-50 dark:hover:bg-stone-800'}`}
               >
                 <div className="w-12 h-12 bg-stone-100 dark:bg-stone-700 rounded-2xl flex items-center justify-center text-stone-400 shrink-0 shadow-inner">
                    <span className="text-lg font-black text-emerald-600">{partnerName?.[0] || '?'}</span>
                 </div>
                 <div className="flex-1 text-left min-w-0">
                    <div className="flex justify-between items-center mb-1">
                      <p className="font-black text-stone-900 dark:text-white text-sm truncate tracking-tight">
                        {partnerName} <span className="text-[10px] text-stone-400 font-bold uppercase ml-1 opacity-60">({partnerRole})</span>
                      </p>
                      <span className="text-[9px] font-bold text-stone-400">
                        {c.lastMessageAt ? new Date(toDate(c.lastMessageAt)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                      </span>
                    </div>
                    <p className="text-[11px] text-emerald-600 font-bold truncate mb-1 opacity-80">{c.circuitTitle} — {c.journeyDate}</p>
                    <p className="text-xs text-stone-500 font-medium truncate italic">{c.lastMessage}</p>
                 </div>
                 {unreadCount > 0 && (
                   <div className="absolute top-4 right-4 w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center text-[10px] font-black text-white shadow-lg shadow-emerald-600/30">
                     {unreadCount}
                   </div>
                 )}
               </button>
             );
           })}
           {!convLoading && conversations.length === 0 && (
             <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
               <div className="p-4 bg-stone-50 dark:bg-stone-800 rounded-full">
                  <MessageSquare size={32} className="text-stone-300" />
               </div>
               <p className="text-xs font-black text-stone-400 uppercase tracking-widest">Aucune conversation</p>
             </div>
           )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className={`flex-1 flex flex-col min-w-0 bg-white dark:bg-stone-900 ${!selectedConv ? 'hidden md:flex' : 'flex'}`}>
        {selectedConv ? (
          <>
            {/* Chat Header */}
            <div className="p-4 md:p-6 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-4 min-w-0">
                 <button onClick={() => setSelectedConv(null)} className="md:hidden p-2 text-stone-400"><ArrowLeft size={20} /></button>
                 <div className="w-10 h-10 md:w-12 md:h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center text-emerald-600 font-black shrink-0 shadow-inner">
                    {(profile?.role === 'ROLE_GUIDE' ? selectedConv.clientName : selectedConv.guideName)?.[0] || '?'}
                 </div>
                 <div className="min-w-0">
                    <h3 className="text-sm md:text-base font-black text-stone-900 dark:text-white truncate uppercase tracking-tight">
                      {profile?.role === 'ROLE_GUIDE' ? selectedConv.clientName : selectedConv.guideName}
                    </h3>
                    <div className="flex items-center gap-2">
                       <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest">{selectedConv.circuitTitle}</span>
                       <span className="w-1 h-1 bg-stone-300 rounded-full" />
                       <span className="text-[10px] text-stone-400 font-medium">{selectedConv.journeyDate}</span>
                    </div>
                 </div>
              </div>
              <div className="hidden sm:flex items-center gap-2 md:gap-4 shrink-0">
                 <button className="p-2 md:p-3 bg-stone-50 dark:bg-stone-800 text-stone-400 hover:text-emerald-600 rounded-2xl transition-all shadow-sm"><Phone size={18} /></button>
                 <button className="p-2 md:p-3 bg-stone-50 dark:bg-stone-800 text-stone-400 hover:text-emerald-600 rounded-2xl transition-all shadow-sm"><Video size={18} /></button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 bg-stone-50/30 dark:bg-stone-950/20">
              {messages.map((m, idx) => {
                const isMine = m.senderId === user?.uid;
                const showAuthor = idx === 0 || messages[idx-1].senderId !== m.senderId;
                
                return (
                  <div key={m.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'} items-end gap-3`}>
                    {!isMine && showAuthor && (
                      <div className="w-8 h-8 bg-stone-100 dark:bg-stone-800 rounded-xl flex items-center justify-center text-[10px] font-black text-stone-400 shrink-0">
                        {m.senderName?.[0]}
                      </div>
                    )}
                    {!isMine && !showAuthor && <div className="w-8 shrink-0" />}
                    
                    <div className="max-w-[80%] md:max-w-[70%] space-y-1">
                      {!isMine && showAuthor && (
                        <p className="text-[10px] font-black text-stone-400 uppercase ml-1">{m.senderName} ({m.senderRole === 'ROLE_GUIDE' ? 'Guide' : 'Client'})</p>
                      )}
                      <div className={`p-4 rounded-[1.5rem] shadow-sm text-sm font-medium leading-relaxed ${isMine ? 'bg-stone-900 text-white rounded-br-none' : 'bg-white dark:bg-stone-800 text-stone-800 dark:text-stone-200 rounded-bl-none border border-stone-100 dark:border-stone-700'}`}>
                        {m.text}
                      </div>
                      <p className={`text-[9px] font-bold text-stone-400 ${isMine ? 'text-right' : 'text-left'}`}>
                        {m.createdAt ? new Date(toDate(m.createdAt)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 md:p-8 border-t border-stone-100 dark:border-stone-800 bg-white dark:bg-stone-900">
               <form onSubmit={handleSendMessage} className="flex items-center gap-4 bg-stone-50 dark:bg-stone-800 p-2 md:p-3 rounded-[2rem] border border-stone-100 dark:border-stone-700 shadow-inner">
                  <input 
                    value={newMessage}
                    onChange={e => setNewMessage(e.target.value)}
                    placeholder="Écrivez votre message..."
                    className="flex-1 bg-transparent border-none outline-none px-4 text-sm font-medium dark:text-white"
                  />
                  <button 
                    type="submit"
                    disabled={!newMessage.trim()}
                    className="w-10 h-10 md:w-12 md:h-12 bg-emerald-600 text-white rounded-2xl flex items-center justify-center hover:bg-emerald-700 disabled:opacity-50 disabled:grayscale transition-all shadow-lg shadow-emerald-600/20"
                  >
                    <Send size={18} />
                  </button>
               </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-6">
             <div className="w-32 h-32 bg-stone-50 dark:bg-stone-800 rounded-full flex items-center justify-center border border-stone-100 dark:border-stone-800 shadow-inner">
                <MessageSquare size={48} className="text-stone-200" />
             </div>
             <div className="space-y-2">
                <h3 className="text-xl font-black text-stone-900 dark:text-white tracking-tight uppercase tracking-widest">MaliTrek Messages</h3>
                <p className="max-w-xs text-sm text-stone-400 font-medium leading-relaxed">
                  Sélectionnez une discussion pour commencer à discuter avec votre guide ou votre client.
                </p>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../../lib/firestoreUtils';
import { db } from '../../firebase';
import { Circuit, POI } from '../../types';
import { AdvancedMap } from '../../components/shared/AdvancedMap';
import { PremiumLoading } from '../../components/shared/UI';
import { Search, Map as MapIcon, List, Star, Clock, MapPin, X, ArrowLeft, ChevronRight } from 'lucide-react';

export const ExploreMapView: React.FC<{ onViewChange?: (view: string) => void }> = ({ onViewChange }) => {
    const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
    const [circuits, setCircuits] = useState<Circuit[]>([]);
    const [pois, setPois] = useState<POI[]>([]);
    const [selectedCircuit, setSelectedCircuit] = useState<Circuit | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [filterCategory, setFilterCategory] = useState<string>('all');
    const [isLoading, setIsLoading] = useState(true);
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    useEffect(() => {
        const unsubC = onSnapshot(
            query(collection(db, 'circuits'), where('status', '==', 'approved')),
            (snap) => {
                setCircuits(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Circuit)));
                setIsLoading(false);
            },
            (error) => {
                handleFirestoreError(error, OperationType.LIST, 'circuits');
                setIsLoading(false);
            }
        );

        const unsubP = onSnapshot(collection(db, 'pois'), (snap) => {
            setPois(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as POI)));
        }, (error) => {
            handleFirestoreError(error, OperationType.LIST, 'pois');
        });

        return () => { unsubC(); unsubP(); };
    }, []);

    const filteredCircuits = useMemo(() => {
        return circuits.filter(c => {
            const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                 c.location.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesCategory = filterCategory === 'all' || c.category === filterCategory;
            return matchesSearch && matchesCategory;
        });
    }, [circuits, searchQuery, filterCategory]);

    const handleMarkerClick = (id: string, type: 'circuit' | 'journey' | 'poi' | 'step') => {
        if (type === 'circuit') {
            const circuit = circuits.find(c => c.id === id);
            if (circuit) {
                setSelectedCircuit(circuit);
                if (window.innerWidth < 1024) setViewMode('list'); 
            }
        }
    };

    return (
        <div className="h-screen flex flex-col bg-white overflow-hidden text-emerald-primary relative">
            {/* Minimalist Top Nav - Sticky on Mobile */}
            <div className="h-20 md:h-24 bg-white/80 backdrop-blur-xl border-b border-stone-50 px-4 md:px-12 flex items-center justify-between z-50 gap-4 sticky top-0">
                <div className="flex items-center gap-4 md:gap-8 shrink-0">
                    <button 
                        onClick={() => onViewChange?.('home')} 
                        className="w-10 h-10 md:w-14 md:h-14 flex items-center justify-center bg-stone-100 hover:bg-emerald-accent hover:text-white rounded-xl md:rounded-2xl transition-all active:scale-95 shadow-sm"
                    >
                        <ArrowLeft className="w-5 h-5 md:w-6 md:h-6" />
                    </button>
                    <div className="stagger-in hidden md:block">
                       <p className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-1">Immersion</p>
                       <h1 className="text-xl md:text-3xl font-serif font-black tracking-tighter italic whitespace-nowrap">Explorer <span className="text-stone-300">le Mali</span></h1>
                    </div>
                </div>

                <div className="flex-1 max-w-2xl mx-0 md:mx-20">
                   <div className="w-full relative group">
                      <Search className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 text-stone-200 group-focus-within:text-emerald-accent transition-colors" size={18} />
                      <input 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Où aller ?" 
                        className="w-full h-12 md:h-16 pl-10 md:pl-16 pr-4 md:pr-8 rounded-2xl md:rounded-[2rem] bg-stone-50 border-transparent text-xs md:text-sm font-bold focus:bg-white focus:ring-4 focus:ring-emerald-accent/10 transition-all outline-none placeholder:text-stone-200"
                      />
                   </div>
                </div>

                <div className="hidden sm:flex items-center gap-4 md:gap-6 shrink-0">
                    <div className="bg-stone-50 p-1.5 rounded-2xl border border-stone-100 shadow-inner flex">
                        <button 
                            onClick={() => setViewMode('map')}
                            className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'map' ? 'bg-white shadow-md text-emerald-accent' : 'text-stone-premium/30'}`}
                        >
                            Carte
                        </button>
                        <button 
                            onClick={() => setViewMode('list')}
                            className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white shadow-md text-emerald-accent' : 'text-stone-premium/30'}`}
                        >
                            Liste
                        </button>
                    </div>
                </div>
            </div>

            {isLoading ? (
                <div className="flex-1 flex items-center justify-center bg-sable-light">
                    <PremiumLoading message="Déploiement de la cartographie..." />
                </div>
            ) : (
                <div className="flex-1 flex overflow-hidden relative">
                    {/* Discovery Sidebar / List View on Mobile */}
                    <aside 
                        className={`absolute inset-0 lg:relative z-40 bg-white border-r border-stone-50 transition-all duration-700 ease-in-out flex flex-col
                            ${viewMode === 'list' ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
                            ${isSidebarOpen ? 'w-full lg:w-[450px]' : 'w-0 lg:w-0'}`}
                    >
                        <div className="p-6 md:p-10 border-b border-stone-50 shrink-0">
                            <div className="flex gap-3 md:gap-4 overflow-x-auto pb-2 no-scrollbar">
                               {['all', 'Culture', 'Nature', 'Aventure', 'Histoire'].map(cat => (
                                 <button
                                    key={cat}
                                    onClick={() => setFilterCategory(cat)}
                                    className={`px-6 md:px-8 py-3 md:py-3.5 rounded-full text-[9px] md:text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all border-2 ${
                                        filterCategory === cat ? 'bg-emerald-primary border-emerald-primary text-white' : 'bg-transparent border-stone-100 text-stone-premium/40 hover:border-emerald-accent text-[8px]'
                                    }`}
                                 >
                                   {cat === 'all' ? 'Tous' : cat}
                                 </button>
                               ))}
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-4 md:p-10 space-y-8 md:space-y-12 custom-scrollbar pb-32">
                            {filteredCircuits.length > 0 ? (
                                filteredCircuits.map(circuit => (
                                    <motion.div
                                        key={circuit.id}
                                        layout
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        onClick={() => setSelectedCircuit(circuit)}
                                        className={`group cursor-pointer rounded-3xl md:rounded-[3rem] overflow-hidden transition-all duration-500 border-2
                                            ${selectedCircuit?.id === circuit.id ? 'border-emerald-accent bg-white' : 'border-transparent bg-stone-50/50 hover:bg-white shadow-sm'}`}
                                    >
                                        <div className="relative h-48 md:h-64 overflow-hidden">
                                            <img src={circuit.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]" />
                                            <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary/60 via-transparent to-transparent opacity-60" />
                                            <div className="absolute inset-x-4 md:inset-x-6 top-4 md:top-6 flex justify-between items-start">
                                               <span className="px-3 md:px-4 py-1.5 bg-white/90 backdrop-blur-md rounded-xl text-[8px] md:text-[9px] font-black uppercase tracking-widest text-emerald-accent shadow-sm">{circuit.category}</span>
                                               <div className="flex items-center gap-1.5 bg-emerald-primary/90 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-sm text-white">
                                                  <Star size={12} className="text-emerald-accent fill-current" />
                                                  <span className="text-[10px] font-bold">{circuit.averageRating?.toFixed(1) || '4.9'}</span>
                                               </div>
                                            </div>
                                            <div className="absolute bottom-4 md:bottom-6 left-4 md:left-6 right-4 md:right-6">
                                                <h3 className="text-xl md:text-2xl font-serif font-black text-white tracking-tight leading-tight drop-shadow-lg">{circuit.title}</h3>
                                            </div>
                                        </div>
                                        <div className="p-4 md:p-8 space-y-4 md:space-y-6">
                                            <div className="flex flex-wrap items-center gap-4 md:gap-6 text-[9px] md:text-[10px] font-bold uppercase tracking-widest text-stone-premium/40">
                                                <span className="flex items-center gap-2"><MapPin size={14} className="text-emerald-accent" /> {circuit.location}</span>
                                                <span className="flex items-center gap-2"><Clock size={14} className="text-emerald-accent" /> {circuit.duration}</span>
                                            </div>
                                            <div className="flex justify-between items-center pt-4 md:pt-6 border-t border-stone-50">
                                                <div>
                                                    <p className="text-[8px] font-bold text-stone-premium/30 uppercase tracking-widest mb-1 italic">Tarif</p>
                                                    <p className="text-xl md:text-2xl font-serif font-black text-emerald-primary">{circuit.basePrice.toLocaleString()} <span className="text-[10px] font-sans not-italic font-bold opacity-30">CFA</span></p>
                                                </div>
                                                <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-emerald-primary text-white flex items-center justify-center transition-all">
                                                   <ChevronRight size={20} />
                                                </div>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))
                            ) : (
                                <div className="py-20 text-center space-y-4">
                                    <MapIcon size={32} className="mx-auto text-stone-100" />
                                    <p className="text-xl font-serif italic text-stone-200">Aucun secret trouvé.</p>
                                </div>
                            )}
                        </div>
                    </aside>

                    {/* Floating Toggle for Mobile */}
                    <div className="lg:hidden fixed bottom-24 left-1/2 -translate-x-1/2 z-[55] flex bg-emerald-primary/95 backdrop-blur-xl border border-white/20 p-1.5 rounded-full shadow-2xl">
                        <button 
                            onClick={() => setViewMode('map')}
                            className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'map' ? 'bg-white text-emerald-primary' : 'text-white/60'}`}
                        >
                            <MapIcon size={16} />
                            Carte
                        </button>
                        <button 
                            onClick={() => setViewMode('list')}
                            className={`flex items-center gap-2 px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'list' ? 'bg-white text-emerald-primary' : 'text-white/60'}`}
                        >
                            <List size={16} />
                            Liste
                        </button>
                    </div>

                    {/* Map Interface */}
                    <main className={`flex-1 h-full relative bg-[#FDFCFB] transition-opacity duration-500 ${viewMode === 'list' ? 'opacity-0 lg:opacity-100 pointer-events-none lg:pointer-events-auto' : 'opacity-100'}`}>
                        <div className="absolute inset-0">
                            <AdvancedMap 
                                circuits={filteredCircuits}
                                pois={pois}
                                itinerary={selectedCircuit?.itinerary || []}
                                selectedId={selectedCircuit?.id}
                                onMarkerClick={handleMarkerClick}
                                center={selectedCircuit ? [selectedCircuit.lat || 12.6392, selectedCircuit.lng || -8.0029] : undefined}
                            />
                        </div>

                        {/* Quick Select Panel for Mobile (Luxury Bottom Sheet) */}
                        <AnimatePresence>
                            {selectedCircuit && (
                                <motion.div 
                                    initial={{ y: '100%' }}
                                    animate={{ y: 0 }}
                                    exit={{ y: '100%' }}
                                    transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                                    className="absolute bottom-0 inset-x-0 bg-emerald-primary text-white p-6 md:p-12 rounded-t-[2.5rem] md:rounded-t-[5rem] z-50 lg:hidden shadow-sahara"
                                >
                                    <div className="w-12 h-1.5 bg-white/10 rounded-full mx-auto mb-4 md:mb-10 opacity-50" />
                                    <div className="flex justify-between items-start mb-6 md:mb-10">
                                        <div className="space-y-1 md:space-y-4">
                                            <span className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.4em] text-emerald-accent italic">{selectedCircuit.category}</span>
                                            <h2 className="text-2xl md:text-5xl font-serif font-black leading-tight italic tracking-tighter">{selectedCircuit.title}</h2>
                                        </div>
                                        <button onClick={() => setSelectedCircuit(null)} className="w-10 h-10 md:w-14 md:h-14 bg-white/10 rounded-xl md:rounded-2xl flex items-center justify-center backdrop-blur-md active:scale-90 transition-all"><X size={20} /></button>
                                    </div>
                                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 md:gap-6 pt-6 md:pt-10 border-t border-white/5">
                                        <div>
                                            <p className="text-[9px] md:text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1 italic">Investissement</p>
                                            <p className="text-2xl md:text-4xl font-serif italic font-black text-emerald-accent">{selectedCircuit.basePrice.toLocaleString()} <span className="text-sm font-sans not-italic font-bold opacity-30">CFA</span></p>
                                        </div>
                                        <button 
                                            onClick={() => onViewChange?.('home')}
                                            className="h-14 md:h-20 px-8 md:px-12 bg-emerald-accent text-emerald-primary rounded-xl md:rounded-[1.5rem] font-black text-[10px] md:text-xs uppercase tracking-[0.2em] shadow-xl active:scale-95 transition-all w-full md:w-auto"
                                        >
                                            SÉCURISER MA PLACE
                                        </button>
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* Sidebar Toggle (Desktop High-End) */}
                        <button 
                          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                          className="hidden lg:flex absolute left-0 top-1/2 -translate-y-1/2 z-50 w-8 h-24 bg-white border border-stone-50 rounded-r-3xl items-center justify-center hover:bg-emerald-accent hover:text-white transition-all shadow-sahara"
                          style={{ left: isSidebarOpen ? (viewMode === 'list' ? '0' : '0') : '0' }}
                        >
                          <ChevronRight className={`transition-transform duration-[1s] ${isSidebarOpen ? 'rotate-180' : 'rotate-0'}`} size={20} />
                        </button>

                        {/* Map Detail Panel (Desktop Ultra-Luxury) */}
                        <AnimatePresence>
                            {selectedCircuit && (
                                <motion.div 
                                    initial={{ x: '120%', opacity: 0 }}
                                    animate={{ x: 0, opacity: 1 }}
                                    exit={{ x: '120%', opacity: 0 }}
                                    transition={{ type: 'spring', damping: 30, stiffness: 150 }}
                                    className="absolute top-10 right-10 bottom-10 w-[550px] bg-white rounded-[5rem] shadow-sahara overflow-hidden z-40 hidden lg:flex flex-col border border-stone-50"
                                >
                                    <div className="relative h-[45%] group overflow-hidden">
                                        <img src={selectedCircuit.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[3s]" />
                                        <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary/80 via-transparent to-transparent opacity-40" />
                                        <button 
                                            onClick={() => setSelectedCircuit(null)} 
                                            className="absolute top-10 right-10 w-14 h-14 bg-white/20 backdrop-blur-xl rounded-2xl text-white flex items-center justify-center hover:bg-emerald-accent transition-all shadow-xl active:scale-90"
                                        >
                                            <X size={28} />
                                        </button>
                                        <div className="absolute bottom-10 left-10 right-10">
                                           <span className="px-5 py-2 bg-emerald-accent rounded-xl text-[10px] font-black uppercase tracking-widest text-emerald-primary shadow-xl mb-4 inline-block italic">
                                                {selectedCircuit.category} Signature
                                            </span>
                                            <h2 className="text-5xl font-serif font-black text-white tracking-tighter leading-tight drop-shadow-2xl italic">{selectedCircuit.title}</h2>
                                        </div>
                                    </div>
                                    <div className="flex-1 p-16 overflow-y-auto custom-scrollbar space-y-16">
                                        <div className="space-y-8">
                                            <p className="text-lg font-serif italic text-stone-premium/60 leading-relaxed font-medium">
                                                {selectedCircuit.description || "Une odyssée sur mesure à travers les joyaux occultes du Mali, orchestrée pour l'élite des voyageurs en quête d'authentique."}
                                            </p>
                                            
                                            <div className="flex gap-12 items-center">
                                               <div className="space-y-1">
                                                  <p className="text-[9px] font-black uppercase tracking-[0.3em] text-stone-200">Localité</p>
                                                  <p className="text-sm font-black text-emerald-primary">{selectedCircuit.location}</p>
                                               </div>
                                               <div className="space-y-1">
                                                  <p className="text-[9px] font-black uppercase tracking-[0.3em] text-stone-200">Temporalité</p>
                                                  <p className="text-sm font-black text-emerald-primary uppercase">{selectedCircuit.duration}</p>
                                               </div>
                                               <div className="space-y-1">
                                                  <p className="text-[9px] font-black uppercase tracking-[0.3em] text-stone-200">Expertise</p>
                                                  <p className="text-sm font-black text-emerald-primary uppercase tracking-widest">Premium</p>
                                               </div>
                                            </div>
                                        </div>

                                        <div className="space-y-10">
                                            <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-emerald-accent italic">L'Expérience Par Étapes</h4>
                                            <div className="space-y-8">
                                                {(selectedCircuit.itinerary || []).slice(0, 4).map((step, idx) => (
                                                    <div key={idx} className="flex gap-8 items-start group">
                                                       <div className="w-14 h-14 rounded-[1.5rem] bg-stone-50 border border-stone-100 flex-shrink-0 flex items-center justify-center font-serif italic font-black text-emerald-accent text-2xl group-hover:bg-emerald-primary group-hover:text-white transition-all duration-500 shadow-sm">
                                                          {idx + 1}
                                                       </div>
                                                       <div className="pt-2">
                                                          <h6 className="text-[15px] font-black text-emerald-primary mb-1 tracking-tight">{step.title}</h6>
                                                          <p className="text-[10px] font-bold uppercase tracking-widest text-stone-premium/30 italic">{step.description || "Exploration exclusive & Découverte"}</p>
                                                       </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="pt-16 border-t border-stone-50 flex items-center justify-between mt-auto">
                                            <div>
                                                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-200 mb-2 italic">Valuation Private</p>
                                                <p className="text-5xl font-serif font-black italic text-emerald-primary">{selectedCircuit.basePrice.toLocaleString()} <span className="text-sm font-sans not-italic font-bold opacity-30">CFA</span></p>
                                            </div>
                                            <button 
                                                onClick={() => onViewChange?.('home')}
                                                className="h-20 px-14 bg-emerald-primary text-white rounded-[1.5rem] font-black text-[11px] uppercase tracking-[0.3em] shadow-sahara hover:bg-emerald-accent hover:text-emerald-primary transition-all active:scale-95 duration-500"
                                            >
                                                RÉSERVER CETTE ODYSSÉE
                                            </button>
                                        </div>
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </main>
                </div>
            )}
        </div>
    );
};

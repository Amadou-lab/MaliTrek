import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, onSnapshot, orderBy, where, doc, getDoc, limit } from 'firebase/firestore';
import { db } from '../../firebase';
import { UserProfile, Transaction, Reservation, Withdrawal } from '../../types';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle, 
  ShieldAlert, 
  Plus, 
  Calendar,
  AlertTriangle,
  Download,
  Filter,
  ArrowRight
} from 'lucide-react';
import { trekService } from '../../services/trekService';
import toast from 'react-hot-toast';

export const GuideWalletView: React.FC<{ profile: UserProfile }> = ({ profile }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('orange_money');
  const [withdrawPhone, setWithdrawPhone] = useState(profile.phone || '');
  const [activeFilter, setActiveFilter] = useState('all');

  useEffect(() => {
    const q = query(
      collection(db, 'transactions'), 
      where('userId', '==', profile.uid),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
    
    return onSnapshot(q, (snap) => {
      setTransactions(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => {
      trekService.handleFirestoreError(error, 'list' as any, 'transactions');
    });
  }, [profile.uid]);

  const handleWithdrawRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    
    if (isNaN(amount) || amount < 1000) {
      toast.error('Montant minimum de retrait: 1 000 CFA');
      return;
    }

    if (amount > (profile.balanceAvailable || 0)) {
       toast.error('Solde disponible insuffisant.');
       return;
    }

    const loading = toast.loading('Envoi de la demande...');
    try {
      await trekService.requestWithdrawal(profile.uid, amount, withdrawMethod as any, withdrawPhone);
      toast.success('Demande de retrait enregistrée. En attente de validation admin.', { id: loading });
      setIsWithdrawModalOpen(false);
      setWithdrawAmount('');
    } catch (e) {
      toast.error('Erreur lors de la demande.', { id: loading });
    }
  };

  const filteredTransactions = transactions.filter(tx => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'earnings') return tx.type === 'guide_earning_release';
    if (activeFilter === 'withdrawals') return tx.type === 'guide_withdrawal_request' || tx.type === 'guide_withdrawal_paid';
    if (activeFilter === 'litiges') return tx.type.includes('dispute');
    return true;
  });

  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-1 md:space-y-2">
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic">Trésorerie MaliTrek</p>
          <h2 className="text-2xl md:text-5xl font-serif font-black text-emerald-primary tracking-tight italic">Mon Portefeuille</h2>
          <p className="text-stone-400 font-medium text-[10px] md:text-base italic">Gérez vos gains, commissions et demandes de retrait.</p>
        </div>
        <button 
          onClick={() => setIsWithdrawModalOpen(true)}
          className="w-full md:w-auto bg-emerald-primary text-white px-8 py-4 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-[0.2em] md:tracking-widest flex items-center justify-center gap-3 hover:translate-y-[-2px] hover:shadow-xl hover:shadow-emerald-primary/20 transition-all active:scale-95 italic"
        >
          <Plus size={18} /> Demande de Retrait
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-6">
        <div className="bg-emerald-900 text-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] shadow-sahara relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 group-hover:scale-125 transition-transform duration-700" />
          <div className="relative z-10 space-y-4 md:space-y-6">
            <div className="flex items-center gap-3 text-emerald-accent font-black uppercase tracking-widest text-[8px] md:text-[10px] italic">
               <CheckCircle size={14} className="animate-pulse" /> Solde Disponible
            </div>
            <div className="space-y-1">
              <p className="text-3xl md:text-5xl font-serif font-black italic">{(profile.balanceAvailable || 0).toLocaleString()}</p>
              <p className="text-[10px] font-medium text-emerald-100/40 italic">XOF • Prêt pour le retrait</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-stone-100 shadow-sahara space-y-4 md:space-y-6">
          <div className="flex items-center gap-3 text-emerald-primary font-black uppercase tracking-widest text-[8px] md:text-[10px] italic">
             <Clock size={14} /> Gains en Attente
          </div>
          <div className="space-y-1">
            <p className="text-3xl md:text-5xl font-serif font-black text-emerald-primary italic">{(profile.balancePending || 0).toLocaleString()}</p>
            <p className="text-[10px] font-medium text-stone-300 italic">XOF • Validation client (24h)</p>
          </div>
        </div>

        <div className="bg-emerald-accent text-emerald-primary p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-emerald-accent/20 space-y-4 md:space-y-6">
          <div className="flex items-center gap-3 text-emerald-primary font-black uppercase tracking-widest text-[8px] md:text-[10px] italic">
             <ShieldAlert size={14} /> Bloqué (Litiges)
          </div>
          <div className="space-y-1">
            <p className="text-3xl md:text-5xl font-serif font-black italic">{(profile.balanceBlocked || 0).toLocaleString()}</p>
            <p className="text-[10px] font-medium text-emerald-primary/40 italic">XOF • Arbitrage en cours</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] md:rounded-[2.5rem] border border-stone-100 shadow-sahara overflow-hidden">
        <div className="p-6 md:p-10 border-b border-stone-50 flex flex-col md:flex-row justify-between items-center gap-6">
           <h3 className="text-lg md:text-2xl font-serif font-black text-emerald-primary tracking-tight italic">Historique des Flux</h3>
           <div className="flex gap-1 md:gap-2 bg-stone-50 p-1 md:p-1.5 rounded-xl md:rounded-2xl w-full md:w-auto overflow-x-auto">
              {[
                { id: 'all', label: 'Tous' },
                { id: 'earnings', label: 'Gains' },
                { id: 'withdrawals', label: 'Retraits' },
                { id: 'litiges', label: 'Litiges' }
              ].map(f => (
                <button 
                  key={f.id}
                  onClick={() => setActiveFilter(f.id)}
                  className={`flex-1 md:flex-none px-4 md:px-6 py-2 md:py-2.5 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeFilter === f.id ? 'bg-emerald-primary text-white shadow-lg' : 'text-stone-300 hover:text-emerald-primary'}`}
                >
                  {f.label}
                </button>
              ))}
           </div>
        </div>

        <div className="divide-y divide-stone-50">
          {filteredTransactions.map((tx, idx) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={tx.id} 
              className="p-5 md:p-8 hover:bg-stone-50 transition-all flex flex-col md:flex-row items-center justify-between gap-4 md:gap-6 group"
            >
              <div className="flex items-center gap-4 md:gap-6 w-full md:w-auto">
                <div className={`w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${
                  tx.category === 'credit' ? 'bg-emerald-50 text-emerald-primary shadow-emerald-primary/10' : 'bg-stone-50 text-stone-400'
                }`}>
                  {tx.category === 'credit' ? <ArrowUpRight className="w-5 md:w-6 h-5 md:h-6" /> : <ArrowDownLeft className="w-5 md:w-6 h-5 md:h-6" />}
                </div>
                <div className="min-w-0">
                   <div className="flex items-center gap-2 mb-0.5 md:mb-1">
                     <p className="text-[7px] md:text-[10px] font-black uppercase tracking-widest text-stone-300 italic truncate max-w-[150px]">{tx.type.replace(/_/g, ' ')}</p>
                     <span className={`px-2 py-0.5 rounded-full text-[6px] md:text-[8px] font-black uppercase tracking-widest ${
                       tx.status === 'completed' ? 'bg-emerald-50 text-emerald-primary' : 'bg-amber-50 text-amber-600'
                     }`}>
                       {tx.status}
                     </span>
                   </div>
                   <h4 className="font-serif font-black text-emerald-primary group-hover:text-emerald-accent transition-colors text-sm md:text-base italic truncate tracking-tight">{tx.description}</h4>
                   {tx.reservationId && (
                     <p className="text-[7px] md:text-[9px] font-black text-stone-300 uppercase tracking-widest mt-0.5 italic">Ref: {tx.reservationId.slice(-8).toUpperCase()}</p>
                   )}
                </div>
              </div>

              <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-1 w-full md:w-auto pt-2 md:pt-0 border-t md:border-t-0 border-stone-50">
                 <p className={`text-lg md:text-2xl font-serif font-black italic ${tx.category === 'credit' ? 'text-emerald-primary' : 'text-stone-400'}`}>
                   {tx.category === 'credit' ? '+' : '-'}{tx.amount.toLocaleString()} XOF
                 </p>
                 <div className="flex items-center gap-1.5 md:gap-2 text-stone-300 font-black text-[7px] md:text-[10px] uppercase tracking-widest italic">
                   <Calendar className="w-2.5 md:w-3 h-2.5 md:h-3" />
                   {tx.createdAt ? new Date(tx.createdAt.seconds * 1000).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : 'Pending'}
                 </div>
              </div>
            </motion.div>
          ))}
          {filteredTransactions.length === 0 && (
             <div className="py-20 text-center text-stone-300 font-black italic uppercase tracking-[0.3em] text-xs">
                Aucune donnée entrante.
             </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {isWithdrawModalOpen && (
          <div className="fixed inset-0 bg-emerald-primary/95 backdrop-blur-xl z-[200] flex items-end md:items-center justify-center p-0 md:p-4">
            <motion.div 
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              className="bg-white rounded-t-[3rem] md:rounded-[4rem] w-full max-w-xl h-[90vh] md:h-auto overflow-y-auto shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-8 md:p-12 bg-emerald-primary text-white flex justify-between items-start sticky top-0 z-20 overflow-hidden">
                 <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-accent/10 rounded-full -mr-32 -mt-32 blur-3xl animate-pulse" />
                 <div className="space-y-2 relative z-10">
                   <p className="text-[8px] font-black uppercase tracking-[0.4em] text-emerald-accent italic">Transaction Sécurisée</p>
                   <h3 className="text-2xl md:text-4xl font-serif font-black tracking-tight italic">Demander un Retrait</h3>
                   <p className="text-emerald-100/60 text-[10px] font-medium italic">Fonds versés directement sur votre compte mobile.</p>
                 </div>
                 <button onClick={() => setIsWithdrawModalOpen(false)} className="bg-white/10 p-3 rounded-2xl text-emerald-accent relative z-10 hover:bg-white/20 transition-all">
                    <Download size={24} className="rotate-180" />
                 </button>
              </div>

              <form onSubmit={handleWithdrawRequest} className="p-8 md:p-12 space-y-6 md:space-y-10">
                 <div className="space-y-6">
                    <div className="space-y-3">
                      <label className="text-[9px] md:text-[11px] font-black text-stone-300 uppercase tracking-widest ml-1 italic italic">Montant (XOF)</label>
                      <div className="relative group">
                        <input 
                          type="number" 
                          required
                          min="1000"
                          max={profile.balanceAvailable}
                          className="w-full bg-stone-50 border-2 border-stone-100 rounded-2xl px-8 py-5 md:py-6 font-serif font-black text-3xl md:text-5xl outline-none ring-emerald-primary/10 focus:ring-8 focus:border-emerald-primary transition-all text-emerald-primary italic"
                          placeholder="0"
                          value={withdrawAmount}
                          onChange={e => setWithdrawAmount(e.target.value)}
                        />
                        <div className="absolute right-6 top-1/2 -translate-y-1/2 text-stone-200 font-black text-lg italic pointer-events-none group-focus-within:text-emerald-accent transition-colors">XOF</div>
                      </div>
                      <div className="flex justify-between items-center px-1">
                        <p className="text-[9px] font-black text-emerald-accent italic uppercase tracking-wider">Min: 1.000</p>
                        <p className="text-[10px] font-bold text-stone-300 italic uppercase">Disponible: {profile.balanceAvailable?.toLocaleString()} XOF</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-[9px] md:text-[11px] font-black text-stone-300 uppercase tracking-widest ml-1 italic">Méthode de réception</label>
                      <div className="grid grid-cols-2 gap-3">
                         {[
                           { id: 'orange_money', label: 'Orange Money' },
                           { id: 'moov_money', label: 'Moov Money' },
                           { id: 'wave', label: 'Wave' },
                           { id: 'bank', label: 'Virement' }
                         ].map(m => (
                           <button 
                            key={m.id}
                            type="button"
                            onClick={() => setWithdrawMethod(m.id)}
                            className={`p-4 md:p-5 rounded-2xl text-[9px] md:text-[11px] font-black uppercase tracking-widest border-2 transition-all italic ${withdrawMethod === m.id ? 'bg-emerald-primary text-white border-emerald-primary shadow-xl shadow-emerald-primary/20 scale-[1.02]' : 'bg-white text-stone-400 border-stone-100 hover:border-emerald-accent/30'}`}
                           >
                             {m.label}
                           </button>
                         ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-[9px] md:text-[11px] font-black text-stone-300 uppercase tracking-widest ml-1 italic">Numéro / Coordonnées</label>
                      <div className="relative">
                        <input 
                          type="text" 
                          required
                          className="w-full bg-stone-50 border-2 border-stone-100 rounded-2xl px-14 py-5 font-black text-emerald-primary outline-none ring-emerald-primary/10 focus:ring-8 focus:border-emerald-primary transition-all text-sm md:text-base italic"
                          placeholder="Ex: 77 00 00 00"
                          value={withdrawPhone}
                          onChange={e => setWithdrawPhone(e.target.value)}
                        />
                        <div className="absolute left-6 top-1/2 -translate-y-1/2 text-stone-300">
                          <Filter size={20} />
                        </div>
                      </div>
                    </div>
                 </div>

                 <div className="bg-emerald-accent/10 p-6 rounded-[2rem] border border-emerald-accent/20 flex gap-4 relative overflow-hidden group">
                    <div className="absolute inset-0 bg-emerald-accent/5 translate-x-full group-hover:translate-x-0 transition-transform duration-500" />
                    <AlertTriangle className="text-emerald-primary shrink-0 relative z-10" size={24} />
                    <p className="text-[10px] font-black text-emerald-primary leading-relaxed uppercase tracking-widest relative z-10 italic">
                       Le traitement administratif est synchronisé sous 24h. Chaque requête est audité par le département financier.
                    </p>
                 </div>

                 <div className="flex gap-4 pt-4">
                   <button 
                    type="button"
                    onClick={() => setIsWithdrawModalOpen(false)}
                    className="flex-1 h-16 rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest text-stone-300 hover:bg-stone-50 transition-all italic"
                   >
                     Annuler
                   </button>
                   <button 
                    type="submit"
                    className="flex-1 h-16 bg-emerald-primary text-white rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-[0.2em] shadow-2xl shadow-emerald-primary/20 active:scale-95 transition-all italic flex items-center justify-center gap-3"
                   >
                     Finaliser le Retrait <ArrowRight size={18} />
                   </button>
                 </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

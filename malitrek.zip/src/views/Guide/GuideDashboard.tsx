import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, onSnapshot, doc, updateDoc, deleteDoc, addDoc, orderBy, serverTimestamp, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { handleFirestoreError, OperationType, sortByDateDesc, toDate } from '../../lib/firestoreUtils';
import { useAuth } from '../../contexts/AuthContext';
import { Circuit, Reservation, Journey, Transaction, WithdrawalRequest, UserProfile } from '../../types';
import { 
  Plus, 
  TrendingUp, 
  Users, 
  ShieldCheck, 
  Wallet, 
  WalletCards,
  BarChart3,
  MapPin,
  Compass,
  History,
  AlertCircle,
  RefreshCw,
  Star,
  ChevronRight,
  Trophy,
  ArrowRight,
  Clock
} from 'lucide-react';
import { trekService } from '../../services/trekService';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { ProfileView } from '../../components/Profile/ProfileView';
import { SettingsView } from '../../components/Settings/SettingsView';
import { GuideWalletView } from './GuideWalletView';
import { GuideReportsView } from './GuideReportsView';
import { UserGuideView } from '../../components/Guide/UserGuideView';
import { GuideReservationsView } from '../../components/reservations/GuideReservationsView';
import { WithdrawalModal } from '../../components/earnings/WithdrawalModal';
import { ReservationDetails } from '../../components/reservations/ReservationDetails';
import { JourneysListView } from '../../components/guide/JourneysListView';
import { PlanJourneyModal } from '../../components/guide/PlanJourneyModal';
import { CircuitDetailsFull } from '../../components/trek/CircuitDetailsFull';
import { CircuitsListView } from '../../components/guide/CircuitsListView';
import { CircuitModal } from '../../components/guide/CircuitModal';
import { ClientsListView } from '../../components/guide/ClientsListView';
import { CircuitDetailsModal } from '../../components/guide/CircuitDetailsModal';
import { JourneyItineraryModal } from '../../components/guide/JourneyItineraryModal';
import { ChatView } from '../General/ChatView';
import { ActiveJourneyBlock } from '../../components/trek/ActiveJourneyBlock';
import { ReportIncidentModal } from '../../components/reservations/ReportIncidentModal';
import { DisputeForm } from '../../components/reservations/DisputeForm';
import toast from 'react-hot-toast';
import { ConfirmModal } from '../../components/ui/ConfirmModal';
import { NotificationInbox } from '../../components/Notifications/NotificationInbox';
import { useNotifications } from '../../contexts/NotificationContext';

import { LeaderboardView } from '../Leaderboard/LeaderboardView';
import { JourneyConsoleView } from './JourneyConsoleView';
import { GuideMapView } from './Views/GuideMapView';
import { useNavigation } from '../../contexts/NavigationContext';

export const GuideDashboard: React.FC<{ activeView: string; onViewChange: (view: string) => void }> = ({ activeView, onViewChange }) => {
  const { profile } = useAuth();
  const { unreadCount } = useNotifications();
  const { params } = useNavigation();
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [journeys, setJourneys] = useState<Journey[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<any[]>([]);
  
  const [isAddingCircuit, setIsAddingCircuit] = useState(false);
  const [editingCircuit, setEditingCircuit] = useState<Circuit | null>(null);
  const [isAddingJourney, setIsAddingJourney] = useState(false);
  const [selectedCircuitForJourney, setSelectedCircuitForJourney] = useState<Circuit | null>(null);
  
  const [viewingCircuit, setViewingCircuit] = useState<Circuit | null>(null);
  const [viewingJourneyItinerary, setViewingJourneyItinerary] = useState<Journey | null>(null);
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null);
  const [selectedClientProfile, setSelectedClientProfile] = useState<UserProfile | null>(null);

  // Derive selectedResJourney instead of using state to avoid loop
  const selectedResJourney = useMemo(() => {
    if (!selectedReservation || !journeys.length) return null;
    return journeys.find(j => j.id === selectedReservation.journeyId) || null;
  }, [selectedReservation, journeys]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [isDisputing, setIsDisputing] = useState(false);
  const [isReportingIncident, setIsReportingIncident] = useState(false);
  
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const [selectedJourneyId, setSelectedJourneyId] = useState<string | null>(null);

  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const Card: React.FC<{ children: React.ReactNode, className?: string, onClick?: () => void }> = ({ children, className, onClick }) => (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={onClick ? { scale: 1.02 } : undefined}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      onClick={onClick}
      className={`bg-white p-8 rounded-[2.5rem] shadow-sm border border-stone-100 ${className} ${onClick ? 'cursor-pointer' : ''}`}
    >
      {children}
    </motion.div>
  );

  useEffect(() => {
    if (params.reservationId && activeView === 'reservations') {
      const res = reservations.find(r => r.id === params.reservationId);
      if (res) setSelectedReservation(res);
    }
    if (params.journeyId && (activeView === 'journeys' || activeView === 'dashboard')) {
      setSelectedJourneyId(params.journeyId);
    }
    if (params.conversationId && activeView === 'messages') {
      setActiveConversationId(params.conversationId);
    }
  }, [params, activeView, reservations, journeys]);

  useEffect(() => {
    if (!profile?.uid) return;

    setIsLoading(true);
    const qCircuits = query(collection(db, 'circuits'), where('guideId', '==', profile.uid));
    const unsubscribeCircuits = onSnapshot(qCircuits, (snapshot) => {
      setCircuits(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Circuit)).sort(sortByDateDesc));
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'circuits');
      setIsLoading(false);
    });

    const qJourneys = query(collection(db, 'journeys'), where('guideId', '==', profile.uid));
    const unsubscribeJourneys = onSnapshot(qJourneys, (snapshot) => {
      setJourneys(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Journey)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'journeys');
    });

    const qRes = query(collection(db, 'reservations'), where('guideId', '==', profile.uid));
    const unsubscribeRes = onSnapshot(qRes, (snapshot) => {
      setReservations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reservation)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reservations');
    });

    const qWithdrawals = query(collection(db, 'withdrawals'), where('guideId', '==', profile.uid));
    const unsubscribeWithdrawals = onSnapshot(qWithdrawals, (snapshot) => {
      setWithdrawalRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as WithdrawalRequest)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'withdrawals');
    });

    const qTx = query(collection(db, 'transactions'), where('userId', '==', profile.uid));
    const unsubscribeTx = onSnapshot(qTx, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'transactions');
    });

    return () => {
      unsubscribeCircuits();
      unsubscribeJourneys();
      unsubscribeRes();
      unsubscribeWithdrawals();
      unsubscribeTx();
    };
  }, [profile?.uid]);

  // Fetch client profile when reservation changes
  useEffect(() => {
    if (!selectedReservation) {
      setSelectedClientProfile(null);
      return;
    }

    // Fetch Client Profile
    const fetchClient = async () => {
      // Small guard to avoid re-fetching same client
      if (selectedClientProfile?.uid === selectedReservation.userId) return;
      
      const path = `users/${selectedReservation.userId}`;
      try {
        const snap = await getDoc(doc(db, 'users', selectedReservation.userId));
        if (snap.exists()) setSelectedClientProfile(snap.data() as UserProfile);
      } catch (e) {
        handleFirestoreError(e, OperationType.GET, path);
      }
    };

    fetchClient();
  }, [selectedReservation?.userId]); // Only depend on the ID

  // Memoize enriched reservations for performance and stability
  const enrichedReservations = useMemo(() => {
    return reservations.map(r => ({ 
      ...r, 
      journey: journeys.find(j => j.id === r.journeyId) 
    }));
  }, [reservations, journeys]);

  // Financials
  const availableBalance = profile?.balanceAvailable || 0;
  const pendingBalance = profile?.balancePending || 0;

  const totalRevenue = reservations
    .filter(r => r.paymentStatus === 'paid' || r.paymentStatus === 'released')
    .reduce((acc, res) => acc + (res.totalPaid || 0), 0);
  
  const chartData = [...Array(7)].map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
    const dayKey = d.toISOString().split('T')[0];
    
    const dayRevenue = reservations
      .filter(r => (r.paymentStatus === 'paid' || r.paymentStatus === 'released') && toDate(r.createdAt).toISOString().startsWith(dayKey))
      .reduce((acc, r) => acc + (r.totalPaid || 0), 0);
      
    return {
      name: dateStr,
      revenue: dayRevenue
    };
  });

  const handleOpenJourneyConsole = (journeyId: string) => {
    setSelectedJourneyId(journeyId);
    onViewChange('journey_console');
  };

  const handleStartJourney = async (journeyId: string) => {
    handleOpenJourneyConsole(journeyId);
  };

  const handleCompleteJourney = async (journeyId: string) => {
    const loadingToast = toast.loading('Clôture du trajet...');
    try {
      await trekService.completeJourney(journeyId, profile!.uid);
      toast.success('Trajet terminé ! Les clients doivent valider.', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la clôture', { id: loadingToast });
    }
  };

  const handlePublishJourney = async (journeyId: string) => {
    const loadingToast = toast.loading('Publication du trajet...');
    try {
      await trekService.publishJourney(journeyId);
      toast.success('Trajet publié ! Visible par les clients.', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de la publication', { id: loadingToast });
    }
  };

  const handleCancelJourney = async (journeyId: string) => {
    const reason = window.prompt("Motif de l'annulation du trajet ?");
    if (!reason) return;

    const loadingToast = toast.loading('Annulation du trajet...');
    try {
      await trekService.cancelJourney(journeyId, profile!.uid, reason);
      toast.success('Trajet annulé.', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur lors de l\'annulation', { id: loadingToast });
    }
  };

  const handleSubmitCircuit = async (circuitId: string) => {
    try {
      await trekService.submitCircuitForValidation(circuitId);
      toast.success('Circuit soumis pour validation admin !');
    } catch (error) {
      toast.error('Erreur lors de la soumission');
    }
  };

  const handleAddCircuit = async (data: any) => {
    try {
      await trekService.createCircuit(data, profile!.uid);
      setIsAddingCircuit(false);
      toast.success('Circuit créé en brouillon !');
    } catch (error) {
      toast.error('Erreur lors de la création');
    }
  };

  const handleUpdateCircuit = async (data: any) => {
    try {
      const { id, ...rest } = data;
      await updateDoc(doc(db, 'circuits', id), { ...rest, updatedAt: serverTimestamp() });
      setEditingCircuit(null);
      toast.success('Circuit mis à jour !');
    } catch (error) {
      toast.error('Erreur lors de la mise à jour');
    }
  };

  const handleDeleteCircuit = async (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Supprimer le circuit',
      message: 'Voulez-vous vraiment supprimer ce circuit template ?',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'circuits', id));
          toast.success('Circuit supprimé');
        } catch (error) {
          toast.error('Erreur lors de la suppression');
        }
      }
    });
  };

  const handlePlanJourney = async (data: any) => {
    try {
      const circuit = circuits.find(c => c.id === data.circuitId);
      if (!circuit) return;
      await trekService.createJourney(data, circuit);
      setIsAddingJourney(false);
      toast.success('Trajet planifié !');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Erreur');
    }
  };

  const handleWithdrawalRequest = async (amount: number, method: any, accountNumber: string) => {
    try {
      await trekService.requestWithdrawal(profile!.uid, amount, method, accountNumber);
      setIsWithdrawing(false);
      toast.success('Demande de retrait envoyée !');
    } catch (error) {
      toast.error('Erreur lors du retrait');
    }
  };

  const handleSyncStats = async () => {
    if (!profile?.uid) return;
    const loading = toast.loading('Synchronisation des statistiques...');
    try {
      await trekService.recalculateGuideStats(profile.uid);
      toast.success('Statistiques synchronisées avec succès !', { id: loading });
    } catch (e) {
      toast.error('Erreur lors de la synchronisation', { id: loading });
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col">
      <main className="flex-1 overflow-y-auto pb-32 p-3 md:p-8">
        {activeView === 'dashboard' && (
          <div className="max-w-7xl mx-auto space-y-6 md:space-y-12">
            {/* Professional Banner / Status */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 md:gap-10 bg-white p-6 md:p-12 rounded-[2.5rem] md:rounded-[4.1rem] border border-stone-100 shadow-sahara relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-64 md:w-96 h-64 md:h-96 bg-emerald-500/5 rounded-full -mr-16 md:-mr-32 -mt-16 md:-mt-32 blur-3xl group-hover:bg-emerald-500/10 transition-all duration-[3s]" />
                <div className="flex flex-col md:flex-row items-center md:items-end gap-5 md:gap-10 relative text-center md:text-left">
                  <div className="w-20 md:w-28 h-20 md:h-28 rounded-[2rem] md:rounded-[3rem] overflow-hidden bg-stone-100 border-4 md:border-8 border-white shadow-2xl group-hover:rotate-3 transition-transform duration-1000 rotate-2">
                    <img src={profile?.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="space-y-2">
                    <p className="text-[7px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] md:tracking-[0.5em] mb-1 md:mb-3 italic italic">Maître de Terrain</p>
                    <h1 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter leading-none italic">
                      L'Expédition de <br /><span className="text-stone-300 underline decoration-emerald-accent/20 underline-offset-4 md:underline-offset-8">{profile?.displayName?.split(' ')[0]}</span>
                    </h1>
                    <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 md:gap-4 mt-3 md:mt-6">
                      <span className={`px-3 md:px-5 py-1.5 md:py-2 rounded-lg md:rounded-xl text-[7px] md:text-[9px] font-black uppercase tracking-widest md:tracking-[0.2em] shadow-sm flex items-center gap-1.5 md:gap-2 ${
                        profile?.guideTier === 'elite' ? 'bg-amber-50 text-amber-600 border border-amber-100' :
                        profile?.guideTier === 'premium' ? 'bg-emerald-50 text-emerald-primary border border-emerald-primary/10' : 'bg-stone-50 text-stone-400 border border-stone-100'
                      }`}>
                        {profile?.guideTier === 'elite' ? <Trophy className="w-3 md:w-3.5 h-3 md:h-3.5" /> : (profile?.guideTier === 'premium' ? <ShieldCheck className="w-3 md:w-3.5 h-3 md:h-3.5" /> : <Users className="w-3 md:w-3.5 h-3 md:h-3.5" />)}
                        {profile?.guideTier || 'Standard'} Tier
                      </span>
                      <span className="bg-emerald-900 text-white px-3 md:px-5 py-1.5 md:py-2 rounded-lg md:rounded-xl text-[7px] md:text-[9px] font-black uppercase tracking-widest md:tracking-[0.2em] shadow-lg shadow-emerald-900/10 flex items-center gap-1.5 md:gap-2 italic">
                        <RefreshCw className="w-3 md:w-3.5 h-3 md:h-3.5 animate-spin-slow" /> {(profile?.trustScore || 100).toFixed(0)} Trust
                      </span>
                      {profile?.isVerified && (
                        <div className="flex items-center gap-1.5 md:gap-2 text-[7px] md:text-[9px] font-black text-emerald-accent uppercase tracking-widest bg-emerald-accent/10 border border-emerald-accent/20 px-3 md:px-5 py-1.5 md:py-2 rounded-lg md:rounded-xl shadow-sm italic">
                           <ShieldCheck className="w-3 md:w-3.5 h-3 md:h-3.5" /> Vérifié
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-2 md:gap-4 relative w-full md:w-auto">
                  <button 
                    onClick={() => onViewChange('settings')}
                    className="h-14 md:h-20 px-8 md:px-12 bg-emerald-primary text-white hover:bg-emerald-accent hover:text-emerald-primary rounded-xl md:rounded-[1.5rem] font-black text-[9px] md:text-[11px] uppercase tracking-[0.2em] md:tracking-[0.3em] transition-all shadow-xl shadow-emerald-primary/20 active:scale-95 flex items-center justify-center gap-3 italic"
                  >
                    Profil Public <ArrowRight className="w-4 md:w-5 h-4 md:h-5" />
                  </button>
                  <button 
                    onClick={handleSyncStats}
                    className="h-10 md:h-14 px-6 md:px-8 bg-stone-50 border border-stone-100 text-stone-300 hover:text-emerald-accent hover:border-emerald-accent rounded-lg md:rounded-xl text-[8px] md:text-[9px] font-black uppercase tracking-widest transition-all italic"
                  >
                    Auto-Sync Stats
                  </button>
                </div>
            </div>

            {/* Active Journey Section */}
            {journeys.find(j => j.status === 'in_progress') && (
              <div className="bg-emerald-primary text-white p-6 md:p-12 rounded-[2rem] md:rounded-[4rem] shadow-sahara relative overflow-hidden group">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5" />
                <div className="absolute top-0 right-0 w-[400px] md:w-[500px] h-[400px] md:h-[500px] bg-white/5 rounded-full -mr-32 md:-mr-64 -mt-32 md:-mt-64 blur-3xl group-hover:bg-white/10 transition-all duration-1000" />
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 md:gap-12 relative z-10">
                  <div className="flex flex-col sm:flex-row items-center gap-4 md:gap-10 text-center sm:text-left">
                    <div className="w-14 h-14 md:w-20 md:h-20 bg-white/10 backdrop-blur-xl rounded-xl md:rounded-[2rem] flex items-center justify-center shadow-2xl rotate-3 shrink-0">
                      <Compass className="w-7 md:w-8 h-7 md:h-8 text-emerald-accent animate-spin-slow" />
                    </div>
                    <div>
                      <p className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] md:tracking-[0.5em] text-emerald-accent mb-1 md:mb-3 italic">Mission terrain active</p>
                      <h2 className="text-xl md:text-4xl font-serif italic font-black tracking-tight leading-tight">{journeys.find(j => j.status === 'in_progress')!.title}</h2>
                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 md:gap-8 mt-3 md:mt-6 text-emerald-100/60 text-[8px] md:text-[10px] font-black uppercase tracking-widest italic">
                        <span className="flex items-center gap-1.5"><Users className="w-3 md:w-3.5 h-3 md:h-3.5 text-emerald-accent" /> {reservations.filter(r => r.journeyId === journeys.find(j => j.status === 'in_progress')!.id).length} PAX</span>
                        <span className="flex items-center gap-1.5"><MapPin className="w-3 md:w-3.5 h-3 md:h-3.5 text-emerald-accent" /> Étape {(journeys.find(j => j.status === 'in_progress')!.currentStepIndex || 0) + 1}</span>
                        <span className="flex items-center gap-1.5"><Clock className="w-3 md:w-3.5 h-3 md:h-3.5 text-emerald-accent" /> {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} GMT</span>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleOpenJourneyConsole(journeys.find(j => j.status === 'in_progress')!.id)}
                    className="w-full lg:w-auto px-10 md:px-14 h-14 md:h-20 bg-white text-emerald-primary rounded-xl md:rounded-[1.5rem] font-black text-[9px] md:text-11px uppercase tracking-[0.2em] md:tracking-[0.3em] hover:bg-emerald-accent hover:shadow-2xl transition-all shadow-xl shadow-black/20 flex items-center justify-center gap-3 md:gap-4 active:scale-95 whitespace-nowrap italic"
                  >
                    Console Terrain <ArrowRight className="w-4 md:w-5 h-4 md:h-5" />
                  </button>
                </div>
            </div>
            )}

            {/* Business KPIs */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-8">
              {[
                { label: 'Disponible', value: (availableBalance || 0).toLocaleString() + ' CFA', icon: Wallet, color: 'text-emerald-primary', bg: 'bg-emerald-50', view: 'wallet' },
                { label: 'En attente', value: (pendingBalance || 0).toLocaleString() + ' CFA', icon: ShieldCheck, color: 'text-emerald-accent', bg: 'bg-emerald-accent/10', view: 'wallet' },
                { label: 'Taux Succès', value: '98.5%', icon: TrendingUp, color: 'text-emerald-primary', bg: 'bg-stone-50' },
                { label: 'Avis Moyen', value: (profile?.averageRating || 0).toFixed(1) + ' / 5', icon: Star, color: 'text-emerald-primary', bg: 'bg-stone-50' },
              ].map((stat, i) => (
                <Card 
                  key={i} 
                  onClick={stat.view ? () => onViewChange(stat.view) : undefined}
                  className="flex flex-col gap-4 md:gap-6 p-5 md:p-10 min-h-[140px] md:min-h-[220px] justify-between group overflow-hidden hover:shadow-sahara transition-all border border-stone-100 rounded-[1.5rem] md:rounded-[2.5rem]"
                >
                  <div className={`${stat.bg} ${stat.color} w-9 h-9 md:w-14 md:h-14 rounded-lg md:rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-inner shrink-0 shadow-lg shadow-black/[0.02]`}>
                    {/* @ts-ignore */}
                    <stat.icon className="w-4 md:w-6 h-4 md:h-6" />
                  </div>
                  <div>
                    <p className="text-stone-300 text-[7px] md:text-[9px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] mb-1 md:mb-2 italic truncate">{stat.label}</p>
                    <p className="text-base md:text-3xl font-black text-emerald-primary tracking-tighter leading-none italic">{stat.value}</p>
                  </div>
                  {stat.view && (
                    <div className="hidden md:block text-[10px] font-black text-emerald-accent uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity italic">Consulter <ArrowRight size={10} className="inline ml-1" /></div>
                  )}
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
              {/* Analytics Section */}
              <div className="lg:col-span-2 space-y-4 md:space-y-6">
                <div className="flex justify-between items-end px-2 md:px-4">
                  <div className="space-y-1">
                    <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic mb-1">Market Performance</p>
                    <h2 className="text-xl md:text-3xl font-serif font-black text-emerald-primary tracking-tight flex items-center gap-3 italic">
                      Vision Business
                    </h2>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 md:px-4 py-2 bg-white border border-stone-100 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase tracking-widest text-stone-300 italic">SEM</button>
                    <button className="px-3 md:px-4 py-2 bg-stone-900 text-white rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase tracking-widest italic shadow-lg shadow-stone-900/10">MOIS</button>
                  </div>
                </div>
                <Card className="h-[350px] md:h-[450px] p-6 md:p-10 relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-b from-stone-50/50 to-transparent pointer-events-none" />
                  <div className="relative z-10">
                    <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest mb-1 italic">Revenus cumulés (CFA)</p>
                    <p className="text-2xl md:text-3xl font-serif font-black text-emerald-primary italic">{(totalRevenue || 0).toLocaleString()} <span className="text-xs md:text-sm">XOF</span></p>
                  </div>
                  <div className="h-full w-full absolute inset-0 pt-20">
                    <ResponsiveContainer width="100%" height="90%">
                      <AreaChart data={chartData} margin={{ top: 20, right: 10, left: 10, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#065f46" stopOpacity={0.15}/>
                            <stop offset="95%" stopColor="#065f46" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="10 10" vertical={false} stroke="#f8fafc" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 9, fill: '#cbd5e1', fontWeight: '900', letterSpacing: '0.1em'}} />
                        <YAxis hide />
                        <Tooltip 
                          contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.1)', padding: '1rem', background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(10px)' }}
                          itemStyle={{ fontWeight: '900', color: '#065f46', textTransform: 'uppercase', fontSize: '10px' }}
                          labelStyle={{ fontWeight: 'black', marginBottom: '4px', fontSize: '11px', color: '#64748b' }}
                        />
                        <Area type="monotone" dataKey="revenue" stroke="#065f46" strokeWidth={4} fillOpacity={1} fill="url(#colorRev)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              </div>

              {/* Feed Section */}
              <div className="space-y-4 md:space-y-6">
                <div className="flex justify-between items-end px-2 md:px-4">
                  <div className="space-y-1">
                    <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic mb-1">Inbound Activity</p>
                    <h2 className="text-xl md:text-3xl font-serif font-black text-emerald-primary tracking-tight italic">Flux Résas</h2>
                  </div>
                  <button 
                    onClick={() => onViewChange('reservations')}
                    className="text-[9px] md:text-[10px] font-black uppercase tracking-widest text-emerald-accent border-b border-emerald-accent/20 pb-1 italic"
                  >
                    Voir tout
                  </button>
                </div>
                <div className="flex flex-col gap-3 md:gap-4">
                  {reservations.slice(0, 5).map(res => (
                    <motion.div 
                      key={res.id} 
                      whileHover={{ x: 5 }}
                      onClick={() => setSelectedReservation(res)}
                      className="group bg-white p-4 md:p-6 rounded-2xl md:rounded-[2rem] border border-stone-100 shadow-sahara flex items-center justify-between cursor-pointer active:scale-95 transition-all"
                    >
                      <div className="flex items-center gap-3 md:gap-4">
                        <div className="w-10 h-10 md:w-12 md:h-12 bg-stone-50 rounded-xl flex items-center justify-center font-black text-stone-200 text-xs shadow-inner uppercase rotate-2 group-hover:rotate-0 transition-transform">
                          {res.fullname?.charAt(0)}
                        </div>
                        <div className="min-w-0">
                          <p className="font-serif font-black text-emerald-primary text-sm md:text-base group-hover:text-emerald-accent transition-colors truncate italic italic">{res.fullname}</p>
                          <div className="flex items-center gap-2">
                            <span className="text-[8px] md:text-[9px] font-black text-stone-300 tracking-widest uppercase italic">{res.passengers} pax</span>
                            <span className="w-1 h-1 bg-stone-100 rounded-full" />
                            <span className="text-[8px] md:text-[9px] font-black text-stone-300 tracking-widest uppercase italic">{toDate(res.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-emerald-primary font-black text-sm md:text-base italic">{(res.totalPaid || 0).toLocaleString()} <span className="text-[8px] md:text-[10px]">CFA</span></p>
                        <p className={`text-[7px] md:text-[8px] font-black uppercase tracking-[0.2em] shadow-sm px-2 py-0.5 rounded-full inline-block mt-1 ${
                          res.status === 'confirmed' ? 'bg-emerald-50 text-emerald-primary' : 'bg-stone-50 text-stone-300'
                        }`}>{res.status}</p>
                      </div>
                    </motion.div>
                  ))}
                  {reservations.length === 0 && (
                    <div className="bg-white p-12 rounded-[2.5rem] border-2 border-dashed border-stone-100 flex flex-col items-center justify-center text-center">
                       <AlertCircle className="w-10 h-10 text-stone-100 mb-4" />
                       <p className="text-stone-300 font-bold text-xs italic uppercase tracking-widest">Aucune donnée entrante.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Actions Portal */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-10 pt-6 md:pt-10">
               <div className="space-y-4 md:space-y-6">
                <h3 className="text-base md:text-xl font-serif font-black text-emerald-primary ml-2 md:ml-4 tracking-tight flex items-center gap-3 italic">
                  <Compass className="w-4 md:w-5 h-4 md:h-5 text-emerald-accent" />
                  Missions de Terrain
                </h3>
                <Card className="flex flex-col gap-6 md:gap-8 p-8 md:p-10 bg-emerald-900 text-white border-none shadow-2xl shadow-emerald-900/20 group cursor-pointer active:scale-95 transition-all overflow-hidden relative" onClick={() => onViewChange('journeys')}>
                   <div className="absolute -right-10 -bottom-10 opacity-10 rotate-12 group-hover:rotate-45 transition-transform duration-1000">
                     <Compass size={180} />
                   </div>
                   <p className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-emerald-accent/60 italic">Planning & Logistique</p>
                   <h4 className="text-2xl md:text-4xl font-serif font-black tracking-tighter leading-none italic group-hover:translate-x-2 transition-transform">Gérer mes <br/>missions live</h4>
                   <div className="flex items-center gap-3 mt-2 md:mt-4">
                     <span className="w-10 h-10 bg-emerald-accent/20 rounded-xl flex items-center justify-center shadow-lg">
                       <ChevronRight className="w-5 h-5 text-emerald-accent" />
                     </span>
                     <p className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] italic text-emerald-accent">Accéder au terrain</p>
                   </div>
                </Card>
               </div>

               <div className="space-y-4 md:space-y-6">
                <h3 className="text-base md:text-xl font-serif font-black text-emerald-primary ml-2 md:ml-4 tracking-tight flex items-center gap-3 italic">
                  <Plus className="w-4 md:w-5 h-4 md:h-5 text-emerald-accent" />
                  Ingénierie Trek
                </h3>
                <Card className="flex flex-col gap-6 md:gap-8 p-8 md:p-10 bg-emerald-accent text-emerald-primary border-none shadow-2xl shadow-emerald-accent/20 group cursor-pointer active:scale-95 transition-all overflow-hidden relative" onClick={() => setIsAddingCircuit(true)}>
                   <div className="absolute -right-10 -bottom-10 opacity-10 rotate-12 group-hover:rotate-45 transition-transform duration-1000">
                     <MapPin size={180} />
                   </div>
                   <p className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-emerald-primary/40 italic">Design d'expérience</p>
                   <h4 className="text-2xl md:text-4xl font-serif font-black tracking-tighter leading-none italic group-hover:translate-x-2 transition-transform">Nouveau <br/>circuit Trek</h4>
                   <div className="flex items-center gap-3 mt-2 md:mt-4">
                     <span className="w-10 h-10 bg-emerald-primary/10 rounded-xl flex items-center justify-center shadow-lg">
                       <Plus className="w-5 h-5 text-emerald-primary" />
                     </span>
                     <p className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] italic text-emerald-primary">Mode concepteur</p>
                   </div>
                </Card>
               </div>

               <div className="space-y-4 md:space-y-6">
                <h3 className="text-base md:text-xl font-serif font-black text-emerald-primary ml-2 md:ml-4 tracking-tight flex items-center gap-3 italic">
                  <WalletCards className="w-4 md:w-5 h-4 md:h-5 text-emerald-accent" />
                  Trésorerie MaliTrek
                </h3>
                <Card className="flex flex-col gap-6 md:gap-8 p-8 md:p-10 bg-white border border-stone-100 shadow-sahara group cursor-pointer active:scale-95 transition-all overflow-hidden relative" onClick={() => onViewChange('wallet')}>
                   <div className="absolute -right-10 -bottom-10 opacity-[0.03] rotate-12 group-hover:rotate-45 transition-transform duration-1000">
                     <Wallet size={180} />
                   </div>
                   <p className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-stone-200 italic">Financial Hub</p>
                   <h4 className="text-2xl md:text-4xl font-serif font-black text-emerald-primary tracking-tighter leading-none italic group-hover:translate-x-2 transition-transform">Retrait de <br/>mes gains</h4>
                   <div className="flex items-center gap-3 mt-2 md:mt-4">
                     <span className="w-10 h-10 bg-stone-900 rounded-xl flex items-center justify-center shadow-xl">
                       <ArrowRight className="w-5 h-5 text-white" />
                     </span>
                     <p className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] italic text-stone-300">Portefeuille pro</p>
                   </div>
                </Card>
               </div>
            </div>
          </div>
        )}

        {activeView === 'circuits' && (
          <CircuitsListView 
            circuits={circuits}
            onAdd={() => { setEditingCircuit(null); setIsAddingCircuit(true); }}
            onPlanJourney={(c) => { setSelectedCircuitForJourney(c); setIsAddingJourney(true); }}
            onViewDetails={setViewingCircuit}
            onEdit={(c) => { setEditingCircuit(c); setIsAddingCircuit(true); }}
            onDelete={handleDeleteCircuit}
            onSubmitForValidation={handleSubmitCircuit}
            onClose={(id) => {
              const reason = window.prompt('Pourquoi fermez-vous ce circuit ?');
              if (reason) trekService.closeCircuit(id, profile!.uid, reason);
            }}
            onReopen={(id) => trekService.reopenCircuit(id, profile!.uid)}
          />
        )}

        {activeView === 'journeys' && (
          <JourneysListView 
            journeys={journeys}
            reservations={reservations}
            onAddJourney={() => setIsAddingJourney(true)}
            onManageSteps={(j) => handleStartJourney(j.id)}
            onCompleteJourney={(j) => handleCompleteJourney(j.id)}
            onPublishJourney={(j) => handlePublishJourney(j.id)}
            onCancelJourney={(j) => {
              setConfirmConfig({
                isOpen: true,
                title: 'Annuler le trajet',
                message: 'Cela annulera toutes les réservations. Voulez-vous continuer ?',
                onConfirm: () => handleCancelJourney(j.id)
              });
            }}
            onViewItinerary={setViewingJourneyItinerary}
          />
        )}

        {activeView === 'map_view' && <GuideMapView />}

        {activeView === 'reservations' && (
          <GuideReservationsView 
            reservations={enrichedReservations}
            onSelectDetail={setSelectedReservation}
          />
        )}

        {activeView === 'wallet' && profile && (
          <GuideWalletView profile={profile} />
        )}

        {activeView === 'journey_console' && profile && (
          <JourneyConsoleView 
            journeyId={selectedJourneyId} 
            profile={profile} 
            onBack={() => onViewChange('journeys')}
          />
        )}

        {activeView === 'reports' && profile && (
          <GuideReportsView profile={profile} />
        )}
        {activeView === 'notifications' && <NotificationInbox />}
        {activeView === 'messages' && (
          <div className="h-full">
            <ChatView 
              initialConversationId={activeConversationId} 
              onBack={() => {
                setActiveConversationId(null);
                onViewChange('dashboard');
              }} 
            />
          </div>
        )}
        {activeView === 'profile' && <ProfileView />}
        {activeView === 'settings' && <SettingsView />}
        
        {activeView === 'clients' && (
          <div className="px-4 md:px-12 pt-8">
            <ClientsListView 
              reservations={reservations}
            />
          </div>
        )}
        
        {activeView === 'leaderboard' && (
          <div className="px-4 md:px-12 pt-8">
             <LeaderboardView />
          </div>
        )}
      </main>

      <CircuitModal 
        isOpen={isAddingCircuit}
        onClose={() => { setIsAddingCircuit(false); setEditingCircuit(null); }}
        initialData={editingCircuit}
        onSubmit={editingCircuit ? handleUpdateCircuit : handleAddCircuit}
      />

      <PlanJourneyModal 
        isOpen={isAddingJourney}
        onClose={() => { setIsAddingJourney(false); setSelectedCircuitForJourney(null); }}
        circuits={circuits.filter(c => c.status === 'approved')}
        selectedCircuit={selectedCircuitForJourney}
        onPlan={handlePlanJourney}
      />

      <WithdrawalModal 
        isOpen={isWithdrawing}
        onClose={() => setIsWithdrawing(false)}
        balance={availableBalance}
        onSubmit={handleWithdrawalRequest}
      />

      {selectedReservation && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[120] flex items-end md:items-center justify-center p-0 md:p-4">
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            className="bg-white rounded-t-[3rem] md:rounded-[3rem] w-full max-w-4xl h-[90vh] md:h-[80vh] p-8 md:p-12 overflow-y-auto"
          >
            <ReservationDetails 
              reservation={{
                ...selectedReservation,
                journey: selectedResJourney || journeys.find(j => j.id === selectedReservation.journeyId),
                circuit: circuits.find(c => c.id === selectedReservation.circuitId)
              }}
              userRole="ROLE_GUIDE"
              clientProfile={selectedClientProfile || undefined}
              onClose={() => setSelectedReservation(null)}
              onAction={async (action, payload) => {
                if (action === 'message_person') {
                   if (!profile || !selectedReservation) return;
                   const loadingToast = toast.loading('Ouverture de la discussion...');
                   try {
                     const convId = await trekService.getOrCreateConversation({
                       reservationId: selectedReservation.id,
                       clientId: selectedReservation.userId,
                       guideId: selectedReservation.guideId,
                       journeyId: selectedReservation.journeyId,
                       circuitId: selectedReservation.circuitId
                     });
                     if (convId) {
                       setActiveConversationId(convId);
                       setSelectedReservation(null);
                       onViewChange('messages');
                     }
                     toast.dismiss(loadingToast);
                   } catch (e) {
                      toast.error('Erreur lors de l\'ouverture du chat', { id: loadingToast });
                   }
                }
                if (action === 'mark_step_complete') {
                  if (payload?.stepId) {
                    const loading = toast.loading('Validation de l\'étape...');
                    try {
                      await trekService.markStepComplete(selectedReservation.id, payload.stepId);
                      toast.success('Étape validée !', { id: loading });
                    } catch (e) {
                      toast.error('Erreur lors de la validation', { id: loading });
                    }
                  }
                }
                if (action === 'report_issue') {
                  setIsDisputing(true);
                }
              }}
            />
          </motion.div>
        </div>
      )}

      <AnimatePresence>
        {isReportingIncident && selectedReservation && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-transparent w-full max-w-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <ReportIncidentModal 
                reservation={{
                  ...selectedReservation,
                  journey: journeys.find(j => j.id === selectedReservation.journeyId)
                }}
                profile={profile!}
                onClose={() => setIsReportingIncident(false)}
                onSuccess={() => {
                  setIsReportingIncident(false);
                  setSelectedReservation(null);
                }}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isDisputing && selectedReservation && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-transparent w-full max-w-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <DisputeForm 
                reservationId={selectedReservation.id}
                journeyId={selectedReservation.journeyId}
                userId={profile?.uid || ""}
                userRole={profile?.role || "ROLE_GUIDE"}
                onClose={() => setIsDisputing(false)}
                onSuccess={() => {
                  setIsDisputing(false);
                  setSelectedReservation(null);
                }}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {viewingCircuit && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-0 md:p-4">
          <motion.div
            initial={{ y: "100%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            className="bg-white rounded-[3rem] w-full max-w-7xl h-full md:h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-full overflow-y-auto">
              <CircuitDetailsFull 
                circuit={viewingCircuit}
                role="ROLE_GUIDE"
                onClose={() => setViewingCircuit(null)}
                onEdit={() => {
                  setEditingCircuit(viewingCircuit);
                  setIsAddingCircuit(true);
                  setViewingCircuit(null);
                }}
                availableJourneys={journeys.filter(j => j.circuitId === viewingCircuit.id)}
              />
            </div>
          </motion.div>
        </div>
      )}
      {viewingJourneyItinerary && <JourneyItineraryModal journey={viewingJourneyItinerary} onClose={() => setViewingJourneyItinerary(null)} />}

      <ConfirmModal 
        isOpen={confirmConfig.isOpen}
        onClose={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmConfig.onConfirm}
        title={confirmConfig.title}
        message={confirmConfig.message}
      />
    </div>
  );
};

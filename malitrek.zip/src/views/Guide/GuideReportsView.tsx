import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, onSnapshot, getDocs, where, limit, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import { UserProfile } from '../../types';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Map as MapIcon, 
  CheckCircle, 
  Star,
  Package,
  Calendar,
  AlertCircle,
  FileText,
  Award
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { Review } from '../../types';

export const GuideReportsView: React.FC<{ profile: UserProfile }> = ({ profile }) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState({
    totalEarned: profile.totalEarned || 0,
    totalBookings: profile.totalBookings || 0,
    rating: profile.rating || 0,
    reviewCount: profile.reviewCount || 0,
    disputeRate: 2 // Sample
  });

  useEffect(() => {
    const q = query(
      collection(db, 'reviews'),
      where('guideId', '==', profile.uid),
      orderBy('createdAt', 'desc'),
      limit(5)
    );
    const unsub = onSnapshot(q, (snap) => {
      setReviews(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Review)));
    });
    return unsub;
  }, [profile.uid]);

  const dataWeekly = [
    { name: 'Lun', earnings: 15000 },
    { name: 'Mar', earnings: 22000 },
    { name: 'Mer', earnings: 8000 },
    { name: 'Jeu', earnings: 35000 },
    { name: 'Ven', earnings: 42000 },
    { name: 'Sam', earnings: 85000 },
    { name: 'Dim', earnings: 32000 },
  ];

  const dataPerformance = [
    { name: 'Circuit A', value: 45 },
    { name: 'Circuit B', value: 30 },
    { name: 'Autres', value: 25 },
  ];

  const COLORS = ['#065f46', '#10b981', '#cbd5e1'];

  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-1 md:space-y-2">
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic">Data Engineering</p>
          <h2 className="text-2xl md:text-5xl font-serif font-black text-emerald-primary tracking-tight italic">Performance Insight</h2>
          <p className="text-stone-400 font-medium text-[10px] md:text-base italic">Analysez votre activité et optimisez vos revenus terrain.</p>
        </div>
        <div className="w-full md:w-auto">
           <button className="w-full md:w-auto p-4 md:p-5 bg-white border border-stone-100 text-emerald-primary rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-3 shadow-sahara active:scale-95 transition-all italic">
             <FileText size={18} /> Export Performance PDF
           </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-8">
        {[
          { label: 'Revenus Totaux', value: `${(profile.totalEarned || 0).toLocaleString()} XOF`, icon: <TrendingUp size={20} />, color: 'emerald' },
          { label: 'Clients PAX', value: profile.totalBookings || 0, icon: <Users size={20} />, color: 'blue' },
          { label: 'Rating Star', value: `${(profile.rating || 0).toFixed(1)} / 5`, icon: <Star size={20} />, color: 'amber' },
          { label: 'Taux Litige', value: '1.2%', icon: <AlertCircle size={20} />, color: 'rose' }
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white p-5 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border border-stone-100 shadow-sahara group hover:translate-y-[-4px] transition-transform">
            <div className={`w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center mb-4 md:mb-6 text-white shadow-lg ${
              kpi.color === 'emerald' ? 'bg-emerald-600 shadow-emerald-600/20' :
              kpi.color === 'blue' ? 'bg-emerald-900 shadow-emerald-900/20' :
              kpi.color === 'amber' ? 'bg-emerald-accent shadow-emerald-accent/20' : 'bg-stone-900 shadow-stone-900/20'
            }`}>
              {kpi.icon}
            </div>
            <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest mb-1 italic truncate">{kpi.label}</p>
            <p className="text-sm md:text-2xl font-serif font-black text-emerald-primary italic tracking-tight">{kpi.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
        <div className="lg:col-span-2 bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-stone-100 shadow-sahara space-y-6 md:space-y-8 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-50 rounded-full -mr-32 -mt-32 blur-3xl opacity-50" />
           <div className="flex justify-between items-center text-left relative z-10">
             <div className="space-y-1">
               <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-widest italic">Weekly Revenue</p>
               <h3 className="text-lg md:text-2xl font-serif font-black text-emerald-primary tracking-tight italic">Gains 7 Derniers Jours</h3>
             </div>
             <Calendar size={20} className="text-emerald-accent animate-pulse" />
           </div>
           <div className="h-[250px] md:h-[350px] w-full relative z-10 pt-4">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={dataWeekly} margin={{ left: -20 }}>
                 <CartesianGrid strokeDasharray="10 10" vertical={false} stroke="#f8fafc" />
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 900, fill: '#cbd5e1', letterSpacing: '0.1em' }} dy={15} />
                 <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 900, fill: '#cbd5e1' }} />
                 <Tooltip 
                  contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.1)', background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(10px)', padding: '1rem' }}
                  itemStyle={{ fontWeight: '900', color: '#065f46', fontSize: '12px' }}
                  labelStyle={{ fontWeight: 'black', color: '#94a3b8', fontSize: '10px', marginBottom: '4px' }}
                  cursor={{ fill: '#f8fafc' }}
                 />
                 <Bar dataKey="earnings" fill="#065f46" radius={[12, 12, 4, 4]} barSize={40} />
               </BarChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-emerald-primary text-white p-6 md:p-10 rounded-[2rem] md:rounded-[2.5rem] border border-emerald-primary/10 shadow-sahara space-y-6 md:space-y-8 relative overflow-hidden group">
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5" />
           <div className="flex justify-between items-center text-left relative z-10">
             <div className="space-y-1">
               <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-widest italic">Product Mix</p>
               <h3 className="text-lg md:text-2xl font-serif font-black text-white tracking-tight italic">Top Circuits</h3>
             </div>
             <Package size={20} className="text-emerald-accent" />
           </div>
           <div className="h-[200px] md:h-[250px] w-full relative z-10">
             <ResponsiveContainer width="100%" height="100%">
               <PieChart>
                 <Pie
                  data={dataPerformance}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={85}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                 >
                   {dataPerformance.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : index === 1 ? '#047857' : '#065f46'} />
                   ))}
                 </Pie>
                 <Tooltip 
                   contentStyle={{ borderRadius: '1rem', border: 'none', background: '#0f172a', color: 'white', fontWeight: 'bold' }}
                   itemStyle={{ color: 'white', fontSize: '10px' }}
                 />
               </PieChart>
               <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                 <p className="text-[8px] font-black uppercase tracking-[0.2em] text-emerald-accent">Volume</p>
                 <p className="text-2xl font-black italic">Sales</p>
               </div>
             </ResponsiveContainer>
           </div>
           <div className="space-y-3 relative z-10 pt-4">
              {dataPerformance.map((perf, idx) => (
                <div key={idx} className="flex items-center justify-between group/item">
                   <div className="flex items-center gap-3">
                      <div className="w-2.5 h-2.5 rounded-full shadow-lg" style={{ backgroundColor: idx === 0 ? '#10b981' : idx === 1 ? '#047857' : '#065f46' }} />
                      <span className="text-[10px] font-black text-emerald-100/60 uppercase tracking-widest group-hover/item:text-white transition-colors italic">{perf.name}</span>
                   </div>
                   <span className="text-xs font-black italic text-emerald-accent">{perf.value}%</span>
                </div>
              ))}
           </div>
        </div>
      </div>

      {/* Recent Reviews Section */}
      <div className="space-y-6 md:space-y-10">
        <div className="flex justify-between items-end px-2 md:px-4">
          <div className="space-y-1">
             <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic">Voice of Customer</p>
             <h3 className="text-xl md:text-3xl font-serif font-black text-emerald-primary tracking-tight italic">Derniers Avis Clients</h3>
          </div>
          <div className="flex items-center gap-2 text-emerald-primary bg-emerald-accent/20 px-5 py-2.5 rounded-full border border-emerald-accent/10 shadow-lg shadow-emerald-accent/5">
            <Star size={16} fill="currentColor" className="text-emerald-primary" />
            <span className="text-xs md:text-sm font-black italic">{(profile.rating || 0).toFixed(1)} / 5</span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
          {reviews.map(review => (
            <div key={review.id} className="bg-white p-6 md:p-8 rounded-[2rem] md:rounded-[2.5rem] border border-stone-100 shadow-sahara space-y-4 md:space-y-6 group hover:translate-x-1 transition-transform">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3 md:gap-4">
                  <div className="w-10 h-10 md:w-14 md:h-14 bg-stone-50 rounded-xl md:rounded-2xl flex items-center justify-center text-stone-200 overflow-hidden shadow-inner rotate-3 group-hover:rotate-0 transition-transform">
                    {review.userPhoto ? <img src={review.userPhoto} className="w-full h-full object-cover" /> : <Users className="w-5 md:w-6 h-5 md:h-6" />}
                  </div>
                  <div className="min-w-0">
                    <p className="font-serif font-black text-emerald-primary text-sm md:text-lg leading-none mb-1 md:mb-1.5 italic truncate">{review.userName}</p>
                    <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest italic">
                       {review.createdAt ? new Date(review.createdAt.seconds * 1000).toLocaleDateString() : 'Récemment'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-0.5 text-emerald-accent shrink-0">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={`w-3 md:w-4 h-3 md:h-4 ${i < review.ratingGlobal ? 'animate-pulse' : ''}`} fill={i < review.ratingGlobal ? 'currentColor' : 'none'} strokeWidth={3} />
                  ))}
                </div>
              </div>
              <p className="text-xs md:text-sm font-medium text-stone-400 leading-relaxed italic border-l-4 border-emerald-accent/20 pl-4">
                "{review.comment}"
              </p>
              <div className="pt-4 border-t border-stone-50 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="text-center group/kpi">
                  <p className="text-[7px] md:text-[8px] font-black text-stone-300 uppercase mb-0.5 tracking-tighter italic group-hover/kpi:text-emerald-accent">Guide</p>
                  <p className="text-xs font-black text-emerald-primary italic">{review.ratingGuide}/5</p>
                </div>
                <div className="text-center group/kpi">
                  <p className="text-[7px] md:text-[8px] font-black text-stone-300 uppercase mb-0.5 tracking-tighter italic group-hover/kpi:text-emerald-accent">XP</p>
                  <p className="text-xs font-black text-emerald-primary italic relative inline-block">{review.ratingExperience}/5</p>
                </div>
                <div className="text-center group/kpi">
                  <p className="text-[7px] md:text-[8px] font-black text-stone-300 uppercase mb-0.5 tracking-tighter italic group-hover/kpi:text-emerald-accent">Ponctuel</p>
                  <p className="text-xs font-black text-emerald-primary italic">{review.ratingPunctuality}/5</p>
                </div>
                <div className="text-center group/kpi">
                  <p className="text-[7px] md:text-[8px] font-black text-stone-300 uppercase mb-0.5 tracking-tighter italic group-hover/kpi:text-emerald-accent">Qualité</p>
                  <p className="text-xs font-black text-emerald-primary italic">{review.ratingValue}/5</p>
                </div>
              </div>
            </div>
          ))}
          {reviews.length === 0 && (
            <div className="col-span-full py-16 md:py-24 bg-stone-50/50 rounded-[3rem] border-2 border-dashed border-stone-100 flex flex-col items-center justify-center space-y-4">
              <Star size={40} className="text-stone-100" />
              <p className="text-stone-300 font-black italic uppercase tracking-widest text-[10px]">Aucune donnée entrante.</p>
            </div>
          )}
        </div>
      </div>

      <div className="bg-emerald-primary p-8 md:p-16 rounded-[2.5rem] md:rounded-[4rem] text-white flex flex-col lg:flex-row items-center gap-10 md:gap-16 text-center lg:text-left shadow-sahara relative overflow-hidden group">
         <div className="absolute inset-0 bg-gradient-to-br from-emerald-800 to-emerald-950 opacity-50" />
         <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-accent/5 rounded-full -mr-64 -mt-64 blur-3xl group-hover:bg-emerald-accent/10 transition-all duration-1000" />
         
         <div className="shrink-0 w-20 h-20 md:w-32 md:h-32 bg-emerald-accent rounded-[1.5rem] md:rounded-[3rem] flex items-center justify-center -rotate-12 group-hover:rotate-0 transition-all duration-700 shadow-2xl relative z-10">
            <Award className="w-10 md:w-16 h-10 md:h-16 text-emerald-primary animate-bounce-slow" />
         </div>
         <div className="space-y-3 md:space-y-4 relative z-10 max-w-2xl">
            <p className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-emerald-accent italic">Achievement Status</p>
            <h3 className="text-2xl md:text-5xl font-serif font-black tracking-tighter italic">Guide d'Exception</h3>
            <p className="text-emerald-100/60 font-medium leading-relaxed text-xs md:text-lg italic">
               "Votre taux de satisfaction est à <span className="text-emerald-accent">98.5%</span>. Vous figurez parmi l'élite MaliTrek. Maintenez ce standard pour débloquer votre statut VIP Ambassador."
            </p>
         </div>
         <div className="flex items-center gap-6 md:gap-8 bg-white/5 p-6 md:p-10 rounded-[2rem] border border-white/10 relative z-10 backdrop-blur-xl shrink-0 group-hover:scale-105 transition-transform">
            <div className="text-center md:text-right">
               <p className="text-[8px] md:text-[10px] font-black uppercase text-emerald-accent tracking-widest italic mb-1">Latency Avg</p>
               <p className="text-xl md:text-3xl font-serif font-black italic">12 <span className="text-xs">MIN</span></p>
            </div>
            <div className="w-px h-12 md:h-16 bg-white/10" />
            <div className="text-center md:text-right">
               <p className="text-[8px] md:text-[10px] font-black uppercase text-emerald-accent tracking-widest italic mb-1">Conversion</p>
               <p className="text-xl md:text-3xl font-serif font-black text-emerald-accent italic">82 <span className="text-xs">%</span></p>
            </div>
         </div>
      </div>
    </div>
  );
};

import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Users, 
  Navigation, 
  MapPin, 
  Clock, 
  AlertTriangle, 
  MessageCircle, 
  Play, 
  CheckSquare, 
  ChevronRight,
  MoreVertical,
  Calendar,
  Flag,
  Loader2,
  Info,
  Edit,
  Wifi,
  WifiOff,
  CloudUpload,
  Pause,
  RotateCcw,
  Plus,
  X,
  Map,
  Compass,
  Check,
  Smartphone
} from 'lucide-react';
import { collection, doc, onSnapshot, query, where, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../../lib/firestoreUtils';
import { db } from '../../firebase';
import { Journey, Reservation, UserProfile, OfflineAction } from '../../types';
import { trekService } from '../../services/trekService';
import { offlineService } from '../../services/offlineService';
import { smsFallbackService } from '../../services/smsFallbackService';
import { OfflineRouteFallback } from '../../components/OfflineRouteFallback';
import toast from 'react-hot-toast';

// --- Sub-Components ---

const OfflineStatusBar: React.FC<{ queueCount: number }> = ({ queueCount }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div className={`px-4 py-2 flex items-center justify-between text-[10px] font-black uppercase tracking-widest transition-colors ${
      isOnline ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
    }`}>
      <div className="flex items-center gap-2">
        {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
        <span>{isOnline ? 'Connecté' : 'Mode Hors-Ligne'}</span>
      </div>
      {queueCount > 0 && (
        <div className="flex items-center gap-2">
          <CloudUpload className="w-3 h-3 animate-bounce" />
          <span>{queueCount} actions en attente de sync</span>
        </div>
      )}
    </div>
  );
};

// --- Main View ---

export const JourneyConsoleView: React.FC<{ profile: UserProfile; journeyId: string | null; onBack?: () => void }> = ({ profile, journeyId, onBack }) => {
  const [journey, setJourney] = useState<Journey | null>(null);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [queueCount, setQueueCount] = useState(0);
  
  // UI States
  const [activeTab, setActiveTab] = useState<'main' | 'itinerary' | 'clients' | 'incidents'>('main');
  const [showIncidentModal, setShowIncidentModal] = useState(false);
  const [showPauseModal, setShowPauseModal] = useState(false);
  const [incidentType, setIncidentType] = useState('Autre');
  const [incidentUrgency, setIncidentUrgency] = useState<'medium' | 'high' | 'critical'>('medium');
  const [incidentNote, setIncidentNote] = useState('');
  const [bushMode, setBushMode] = useState(false); // Mode brousse (faible connexion)
  const [isMapLoaded, setIsMapLoaded] = useState(false); // Map loaded flag

  // Sync effect
  useEffect(() => {
    const updateQueue = async () => {
      const q = await offlineService.getQueue();
      setQueueCount(q.length);
    };
    
    const handleSync = async (e: any) => {
      const action = e.detail as OfflineAction;
      try {
        if (action.type === 'CHECK_IN') {
          await trekService.guideMarkPresence(action.payload.resId, profile.uid, action.payload.status);
        } else if (action.type === 'NEXT_STEP') {
          await trekService.advanceJourneyStep(action.payload.journeyId, action.payload.currentIndex);
        } else if (action.type === 'INCIDENT') {
          await trekService.reportIncident(action.payload.data);
        } else if (action.type === 'PAUSE') {
          await trekService.pauseJourney(action.payload.journeyId, action.payload.reason);
        } else if (action.type === 'RESUME') {
          await trekService.resumeJourney(action.payload.journeyId);
        }
        updateQueue();
      } catch (err) {
        console.error('Sync error in Console:', err);
      }
    };

    window.addEventListener('malitrek_sync_action', handleSync);
    const intv = setInterval(updateQueue, 5000);
    updateQueue();
    
    return () => {
      window.removeEventListener('malitrek_sync_action', handleSync);
      clearInterval(intv);
    };
  }, [profile.uid]);

  useEffect(() => {
    if (!journeyId) return;

    // Try to load from cache first for zero-latency start or offline start
    const loadCache = async () => {
      const cached = await offlineService.getCachedJourney(journeyId);
      if (cached && !journey) {
        setJourney(cached);
        setIsLoading(false);
        console.log('[Console] Loaded from offline cache');
      }
    };
    loadCache();

    const unsubJ = onSnapshot(doc(db, 'journeys', journeyId), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as Journey;
        const freshJourney = { id: snap.id, ...data } as Journey;
        setJourney(freshJourney);
        // Cache for offline
        offlineService.cacheJourney(freshJourney);
      }
      setIsLoading(false);
    }, (error) => {
      console.warn('[Console] Failed to fetch live journey, using cache if available');
      setIsLoading(false);
    });

    const qR = query(
      collection(db, 'reservations'), 
      where('journeyId', '==', journeyId),
      where('guideId', '==', profile.uid)
    );
    const unsubR = onSnapshot(qR, (snap) => {
      setReservations(snap.docs.map(d => ({ id: d.id, ...d.data() } as Reservation)));
    });

    return () => { unsubJ(); unsubR(); };
  }, [journeyId, profile.uid]);

  // Actions wrapped in offline queuing
  const handleAction = async (type: OfflineAction['type'], payload: any, onlineCall: () => Promise<any>) => {
    if (!navigator.onLine) {
      await offlineService.queueAction(type, payload);
      toast.success('Action enregistrée (Offline)');
      const q = await offlineService.getQueue();
      setQueueCount(q.length);
      return;
    }

    try {
      await onlineCall();
      toast.success('Action confirmée');
    } catch (e: any) {
      await offlineService.queueAction(type, payload);
      toast.success('Action mise en file d\'attente (Réseau instable)');
      const q = await offlineService.getQueue();
      setQueueCount(q.length);
    }
  };

  const handleNextStep = () => {
    if (!journey) return;
    handleAction('NEXT_STEP', { journeyId: journey.id, currentIndex: journey.currentStepIndex || 0 }, () => 
      trekService.advanceJourneyStep(journey.id, journey.currentStepIndex || 0)
    );
  };

  const handleCheckIn = (resId: string, status: 'present' | 'absent') => {
    handleAction('CHECK_IN', { resId, status }, () => 
      trekService.guideMarkPresence(resId, profile.uid, status)
    );
  };

  const handleIncident = async () => {
    if (!journey) return;
    const data = { 
      journeyId: journey.id, 
      type: incidentType, 
      description: incidentNote, 
      urgency: incidentUrgency,
      userId: profile.uid,
      userName: profile.displayName || 'Guide'
    };

    if (incidentUrgency === 'critical') {
      // Automatic structure for SMS Fallback
      await smsFallbackService.prepareCriticalIncidentSMS(journey.id, data);
      toast('Alerte CRITIQUE : SMS Fallback préparé', { icon: '🚨' });
    }

    await handleAction('INCIDENT', { journeyId: journey.id, data }, () => 
      trekService.reportIncident(data)
    );
    setShowIncidentModal(false);
    setIncidentNote('');
    setIncidentUrgency('medium');
  };

  const handlePause = (reason: string) => {
    if (!journey) return;
    handleAction('PAUSE', { journeyId: journey.id, reason }, () => 
      trekService.pauseJourney(journey.id, reason)
    );
    setShowPauseModal(false);
  };

  const handleResume = () => {
    if (!journey) return;
    handleAction('RESUME', { journeyId: journey.id }, () => 
      trekService.resumeJourney(journey.id)
    );
  };

  if (isLoading) return <div className="flex items-center justify-center h-screen bg-stone-900"><Loader2 className="w-10 h-10 animate-spin text-emerald-500" /></div>;
  if (!journey) return <div className="p-10 text-center">Trajet introuvable</div>;

  const currentStepIndex = journey.currentStepIndex ?? -1;
  const currentStep = journey.itinerarySnapshot?.[currentStepIndex];
  const nextStep = journey.itinerarySnapshot?.[currentStepIndex + 1];
  const participantsCount = reservations.reduce((acc, r) => acc + r.passengers, 0);
  const presentCount = reservations.filter(r => r.guidePresenceStatus === 'present').reduce((acc, r) => acc + r.passengers, 0);

  return (
    <div className={`min-h-screen ${bushMode ? 'bg-[#050B15]' : 'bg-[#0A1931]'} pb-24 text-white overflow-x-hidden font-sans`}>
      <OfflineStatusBar queueCount={queueCount} />
      
      {/* Terrain Header */}
      <div className="px-8 py-8 border-b border-white/5 flex items-center justify-between sticky top-0 z-50 bg-[#0A1931]/90 backdrop-blur-2xl">
        <div className="flex items-center gap-5">
          <button onClick={onBack} className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center transition-all active:scale-90 border border-white/5">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="max-w-[200px]">
            <h1 className="text-xl font-serif italic font-black truncate leading-tight tracking-tight">{journey.title}</h1>
            <div className="flex items-center gap-2 mt-1">
              <div className={`w-2 h-2 rounded-full ${journey.status === 'in_progress' ? 'bg-[#FDE68A] animate-pulse' : 'bg-[#C06014]'}`} />
              <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/40">
                {journey.status === 'in_progress' ? 'Mission Guide' : journey.status === 'paused' ? 'Halt Technique' : 'Initialisation'}
              </span>
            </div>
          </div>
        </div>

        <button 
          onClick={() => setBushMode(!bushMode)}
          className={`px-5 py-2.5 rounded-[1.2rem] text-[9px] font-black uppercase tracking-[0.2em] transition-all border ${
            bushMode ? 'bg-[#C06014] text-white border-[#C06014]' : 'bg-white/5 text-white/40 border-white/5'
          }`}
        >
          {bushMode ? 'Mode Brousse' : 'Mode Standard'}
        </button>
      </div>

      <div className="px-6 pt-10 space-y-12 max-w-lg mx-auto">
        
        {/* Navigation Tabs (Gros Boutons Premium) */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { id: 'main', icon: Navigation, label: 'Bord' },
            { id: 'clients', icon: Users, label: 'Équipage' },
            { id: 'itinerary', icon: Map, label: 'Carte' },
            { id: 'incidents', icon: AlertTriangle, label: 'Alertes' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex flex-col items-center gap-3 p-5 rounded-[2rem] transition-all duration-300 active:scale-[0.85] ${
                activeTab === tab.id 
                  ? 'bg-[#C06014] text-white shadow-2xl shadow-[#C06014]/30 scale-105' 
                  : 'bg-white/5 text-white/30 border border-white/5'
              }`}
            >
              <tab.icon className={`w-6 h-6 transition-transform duration-500 ${activeTab === tab.id ? 'scale-125' : ''}`} strokeWidth={2.5} />
              <span className="text-[7px] font-black uppercase tracking-widest leading-none">{tab.label}</span>
            </button>
          ))}
        </div>

        {activeTab === 'main' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-10">
            
            {/* Status Card Luxury */}
            <div className="bg-white/5 rounded-[3.5rem] p-10 border border-white/5 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:scale-110 transition-transform duration-1000">
                <Compass size={120} />
              </div>
              
              <div className="flex items-center justify-between mb-10">
                <span className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20">Progression</span>
                <div className="flex items-center gap-3 bg-[#FDE68A]/10 px-5 py-2.5 rounded-2xl border border-[#FDE68A]/10">
                  <Users className="w-4 h-4 text-[#FDE68A]" />
                  <span className="text-xl font-serif italic font-black text-[#FDE68A]">{presentCount} <span className="opacity-30 text-xs font-sans not-italic">/ {participantsCount}</span></span>
                </div>
              </div>
              
              <div className="space-y-10">
                <div className="relative z-10">
                  <p className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20 mb-3">Position Actuelle</p>
                  <h2 className="text-3xl font-serif italic font-black text-white leading-tight">
                    {currentStepIndex === -1 ? 'Bivouac de départ' : (currentStep?.title || 'En cours')}
                  </h2>
                </div>
                
                {nextStep && (
                  <div className="pt-8 border-t border-white/5 relative z-10">
                    <p className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20 mb-3 block">Point suivant</p>
                    <div className="flex items-center gap-4 bg-white/5 p-5 rounded-[1.5rem] border border-white/5 transform hover:translate-x-2 transition-transform">
                      <ChevronRight className="w-5 h-5 text-[#FDE68A]" />
                      <p className="text-lg font-black text-white/70 tracking-tight">{nextStep.title}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions Premium */}
            <div className="grid grid-cols-1 gap-6">
              {journey.status === 'in_progress' ? (
                <>
                  <button 
                    onClick={handleNextStep}
                    className="h-32 bg-[#FDE68A] text-[#0A1931] rounded-[2.5rem] flex items-center justify-center gap-6 active:scale-[0.96] transition-all shadow-[0_20px_50px_rgba(253,230,138,0.2)] group"
                  >
                    <div className="w-14 h-14 bg-[#0A1931] rounded-2xl flex items-center justify-center text-white scale-90 group-hover:scale-100 transition-transform">
                      <Navigation className="w-8 h-8" />
                    </div>
                    <span className="text-2xl font-black uppercase tracking-tighter">Valider l'étape</span>
                  </button>

                  <div className="grid grid-cols-2 gap-6">
                    <button 
                      onClick={() => setShowPauseModal(true)}
                      className="h-28 bg-[#C06014] text-white rounded-[2.5rem] flex flex-col items-center justify-center gap-2 active:scale-[0.96] transition-all shadow-2xl shadow-[#C06014]/20 border border-white/10"
                    >
                      <Pause className="w-6 h-6" strokeWidth={3} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Halt</span>
                    </button>
                    <button 
                      onClick={() => setShowIncidentModal(true)}
                      className="h-28 bg-rose-600 text-white rounded-[2.5rem] flex flex-col items-center justify-center gap-2 active:scale-[0.96] transition-all shadow-2xl shadow-rose-900/20 border border-white/10"
                    >
                      <AlertTriangle className="w-6 h-6" strokeWidth={3} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Alerte</span>
                    </button>
                  </div>
                </>
              ) : journey.status === 'paused' ? (
                <button 
                  onClick={handleResume}
                  className="h-32 bg-[#FDE68A] text-[#0A1931] rounded-[2.5rem] flex items-center justify-center gap-6 active:scale-[0.96] transition-all shadow-[0_20px_50px_rgba(253,230,138,0.2)]"
                >
                  <Play className="w-10 h-10 fill-current" />
                  <span className="text-2xl font-black uppercase tracking-tighter">Reprendre la mission</span>
                </button>
              ) : (journey.status === 'open' || journey.status === 'full') ? (
                <button 
                  onClick={() => handleAction('START', { journeyId: journey.id, guideId: profile.uid }, () => trekService.startJourney(journey.id, profile.uid))}
                  className="h-32 bg-[#FDE68A] text-[#0A1931] rounded-[2.5rem] flex items-center justify-center gap-6 active:scale-[0.96] transition-all shadow-[0_20px_50px_rgba(253,230,138,0.2)]"
                >
                  <Play className="w-10 h-10 fill-current" />
                  <span className="text-2xl font-black uppercase tracking-tighter">Lancer l'expédition</span>
                </button>
              ) : null}

              <button 
                onClick={() => setActiveTab('clients')}
                className="h-24 bg-white/5 text-white/80 rounded-[2.2rem] flex items-center px-10 gap-6 border border-white/5 active:scale-95 transition-all group"
              >
                <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center group-hover:bg-[#FDE68A] group-hover:text-[#0A1931] transition-all">
                  <Users className="w-6 h-6" />
                </div>
                <span className="flex-1 text-left font-black text-xs uppercase tracking-widest">Gestion Équipage</span>
                <span className="h-10 px-5 bg-white/10 rounded-full flex items-center justify-center text-[11px] font-black text-[#FDE68A] border border-[#FDE68A]/10">{presentCount} / {participantsCount}</span>
              </button>
            </div>

          </motion.div>
        )}

        {activeTab === 'clients' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="mb-10">
              <h3 className="text-3xl font-serif italic font-black tracking-tight mb-2">Voyageurs</h3>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20">Validation des présences au point critique</p>
            </div>
            
            {reservations.map(res => (
              <div key={res.id} className="bg-white/5 border border-white/5 rounded-[2.5rem] p-8 flex flex-col gap-10 hover:bg-white/10 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 bg-[#FFF8F3] rounded-2xl flex items-center justify-center font-serif italic font-black text-2xl text-[#0A1931] border border-[#C06014]/20 shadow-inner">
                      {res.fullname?.[0] || 'U'}
                    </div>
                    <div>
                      <p className="text-xl font-black tracking-tight">{res.fullname}</p>
                      <p className="text-[10px] font-black uppercase text-[#C06014] tracking-[0.3em] mt-1">{res.passengers} voyageurs</p>
                    </div>
                  </div>
                  <div className={`h-10 flex items-center px-6 rounded-full text-[9px] font-black uppercase tracking-widest ${
                    res.guidePresenceStatus === 'present' ? 'bg-[#FDE68A] text-[#0A1931]' : 'bg-white/5 text-white/30 border border-white/5'
                  }`}>
                    {res.guidePresenceStatus === 'present' ? 'À bord' : res.guidePresenceStatus === 'absent' ? 'Signalé absent' : 'Non validé'}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => handleCheckIn(res.id, 'present')}
                    className={`h-20 rounded-[1.5rem] flex items-center justify-center gap-3 font-black uppercase text-[10px] transition-all shadow-xl active:scale-95 ${
                      res.guidePresenceStatus === 'present' 
                        ? 'bg-[#FDE68A] text-[#0A1931] shadow-[#FDE68A]/10' 
                        : 'bg-white/5 border border-white/10 text-white/40'
                    }`}
                  >
                    <Check className="w-5 h-5 shadow-inner" strokeWidth={4} /> Présent
                  </button>
                  <button 
                    onClick={() => handleCheckIn(res.id, 'absent')}
                    className={`h-20 rounded-[1.5rem] flex items-center justify-center gap-3 font-black uppercase text-[10px] transition-all shadow-xl active:scale-95 ${
                      res.guidePresenceStatus === 'absent' 
                        ? 'bg-rose-600 text-white shadow-rose-900/10' 
                        : 'bg-white/5 border border-white/10 text-white/40'
                    }`}
                  >
                    <X className="w-5 h-5" strokeWidth={4} /> Absent
                  </button>
                </div>
              </div>
            ))}
          </motion.div>
        )}

        {activeTab === 'itinerary' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
            <div className="mb-10">
              <h3 className="text-3xl font-serif italic font-black tracking-tight mb-2">Plan de Route</h3>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20">Suivi GPS et étapes clés</p>
            </div>
            
            {!isMapLoaded || !navigator.onLine ? (
              <div className="p-2 bg-white/5 rounded-[3.5rem] border border-white/5 overflow-hidden">
                <OfflineRouteFallback journey={journey} currentStepIndex={currentStepIndex} />
              </div>
            ) : (
              <div className="h-48 bg-[#0A1931] rounded-[3.5rem] flex items-center justify-center border-2 border-white/5 border-dashed group transition-all hover:border-[#FDE68A]/20">
                <div className="text-center space-y-4">
                   <div className="w-12 h-12 bg-[#FDE68A]/10 rounded-full flex items-center justify-center mx-auto text-[#FDE68A] animate-pulse">
                     <MapPin className="w-6 h-6" />
                   </div>
                   <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20 group-hover:text-[#FDE68A]/40">Connexion Map en cours...</p>
                </div>
              </div>
            )}

            <div className="space-y-6">
              {(journey.itinerarySnapshot || []).map((step, idx) => (
                <div 
                  key={idx}
                  className={`p-10 rounded-[2.5rem] border transition-all relative overflow-hidden ${
                    idx === journey.currentStepIndex 
                      ? 'bg-[#FDE68A]/10 border-[#FDE68A] shadow-[0_0_40px_rgba(253,230,138,0.1)]' : 
                    idx < (journey.currentStepIndex || 0) 
                      ? 'bg-white/5 border-white/5 opacity-30 scale-95' : 'bg-white/5 border-white/5'
                  }`}
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-[10px] font-black ${
                         idx === journey.currentStepIndex ? 'bg-[#FDE68A] text-[#0A1931]' : 'bg-white/5 text-white/20'
                      }`}>
                        {idx + 1}
                      </div>
                      <span className="text-[9px] font-black uppercase tracking-[0.3em] opacity-40">Jour {step.day || 1} • {step.estimatedTime || '---'}</span>
                    </div>
                    {idx < (journey.currentStepIndex || 0) && <Check className="w-5 h-5 text-[#FDE68A]" strokeWidth={3} />}
                  </div>
                  <h4 className="text-xl font-serif italic font-black mb-3">{step.title}</h4>
                  <p className="text-xs text-white/40 leading-relaxed italic font-serif group-hover:text-white/60 transition-colors">{step.description}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'incidents' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-10">
            <div className="flex items-center justify-between mb-10">
              <div>
                <h3 className="text-3xl font-serif italic font-black tracking-tight mb-2">Sécurité</h3>
                <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20">Canaux d'alerte critiques</p>
              </div>
              <button 
                onClick={() => setShowIncidentModal(true)}
                className="h-14 px-8 bg-rose-600 text-white rounded-[2rem] active:scale-95 flex items-center gap-4 shadow-2xl shadow-rose-900/40 group overflow-hidden"
              >
                <div className="w-8 h-8 bg-[#C06014]/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Plus className="w-5 h-5" strokeWidth={3} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest">Alerte</span>
              </button>
            </div>

            <div className="space-y-8">
              <div className="p-14 text-center bg-white/5 rounded-[4rem] border-2 border-dashed border-white/5 group hover:border-[#C06014]/20 transition-all">
                <AlertTriangle className="w-14 h-14 text-white/5 mx-auto mb-6 group-hover:text-[#C06014]/20 transition-colors duration-700" strokeWidth={1} />
                <p className="text-white/20 font-black text-xs uppercase tracking-[0.5em]">Zone de calme</p>
                <p className="text-[10px] text-white/10 font-bold mt-4 font-serif italic italic">Aucun incident détecté sur le parcours</p>
              </div>
              
              <div className="p-10 bg-[#C06014]/5 rounded-[3rem] space-y-6 border border-[#C06014]/10">
                <div className="flex gap-6">
                   <div className="w-12 h-12 bg-[#C06014]/20 rounded-[1.5rem] flex items-center justify-center text-[#C06014]">
                     <Info className="w-6 h-6" />
                   </div>
                   <div className="flex-1 space-y-2">
                     <p className="text-[10px] font-black uppercase tracking-widest text-[#C06014]">Protocole de Surveillance</p>
                     <p className="text-xs font-serif italic text-white/50 leading-relaxed">
                        L'administration MaliTrek surveille ce trajet en temps réel.
                        Chaque mouvement est synchronisé pour votre sécurité.
                     </p>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

      </div>

      {/* Incident Modal */}
      <AnimatePresence>
        {showIncidentModal && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-end sm:items-center justify-center p-4">
            <motion.div 
              initial={{ y: 200, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 200, opacity: 0 }}
              className="bg-stone-900 w-full max-w-md rounded-[3rem] p-10 space-y-8 border border-white/10"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-black text-rose-500">Signaler Incident</h3>
                <button onClick={() => setShowIncidentModal(false)}><X className="w-6 h-6" /></button>
              </div>
              
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-2">
                  {['Retard', 'Méteo', 'Transport', 'Client', 'Sécurité', 'Autre'].map(t => (
                    <button 
                      key={t}
                      onClick={() => setIncidentType(t)}
                      className={`h-14 rounded-2xl font-black uppercase text-[10px] border transition-all ${
                        incidentType === t ? 'bg-rose-500 text-black border-rose-500' : 'bg-transparent text-white/40 border-white/10'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                <div className="space-y-3">
                   <p className="text-[10px] font-black uppercase tracking-widest text-white/30">Niveau d'urgence</p>
                   <div className="grid grid-cols-3 gap-2">
                     {(['medium', 'high', 'critical'] as const).map(u => (
                        <button
                          key={u}
                          onClick={() => setIncidentUrgency(u)}
                          className={`h-12 rounded-xl font-black uppercase text-[8px] border transition-all ${
                            incidentUrgency === u ? 'bg-rose-500 text-black border-rose-500' : 'bg-white/5 text-white/30 border-white/5'
                          }`}
                        >
                          {u === 'critical' ? 'CRITIQUE / SMS' : u}
                        </button>
                     ))}
                   </div>
                </div>
                
                <textarea 
                  value={incidentNote}
                  onChange={(e) => setIncidentNote(e.target.value)}
                  className="w-full h-32 bg-white/5 border border-white/10 rounded-3xl p-6 text-white font-bold outline-none focus:border-rose-500"
                  placeholder="Expliquez brièvement la situation..."
                />
              </div>

              <button 
                onClick={handleIncident}
                className="w-full h-20 bg-rose-500 text-black rounded-[2rem] font-black uppercase tracking-widest text-lg"
              >
                Transmettre l'alerte
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Pause Modal */}
      <AnimatePresence>
        {showPauseModal && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-end sm:items-center justify-center p-4">
            <motion.div 
              initial={{ y: 200, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 200, opacity: 0 }}
              className="bg-stone-900 w-full max-w-md rounded-[3rem] p-10 space-y-8 border border-white/10"
            >
              <h3 className="text-2xl font-black text-amber-500">Mettre le trajet en Pause ?</h3>
              <p className="text-white/40 font-bold uppercase tracking-widest text-[10px] leading-relaxed">
                Les clients seront informés que le trajet est momentanément suspendu (déjeuner, pause technique, etc.).
              </p>
              
              <div className="space-y-2">
                {['Pause Déjeuner', 'Problème Technique', 'Météo Défavorable', 'Pause Repos'].map(reason => (
                  <button 
                    key={reason}
                    onClick={() => handlePause(reason)}
                    className="w-full h-16 bg-white/5 border border-white/10 rounded-2xl font-black text-white px-6 text-left hover:bg-amber-500 hover:text-black transition-all"
                  >
                    {reason}
                  </button>
                ))}
              </div>

              <button 
                onClick={() => setShowPauseModal(false)}
                className="w-full py-4 text-white/40 font-black uppercase tracking-widest text-[10px]"
              >
                Annuler
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Bottom Nav Hint */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-stone-950/80 backdrop-blur-md border border-white/10 p-4 rounded-full shadow-2xl">
        <div className="flex items-center gap-2 px-4 border-r border-white/10">
          <Smartphone className="w-4 h-4 text-emerald-500" />
          <span className="text-[8px] font-black uppercase tracking-[0.2em]">{profile.displayName?.split(' ')[0]}</span>
        </div>
        <div className="flex items-center gap-2 px-4">
           <MapPin className="w-4 h-4 text-rose-500" />
           <span className="text-[8px] font-black uppercase tracking-[0.2em]">Malitrek Terrain</span>
        </div>
      </div>
    </div>
  );
};

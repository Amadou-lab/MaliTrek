import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase';
import { Journey, UserProfile, Circuit } from '../../../types';
import { useAuth } from '../../../contexts/AuthContext';
import { AdvancedMap } from '../../../components/shared/AdvancedMap';
import { Compass, Users, MapPin, Navigation } from 'lucide-react';

export const GuideMapView: React.FC = () => {
    const { profile } = useAuth();
    const [journeys, setJourneys] = useState<Journey[]>([]);
    const [circuits, setCircuits] = useState<Circuit[]>([]);
    const [selectedJourney, setSelectedJourney] = useState<Journey | null>(null);

    useEffect(() => {
        if (!profile?.uid) return;
        
        // Journeys
        const qJ = query(collection(db, 'journeys'), where('guideId', '==', profile.uid), where('status', 'in', ['confirmed', 'in_progress']));
        const unsubJ = onSnapshot(qJ, (snap) => {
            setJourneys(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Journey)));
        });

        // Circuits
        const qC = query(collection(db, 'circuits'), where('guideId', '==', profile.uid));
        const unsubC = onSnapshot(qC, (snap) => {
            setCircuits(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Circuit)));
        });

        return () => { unsubJ(); unsubC(); };
    }, [profile?.uid]);

    return (
        <div className="h-full flex flex-col gap-8">
            <div className="flex justify-between items-end px-4">
                <div className="space-y-1">
                    <h2 className="text-3xl font-black text-stone-900 tracking-tight">Supervision de Terrain</h2>
                    <p className="text-stone-500 font-bold uppercase tracking-[0.2em] text-[8px]">Visualisez vos trajets actifs et la position de vos groupes</p>
                </div>
                <div className="flex gap-4">
                    <div className="bg-emerald-600 px-6 py-3 rounded-2xl text-white flex items-center gap-2 shadow-xl shadow-emerald-600/20">
                        <Navigation size={14} className="animate-pulse" />
                        <span className="text-[10px] font-black uppercase tracking-widest">{journeys.filter(j => j.status === 'in_progress').length} En cours</span>
                    </div>
                </div>
            </div>

            <div className="flex-1 flex gap-8 min-h-0">
                <div className="flex-1 bg-white rounded-[3.5rem] border-4 border-white shadow-2xl relative overflow-hidden">
                    <AdvancedMap 
                        journeys={journeys}
                        circuits={circuits}
                        itinerary={selectedJourney?.itinerarySnapshot || []}
                        showPolyline={true}
                        onMarkerClick={(id, type) => {
                            if (type === 'journey') setSelectedJourney(journeys.find(j => j.id === id) || null);
                        }}
                    />
                </div>

                <div className="w-96 space-y-6 overflow-y-auto no-scrollbar pr-2">
                    {journeys.length === 0 ? (
                        <div className="bg-stone-100/50 rounded-[2.5rem] p-12 text-center border-2 border-dashed border-stone-200">
                            <Compass size={48} className="mx-auto text-stone-300 mb-4" />
                            <p className="text-stone-500 font-black uppercase tracking-widest text-xs">Aucun trajet actif</p>
                        </div>
                    ) : (
                        journeys.map(j => (
                            <div 
                                key={j.id} 
                                className={`p-8 rounded-[2.5rem] border-2 transition-all cursor-pointer ${
                                    selectedJourney?.id === j.id ? 'bg-stone-900 text-white border-stone-900 shadow-2xl' : 'bg-white text-stone-900 border-stone-100 hover:border-emerald-200'
                                }`}
                                onClick={() => setSelectedJourney(j)}
                            >
                                <div className="flex justify-between items-start mb-6">
                                    <div className="space-y-1">
                                        <p className={`text-[8px] font-black uppercase tracking-widest ${selectedJourney?.id === j.id ? 'text-emerald-400' : 'text-emerald-600'}`}>
                                            {j.status === 'in_progress' ? '● Live' : 'Planifié'}
                                        </p>
                                        <h4 className="text-lg font-black leading-tight truncate w-48">{j.title}</h4>
                                    </div>
                                    <div className={`p-3 rounded-2xl ${selectedJourney?.id === j.id ? 'bg-white/10' : 'bg-stone-100 text-stone-400'}`}>
                                        <MapPin size={20} />
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className={`p-4 rounded-2xl ${selectedJourney?.id === j.id ? 'bg-white/5' : 'bg-stone-50'}`}>
                                        <p className="text-[8px] font-black uppercase tracking-widest text-stone-400 mb-1">Participants</p>
                                        <div className="flex items-center gap-2">
                                            <Users size={12} />
                                            <span className="text-sm font-black">{j.activeParticipantsCount || 0}</span>
                                        </div>
                                    </div>
                                    <div className={`p-4 rounded-2xl ${selectedJourney?.id === j.id ? 'bg-white/5' : 'bg-stone-50'}`}>
                                        <p className="text-[8px] font-black uppercase tracking-widest text-stone-400 mb-1">Etape</p>
                                        <p className="text-sm font-black truncate">{j.itinerarySnapshot?.[j.currentStepIndex || 0]?.title || 'Départ'}</p>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

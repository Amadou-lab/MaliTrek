import React from 'react';
import { Reservation, Journey } from '../../../types';
import { toDate } from '../../../lib/firestoreUtils';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { TrendingUp, Users, Calendar, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import toast from 'react-hot-toast';

interface ReportsViewProps {
  reservations: Reservation[];
  journeys: Journey[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ reservations, journeys }) => {
  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  const categoryData = journeys.reduce((acc: any[], j) => {
    const existing = acc.find(item => item.name === j.category);
    if (existing) {
      existing.value += 1;
    } else {
      acc.push({ name: j.category || 'Autre', value: 1 });
    }
    return acc;
  }, []);

  const revenueByJourney = journeys.map(j => {
    const revenue = reservations
      .filter(r => r.journeyId === j.id && r.paymentStatus === 'paid')
      .reduce((sum, r) => sum + r.totalPaid, 0);
    return {
      name: j.title.substring(0, 10) + '...',
      revenue: revenue,
      commission: revenue * 0.3
    };
  });

  const exportFullReport = () => {
    const data = reservations.map(res => ({
      ID: res.id,
      Date: toDate(res.createdAt).toLocaleDateString(),
      Client: res.fullname,
      Montant: res.totalPaid,
      Status: res.status,
      Paiement: res.paymentStatus
    }));
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Rapport Complet");
    XLSX.writeFile(workbook, "Rapport_MaliTrek.xlsx");
    toast.success('Rapport exporté !');
  };

  return (
    <div className="space-y-10">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black text-stone-900 tracking-tight mb-2">Rapports & Statistiques</h1>
          <p className="text-stone-500 font-medium">Analyse détaillée de vos performances.</p>
        </div>
        <button 
          onClick={exportFullReport}
          className="bg-stone-900 text-white px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-stone-900/20"
        >
          <Download size={16} /> Exporter Rapport Complet
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[3rem] border border-stone-100 shadow-sm space-y-6">
          <h3 className="font-black text-stone-900 flex items-center gap-2">
            <TrendingUp size={20} className="text-emerald-600" /> Revenus par Trajet (CFA)
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueByJourney}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{fontSize: 10, fontWeight: '700'}} />
                <YAxis tick={{fontSize: 10, fontWeight: '700'}} />
                <Tooltip />
                <Bar dataKey="revenue" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[3rem] border border-stone-100 shadow-sm space-y-6">
          <h3 className="font-black text-stone-900 flex items-center gap-2">
            <Calendar size={20} className="text-blue-600" /> Répartition par Catégorie
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {categoryData.map((cat, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <span className="text-[10px] font-black text-stone-600 uppercase tracking-widest">{cat.name}: {cat.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

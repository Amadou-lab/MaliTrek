import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Circuit, POI, Journey } from '../../types';
import { useNavigation } from '../../contexts/NavigationContext';
import { 
  Search, 
  MapPin, 
  Star, 
  Compass,
  ArrowRight,
  Instagram,
  Twitter,
  Facebook,
  ChevronRight
} from 'lucide-react';
import { motion } from 'motion/react';

export const HomeView: React.FC<{ 
  onStartBooking: () => void;
  onSearch: (query: string) => void;
  pois: POI[];
  circuits: Circuit[];
  journeys?: Journey[];
}> = ({ onStartBooking, onSearch, pois, circuits, journeys = [] }) => {
  const { profile } = useAuth();
  const { navigateTo } = useNavigation();
  const [searchQuery, setSearchQuery] = React.useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const featuredCircuits = circuits.filter(c => {
    const isApproved = c.status === 'approved';
    const now = new Date();
    const nowStr = now.toLocaleDateString('en-CA');
    const endStr = c.availabilityEnd || '2099-12-31';
    return isApproved && endStr >= nowStr;
  }).slice(0, 3);

  const featuredPois = pois.slice(0, 4);

  return (
    <div className="space-y-0 -mt-20 -mx-6 md:-mx-12 overflow-hidden bg-sable-light">
      {/* Immersive Hero Section */}
      <section className="relative h-[95vh] md:h-screen flex items-center justify-center overflow-hidden bg-emerald-primary">
        <div className="absolute inset-0 z-0 overflow-hidden">
          <motion.img 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 10, ease: "linear" }}
            src="https://images.unsplash.com/photo-1544085311-11a028465b03?q=80&w=2669&auto=format&fit=crop" 
            className="w-full h-full object-cover opacity-50"
            alt="Mali Landscape"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-emerald-primary/40 via-transparent to-emerald-primary/90" />
        </div>

        <div className="relative z-10 container mx-auto px-6 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full border border-white/20 bg-white/5 backdrop-blur-md mb-8">
              <span className="w-2 h-2 rounded-full bg-emerald-accent animate-pulse" />
              <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Édition Prestige 2026</span>
            </div>
            
            <h1 className="text-4xl sm:text-6xl md:text-[9rem] font-serif font-black leading-[0.9] tracking-tighter mb-8">
              Découvrez la <br />
              <span className="italic text-emerald-accent">Majesté</span> du Mali
            </h1>
            
            <p className="max-w-2xl mx-auto text-lg md:text-xl text-white/80 font-medium leading-relaxed mb-12">
              Des cités impériales aux confins du Sahara, vivez une aventure hors du temps orchestrée par les meilleurs experts locaux.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={onStartBooking}
                className="btn-premium w-full sm:w-auto h-16 !bg-emerald-accent hover:!bg-emerald-400 text-emerald-900 group"
              >
                Commencer l'aventure
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={() => document.getElementById('storytelling')?.scrollIntoView({ behavior: 'smooth' })}
                className="btn-secondary w-full sm:w-auto h-16 !bg-white/10 !border-white/20 !text-white hover:!bg-white/20 backdrop-blur-md"
              >
                Explorer la destination
              </button>
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3"
        >
          <div className="w-px h-16 bg-gradient-to-b from-transparent via-white to-transparent" />
          <span className="text-[8px] font-bold uppercase tracking-[0.4em] text-white">Faire défiler</span>
        </motion.div>
      </section>

      {/* Storytelling Refined */}
      <section id="storytelling" className="py-32 container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-8 stagger-in">
            <div>
              <span className="badge-premium bg-emerald-accent/10 text-emerald-accent mb-4 inline-block">Héritage Millénaire</span>
              <h2 className="text-4xl md:text-7xl font-serif font-black text-stone-premium leading-tight">
                Plus qu'un Voyage,<br />
                Une <span className="italic text-emerald-accent">Immersion</span>
              </h2>
            </div>
            <p className="text-lg text-stone-premium/70 leading-relaxed max-w-lg">
              Du silence des Falaises de Bandiagara aux manuscrits de Tombouctou, le Mali offre une profondeur culturelle unique au monde. Nous créons des ponts entre vous et les gardiens de cet héritage.
            </p>
            <div className="grid grid-cols-2 gap-8 border-t border-stone-200 pt-10">
              <div className="space-y-2">
                <p className="text-4xl font-serif italic text-emerald-primary font-bold">100%</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-stone-premium/50">Expérience Authentique</p>
              </div>
              <div className="space-y-2">
                <p className="text-4xl font-serif italic text-emerald-primary font-bold">UNESCO</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-stone-premium/50">Sites Classés</p>
              </div>
            </div>
          </div>
          <div className="relative group">
            <div className="aspect-[4/5] rounded-[3rem] overflow-hidden premium-card">
              <img src="https://images.unsplash.com/photo-1544085311-11a028465b03?q=80&w=2669&auto=format&fit=crop" className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-1000" alt="Djenné Architecture" />
            </div>
            <div className="hidden sm:block absolute -bottom-10 -left-10 glass-card p-8 max-w-[200px] shadow-2xl">
              <span className="text-emerald-accent block font-black text-2xl mb-2 font-serif italic">MaliTrek</span>
              <p className="text-xs font-medium text-stone-premium/80 leading-relaxed">
                "Une expertise terrain inégalée pour des souvenirs gravés à jamais."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Modern Catalog Showcase */}
      <section className="py-32 bg-stone-premium text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.1),transparent)]" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <div className="max-w-2xl">
              <span className="badge-premium bg-white/10 text-emerald-accent mb-4 inline-block">Collections 2026</span>
              <h2 className="text-5xl md:text-8xl font-serif font-black tracking-tighter leading-[0.9]">
                Circuits de <br /><span className="italic text-emerald-accent">Prestige</span>
              </h2>
            </div>
            <button className="h-14 px-8 rounded-full border border-white/20 text-[10px] font-black uppercase tracking-widest hover:bg-white hover:text-emerald-primary transition-all duration-500">
              Explorer tout le catalogue
            </button>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {featuredCircuits.map((circuit, idx) => (
              <motion.div 
                key={circuit.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="group relative aspect-[3/4] rounded-[2.5rem] overflow-hidden premium-card !border-white/5"
              >
                <img src={circuit.image} className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt={circuit.title} />
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary/90 via-emerald-primary/20 to-transparent" />
                <div className="absolute inset-0 p-8 flex flex-col justify-end">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[8px] font-bold uppercase tracking-widest border border-white/10">{circuit.category}</span>
                    <Star className="w-3 h-3 text-emerald-accent fill-emerald-accent" />
                  </div>
                  <h3 className="text-3xl font-serif font-bold mb-6">{circuit.title}</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-white/50">Dès</p>
                      <p className="text-xl font-bold text-emerald-accent">{(circuit.basePrice || 0).toLocaleString()} <span className="text-[10px] opacity-60">CFA</span></p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-emerald-accent text-emerald-900 flex items-center justify-center -rotate-45 group-hover:rotate-0 transition-transform duration-500">
                      <ArrowRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Visual Search Section */}
      <section className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-8xl font-serif font-black text-stone-premium tracking-tighter mb-8 bg-gradient-to-b from-stone-900 to-stone-500 bg-clip-text text-transparent">
              Destination <span className="italic">Mali</span>
            </h2>
            <div className="max-w-2xl mx-auto">
               <form onSubmit={handleSearch} className="relative group">
                 <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-stone-300 group-focus-within:text-emerald-accent transition-colors" size={20} />
                 <input 
                   type="text" 
                   value={searchQuery}
                   onChange={(e) => setSearchQuery(e.target.value)}
                   placeholder="Explorer une cité, un fleuve..." 
                   className="w-full h-18 pl-14 pr-6 rounded-3xl border border-stone-200 bg-stone-50 text-stone-900 placeholder:text-stone-300 focus:outline-none focus:ring-4 focus:ring-emerald-accent/10 transition-all font-medium"
                 />
                 <button className="absolute right-3 top-1/2 -translate-y-1/2 px-4 py-2 bg-emerald-primary text-white rounded-2xl text-xs font-bold hover:bg-emerald-800 transition-colors">
                   Chercher
                 </button>
               </form>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {featuredPois.slice(0, 3).map((poi) => (
                <div key={poi.id} className="group relative aspect-square rounded-[3rem] overflow-hidden premium-card">
                  <img src={poi.image} className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000" alt={poi.name} />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-900/80 via-transparent to-transparent p-10 flex flex-col justify-end">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-accent mb-2">{poi.category}</span>
                    <h4 className="text-3xl font-serif font-black text-white">{poi.name}</h4>
                    <div className="mt-4 flex items-center gap-2 text-white/40 text-[10px] font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0 duration-500">
                      Découvrir <ChevronRight size={12} />
                    </div>
                  </div>
                </div>
             ))}
          </div>
        </div>
      </section>

      {/* Premium Footer */}
      <footer className="bg-emerald-primary text-white py-32 border-t border-white/5">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-16 lg:gap-32">
            <div className="col-span-2">
              <div className="flex items-center gap-4 mb-10">
                <div className="w-16 h-16 bg-emerald-accent rounded-2xl flex items-center justify-center rotate-6 shadow-xl">
                  <Compass className="text-emerald-900 w-8 h-8" />
                </div>
                <span className="text-4xl font-serif italic font-black">MaliTrek</span>
              </div>
              <p className="text-xl text-white/50 max-w-sm mb-10 font-serif leading-relaxed italic">
                L'excellence du voyage au cœur de l'Afrique de l'Ouest.
              </p>
              <div className="flex gap-4">
                 <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-emerald-accent hover:text-emerald-900 transition-all cursor-pointer"><Instagram size={18} /></div>
                 <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-emerald-accent hover:text-emerald-900 transition-all cursor-pointer"><Twitter size={18} /></div>
                 <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-emerald-accent hover:text-emerald-900 transition-all cursor-pointer"><Facebook size={18} /></div>
              </div>
            </div>
            <div>
              <h5 className="text-[10px] font-bold uppercase tracking-[0.3em] text-emerald-accent mb-8">Navigation</h5>
              <ul className="space-y-4 text-sm text-balance">
                 <li><button onClick={() => onStartBooking()} className="text-white/60 hover:text-white transition-colors cursor-pointer outline-none">Destinations</button></li>
                 <li><button onClick={() => navigateTo('terms')} className="text-white/60 hover:text-white transition-colors cursor-pointer outline-none">Notre Vision</button></li>
                 <li><button onClick={() => navigateTo('explore')} className="text-white/60 hover:text-white transition-colors cursor-pointer outline-none">Guides</button></li>
                 <li><button onClick={() => navigateTo('contact')} className="text-white/60 hover:text-white transition-colors cursor-pointer outline-none">FAQ</button></li>
              </ul>
            </div>
            <div>
               <h5 className="text-[10px] font-bold uppercase tracking-[0.3em] text-emerald-accent mb-8">Contact</h5>
               <ul className="space-y-4 text-sm text-balance">
                  <li className="text-white/60">Bamako, Mali</li>
                  <li className="text-white/60">+223 00 00 00</li>
                  <li className="text-white/60">prestige@malitrek.com</li>
               </ul>
            </div>
          </div>
          <div className="mt-32 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
             <p className="text-[px] font-bold text-white/30 uppercase tracking-[0.2em]">© 2026 MaliTrek Prestige • All rights reserved.</p>
             <div className="flex gap-8 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">
                <button onClick={() => navigateTo('terms')} className="hover:text-white transition-colors cursor-pointer outline-none">Privacy</button>
                <button onClick={() => navigateTo('terms')} className="hover:text-white transition-colors cursor-pointer outline-none">Terms</button>
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

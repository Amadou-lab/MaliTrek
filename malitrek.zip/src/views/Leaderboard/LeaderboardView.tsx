import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'motion/react';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../../firebase';
import { Circuit, UserProfile } from '../../types';
import { Trophy, Star, TrendingUp, Heart, Medal, Compass, ArrowRight, User, ShieldCheck } from 'lucide-react';
import { calculateRankingScore, getCircuitBadges, calculateGuideBadges } from '../../lib/rankingUtils';
import { PremiumLoading } from '../../components/shared/UI';

interface LeaderboardViewProps {
  circuits?: Circuit[];
  users?: UserProfile[];
  onViewCircuit?: (circuit: Circuit) => void;
  onViewGuide?: (guideId: string) => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ 
  circuits: initialCircuits, 
  users: initialUsers, 
  onViewCircuit, 
  onViewGuide 
}) => {
  const [activeTab, setActiveTab] = useState<'circuits' | 'guides'>('circuits');
  const [categoryFilter, setCategoryFilter] = useState<string>('Tous');
  const [fetchedCircuits, setFetchedCircuits] = useState<Circuit[]>([]);
  const [fetchedUsers, setFetchedUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialCircuits) setFetchedCircuits(initialCircuits);
    if (initialUsers) setFetchedUsers(initialUsers);

    if (!initialCircuits || !initialUsers) {
      const fetchData = async () => {
        setLoading(true);
        try {
          if (!initialCircuits) {
            const qC = query(collection(db, 'circuits'), where('status', '==', 'approved'), limit(20));
            const snapC = await getDocs(qC);
            setFetchedCircuits(snapC.docs.map(d => ({ id: d.id, ...d.data() } as Circuit)));
          }
          if (!initialUsers) {
            const qU = query(collection(db, 'users'), where('role', '==', 'ROLE_GUIDE'), limit(20));
            const snapU = await getDocs(qU);
            setFetchedUsers(snapU.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
          }
        } catch (err) {
          console.error(err);
        } finally {
          setLoading(false);
        }
      };
      fetchData();
    }
  }, [initialCircuits, initialUsers]);

  const rankedCircuits = useMemo(() => {
    return fetchedCircuits
      .filter(c => c.status === 'approved' && (categoryFilter === 'Tous' || c.category === categoryFilter))
      .map(c => ({
        ...c,
        rankingScore: calculateRankingScore(c)
      }))
      .sort((a, b) => (b.rankingScore || 0) - (a.rankingScore || 0))
      .slice(0, 10);
  }, [fetchedCircuits, categoryFilter]);

  const rankedGuides = useMemo(() => {
    return fetchedUsers
      .filter(u => u.role === 'ROLE_GUIDE')
      .map(u => {
        const guideCircuits = fetchedCircuits.filter(c => c.guideId === u.uid);
        return {
          ...u,
          badges: calculateGuideBadges(u, guideCircuits.length),
          score: (u.rating || 0) * 20 + (u.totalReservations || 0)
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [fetchedUsers, fetchedCircuits]);

  if (loading) {
    return (
      <div className="py-40">
        <PremiumLoading message="Consultation des registres d'exception..." />
      </div>
    );
  }

  return (
    <div className="space-y-20 pb-32 max-w-7xl mx-auto px-6 py-12">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-12 border-b border-stone-100 pb-16">
        <div className="stagger-in">
          <p className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-4 italic">L'Élite du Terroir</p>
          <h1 className="text-4xl md:text-7xl font-serif font-black text-emerald-primary tracking-tighter leading-tight md:leading-[0.9]">Palmarès <br /><span className="italic text-emerald-accent underline decoration-stone-200 decoration-4 md:decoration-8 underline-offset-[8px] md:underline-offset-[16px]">MaliTrek</span></h1>
        </div>
        
        <div className="flex bg-stone-50 p-2 rounded-[2rem] border border-stone-100 shadow-inner w-fit">
          <button 
            onClick={() => setActiveTab('circuits')}
            className={`px-10 py-4 rounded-[1.5rem] text-[10px] font-black flex items-center gap-3 transition-all uppercase tracking-[0.2em] ${activeTab === 'circuits' ? 'bg-emerald-primary text-white shadow-xl shadow-emerald-primary/20 scale-105' : 'text-stone-premium/30 hover:text-emerald-accent'}`}
          >
            <Compass size={18} /> Odyssées
          </button>
          <button 
            onClick={() => setActiveTab('guides')}
            className={`px-10 py-4 rounded-[1.5rem] text-[10px] font-black flex items-center gap-3 transition-all uppercase tracking-[0.2em] ${activeTab === 'guides' ? 'bg-emerald-primary text-white shadow-xl shadow-emerald-primary/20 scale-105' : 'text-stone-premium/30 hover:text-emerald-accent'}`}
          >
            <Medal size={18} /> Maîtres
          </button>
        </div>
      </div>

      {activeTab === 'circuits' && (
        <div className="space-y-12">
          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
            {['Tous', 'Culture', 'Nature', 'Aventure', 'Histoire'].map(cat => (
              <button 
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-8 py-3.5 rounded-full text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all border-2 ${categoryFilter === cat ? 'bg-emerald-accent border-emerald-accent text-emerald-primary shadow-xl shadow-emerald-accent/20 scale-105' : 'bg-transparent border-stone-100 text-stone-premium/30 hover:border-emerald-accent hover:text-emerald-accent'}`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid gap-12">
            {rankedCircuits.map((circuit, index) => {
              const badges = getCircuitBadges(circuit);
              return (
                <motion.div 
                  key={circuit.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-[2rem] md:rounded-[3rem] p-6 md:p-10 border border-stone-50 shadow-sahara hover:shadow-2xl transition-all group flex flex-col md:flex-row items-center gap-8 md:gap-12"
                >
                  <div className="relative w-full md:w-64 h-48 rounded-[2rem] overflow-hidden shrink-0 border border-stone-50">
                    <img 
                      src={circuit.image || `https://picsum.photos/seed/${circuit.id}/600/450`} 
                      alt={circuit.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 left-4 w-12 h-12 bg-white/90 backdrop-blur-md rounded-2xl flex items-center justify-center font-black text-emerald-primary text-lg shadow-xl border border-stone-100">
                      #{index + 1}
                    </div>
                  </div>

                  <div className="flex-1 space-y-6">
                    <div className="flex flex-wrap gap-3">
                       {badges.map(badge => (
                         <span key={badge.label} className={`px-4 py-1.5 bg-${badge.color}-50 text-${badge.color}-600 rounded-xl text-[9px] font-black uppercase tracking-widest italic`}>
                           {badge.label}
                         </span>
                       ))}
                       <span className="px-4 py-1.5 bg-stone-50 text-stone-premium/40 rounded-xl text-[9px] font-black uppercase tracking-widest">
                         {circuit.category}
                       </span>
                    </div>
                    <h3 className="text-4xl font-serif font-black text-emerald-primary group-hover:text-emerald-accent transition-colors tracking-tight leading-tight italic">{circuit.title}</h3>
                    <div className="flex items-center gap-10 text-[11px] font-bold text-stone-premium/40 uppercase tracking-widest">
                       <span className="flex items-center gap-2 text-emerald-accent"><Star size={16} className="fill-current" /> {circuit.averageRating || '4.9'}</span>
                       <span>{circuit.reviewCount || 0} Retours</span>
                       <span className="flex items-center gap-2 text-emerald-accent"><TrendingUp size={16} /> {circuit.rankingScore}% Excellence</span>
                    </div>
                  </div>

                    <div className="flex items-center gap-8 shrink-0 w-full md:w-auto mt-8 md:mt-0 pt-8 md:pt-0 border-t md:border-t-0 md:border-l border-stone-50 md:pl-12">
                       <div className="text-right">
                         <p className="text-[9px] font-bold text-stone-premium/30 uppercase tracking-widest mb-1 italic">Signature Val.</p>
                         <p className="text-3xl font-serif font-black italic text-emerald-primary">{(circuit.basePrice || 0).toLocaleString()} <span className="text-sm font-sans not-italic font-bold opacity-30">CFA</span></p>
                       </div>
                       <button 
                         onClick={() => onViewCircuit?.(circuit)}
                         className="w-16 h-16 bg-emerald-primary text-white rounded-2xl hover:bg-emerald-accent hover:text-emerald-primary transition-all active:scale-95 shadow-xl shadow-emerald-primary/10 flex items-center justify-center -rotate-12 hover:rotate-0 duration-500"
                       >
                         <ArrowRight size={24} />
                       </button>
                    </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'guides' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {rankedGuides.map((guide, index) => (
            <motion.div 
              key={guide.uid}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-[4rem] p-12 border border-stone-50 shadow-sahara hover:shadow-2xl transition-all group text-center relative overflow-hidden"
            >
              {index < 3 && (
                <div className="absolute top-8 left-8">
                   <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl rotate-12 group-hover:rotate-0 transition-transform duration-700 ${index === 0 ? "bg-emerald-accent text-emerald-primary" : index === 1 ? "bg-stone-50 text-stone-400" : "bg-stone-900 text-white"}`}>
                      <Trophy size={28} />
                   </div>
                </div>
              )}
              
              <div className="relative w-32 h-32 mx-auto mb-10">
                <img 
                  src={guide.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${guide.displayName}`} 
                  alt={guide.displayName}
                  className="w-full h-full rounded-[2.5rem] object-cover ring-8 ring-stone-50 transition-transform group-hover:scale-110 duration-1000 group-hover:rotate-3"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute -bottom-4 -right-4 bg-emerald-primary text-emerald-accent text-xs font-black w-12 h-12 rounded-2xl flex items-center justify-center border-4 border-white shadow-2xl">
                  #{index + 1}
                </div>
              </div>

              <h3 className="text-3xl font-serif font-black text-emerald-primary mb-2 italic tracking-tight">{guide.displayName}</h3>
              <p className="text-[10px] font-black text-stone-premium/30 uppercase tracking-[0.3em] mb-8 italic">Maître de Terrain</p>
              
              <div className="flex flex-wrap justify-center gap-3 mb-10 h-16 content-start">
                {(guide.badges || []).map(badge => (
                  <span key={badge} className="px-4 py-1.5 bg-stone-50 text-emerald-accent rounded-xl text-[9px] font-black uppercase tracking-widest border border-stone-100 shadow-sm italic">
                    {badge}
                  </span>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-8 py-8 border-y border-stone-50 mb-10">
                <div className="border-r border-stone-50">
                  <p className="text-[9px] font-bold text-stone-premium/30 uppercase tracking-widest mb-2 italic">Missions</p>
                  <p className="text-2xl font-black text-emerald-primary">{guide.totalReservations || 0}</p>
                </div>
                <div>
                  <p className="text-[9px] font-bold text-stone-premium/30 uppercase tracking-widest mb-2 italic">Excellence</p>
                  <div className="flex justify-center items-center gap-2 text-2xl font-black text-emerald-accent italic">
                    <Star size={18} className="fill-current" /> {guide.rating || '4.9'}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => onViewGuide?.(guide.uid)}
                className="w-full h-18 bg-stone-50 text-stone-premium/60 rounded-3xl font-black uppercase tracking-[0.2em] text-[10px] hover:bg-emerald-primary hover:text-white transition-all shadow-sm active:scale-95 duration-500 border border-stone-100"
              >
                CONSULTER LE MANIFESTE
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  query, 
  onSnapshot, 
  doc, 
  getDoc,
  updateDoc, 
  deleteDoc, 
  writeBatch, 
  getDocs,
  where,
  increment,
  serverTimestamp,
  orderBy
} from 'firebase/firestore';
import { db } from '../../firebase';
import { handleFirestoreError, OperationType, sortByDateDesc, toDate } from '../../lib/firestoreUtils';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Circuit, 
  Journey, 
  UserProfile, 
  Reservation, 
  Transaction, 
  Dispute,
  WithdrawalRequest
} from '../../types';
import { 
  Check, 
  X, 
  Users, 
  Map as MapIcon, 
  CreditCard, 
  TrendingUp, 
  ShieldCheck, 
  LogOut, 
  BarChart3, 
  Eye, 
  AlertCircle,
  Clock,
  ArrowRight,
  Filter,
  DollarSign,
  MapPin,
  Compass,
  Bell,
  Navigation
} from 'lucide-react';
import { trekService } from '../../services/trekService';
import { maintenanceService } from '../../services/maintenanceService';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { ProfileView } from '../../components/Profile/ProfileView';
import { SettingsView } from '../../components/Settings/SettingsView';
import { ConfirmModal } from '../../components/ui/ConfirmModal';
import { CRMMain } from './CRM/CRMMain';
import { AdminSandbox } from '../../components/Admin/AdminSandbox';
import { LeaderboardView } from '../Leaderboard/LeaderboardView';
import { CircuitDetailsFull } from '../../components/trek/CircuitDetailsFull';
import { CircuitsListView } from '../../components/guide/CircuitsListView';
import { AdminDisputesView } from './Views/AdminDisputesView';
import { AdminFinancesView } from './Views/AdminFinancesView';
import { AdminReportsView } from './Views/AdminReportsView';
import { AdminMapView } from './Views/AdminMapView';
import { AdminGuidesView } from './Views/AdminGuidesView';
import { AdminTerrainSupervision } from './AdminTerrainSupervision';
import { useNavigation } from '../../contexts/NavigationContext';
import toast from 'react-hot-toast';

export const AdminDashboard: React.FC<{ activeView: string; onViewChange: (view: string) => void }> = ({ activeView, onViewChange }) => {
  const { profile, logout } = useAuth();
  const { params } = useNavigation();
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [journeys, setJourneys] = useState<Journey[]>([]);
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCircuits: 0,
    pendingCircuits: 0,
    totalRevenue: 0,
    platformGains: 0
  });

  const [viewingCircuit, setViewingCircuit] = useState<Circuit | null>(null);
  const [selectedReservationId, setSelectedReservationId] = useState<string | null>(null);
  const [selectedDisputeId, setSelectedDisputeId] = useState<string | null>(null);

  useEffect(() => {
    if (params.circuitId && (activeView === 'circuits' || activeView === 'dashboard')) {
      const circuit = circuits.find(c => c.id === params.circuitId);
      if (circuit) setViewingCircuit(circuit);
    }
    if (params.reservationId && activeView === 'reservations') {
       setSelectedReservationId(params.reservationId);
    }
    if (params.disputeId && activeView === 'disputes') {
       setSelectedDisputeId(params.disputeId);
    }
  }, [params, activeView, circuits]);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
      const u = snap.docs.map(doc => doc.data() as UserProfile).sort(sortByDateDesc);
      setUsers(u);
      setStats(prev => ({ ...prev, totalUsers: u.length }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    const unsubCircuits = onSnapshot(collection(db, 'circuits'), (snap) => {
      const c = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Circuit)).sort(sortByDateDesc);
      setCircuits(c);
      setStats(prev => ({ 
        ...prev, 
        totalCircuits: c.length,
        pendingCircuits: c.filter(x => x.status === 'pending_admin_validation').length 
      }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'circuits');
    });

    const unsubRes = onSnapshot(collection(db, 'reservations'), (snap) => {
      const r = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reservation)).sort(sortByDateDesc);
      setReservations(r);
      const rev = r.filter(x => x.paymentStatus === 'paid' || x.paymentStatus === 'released').reduce((acc, curr) => acc + (curr.totalPaid || 0), 0);
      const fees = r.filter(x => x.paymentStatus === 'paid' || x.paymentStatus === 'released').reduce((acc, curr) => acc + (curr.platformFee || 0), 0);
      setStats(prev => ({ ...prev, totalRevenue: rev, platformGains: fees }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reservations');
    });

    const unsubDisputes = onSnapshot(collection(db, 'disputes'), (snap) => {
      setDisputes(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Dispute)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'disputes');
    });

    const unsubWithdrawals = onSnapshot(collection(db, 'withdrawals'), (snap) => {
      setWithdrawalRequests(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as WithdrawalRequest)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'withdrawals');
    });

    const unsubJourneys = onSnapshot(collection(db, 'journeys'), (snap) => {
      setJourneys(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Journey)).sort(sortByDateDesc));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'journeys');
    });

    return () => {
      unsubUsers();
      unsubCircuits();
      unsubRes();
      unsubDisputes();
      unsubWithdrawals();
      unsubJourneys();
    };
  }, [profile?.uid]);

  const handleValidateCircuit = async (circuit: Circuit, approved: boolean, reason?: string) => {
    try {
      await trekService.validateCircuit(circuit.id, approved, reason);
      toast.success(approved ? 'Circuit approuvé !' : 'Circuit rejeté.');
      setViewingCircuit(null);
    } catch (error) {
      toast.error('Erreur lors de la validation');
    }
  };

  const handleResolveDispute = async (dispute: Dispute, resolution: 'guide' | 'client') => {
    try {
      const reservationId = dispute.reservationId;
      const resRef = doc(db, 'reservations', reservationId);
      const resSnap = await getDoc(resRef);
      if (!resSnap.exists()) throw new Error('Réservation introuvable');
      const resData = resSnap.data() as Reservation;

      const batch = writeBatch(db);

      if (resolution === 'guide') {
        // Release funds to guide (80%)
        batch.update(resRef, {
          status: 'released',
          paymentStatus: 'released',
          updatedAt: serverTimestamp()
        });

        // Add to guide's available balance
        batch.update(doc(db, 'users', resData.guideId), {
          balanceAvailable: increment(resData.guideShare),
          balancePending: increment(-resData.guideShare),
          lastActivityAt: serverTimestamp()
        });

        // Event
        const eventRef = doc(collection(resRef, 'events'));
        batch.set(eventRef, {
          type: 'dispute_resolved_guide',
          userId: profile?.uid,
          userName: profile?.displayName,
          createdAt: serverTimestamp()
        });
      } else {
        // Refund client (full refund for simplicity, or 80%)
        // The user said: "Si le client signale un problème avant 24h, le paiement est bloqué et l’admin doit arbitrer."
        // Usually refund = return 100% or held for manual outside processing.
        batch.update(resRef, {
          status: 'refunded',
          paymentStatus: 'refunded',
          updatedAt: serverTimestamp()
        });

        // Remove from pending
        batch.update(doc(db, 'users', resData.guideId), {
          balancePending: increment(-resData.guideShare),
          lastActivityAt: serverTimestamp()
        });
        
        // Event
        const eventRef = doc(collection(resRef, 'events'));
        batch.set(eventRef, {
          type: 'dispute_resolved_client_refund',
          userId: profile?.uid,
          userName: profile?.displayName,
          createdAt: serverTimestamp()
        });
      }

      // Close dispute
      batch.update(doc(db, 'disputes', dispute.id), {
        status: 'resolved',
        resolvedAt: serverTimestamp(),
        resolution
      });

      await batch.commit();
      toast.success(resolution === 'guide' ? 'Fonds libérés au guide.' : 'Client remboursé.');
    } catch (error) {
      toast.error('Erreur lors de la résolution');
    }
  };

  const handleUpdateWithdrawal = async (requestId: string, status: 'approved' | 'rejected') => {
    try {
      const req = withdrawalRequests.find(r => r.id === requestId);
      if (!req) return;

      if (status === 'approved') {
        const batch = writeBatch(db);
        batch.update(doc(db, 'withdrawals', requestId), { status: 'approved' });
        batch.update(doc(db, 'users', req.guideId), { 
          balanceAvailable: increment(-req.amount),
          lastActivityAt: serverTimestamp()
        });
        
        // Transaction log
        const txRef = doc(collection(db, 'transactions'));
        batch.set(txRef, {
          id: txRef.id,
          userId: req.guideId,
          amount: -req.amount,
          type: 'withdrawal',
          status: 'completed',
          description: `Retrait effectué via ${req.method}`,
          createdAt: serverTimestamp()
        });

        await batch.commit();
      } else {
        await updateDoc(doc(db, 'withdrawals', requestId), { status: 'rejected' });
      }
      toast.success('Demande de retrait mise à jour');
    } catch (error) {
      toast.error('Erreur lors du traitement');
    }
  };

  const handleSeedRealData = async () => {
    const loadingToast = toast.loading('Initialisation des données...');
    try {
      await maintenanceService.seedInitialData();
      toast.success('Données initialisées !', { id: loadingToast });
    } catch (error) {
      toast.error('Erreur de seeding', { id: loadingToast });
    }
  };

  const handleResetApplication = async () => {
    if (!window.confirm('ÊTES-VOUS SÛR ? Cela va supprimer TOUTES les données de la base Firebase MaliTrek.')) return;
    const loadingToast = toast.loading('Réinitialisation en cours...');
    try {
      await maintenanceService.resetAllCollections();
      await maintenanceService.clearLocalAppCache();
      toast.success('Application réinitialisée !', { id: loadingToast });
      window.location.reload();
    } catch (error) {
      toast.error('Erreur lors du reset', { id: loadingToast });
    }
  };

  const handleClearCache = async () => {
    await maintenanceService.clearLocalAppCache();
    toast.success('Cache local vidé.');
  };

  const Card: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className }) => (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white p-8 rounded-[2.5rem] shadow-sm border border-stone-100 ${className}`}
    >
      {children}
    </motion.div>
  );

  const Calendar: React.FC<{ size?: number, className?: string }> = ({ size, className }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <rect width="18" height="18" x="3" y="4" rx="2" ry="2"/>
      <line x1="16" x2="16" y1="2" y2="6"/>
      <line x1="8" x2="8" y1="2" y2="6"/>
      <line x1="3" x2="21" y1="10" y2="10"/>
    </svg>
  );

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col">
      <main className="flex-1 overflow-y-auto pb-32 p-4 md:p-8">
        {activeView === 'dashboard' && (
          <div className="space-y-8 md:space-y-12 max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-stone-100 pb-8 md:pb-12">
              <div className="stagger-in">
                <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 italic">Quartier Général</p>
                <h1 className="text-4xl md:text-6xl font-serif font-black text-emerald-primary tracking-tighter leading-none italic">Contrôle <br className="hidden md:block" /><span className="text-stone-300">MaliTrek</span></h1>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                <button 
                  onClick={handleSeedRealData}
                  className="w-full sm:w-auto px-6 md:px-8 py-3 md:py-4 bg-emerald-primary text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-emerald-accent transition-all shadow-xl shadow-emerald-primary/10"
                >
                  Générer Données
                </button>
                <button 
                  onClick={async () => {
                    const loading = toast.loading('Réparation...');
                    try {
                      await trekService.repairReservationsData();
                      toast.success('Réparé !', { id: loading });
                    } catch (e) {
                      toast.error('Erreur', { id: loading });
                    }
                  }}
                  className="w-full sm:w-auto px-6 md:px-8 py-3 md:py-4 bg-stone-900 text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  Réparer
                </button>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
              {[
                { label: 'Users', value: stats.totalUsers, icon: Users, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                { label: 'Attente', value: stats.pendingCircuits, icon: MapIcon, color: 'text-amber-600', bg: 'bg-amber-50' },
                { label: 'Volume', value: (stats.totalRevenue || 0).toLocaleString(), icon: TrendingUp, color: 'text-stone-600', bg: 'bg-stone-50' },
                { label: 'Comms', value: (stats.platformGains || 0).toLocaleString(), icon: ShieldCheck, color: 'text-indigo-600', bg: 'bg-indigo-50' },
              ].map((stat, i) => (
                <Card key={i} className="flex flex-col gap-4 md:gap-6 p-6 md:p-10 hover:shadow-sahara transition-all group overflow-hidden">
                  <div className={`${stat.bg} ${stat.color} w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <stat.icon size={18} />
                  </div>
                  <div>
                    <p className="text-stone-400 text-[7px] md:text-[9px] font-black uppercase tracking-[0.2em] mb-1 italic truncate">{stat.label}</p>
                    <p className="text-base md:text-3xl font-black text-emerald-primary tracking-tighter truncate">{stat.value}</p>
                  </div>
                </Card>
              ))}
            </div>

            {/* Active Journeys Supervision */}
            {journeys.filter(j => j.status === 'in_progress').length > 0 && (
              <div className="space-y-6 md:space-y-8">
                 <h2 className="text-xl md:text-2xl font-serif italic font-black text-emerald-primary tracking-tight flex items-center gap-3 md:gap-4">
                    <Navigation size={24} className="text-emerald-accent" />
                    Live Terrain
                 </h2>
                 <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 md:gap-8">
                    {journeys.filter(j => j.status === 'in_progress').map(j => (
                      <div key={j.id} className="bg-white rounded-[2.5rem] md:rounded-[3rem] p-6 md:p-10 border border-stone-100 shadow-sahara group relative overflow-hidden">
                         <div className="absolute top-0 right-0 w-24 h-24 md:w-32 md:h-32 bg-emerald-50 rounded-full -mr-12 -mt-12 md:-mr-16 md:-mt-16 group-hover:bg-emerald-100 transition-colors" />
                         <div className="flex justify-between items-start mb-6 md:mb-10 relative z-10">
                            <div className="space-y-1 md:space-y-2">
                               <p className="text-[7px] md:text-[9px] font-black uppercase tracking-[0.3em] text-emerald-accent italic">Expédition Active</p>
                               <h4 className="font-serif italic font-black text-xl md:text-2xl text-emerald-primary leading-tight uppercase tracking-tighter pr-8 line-clamp-2">{j.title}</h4>
                            </div>
                            <div className="bg-stone-50 p-3 md:p-4 rounded-xl md:rounded-2xl text-emerald-accent shadow-inner shrink-0">
                               <MapPin size={20} />
                            </div>
                         </div>
                         <div className="grid grid-cols-3 gap-3 md:gap-6 mb-6 md:mb-10 relative z-10">
                            <div className="bg-stone-50 p-2 md:p-4 rounded-xl md:rounded-[1.5rem] text-center border border-stone-100">
                               <p className="text-[6px] md:text-[8px] font-black text-stone-300 uppercase tracking-widest mb-1 italic">Clients</p>
                               <p className="text-base md:text-xl font-black text-stone-900">{j.activeParticipantsCount || 0}</p>
                            </div>
                            <div className="bg-emerald-50 p-2 md:p-4 rounded-xl md:rounded-[1.5rem] text-center border border-emerald-100">
                               <p className="text-[6px] md:text-[8px] font-black text-emerald-600/40 uppercase tracking-widest mb-1 italic">Check</p>
                               <p className="text-base md:text-xl font-black text-emerald-primary">{j.checkedInCount || 0}</p>
                            </div>
                            <div className="bg-rose-50 p-2 md:p-4 rounded-xl md:rounded-[1.5rem] text-center border border-rose-100">
                               <p className="text-[6px] md:text-[8px] font-black text-rose-300 uppercase tracking-widest mb-1 italic">Alerte</p>
                               <p className={`text-base md:text-xl font-black ${j.incidentCount ? 'text-rose-500' : 'text-stone-300'}`}>{j.incidentCount || 0}</p>
                            </div>
                         </div>
                         <button 
                            onClick={() => onViewChange('map_view')}
                            className="w-full py-4 md:py-5 bg-stone-900 text-white rounded-xl md:rounded-2xl text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 md:gap-3 active:scale-95 shadow-xl"
                         >
                            Radar Live <ArrowRight size={14} />
                         </button>
                      </div>
                    ))}
                 </div>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10">
              <Card className="p-6 md:p-10">
                <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 flex items-center gap-2">
                  <AlertCircle size={20} className="text-amber-500" />
                  Validations
                </h3>
                <div className="space-y-3 md:space-y-4">
                  {circuits.filter(c => c.status === 'pending_admin_validation').map(c => (
                    <div key={c.id} className="flex items-center justify-between p-3 md:p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex items-center gap-3 md:gap-4 min-w-0">
                        <img src={c.image} alt={c.title} className="w-10 h-10 md:w-12 md:h-12 rounded-xl object-cover shrink-0" />
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 text-xs md:text-sm truncate">{c.title}</p>
                          <p className="text-[8px] md:text-[10px] text-slate-400 font-black uppercase tracking-widest truncate">{c.location}</p>
                        </div>
                      </div>
                      <div className="flex gap-1.5 md:gap-2 shrink-0">
                        <button 
                          onClick={() => setViewingCircuit(c)}
                          className="p-1.5 md:p-2 bg-white text-slate-400 rounded-lg border border-slate-100"
                        >
                          <Eye size={14} />
                        </button>
                        <button 
                          onClick={() => handleValidateCircuit(c, true)}
                          className="p-1.5 md:p-2 bg-emerald-500 text-white rounded-lg"
                        >
                          <Check size={14} />
                        </button>
                        <button 
                          onClick={() => handleValidateCircuit(c, false)}
                          className="p-1.5 md:p-2 bg-rose-500 text-white rounded-lg"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                  {stats.pendingCircuits === 0 && <p className="text-center py-8 md:py-10 text-slate-400 text-xs font-bold">Catalogue à jour.</p>}
                </div>
              </Card>

              <Card className="p-6 md:p-10">
                <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 flex items-center gap-2">
                  <DollarSign size={20} className="text-emerald-500" />
                  Retraits
                </h3>
                <div className="space-y-3 md:space-y-4">
                  {withdrawalRequests.filter(w => w.status === 'pending').map(w => (
                    <div key={w.id} className="flex items-center justify-between p-3 md:p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="min-w-0">
                        <p className="text-bold text-slate-900 text-xs md:text-sm truncate">{w.guideName}</p>
                        <p className="text-[8px] md:text-[10px] text-emerald-600 font-black uppercase tracking-widest truncate">{(w.amount || 0).toLocaleString()} CFA ({w.method})</p>
                      </div>
                      <div className="flex gap-1.5 md:gap-2 shrink-0">
                        <button 
                          onClick={() => handleUpdateWithdrawal(w.id, 'approved')}
                          className="px-3 md:px-4 py-1.5 md:py-2 bg-emerald-100 text-emerald-700 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase"
                        >
                          Payer
                        </button>
                        <button 
                          onClick={() => handleUpdateWithdrawal(w.id, 'rejected')}
                          className="px-3 md:px-4 py-1.5 md:py-2 bg-rose-100 text-rose-700 rounded-lg md:rounded-xl text-[8px] md:text-[10px] font-black uppercase"
                        >
                          Refuser
                        </button>
                      </div>
                    </div>
                  ))}
                  {withdrawalRequests.filter(w => w.status === 'pending').length === 0 && <p className="text-center py-8 md:py-10 text-slate-400 text-xs font-bold">Aucune demande.</p>}
                </div>
              </Card>
            </div>
          </div>
        )}

        {activeView === 'guides' && <AdminGuidesView />}

        {activeView === 'users' && (
          <Card className="p-6 md:p-12">
            <h3 className="text-2xl md:text-4xl font-serif italic font-black text-emerald-primary tracking-tight mb-8 md:mb-12">Utilisateurs</h3>
            <div className="overflow-x-auto -mx-6 md:-mx-12">
              <div className="inline-block min-w-full align-middle">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] text-stone-300 border-b border-stone-50">
                      <th className="pb-4 md:pb-8 px-6 md:px-12">Compte</th>
                      <th className="pb-4 md:pb-8 px-6 md:px-12">Rôle</th>
                      <th className="hidden sm:table-cell pb-4 md:pb-8 px-6 md:px-12 text-right">Soldes</th>
                      <th className="pb-4 md:pb-8 px-6 md:px-12 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-50">
                    {users.map(u => (
                      <tr key={u.uid} className="hover:bg-stone-50/50 transition-all group">
                        <td className="py-4 md:py-8 px-6 md:px-12">
                          <div className="flex items-center gap-3 md:gap-4">
                            <div className="w-8 h-8 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-stone-100 flex items-center justify-center font-black text-stone-300 text-[10px] md:text-sm shrink-0">
                                {u.displayName?.charAt(0)}
                            </div>
                            <div className="min-w-0">
                                <p className="font-black text-emerald-primary text-xs md:text-base truncate">{u.displayName}</p>
                                <p className="text-[8px] md:text-[10px] text-stone-400 font-bold truncate">{u.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 md:py-8 px-6 md:px-12">
                          <span className={`px-2 md:px-4 py-1 rounded-full text-[7px] md:text-[9px] font-black uppercase whitespace-nowrap ${
                            u.role === 'ROLE_ADMIN' ? 'bg-indigo-50 text-indigo-600' :
                            u.role === 'ROLE_GUIDE' ? 'bg-emerald-50 text-emerald-600' : 'bg-stone-50 text-stone-400'
                          }`}>
                            {u.role.replace('ROLE_', '')}
                          </span>
                        </td>
                        <td className="hidden sm:table-cell py-4 md:py-8 px-6 md:px-12 text-right">
                          <div className="whitespace-nowrap">
                             <p className="text-xs md:text-sm font-black text-emerald-600">{(u.balanceAvailable || 0).toLocaleString()} <span className="text-[10px]">CFA</span></p>
                             <p className="text-[8px] md:text-[10px] font-bold text-amber-500/50 italic">{(u.balancePending || 0).toLocaleString()} pending</p>
                          </div>
                        </td>
                        <td className="py-4 md:py-8 px-6 md:px-12 text-right">
                          <button className="w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl bg-stone-50 text-stone-300 hover:text-emerald-accent flex items-center justify-center ml-auto"><Clock size={14} /></button>
                        </td>
                      </tr>
                    ))}
                   </tbody>
                </table>
              </div>
            </div>
          </Card>
        )}

        {activeView === 'map_view' && <AdminMapView />}
        {activeView === 'terrain_supervision' && <AdminTerrainSupervision />}

        {activeView === 'messages' && (
          <CRMMain 
            users={users} 
            reservations={reservations} 
            circuits={circuits} 
            journeys={journeys} 
          />
        )}

        {activeView === 'analytics' && <AdminReportsView />}
        {activeView === 'finance' && <AdminFinancesView />}

        {activeView === 'circuits' && (
          <div className="space-y-6 md:space-y-10">
             <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-2xl md:text-4xl font-black text-stone-900 tracking-tighter">Catalogue</h2>
                <button className="w-full sm:w-auto bg-stone-900 text-white px-6 md:px-8 py-3 md:py-4 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">Ajouter (Admin)</button>
             </div>
             
             <CircuitsListView 
                circuits={circuits}
                onAdd={() => toast('Module admin non implémenté')}
                onPlanJourney={(c) => toast('Réservé aux guides')}
                onViewDetails={setViewingCircuit}
                onEdit={(c) => toast('Réservé aux guides')}
                onDelete={(id) => trekService.updateCircuit(id, { status: 'deleted' as any })}
                onSubmitForValidation={(id) => trekService.validateCircuit(id, true)}
                onClose={(id) => trekService.closeCircuit(id, profile?.uid || 'ADMIN', 'Fermé')}
                onReopen={(id) => trekService.reopenCircuit(id, profile?.uid || 'ADMIN')}
                onDisable={(id) => trekService.disableCircuit(id, profile?.uid || 'ADMIN', 'Désactivé')}
                onEnable={(id) => trekService.enableCircuitByAdmin(id, profile?.uid || 'ADMIN')}
                isAdmin={true}
             />
          </div>
        )}

        {activeView === 'journeys' && (
          <div className="space-y-8 md:space-y-10">
             <h2 className="text-2xl md:text-4xl font-black text-stone-900 tracking-tighter">Calendrier</h2>
             <div className="grid grid-cols-1 gap-4 md:gap-6">
                {journeys.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map(j => (
                  <div key={j.id} className="bg-white p-6 md:p-8 rounded-[2rem] md:rounded-[3rem] border border-stone-100 flex flex-col md:flex-row md:items-center gap-6 md:gap-10">
                     <div className="w-full md:w-32 h-40 md:h-32 rounded-2xl md:rounded-[2.5rem] overflow-hidden shrink-0">
                        <img src={j.image} className="w-full h-full object-cover" />
                     </div>
                     <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                           <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 text-[7px] md:text-[8px] font-black uppercase tracking-widest rounded-full">{j.category}</span>
                           <span className={`px-2 py-0.5 text-[7px] md:text-[8px] font-black uppercase tracking-widest rounded-full ${
                             j.status === 'open' ? 'bg-blue-50 text-blue-600' : 
                             j.status === 'in_progress' ? 'bg-amber-50 text-amber-600' : 'bg-stone-50 text-stone-400'
                           }`}>{j.status.replace('_', ' ')}</span>
                        </div>
                        <h4 className="text-xl md:text-2xl font-black text-stone-900 mb-2 truncate">{j.title}</h4>
                        <div className="flex gap-4 md:gap-6 text-stone-400 font-bold text-[10px] md:text-xs uppercase tracking-widest">
                           <span className="flex items-center gap-1.5 md:gap-2 truncate"><Calendar size={12} /> {j.date ? new Date(j.date).toLocaleDateString() : 'À venir'}</span>
                           <span className="flex items-center gap-1.5 md:gap-2 whitespace-nowrap"><Users size={12} /> {j.availableSeats} / {j.totalSeats} places</span>
                        </div>
                     </div>
                     <div className="flex flex-row md:flex-col justify-between items-center md:items-end gap-2 border-t md:border-t-0 pt-4 md:pt-0">
                        <p className="text-lg md:text-2xl font-black text-stone-900">{(j.pricePerPerson || 0).toLocaleString()} <span className="text-xs">CFA</span></p>
                        <button className="px-6 md:px-8 py-3 md:py-4 bg-stone-900 text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all">Gérer</button>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {/* Disputes View */}
        {activeView === 'disputes' && (
          <AdminDisputesView />
        )}

        {activeView === 'maintenance' && (
          <div className="space-y-8 md:space-y-10">
            <h2 className="text-2xl md:text-4xl font-black text-slate-900 tracking-tighter">Maintenance</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-10">
              <Card className="border-rose-100 bg-rose-50/20 p-6 md:p-8">
                <h3 className="text-lg md:text-xl font-black text-rose-900 mb-3 flex items-center gap-2">
                  <AlertCircle size={20} /> Reset Base
                </h3>
                <p className="text-rose-600 text-[10px] md:text-xs font-bold leading-relaxed mb-6 md:mb-8">
                  Action irréversible. Efface TOUT.
                </p>
                <button 
                  onClick={handleResetApplication}
                  className="w-full py-4 bg-rose-600 text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all"
                >
                  Reset MaliTrek
                </button>
              </Card>

              <Card className="border-emerald-100 bg-emerald-50/20 p-6 md:p-8">
                <h3 className="text-lg md:text-xl font-black text-emerald-900 mb-3 flex items-center gap-2">
                  <Compass size={20} /> Seeding
                </h3>
                <p className="text-emerald-600 text-[10px] md:text-xs font-bold leading-relaxed mb-6 md:mb-8">
                  Recrée un environnement propre.
                </p>
                <button 
                  onClick={handleSeedRealData}
                  className="w-full py-4 bg-emerald-600 text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all"
                >
                  Populer Données
                </button>
              </Card>

              <Card className="border-blue-100 bg-blue-50/20 p-6 md:p-8">
                <h3 className="text-lg md:text-xl font-black text-blue-900 mb-3 flex items-center gap-2">
                  <ShieldCheck size={20} /> Cache
                </h3>
                <p className="text-blue-600 text-[10px] md:text-xs font-bold leading-relaxed mb-6 md:mb-8">
                   Vide les sessions navigateur.
                </p>
                <button 
                  onClick={handleClearCache}
                  className="w-full py-4 bg-blue-600 text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all"
                >
                  Nettoyer Cache
                </button>
              </Card>
            </div>
            
            <Card className="p-6 md:p-10">
              <h3 className="text-lg md:text-xl font-black text-slate-900 mb-4">Vérifications</h3>
              <p className="text-slate-500 text-xs md:text-sm mb-6">Forcer le cycle d'auto-validation (24h).</p>
              <button 
                onClick={() => trekService.checkAutoValidations(profile!)}
                className="w-full sm:w-auto px-8 py-4 bg-slate-900 text-white rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95"
              >
                Lancer Vérif'
              </button>
            </Card>
          </div>
        )}

        {activeView === 'settings' && <SettingsView />}
        {activeView === 'profile' && <ProfileView />}
        {activeView === 'sandbox' && <AdminSandbox />}
        {activeView === 'leaderboard' && (
          <LeaderboardView 
            circuits={circuits} 
            users={users} 
            onViewCircuit={setViewingCircuit} 
            onViewGuide={(id) => toast.success(`Guide ${id}`)} 
          />
        )}

      </main>

      <ConfirmModal 
        isOpen={confirmConfig.isOpen}
        onClose={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmConfig.onConfirm}
        title={confirmConfig.title}
        message={confirmConfig.message}
      />

      {/* Viewing Circuit Detail Overlay */}
      <AnimatePresence>
        {viewingCircuit && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-end md:items-center justify-center">
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              className="bg-white rounded-t-[2.5rem] md:rounded-[3rem] w-full max-w-7xl h-[92vh] md:h-[90vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="h-full overflow-y-auto no-scrollbar">
                <CircuitDetailsFull 
                  circuit={viewingCircuit}
                  role="ROLE_ADMIN"
                  isAdmin={true}
                  onClose={() => setViewingCircuit(null)}
                  onApprove={() => handleValidateCircuit(viewingCircuit, true)}
                  onReject={(reason) => handleValidateCircuit(viewingCircuit, false, reason)}
                  availableJourneys={journeys.filter(j => j.circuitId === viewingCircuit.id)}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

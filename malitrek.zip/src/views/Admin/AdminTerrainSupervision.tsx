import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { 
  Wifi, 
  WifiOff, 
  CloudUpload, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Filter, 
  Search, 
  Smartphone,
  Navigation,
  Globe,
  RefreshCcw,
  MoreHorizontal,
  Mail,
  Zap
} from 'lucide-react';
import { collection, query, orderBy, onSnapshot, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../../firebase';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface SyncLog {
  id: string;
  type: string;
  guideName: string;
  journeyTitle: string;
  status: 'pending' | 'synced' | 'failed';
  createdAt: any;
  syncedAt?: any;
  payload: any;
}

export const AdminTerrainSupervision: React.FC = () => {
  const [logs, setLogs] = useState<SyncLog[]>([]);
  const [incidents, setIncidents] = useState<any[]>([]);
  const [smsAlerts, setSmsAlerts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'critical'>('all');

  useEffect(() => {
    const unsubIncidents = onSnapshot(
      query(collection(db, 'incidents'), orderBy('createdAt', 'desc'), limit(20)),
      (snap) => {
        setIncidents(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setIsLoading(false);
      }
    );

    const unsubSMS = onSnapshot(
      query(collection(db, 'sms_alerts'), orderBy('createdAt', 'desc'), limit(10)),
      (snap) => {
        setSmsAlerts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      }
    );

    return () => {
      unsubIncidents();
      unsubSMS();
    };
  }, []);

  return (
    <div className="space-y-6 md:space-y-12 animate-in fade-in duration-500 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-200 pb-8 md:pb-12">
        <div className="stagger-in">
          <p className="text-[8px] md:text-[10px] font-black text-rose-500 uppercase tracking-[0.4em] mb-2 md:mb-4 italic line-clamp-1">Surveillance Opérationnelle</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-stone-900 tracking-tighter italic leading-none">Radar <br className="hidden md:block" /><span className="text-rose-500">Terrain</span></h2>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex-1 md:flex-none flex items-center gap-2 md:gap-3 px-4 md:px-6 py-2 md:py-3 bg-emerald-50 text-emerald-600 rounded-xl md:rounded-2xl border border-emerald-100">
             <RefreshCcw size={16} className="animate-spin-slow" />
             <span className="text-[8px] md:text-[10px] font-black uppercase tracking-widest">Live Sync Auto</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
        
        {/* Alerts / Incidents Panel */}
        <div className="lg:col-span-2 space-y-6 md:space-y-8">
          <div className="bg-white border border-stone-100 rounded-[2rem] md:rounded-[3rem] p-6 md:p-10 shadow-sahara">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 md:mb-10">
              <h3 className="text-lg md:text-2xl font-serif italic font-black flex items-center gap-3 text-stone-900 tracking-tight">
                <AlertTriangle className="w-5 h-5 md:w-6 md:h-6 text-rose-500" />
                Derniers Incidents
              </h3>
              <div className="flex gap-2 w-full sm:w-auto">
                {['all', 'critical'].map(f => (
                  <button 
                    key={f}
                    onClick={() => setFilter(f as any)}
                    className={`flex-1 sm:flex-none px-4 md:px-6 py-2 rounded-xl text-[8px] md:text-[9px] font-black uppercase tracking-widest border transition-all active:scale-95 ${
                      filter === f ? 'bg-stone-900 text-white border-stone-900' : 'bg-transparent text-stone-300 border-stone-100'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4 md:space-y-6">
              {incidents.filter(i => filter === 'all' || i.urgency === 'critical').map(incident => (
                <div key={incident.id} className="bg-stone-50 rounded-2xl md:rounded-[2.5rem] p-5 md:p-8 border border-stone-100 hover:border-rose-500/20 transition-all group overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/5 rounded-full -mr-12 -mt-12 group-hover:scale-110 transition-transform" />
                  <div className="flex items-start justify-between mb-4 md:mb-6 relative z-10">
                    <div className="flex items-center gap-3 md:gap-5">
                      <div className={`w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center shrink-0 ${incident.urgency === 'critical' ? 'bg-rose-500 text-white' : 'bg-amber-500 text-white shadow-xl shadow-amber-500/10'}`}>
                        <AlertTriangle className="w-5 h-5 md:w-6 md:h-6" />
                      </div>
                      <div className="min-w-0">
                         <p className="font-black text-stone-900 text-base md:text-xl truncate tracking-tight">{incident.type}</p>
                         <p className="text-[8px] md:text-[10px] font-bold uppercase text-stone-400 tracking-widest truncate mt-1">
                            {incident.journeyTitle || incident.journeyId} • {incident.userName || 'Guide'}
                         </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                       <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest mb-1">
                          {incident.createdAt?.seconds ? format(incident.createdAt.seconds * 1000, 'HH:mm', { locale: fr }) : 'A l\'instant'}
                       </p>
                       <span className={`text-[7px] md:text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${
                         incident.urgency === 'critical' ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'
                       }`}>
                         {incident.urgency}
                       </span>
                    </div>
                  </div>
                  <p className="text-xs md:text-sm text-stone-600 leading-relaxed font-bold italic relative z-10 bg-white/50 backdrop-blur-sm p-4 md:p-6 rounded-xl md:rounded-2xl border border-white">
                    "{incident.description || incident.note || 'Aucune description fournie.'}"
                  </p>
                </div>
              ))}
              {incidents.length === 0 && (
                <div className="text-center py-16 md:py-24 bg-stone-50 rounded-[2rem] border border-dashed border-stone-200">
                  <p className="text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] mb-2">Silence Radio</p>
                  <p className="text-xs text-stone-400 font-bold">Aucun incident à signaler sur le terrain.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Status Side Panel */}
        <div className="space-y-6 md:space-y-10">
          
          {/* SMS Logs */}
          <div className="bg-white border border-stone-100 rounded-[2rem] md:rounded-[3rem] p-6 md:p-10 shadow-sahara relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 md:p-6">
               <Zap className="w-8 h-8 md:w-12 md:h-12 text-amber-500/10" />
            </div>
            <h3 className="text-lg md:text-xl font-black mb-6 md:mb-8 flex items-center gap-3 text-stone-900 tracking-tight relative z-10">
              SMS Fallback
            </h3>
            <div className="space-y-3 md:space-y-4 relative z-10">
              {smsAlerts.map(alert => (
                <div key={alert.id} className="bg-stone-50 rounded-2xl p-4 border border-stone-100 relative group transition-all">
                   <div className="flex items-center justify-between mb-2">
                      <span className={`text-[7px] md:text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${
                         alert.status === 'sent' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'
                      }`}>
                        {alert.status}
                      </span>
                      <span className="text-[8px] text-stone-300 font-bold">{alert.createdAt?.seconds ? format(alert.createdAt.seconds * 1000, 'HH:mm', { locale: fr }) : ''}</span>
                   </div>
                   <p className="text-[10px] md:text-[11px] font-bold text-stone-600 line-clamp-2 italic leading-tight overflow-hidden">"{alert.message}"</p>
                </div>
              ))}
              {smsAlerts.length === 0 && (
                <p className="text-[10px] font-black text-center text-stone-200 uppercase tracking-widest py-10">Aucun SMS actif</p>
              )}
            </div>
          </div>

          {/* Device Sync Status */}
          <div className="bg-white border border-stone-100 rounded-[2rem] md:rounded-[3rem] p-6 md:p-10 shadow-sahara overflow-hidden">
            <h3 className="text-lg md:text-xl font-black mb-6 md:mb-8 flex items-center gap-3 text-stone-900 tracking-tight">
              Terminaux
            </h3>
            <div className="space-y-4 md:space-y-6">
               <div className="flex items-center justify-between p-4 md:p-6 bg-emerald-50/30 rounded-2xl border border-emerald-50 group hover:scale-[1.02] transition-transform">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600">
                       <Wifi size={20} />
                    </div>
                    <div>
                       <span className="text-xs md:text-sm font-black text-stone-900">Guide Ahmad</span>
                       <p className="text-[8px] md:text-[9px] font-bold text-stone-400 italic">Samsung A54 • Koulikoro</p>
                    </div>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
               </div>
               
               <div className="flex items-center justify-between p-4 md:p-6 bg-rose-50/30 rounded-2xl border border-rose-50 group hover:scale-[1.02] transition-transform">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600">
                       <WifiOff size={20} />
                    </div>
                    <div>
                       <span className="text-xs md:text-sm font-black text-stone-900">Guide Moussa</span>
                       <p className="text-[8px] md:text-[9px] font-bold text-stone-400 italic">iPhone 13 • Zone Ombre</p>
                    </div>
                  </div>
                  <div className="text-right">
                     <span className="text-[7px] md:text-[8px] font-black uppercase text-rose-500 tracking-widest block">Sync Pending</span>
                     <p className="text-[8px] font-bold text-rose-300">Last. 12:45</p>
                  </div>
               </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { Zap, Play, Pause, ChevronRight, Settings, Plus, Layout, Mail, Bell, Gift, UserPlus } from 'lucide-react';

const mockWorkflows = [
  { id: '1', name: 'Accueil nouveaux clients', trigger: 'Inscription', action: 'Notification Welcome', active: true, stat: 'A généré 12 réservations' },
  { id: '2', name: 'Relance inactifs 30j', trigger: 'Inactivité > 30j', action: 'Offre promo -15%', active: false, stat: 'En pause' },
  { id: '3', name: 'Fidélisation VIP', trigger: '10ème réservation', action: 'Badge VIP + Cadeau', active: true, stat: '42 clients récompensés' },
  { id: '4', name: 'Après-Vente', trigger: 'Circuit terminé', action: 'Demande avis', active: true, stat: 'Taux avis: 74%' },
];

export const AutomationView: React.FC = () => {
  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 stagger-in">
        <div>
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 italic">Marketing Automation</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Scénarios</h2>
          <p className="text-[10px] md:text-sm text-stone-400 font-bold mt-2 md:mt-4 italic">Automatisez vos interactions pour gagner du temps.</p>
        </div>
        <button className="w-full md:w-auto bg-stone-900 text-white px-8 py-4 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-stone-900/10 active:scale-95 transition-all flex items-center justify-center gap-2">
            <Plus size={14} strokeWidth={3} /> Nouveau Workflow
        </button>
      </header>

      <div className="grid grid-cols-1 gap-4 md:gap-6">
        {mockWorkflows.map((flow) => (
          <div key={flow.id} className="bg-white p-5 md:p-8 rounded-2xl md:rounded-[3rem] border border-stone-100 shadow-sahara flex flex-col md:flex-row items-stretch md:items-center justify-between group hover:border-emerald-primary/10 transition-all gap-6">
            <div className="flex items-center gap-4 md:gap-8">
              <div className={`w-12 h-12 md:w-16 md:h-16 rounded-xl md:rounded-2xl flex items-center justify-center shrink-0 ${flow.active ? 'bg-emerald-50 text-emerald-primary' : 'bg-stone-50 text-stone-200'}`}>
                <Zap className={`w-6 md:w-7 h-6 md:h-7 ${flow.active ? 'animate-pulse' : ''}`} fill={flow.active ? 'currentColor' : 'none'} />
              </div>
              <div className="space-y-1 min-w-0">
                <div className="flex items-center gap-2 md:gap-3">
                  <h3 className="text-sm md:text-lg font-black text-emerald-primary truncate italic">{flow.name}</h3>
                  <span className={`px-2 md:px-3 py-1 rounded-full text-[7px] md:text-[8px] font-black uppercase tracking-widest ${flow.active ? 'bg-emerald-100 text-emerald-primary' : 'bg-stone-100 text-stone-400'}`}>
                    {flow.active ? 'Actif' : 'Pause'}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2 md:gap-4 text-[9px] md:text-xs font-bold text-stone-300 italic">
                  <span className="flex items-center gap-1"><UserPlus className="w-2.5 md:w-3 h-2.5 md:h-3"/> {flow.trigger}</span>
                  <span className="hidden md:inline text-stone-100">/</span>
                  <span className="flex items-center gap-1 text-emerald-accent"><Bell className="w-2.5 md:w-3 h-2.5 md:h-3"/> {flow.action}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between md:justify-end gap-4 md:gap-8 border-t md:border-t-0 border-stone-50 pt-4 md:pt-0">
              <div className="text-left md:text-right">
                <p className="text-[7px] md:text-[10px] font-black text-stone-200 uppercase tracking-widest italic leading-none mb-1">IMPACT</p>
                <p className="text-[8px] md:text-[10px] font-black text-emerald-primary uppercase tracking-widest italic truncate">{flow.stat}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button className="p-3 md:p-4 bg-stone-50 rounded-xl text-stone-300 hover:text-emerald-primary transition-all">
                  <Settings className="w-4 md:w-4.5 h-4 md:h-4.5" />
                </button>
                <button className={`p-3 md:p-4 rounded-xl transition-all shadow-lg ${flow.active ? 'bg-amber-50 text-amber-500 shadow-amber-500/10' : 'bg-emerald-50 text-emerald-primary shadow-emerald-500/10'}`}>
                  {flow.active ? <Pause className="w-4 md:w-4.5 h-4 md:h-4.5" fill="currentColor" /> : <Play className="w-4 md:w-4.5 h-4 md:h-4.5" fill="currentColor" />}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10">
        <div className="bg-white p-6 md:p-12 rounded-[2rem] md:rounded-[3.5rem] border border-stone-100 shadow-sahara italic space-y-4 md:space-y-8 relative overflow-hidden">
           <Layout size={80} className="absolute -left-4 -bottom-4 text-stone-50 -rotate-12" />
           <div className="relative z-10 flex items-center gap-3 md:gap-4 mb-2 md:mb-6">
             <div className="w-8 h-8 md:w-10 md:h-10 bg-stone-900 text-white rounded-lg md:rounded-xl flex items-center justify-center font-black text-xs md:text-sm">?</div>
             <h4 className="text-[10px] md:text-sm font-black text-emerald-primary uppercase tracking-widest italic">Intelligence Automatisée</h4>
           </div>
           <p className="relative z-10 text-[10px] md:text-sm text-stone-400 font-bold leading-relaxed italic">
             Le marketing automation permet de créer des boucles d'engagement fluides. Lorsqu'un "déclencheur" est détecté (ex: inscription), une "action" est exécutée immédiatement. C'est le meilleur moyen de garder vos clients actifs sans effort manuel constant.
           </p>
        </div>
        <div className="bg-emerald-primary rounded-[2rem] md:rounded-[3.5rem] p-8 md:p-12 text-white relative overflow-hidden group shadow-2xl">
           <Gift size={100} className="absolute -right-5 -bottom-5 text-white/5 md:text-white/10 group-hover:scale-125 group-hover:rotate-12 transition-transform duration-1000" />
           <div className="relative z-10 space-y-4 md:space-y-6">
             <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic mb-2">PRO TIPS</p>
             <h4 className="text-xl md:text-3xl font-serif italic font-black leading-tight">Besoin d'un scénario ?</h4>
             <p className="text-white/60 text-[10px] md:text-base font-bold italic leading-relaxed">
               Découvrez notre bibliothèque de modèles d'automatisation optimisés pour le marché Malien.
             </p>
             <button className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] bg-white/10 border border-white/10 px-8 py-4 rounded-xl md:rounded-2xl hover:bg-white/20 transition-all active:scale-95">Parcourir les modèles</button>
           </div>
        </div>
      </div>
    </div>
  );
};

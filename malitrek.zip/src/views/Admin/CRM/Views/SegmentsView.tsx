import React from 'react';
import { motion } from 'motion/react';
import { Filter, Users, Plus, Target, ChevronRight, Zap } from 'lucide-react';
import { toDate } from '../../../../lib/firestoreUtils';

import { UserProfile } from '../../../../types';

interface SegmentsViewProps {
  users: UserProfile[];
}

export const SegmentsView: React.FC<SegmentsViewProps> = ({ users }) => {
  const mockSegments = [
    { id: '1', name: 'Clients VIP', description: 'Clients ayant effectué plus de 10 réservations.', count: users.filter(u => u.status === 'vip').length, activity: 'Élevée', color: 'amber' },
    { id: '2', name: 'Nouveaux Inscrits', description: 'Utilisateurs inscrits dans les 30 derniers jours.', count: users.filter(u => {
      const created = toDate(u.createdAt);
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return created > thirtyDaysAgo;
    }).length, activity: 'Moyenne', color: 'blue' },
    { id: '3', name: 'Inactifs (30j+)', description: 'Aucune activité sur la plateforme depuis un mois.', count: users.filter(u => u.status === 'inactive').length, activity: 'Basse', color: 'rose' },
    { id: '4', name: 'Fans de Nature', description: 'Clients ayant réservé majoritairement des circuits Nature.', count: users.filter(u => u.categoryPreferences?.includes('Nature')).length, activity: 'Très Élevée', color: 'emerald' },
  ];
  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div className="stagger-in">
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 italic">Marketing Segmentation</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Audiences Cibles</h2>
          <p className="text-[11px] md:text-sm text-stone-400 font-bold mt-2 md:mt-4 italic">Ciblez vos clients selon leurs comportements réels.</p>
        </div>
        <button className="w-full md:w-auto bg-stone-900 text-white px-8 py-4 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-stone-900/10 active:scale-95 transition-all flex items-center justify-center gap-2">
          <Plus size={14} strokeWidth={3} /> Nouveau Segment
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
        {mockSegments.map((segment) => (
          <motion.div 
            key={segment.id}
            whileHover={{ y: -5 }}
            className="group bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border border-stone-100 shadow-sahara space-y-6 md:space-y-8 cursor-pointer relative overflow-hidden transition-all"
          >
            <div className={`absolute top-0 right-0 w-24 h-24 md:w-32 md:h-32 rounded-bl-[4rem] md:rounded-bl-[5rem] -mr-8 -mt-8 transition-all group-hover:scale-110 opacity-10 ${
              segment.color === 'emerald' ? 'bg-emerald-500' :
              segment.color === 'blue' ? 'bg-indigo-500' :
              segment.color === 'rose' ? 'bg-rose-500' : 'bg-amber-500'
            }`} />
            
            <div className="relative z-10 flex justify-between items-start">
              <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center ${
                segment.color === 'emerald' ? 'bg-emerald-50 text-emerald-600' :
                segment.color === 'blue' ? 'bg-indigo-50 text-indigo-600' :
                segment.color === 'rose' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'
              }`}>
                <Target className="w-5 md:w-6 h-5 md:h-6" />
              </div>
              <div className="text-right">
                <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest leading-none mb-1 italic">POPULATION</p>
                <div className="flex items-center gap-1.5 justify-end">
                  <Users size={12} className="text-stone-300" />
                  <span className="text-lg md:text-xl font-black text-emerald-primary">{segment.count}</span>
                </div>
              </div>
            </div>

            <div className="relative z-10">
              <h3 className="text-lg md:text-xl font-black text-emerald-primary tracking-tight font-serif italic mb-1 md:mb-2">{segment.name}</h3>
              <p className="text-[10px] md:text-sm font-bold text-stone-400 italic leading-relaxed">{segment.description}</p>
            </div>

            <div className="relative z-10 pt-4 md:pt-6 border-t border-stone-50 flex justify-between items-center">
              <div className="flex items-center gap-2 md:gap-3">
                <div className={`w-2 h-2 rounded-full animate-pulse ${
                   segment.activity.includes('Élevée') ? 'bg-emerald-500' : 'bg-stone-300'
                }`} />
                <span className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest">{segment.activity}</span>
              </div>
              <button className="text-[8px] md:text-[10px] font-black text-emerald-primary uppercase tracking-widest flex items-center gap-2 group-hover:gap-4 transition-all">
                Gérer <ChevronRight size={12} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-stone-900 rounded-[2rem] md:rounded-[3.5rem] p-8 md:p-14 text-white relative overflow-hidden shadow-2xl">
         <Zap size={100} className="absolute -right-5 -bottom-5 text-white/5 md:text-white/10" />
         <div className="relative z-10 max-w-xl space-y-4 md:space-y-8">
           <h3 className="text-xl md:text-3xl font-serif italic font-black tracking-tight"><span className="text-emerald-accent">Conseil</span> CRM</h3>
           <p className="text-stone-400 text-xs md:text-base font-bold italic leading-relaxed">
             Les segments dynamiques s'ajustent en temps réel. Ciblez vos "Fans de Nature" avec des campagnes spécifiques pour augmenter vos conversions de 35%.
           </p>
           <button className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] bg-white/5 border border-white/10 hover:bg-white/10 px-8 py-4 rounded-xl md:rounded-2xl transition-all active:scale-95">
             Optimiser mon ciblage
           </button>
         </div>
      </div>
    </div>
  );
};

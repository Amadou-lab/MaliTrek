import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Filter, MoreHorizontal, User, Mail, Phone, MapPin, Calendar, Tag, ChevronRight, MessageSquare, History, Edit, Trash2 } from 'lucide-react';
import { toDate } from '../../../../lib/firestoreUtils';

import { UserProfile, Reservation } from '../../../../types';

interface ClientsViewProps {
  users: UserProfile[];
  reservations: Reservation[];
}

export const ClientsView: React.FC<ClientsViewProps> = ({ users, reservations }) => {
  const [selectedClient, setSelectedClient] = useState<UserProfile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const clients = users.filter(u => u.role === 'ROLE_CLIENT');
  const filteredClients = clients.filter(c => 
    c.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'VIP': return 'bg-amber-100 text-amber-600 border-amber-200';
      case 'Actif': return 'bg-emerald-100 text-emerald-600 border-emerald-200';
      case 'Inactif': return 'bg-stone-100 text-stone-400 border-stone-200';
      default: return 'bg-stone-50 text-stone-900 border-stone-100';
    }
  };

  return (
    <div className="space-y-6 md:space-y-10 relative">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 italic">User Management</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Gestion Clients</h2>
        </div>
        <button className="w-full md:w-auto bg-stone-900 text-white px-8 py-4 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-stone-900/10 active:scale-95 transition-all flex items-center justify-center gap-2">
          <User size={14} /> Ajouter
        </button>
      </header>

      {/* Filters Bar */}
      <div className="bg-white p-4 md:p-6 rounded-2xl md:rounded-[2rem] border border-stone-100 shadow-sahara flex flex-col md:flex-row gap-3 md:gap-4 items-stretch md:items-center">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-4 md:left-6 top-1/2 -translate-y-1/2 text-stone-300" />
          <input 
            type="text" 
            placeholder="Rechercher..." 
            className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-2xl pl-12 md:pl-16 pr-6 py-3.5 md:py-4 outline-none focus:ring-4 focus:ring-emerald-500/5 transition-all font-black text-xs md:text-sm text-emerald-primary"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <button className="px-6 py-3.5 md:py-4 bg-stone-50 border border-stone-100 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest text-stone-400 flex items-center justify-center gap-2 hover:bg-stone-100 transition-all shrink-0">
          <Filter size={14} /> Filtres
        </button>
      </div>

      {/* Mobile View: Cards */}
      <div className="grid grid-cols-1 md:hidden gap-4">
        <AnimatePresence>
          {filteredClients.map((client) => (
            <motion.div
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              key={client.uid}
              onClick={() => setSelectedClient(client)}
              className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sahara relative overflow-hidden"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-stone-50 rounded-xl flex items-center justify-center font-black text-stone-200 overflow-hidden ring-4 ring-stone-50">
                  {client.photoURL ? <img src={client.photoURL} alt="" className="w-full h-full object-cover" /> : client.displayName?.charAt(0) || 'U'}
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-black text-emerald-primary truncate leading-tight">{client.displayName}</h4>
                  <p className="text-[10px] font-black text-stone-300 truncate lowercase">{client.email}</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-stone-50">
                <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border ${getStatusColor(client.status || 'Actif')}`}>
                  {client.status || 'Actif'}
                </span>
                <div className="flex flex-col items-end">
                   <span className="text-[8px] font-black text-stone-300 uppercase tracking-widest">Réservations</span>
                   <span className="text-xs font-black text-emerald-primary">{client.totalBookings || 0}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Desktop View: Table */}
      <div className="hidden md:block bg-white rounded-[3rem] border border-stone-100 shadow-sahara overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-stone-50">
              <th className="px-10 py-6 text-[9px] font-black text-stone-300 uppercase tracking-widest italic">Client</th>
              <th className="px-10 py-6 text-[9px] font-black text-stone-300 uppercase tracking-widest italic">Statut</th>
              <th className="px-10 py-6 text-[9px] font-black text-stone-300 uppercase tracking-widest italic">Localisation</th>
              <th className="px-10 py-6 text-[9px] font-black text-stone-300 uppercase tracking-widest italic">Résas</th>
              <th className="px-10 py-6 text-[9px] font-black text-stone-300 uppercase tracking-widest italic">Inscription</th>
              <th className="px-10 py-6"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-50">
            {filteredClients.map((client) => (
              <tr 
                key={client.uid} 
                className="hover:bg-stone-50/50 cursor-pointer transition-all group"
                onClick={() => setSelectedClient(client)}
              >
                <td className="px-10 py-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center font-black text-stone-200 group-hover:scale-105 group-hover:ring-4 group-hover:ring-emerald-50 transition-all overflow-hidden shrink-0">
                      {client.photoURL ? <img src={client.photoURL} alt="" className="w-full h-full object-cover" /> : client.displayName?.charAt(0) || 'U'}
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="text-sm font-black text-emerald-primary truncate">{client.displayName}</span>
                      <span className="text-xs font-bold text-stone-300 truncate lowercase">{client.email}</span>
                    </div>
                  </div>
                </td>
                <td className="px-10 py-6">
                  <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.2em] border ${getStatusColor(client.status || 'Actif')}`}>
                    {client.status || 'Actif'}
                  </span>
                </td>
                <td className="px-10 py-6">
                  <div className="flex items-center gap-2 text-[10px] font-black text-stone-500 uppercase tracking-widest">
                    <MapPin size={12} className="text-stone-300" />
                    {client.location || 'BAMAKO'}
                  </div>
                </td>
                <td className="px-10 py-6">
                  <span className="text-sm font-black text-emerald-primary">{client.totalBookings || 0}</span>
                </td>
                <td className="px-10 py-6 text-[10px] font-black text-stone-300 italic">
                  {client.createdAt ? toDate(client.createdAt).toLocaleDateString() : '-'}
                </td>
                <td className="px-10 py-6 text-right">
                  <button className="p-2 text-stone-200 hover:text-emerald-primary transition-all">
                    <MoreHorizontal size={20} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Client Detail Drawer */}
      <AnimatePresence>
        {selectedClient && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-stone-900/40 backdrop-blur-md z-[200]"
              onClick={() => setSelectedClient(null)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed top-0 right-0 h-screen w-full md:w-[600px] bg-stone-50 shadow-2xl z-[210] p-6 md:p-12 overflow-y-auto no-scrollbar"
            >
              <div className="space-y-8 md:space-y-12 pb-20 md:pb-0">
                <header className="flex justify-between items-center">
                  <button 
                    onClick={() => setSelectedClient(null)}
                    className="p-3 bg-white shadow-sahara rounded-xl text-stone-400 hover:text-emerald-primary transition-all"
                  >
                    <ArrowLeft size={20} />
                  </button>
                  <div className="flex gap-3">
                    <button className="p-3 bg-white shadow-sahara rounded-xl text-stone-400 hover:text-emerald-primary transition-all"><Edit size={18}/></button>
                    <button className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-500 hover:bg-rose-100 transition-all"><Trash2 size={18}/></button>
                  </div>
                </header>

                <div className="flex flex-col items-center text-center space-y-4 md:space-y-6">
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-white rounded-[2rem] md:rounded-[2.5rem] flex items-center justify-center text-3xl md:text-4xl font-black text-stone-100 shadow-sahara overflow-hidden ring-4 ring-white">
                    {selectedClient.photoURL ? <img src={selectedClient.photoURL} alt="" className="w-full h-full object-cover" /> : selectedClient.displayName?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h3 className="text-2xl md:text-3xl font-serif font-black text-emerald-primary tracking-tight leading-none mb-3 italic">{selectedClient.displayName}</h3>
                    <span className={`px-4 py-1.5 rounded-full text-[8px] md:text-[9px] font-black uppercase tracking-[0.2em] border ${getStatusColor(selectedClient.status || 'Actif')}`}>
                      {selectedClient.status || 'Actif'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                   <div className="bg-white p-5 md:p-6 rounded-2xl md:rounded-3xl space-y-1 border border-stone-100 shadow-sahara">
                     <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest leading-none mb-1 italic">Email</p>
                     <p className="text-xs md:text-sm font-black text-emerald-primary truncate">{selectedClient.email}</p>
                   </div>
                   <div className="bg-white p-5 md:p-6 rounded-2xl md:rounded-3xl space-y-1 border border-stone-100 shadow-sahara">
                     <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest leading-none mb-1 italic">Téléphone</p>
                     <p className="text-xs md:text-sm font-black text-emerald-primary">{selectedClient.phone || 'N/A'}</p>
                   </div>
                </div>

                <div className="space-y-4 md:space-y-6">
                  <h4 className="text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] ml-2 italic">Segmentation</h4>
                  <div className="flex flex-wrap gap-2 md:gap-3">
                    {selectedClient.tags?.map((tag: string) => (
                      <span key={tag} className="px-4 py-2 bg-stone-900 text-white text-[9px] font-black uppercase tracking-widest rounded-xl flex items-center gap-2 shadow-lg shadow-stone-900/10">
                        <Tag size={12} fill="currentColor" /> {tag}
                      </span>
                    ))}
                    {!selectedClient.tags?.length && <span className="text-[10px] text-stone-300 font-bold uppercase italic ml-2">Aucun tag</span>}
                    <button className="px-4 py-2 border-2 border-dashed border-stone-200 text-stone-300 hover:border-emerald-primary hover:text-emerald-primary rounded-xl transition-all">
                      <Plus size={12} />
                    </button>
                  </div>
                </div>

                <div className="space-y-6 md:space-y-8">
                  <div className="flex justify-between items-center px-2">
                    <h4 className="text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] italic">Historique</h4>
                    <button className="text-[8px] font-black text-emerald-accent uppercase tracking-widest border-b border-emerald-accent italic">Tout voir</button>
                  </div>
                  <div className="space-y-3 md:space-y-4">
                    {reservations.filter(r => r.userId === selectedClient.uid).map((res, i) => (
                      <div key={i} className="flex items-center justify-between p-5 md:p-6 bg-white rounded-2xl md:rounded-3xl border border-stone-100 shadow-sahara group">
                        <div className="flex items-center gap-4 min-w-0">
                           <div className="w-10 h-10 bg-stone-50 rounded-xl flex items-center justify-center text-stone-300 shrink-0 group-hover:bg-emerald-50 group-hover:text-emerald-primary transition-colors">
                             <Calendar size={14} />
                           </div>
                           <div className="flex flex-col min-w-0">
                             <span className="text-[10px] md:text-xs font-black text-emerald-primary truncate uppercase tracking-tighter italic">Réservation {res.status}</span>
                             <span className="text-[8px] md:text-[10px] font-black text-stone-300 italic">{res.createdAt ? toDate(res.createdAt).toLocaleDateString() : 'N/A'}</span>
                           </div>
                        </div>
                        <span className="text-[10px] md:text-sm font-black text-emerald-primary shrink-0 ml-2">{(res.totalPaid || 0).toLocaleString()} <span className="text-[8px] uppercase text-stone-300">CFA</span></span>
                      </div>
                    ))}
                    {!reservations.filter(r => r.userId === selectedClient.uid).length && (
                      <div className="p-8 md:p-10 bg-white border-2 border-dashed border-stone-100 rounded-3xl text-center shadow-inner">
                        <p className="text-[10px] text-stone-300 font-bold uppercase tracking-widest italic">Aucun voyage répertorié</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4 md:pt-6">
                  <button className="w-full bg-emerald-primary text-white py-5 md:py-6 rounded-2xl md:rounded-3xl font-black uppercase tracking-[0.2em] text-[10px] md:text-xs shadow-2xl shadow-emerald-primary/20 active:scale-95 transition-all">
                    Envoyer un message
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

const Plus = ({ size }: { size: number }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
const Star = ({ size }: { size: number }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
const ArrowLeft = ({ size }: { size: number }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>

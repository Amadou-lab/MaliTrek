import React from 'react';
import { motion } from 'motion/react';
import { FileText, Plus, Copy, Trash2, Edit, Save, Bell, Sparkles, Filter } from 'lucide-react';

const mockTemplates = [
  { id: '1', name: 'Nouveau Circuit Validé', type: 'Promotion', message: "Bonne nouvelle ! Un nouveau circuit vient d'être validé. Découvrez {circuit_name} maintenant !", category: 'Système' },
  { id: '2', name: 'Offre Spéciale - Pays Dogon', type: 'Réduction', message: "Promotion exclusive : -20% sur tous les circuits au Pays Dogon ce week-end ! Profitez-en.", category: 'Marketing' },
  { id: '3', name: 'Expérience Recommandée', type: 'Curated', message: "Selon vos préférences, vous allez adorer {circuit_name}. Réservez votre place !", category: 'Recommandation' },
  { id: '4', name: 'Relance Panier Abandonné', type: 'Reminder', message: "Votre aventure vous attend toujours. Finalisez votre réservation pour {circuit_name}.", category: 'Relance' },
];

export const TemplatesView: React.FC = () => {
  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 stagger-in">
        <div>
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 italic">Content Management</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Modèles Messages</h2>
          <p className="text-[10px] md:text-sm text-stone-400 font-bold mt-2 md:mt-4 italic">Gagnez en efficacité avec des templates pré-enregistrés.</p>
        </div>
        <button className="w-full md:w-auto bg-stone-900 text-white px-8 py-4 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-stone-900/10 active:scale-95 transition-all flex items-center justify-center gap-2">
            <Plus size={14} strokeWidth={3} /> Nouveau Template
        </button>
      </header>

      {/* Grid of Templates */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white border-2 border-dashed border-stone-100 rounded-[2rem] md:rounded-[3rem] aspect-square flex flex-col items-center justify-center p-8 md:p-10 group cursor-pointer hover:border-emerald-primary transition-all shadow-sahara"
        >
          <div className="w-16 h-16 md:w-20 md:h-20 bg-stone-50 rounded-2xl md:rounded-[2rem] flex items-center justify-center text-stone-200 group-hover:text-emerald-primary group-hover:scale-105 group-hover:rotate-6 transition-all mb-4 md:mb-6">
            <Plus className="w-7 md:w-8 h-7 md:h-8" />
          </div>
          <span className="text-[10px] font-black text-stone-300 group-hover:text-emerald-primary uppercase tracking-[0.2em] italic">Créer un modèle</span>
        </motion.div>

        {mockTemplates.map((template) => (
          <motion.div 
            key={template.id}
            whileHover={{ y: -5 }}
            className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border border-stone-100 shadow-sahara flex flex-col justify-between group transition-all"
          >
            <div className="space-y-6">
              <div className="flex justify-between items-start">
                 <div className="w-10 h-10 md:w-14 md:h-14 bg-stone-50 text-stone-300 rounded-xl md:rounded-2xl flex items-center justify-center group-hover:bg-emerald-primary group-hover:text-white group-hover:-rotate-6 transition-all duration-500 shrink-0">
                   <Bell className="w-5 md:w-6 h-5 md:h-6" />
                 </div>
                 <div className="flex gap-1">
                   <button className="p-2 md:p-3 text-stone-200 hover:text-emerald-primary transition-all"><Copy size={14} /></button>
                   <button className="p-2 md:p-3 text-stone-200 hover:text-emerald-primary transition-all"><Edit size={14} /></button>
                   <button className="p-2 md:p-3 text-rose-100 hover:text-rose-500 transition-all"><Trash2 size={14} /></button>
                 </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg md:text-xl font-serif font-black text-emerald-primary tracking-tight leading-tight italic truncate">{template.name}</h3>
                <span className="inline-block px-3 py-1 bg-emerald-50 text-emerald-primary text-[8px] font-black uppercase tracking-widest rounded-full">{template.category}</span>
              </div>

              <div className="bg-stone-50/50 p-4 md:p-6 rounded-2xl italic border border-stone-100/50">
                 <p className="text-[10px] md:text-xs text-stone-400 font-bold leading-relaxed">"{template.message}"</p>
              </div>
            </div>

            <div className="pt-6 md:pt-8 border-t border-stone-50 mt-6 md:mt-8 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Sparkles size={12} className="text-emerald-accent" />
                <span className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-300 italic">Optimisé Marketing</span>
              </div>
              <button className="text-[9px] md:text-[10px] font-black uppercase tracking-widest text-emerald-primary hover:bg-emerald-primary hover:text-white px-3 py-1.5 rounded-lg transition-all italic">Utiliser</button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

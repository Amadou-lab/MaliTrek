import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, Send, ImageIcon, Target, Calendar, Clock, ChevronRight, BarChart3, Clock3, Layout, Smartphone, CheckCircle2, Zap, Sparkles } from 'lucide-react';
import toast from 'react-hot-toast';

export const NotificationsView: React.FC = () => {
  const [step, setStep] = useState(1);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [segment, setSegment] = useState('all');
  const [scheduling, setScheduling] = useState('now');

  const handleSend = () => {
    const loadingToast = toast.loading('Envoi de la notification...');
    setTimeout(() => {
      toast.success('Notification programmée avec succès !', { id: loadingToast });
      setStep(1);
      setTitle('');
      setMessage('');
    }, 1500);
  };

  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <header className="stagger-in">
        <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 italic">Push Notifications</p>
        <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Campagnes Push</h2>
        <p className="text-[10px] md:text-sm text-stone-400 font-bold mt-2 md:mt-4 italic">Créez et diffusez des messages impactants.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Creation Form */}
        <div className="lg:col-span-2 space-y-6 md:space-y-8">
          <div className="bg-white rounded-2xl md:rounded-[4rem] border border-stone-100 shadow-sahara overflow-hidden flex flex-col">
            {/* Step Indicator */}
            <div className="bg-stone-50 border-b border-stone-100 px-6 md:px-12 py-5 md:py-8 flex justify-between md:justify-start md:gap-12 items-center">
              {[
                { id: 1, label: 'Message' },
                { id: 2, label: 'Public' },
                { id: 3, label: 'Envoi' }
              ].map((s) => (
                <div key={s.id} className="flex items-center gap-2 md:gap-3">
                  <div className={`w-8 h-8 rounded-lg md:rounded-xl flex items-center justify-center text-[10px] font-black transition-all ${
                    step >= s.id ? 'bg-emerald-primary text-white scale-110 shadow-lg shadow-emerald-primary/20' : 'bg-stone-100 text-stone-300'
                  }`}>
                    {s.id}
                  </div>
                  <span className={`hidden md:block text-[9px] font-black uppercase tracking-widest ${
                    step >= s.id ? 'text-emerald-primary' : 'text-stone-300'
                  }`}>{s.label}</span>
                </div>
              ))}
            </div>

            <div className="p-6 md:p-14 min-h-[300px]">
              <AnimatePresence mode="wait">
                {step === 1 && (
                  <motion.div 
                    key="msg" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="space-y-6 md:space-y-8"
                  >
                    <div className="space-y-2 md:space-y-3">
                      <label className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] ml-2 italic">Titre Accrocheur</label>
                      <input 
                        type="text"
                        value={title}
                        onChange={e => setTitle(e.target.value)}
                        placeholder="ex: Le Pays Dogon vous attend !"
                        className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl md:rounded-2xl px-6 md:px-8 py-4 md:py-6 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-primary outline-none font-black text-emerald-primary transition-all text-base md:text-xl placeholder:text-stone-200"
                      />
                    </div>
                    <div className="space-y-2 md:space-y-3">
                      <label className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] ml-2 italic">Message Principal</label>
                      <textarea 
                        rows={4}
                        value={message}
                        onChange={e => setMessage(e.target.value)}
                        placeholder="Décrivez l'offre ou l'invitation..."
                        className="w-full bg-stone-50 border-2 border-stone-100 rounded-2xl md:rounded-[2.5rem] px-6 md:px-8 py-4 md:py-6 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-primary outline-none font-bold text-stone-600 transition-all resize-none placeholder:text-stone-200 text-sm md:text-base leading-relaxed"
                      />
                    </div>
                    <div className="space-y-2 md:space-y-3">
                      <label className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] ml-2 italic">Média (URL)</label>
                      <div className="relative">
                        <ImageIcon size={18} className="absolute left-6 top-1/2 -translate-y-1/2 text-stone-200" />
                        <input 
                          type="text"
                          placeholder="https://images.unsplash..."
                          className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl md:rounded-2xl pl-16 pr-8 py-4 md:py-6 focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-primary outline-none font-black text-xs md:text-sm text-emerald-primary transition-all placeholder:text-stone-200"
                        />
                      </div>
                    </div>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div 
                    key="target" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="space-y-6 md:space-y-10"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                      {[
                        { id: 'all', label: 'Tout le Public', desc: '1,284 utilisateurs actifs', icon: <Target size={20} /> },
                        { id: 'vip', label: 'Cercle VIP', desc: '42 explorateurs premium', icon: <Zap size={20} className="text-amber-500" /> },
                        { id: 'new', label: 'Nouveaux Visages', desc: '128 inscrits récents', icon: <Bell size={20} className="text-blue-500" /> },
                        { id: 'inactive', label: 'Réengagement', desc: '350 inactifs (30j+)', icon: <Clock size={20} className="text-rose-500" /> }
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => setSegment(item.id)}
                          className={`flex items-center md:items-start md:flex-col gap-4 p-5 md:p-8 rounded-2xl md:rounded-[2.5rem] border-2 transition-all text-left ${
                            segment === item.id ? 'bg-stone-900 border-stone-900 text-white shadow-2xl md:scale-105' : 'bg-stone-50 border-stone-100 text-stone-300 hover:bg-stone-100 group'
                          }`}
                        >
                          <div className={`p-3 md:p-4 rounded-xl shrink-0 ${segment === item.id ? 'bg-white/10' : 'bg-white shadow-sm ring-4 ring-stone-100 group-hover:ring-emerald-50'}`}>{item.icon}</div>
                          <div className="min-w-0">
                            <p className="font-black text-xs md:text-sm uppercase tracking-tight truncate italic">{item.label}</p>
                            <p className={`text-[8px] md:text-[10px] font-bold italic truncate ${segment === item.id ? 'text-stone-400' : 'text-stone-300'}`}>{item.desc}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {step === 3 && (
                  <motion.div 
                    key="sched" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="space-y-6 md:space-y-10"
                  >
                    <div className="space-y-4 md:space-y-6">
                      <button 
                        onClick={() => setScheduling('now')}
                        className={`w-full flex items-center justify-between p-6 md:p-10 rounded-2xl md:rounded-[3rem] border-2 transition-all ${
                          scheduling === 'now' ? 'bg-emerald-50 border-emerald-primary ring-8 ring-emerald-primary/5' : 'bg-stone-50 border-stone-100'
                        }`}
                      >
                         <div className="flex items-center gap-4 md:gap-8 text-left">
                           <div className={`p-4 md:p-5 rounded-xl md:rounded-2xl ${scheduling === 'now' ? 'bg-emerald-primary text-white shadow-lg shadow-emerald-primary/20' : 'bg-white text-stone-300 shadow-sm'}`}>
                             <Send size={24} />
                           </div>
                           <div>
                             <p className="text-sm md:text-lg font-black text-emerald-primary italic leading-none mb-1 md:mb-2">Diffusion instantanée</p>
                             <p className="text-[10px] md:text-xs font-bold text-stone-300 italic">Envoi direct sur tous les points de contact.</p>
                           </div>
                         </div>
                         {scheduling === 'now' && <CheckCircle2 className="text-emerald-primary shrink-0" />}
                      </button>

                      <button 
                        onClick={() => setScheduling('later')}
                        className={`w-full flex items-center justify-between p-6 md:p-10 rounded-2xl md:rounded-[3rem] border-2 transition-all ${
                          scheduling === 'later' ? 'bg-amber-50 border-amber-primary ring-8 ring-amber-primary/5' : 'bg-stone-50 border-stone-100'
                        }`}
                      >
                         <div className="flex items-center gap-4 md:gap-8 text-left">
                           <div className={`p-4 md:p-5 rounded-xl md:rounded-2xl ${scheduling === 'later' ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20' : 'bg-white text-stone-300 shadow-sm'}`}>
                             <Calendar size={24} />
                           </div>
                           <div>
                             <p className="text-sm md:text-lg font-black text-emerald-primary italic leading-none mb-1 md:mb-2">Programmation temporelle</p>
                             <p className="text-[10px] md:text-xs font-bold text-stone-300 italic tracking-tight leading-tight">Choisissez le moment optimal pour votre cible.</p>
                           </div>
                         </div>
                         {scheduling === 'later' && <CheckCircle2 className="text-amber-500 shrink-0" />}
                      </button>
                    </div>

                    {scheduling === 'later' && (
                      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                        <div className="bg-white p-5 md:p-6 rounded-xl md:rounded-2xl border border-stone-100 shadow-sahara flex items-center gap-4 group focus-within:ring-4 focus-within:ring-emerald-50 transition-all">
                          <Calendar size={18} className="text-stone-300 group-focus-within:text-emerald-primary" />
                          <input type="date" className="bg-transparent outline-none font-black text-xs md:text-sm text-emerald-primary w-full" />
                        </div>
                        <div className="bg-white p-5 md:p-6 rounded-xl md:rounded-2xl border border-stone-100 shadow-sahara flex items-center gap-4 group focus-within:ring-4 focus-within:ring-emerald-50 transition-all">
                          <Clock3 size={18} className="text-stone-300 group-focus-within:text-emerald-primary" />
                          <input type="time" className="bg-transparent outline-none font-black text-xs md:text-sm text-emerald-primary w-full" />
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <footer className="bg-stone-50 border-t border-stone-100 px-6 md:px-14 py-6 md:py-10 flex justify-between items-center">
              <button 
                onClick={() => setStep(v => Math.max(1, v - 1))}
                className="text-[9px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest hover:text-emerald-primary transition-colors italic"
              >
                {step === 1 ? 'Annuler' : 'Précédent'}
              </button>
              <div className="flex gap-4">
                {step < 3 ? (
                  <button 
                    onClick={() => setStep(v => v + 1)}
                    className="bg-stone-900 text-white px-8 md:px-12 py-4 md:py-6 rounded-xl md:rounded-3xl font-black uppercase tracking-[0.2em] text-[9px] md:text-xs shadow-2xl shadow-stone-900/10 active:scale-95 transition-all flex items-center gap-3"
                  >
                    Ciblage <ChevronRight size={14} />
                  </button>
                ) : (
                  <button 
                    onClick={handleSend}
                    className="bg-emerald-primary text-white px-8 md:px-12 py-4 md:py-6 rounded-xl md:rounded-3xl font-black uppercase tracking-[0.2em] text-[9px] md:text-xs shadow-2xl shadow-emerald-primary/20 active:scale-95 transition-all flex items-center gap-3"
                  >
                    Diffuser <CheckCircle2 size={14} />
                  </button>
                )}
              </div>
            </footer>
          </div>
        </div>

        {/* Live Preview */}
        <div className="space-y-6 md:space-y-8">
          <div className="flex justify-between items-center px-4">
             <h3 className="text-[10px] font-black text-stone-300 uppercase tracking-[0.3em] italic">Live Design</h3>
             <span className="flex items-center gap-2 text-[8px] font-black text-emerald-accent uppercase tracking-widest bg-emerald-50 px-2 py-1 rounded-full border border-emerald-primary/10">App Preview</span>
          </div>
          
          <div className="relative w-full max-w-[280px] md:max-w-[320px] mx-auto aspect-[9/19] bg-stone-950 rounded-[2.5rem] md:rounded-[3.5rem] p-3 md:p-4 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border-[8px] border-stone-900 flex flex-col items-center">
             <div className="w-24 h-6 bg-stone-900 rounded-b-2xl absolute top-0 z-10"></div>
             
             {/* Notification Card */}
             <div className="mt-16 md:mt-20 w-full relative z-20 px-1 md:px-0">
               <motion.div 
                 key={title + message}
                 initial={{ y: 20, opacity: 0, scale: 0.9 }}
                 animate={{ y: 0, opacity: 1, scale: 1 }}
                 className="bg-white/90 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/50"
               >
                 <div className="flex justify-between items-start mb-2">
                   <div className="flex items-center gap-2">
                     <div className="w-5 h-5 bg-stone-900 rounded-lg flex items-center justify-center shadow-lg">
                       <Layout size={10} className="text-emerald-primary" />
                     </div>
                     <span className="text-[8px] md:text-[10px] font-black text-stone-900 uppercase tracking-tighter italic">MaliTrek</span>
                   </div>
                   <span className="text-[7px] font-black text-stone-300 uppercase italic">MTN-4G</span>
                 </div>
                 <h4 className="text-[10px] md:text-xs font-black text-emerald-primary mb-1 italic leading-tight">{title || 'Votre titre ici...'}</h4>
                 <p className="text-[8px] md:text-[10px] font-bold text-stone-400 leading-tight italic line-clamp-2">{message || 'Le corps de votre message apparaîtra ici pour tester la lisibilité.'}</p>
                 <div className="mt-3 flex justify-end">
                   <div className="bg-emerald-primary text-[7px] font-black text-white uppercase tracking-widest px-3 py-1 rounded-full shadow-lg shadow-emerald-primary/20">Explorer</div>
                 </div>
               </motion.div>
             </div>

             <div className="mt-auto mb-4 w-24 md:w-32 h-1 bg-white/10 rounded-full"></div>
          </div>
          
          <div className="bg-white p-5 md:p-8 rounded-2xl md:rounded-[3rem] border border-stone-100 shadow-sahara space-y-3 md:space-y-4">
            <div className="flex items-center gap-2 text-emerald-accent">
               <Sparkles size={14} />
               <h4 className="text-[8px] md:text-[10px] font-black uppercase tracking-widest italic">Analyse Prédictive</h4>
            </div>
            <p className="text-[9px] md:text-[10px] font-bold text-stone-400 italic italic leading-relaxed">
              "L'utilisation d'émojis dans vos notifications augmente le taux d'ouverture moyen de <span className="text-emerald-primary">24.5%</span> sur le réseau Malien."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

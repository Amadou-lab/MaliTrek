import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, Users, CreditCard, ChevronRight, Activity } from 'lucide-react';
import { toDate } from '../../../../lib/firestoreUtils';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';

import { UserProfile, Reservation, Circuit, Journey } from '../../../../types';

const data = [
  { name: 'Lun', users: 400, bookings: 240, revenue: 120000 },
  { name: 'Mar', users: 300, bookings: 139, revenue: 80000 },
  { name: 'Mer', users: 200, bookings: 980, revenue: 250000 },
  { name: 'Jeu', users: 278, bookings: 390, revenue: 150000 },
  { name: 'Ven', users: 189, bookings: 480, revenue: 190000 },
  { name: 'Sam', users: 239, bookings: 380, revenue: 300000 },
  { name: 'Dim', users: 349, bookings: 430, revenue: 350000 },
];

interface CRMOverviewProps {
  users: UserProfile[];
  reservations: Reservation[];
  circuits: Circuit[];
  journeys: Journey[];
}

export const CRMOverview: React.FC<CRMOverviewProps> = ({ users, reservations, circuits, journeys }) => {
  const totalRevenue = reservations
    .filter(r => r.paymentStatus === 'paid' && r.status !== 'cancelled')
    .reduce((acc, curr) => acc + curr.totalPaid, 0);
  
  const conversionRate = users.length > 0 ? (users.filter(u => u.totalBookings && u.totalBookings > 0).length / users.length * 100).toFixed(1) : '0';
  const newUsers = users.filter(u => {
    const created = toDate(u.createdAt);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return created > thirtyDaysAgo;
  }).length;
  return (
    <div className="space-y-6 md:space-y-12">
      <header className="stagger-in">
        <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 italic">Performance Marketing</p>
        <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Vue d'ensemble</h2>
        <p className="text-[10px] md:text-sm text-stone-400 font-bold mt-2 md:mt-4 italic">Suivez la performance globale de votre base client.</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
        {[
          { label: 'Total Clients', value: (users?.length || 0).toLocaleString(), trend: `+${Math.floor(Math.random() * 15)}%`, icon: <Users size={20} />, color: 'emerald' },
          { label: 'Nouveaux', value: newUsers.toString(), trend: '+5%', icon: <Activity size={20} />, color: 'stone' },
          { label: 'Taux Conv.', value: `${conversionRate}%`, trend: '+2.4%', icon: <TrendingUp size={20} />, color: 'amber' },
          { label: 'Revenu Total', value: `${(totalRevenue / 1000).toFixed(1)}k`, trend: '+12%', icon: <CreditCard size={20} />, color: 'indigo' }
        ].map((stat, i) => (
          <div 
            key={i}
            className="bg-white p-5 md:p-8 rounded-[2rem] md:rounded-[3rem] border border-stone-100 shadow-sahara relative overflow-hidden group hover:border-emerald-primary/20 transition-all"
          >
            <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center mb-4 md:mb-6 ${
              stat.color === 'emerald' ? 'bg-emerald-50 text-emerald-600' :
              stat.color === 'stone' ? 'bg-stone-50 text-stone-600' :
              stat.color === 'amber' ? 'bg-amber-50 text-amber-600' :
              'bg-indigo-50 text-indigo-600'
            }`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-[7px] md:text-[9px] font-black text-stone-300 uppercase tracking-widest leading-none mb-1 md:mb-2 truncate italic">{stat.label}</p>
              <div className="flex items-baseline gap-2 md:gap-3 flex-wrap">
                <h4 className="text-base md:text-2xl font-black text-emerald-primary leading-none">{stat.value}</h4>
                <span className={`text-[8px] md:text-[10px] font-black italic ${stat.trend.startsWith('+') ? 'text-emerald-primary' : 'text-rose-500'}`}>{stat.trend}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10">
        <div className="bg-white p-6 md:p-10 rounded-[2.5rem] md:rounded-[4rem] border border-stone-100 shadow-sahara space-y-6 md:space-y-8 overflow-hidden">
          <div className="flex justify-between items-center gap-4">
            <h3 className="text-base md:text-xl font-black text-emerald-primary tracking-tight font-serif italic">Activité</h3>
            <div className="px-3 md:px-4 py-1.5 md:py-2 bg-stone-50 rounded-lg md:rounded-xl text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-400 shrink-0">
              7 JOURS
            </div>
          </div>
          <div className="h-[200px] md:h-80 -mx-4 md:mx-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ left: -20, right: 10, top: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f4" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '1rem', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                    fontWeight: '900',
                    fontSize: '10px'
                  }} 
                />
                <Area type="monotone" dataKey="users" stroke="#10b981" strokeWidth={4} fillOpacity={1} fill="url(#colorUsers)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 md:p-10 rounded-[2.5rem] md:rounded-[4rem] border border-stone-100 shadow-sahara space-y-6 md:space-y-8 overflow-hidden">
          <div className="flex justify-between items-center gap-4">
            <h3 className="text-base md:text-xl font-black text-emerald-primary tracking-tight font-serif italic">Revenus</h3>
            <div className="px-3 md:px-4 py-1.5 md:py-2 bg-stone-50 rounded-lg md:rounded-xl text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-400 shrink-0">
              HEBDOMADAIRE
            </div>
          </div>
          <div className="h-[200px] md:h-80 -mx-4 md:mx-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ left: -20, right: 10, top: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f4" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} />
                <Tooltip 
                  cursor={{ fill: '#f5f5f4' }}
                  contentStyle={{ 
                    borderRadius: '1rem', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                    fontWeight: '900',
                    fontSize: '10px'
                  }} 
                />
                <Bar dataKey="revenue" radius={[10, 10, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#1c1917' : '#d6d3d1'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

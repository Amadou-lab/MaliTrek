import React from 'react';
import { motion } from 'motion/react';
import { BarChart3, TrendingUp, MousePointer2, Eye, Target, ArrowUpRight, ArrowDownRight, Smartphone, Mail, Bell } from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  Cell,
  PieChart,
  Pie
} from 'recharts';

const data = [
  { name: 'Jan', sent: 1200, opened: 800, clicked: 450 },
  { name: 'Fév', sent: 2100, opened: 1400, clicked: 720 },
  { name: 'Mar', sent: 1800, opened: 1200, clicked: 680 },
  { name: 'Avr', sent: 2400, opened: 1900, clicked: 1100 },
];

const pieData = [
  { name: 'Taux Ouverture', value: 72, color: '#10b981' },
  { name: 'Rebond', value: 28, color: '#f87171' },
];

export const AnalyticsView: React.FC = () => {
  return (
    <div className="space-y-6 md:space-y-12 pb-20">
      <header className="stagger-in">
        <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 italic">Campaign Analytics</p>
        <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Performance Marketing</h2>
        <p className="text-[10px] md:text-sm text-stone-400 font-bold mt-2 md:mt-4 italic">Analysez l'impact réel de vos communications.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8">
        {[
          { label: 'Total Diffusions', value: '7.5k', change: '+24%', up: true, icon: <Smartphone size={20}/> },
          { label: 'Taux Ouverture', value: '72%', change: '+5%', up: true, icon: <Eye size={20}/> },
          { label: 'Taux de Clic', value: '18.4%', change: '-2%', up: false, icon: <MousePointer2 size={20}/> }
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 md:p-8 rounded-2xl md:rounded-[3rem] border border-stone-100 shadow-sahara group transition-all hover:border-emerald-primary/10">
            <div className="flex items-center md:items-start justify-between md:flex-col gap-4">
               <div className="w-10 h-10 md:w-14 md:h-14 bg-stone-50 text-stone-300 rounded-xl md:rounded-[1.5rem] flex items-center justify-center group-hover:bg-emerald-primary group-hover:text-white group-hover:rotate-6 transition-all duration-500 shrink-0">
                 {stat.icon}
               </div>
               <div className="flex-1 md:mt-2">
                  <p className="text-[8px] md:text-[10px] font-black text-stone-300 uppercase tracking-widest leading-none mb-1 md:mb-2 truncate italic">{stat.label}</p>
                  <div className="flex items-baseline gap-2 md:gap-3 flex-wrap">
                    <h4 className="text-xl md:text-3xl font-black text-emerald-primary">{stat.value}</h4>
                    <span className={`text-[8px] md:text-[10px] font-black italic flex items-center gap-1 ${stat.up ? 'text-emerald-primary' : 'text-rose-500'}`}>
                      {stat.up ? <ArrowUpRight size={10}/> : <ArrowDownRight size={10}/>} {stat.change}
                    </span>
                  </div>
               </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10">
         <div className="bg-white p-6 md:p-10 rounded-2xl md:rounded-[4rem] border border-stone-100 shadow-sahara space-y-6 md:space-y-10 overflow-hidden">
            <div className="flex justify-between items-center gap-4">
               <h3 className="text-base md:text-xl font-black text-emerald-primary tracking-tight font-serif italic">Tunnel de Conversion</h3>
               <div className="px-3 md:px-4 py-1.5 md:py-2 bg-stone-50 rounded-lg md:rounded-xl text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-400 shrink-0">
                  MARS 2024
               </div>
            </div>
            <div className="h-[200px] md:h-80 -mx-4 md:mx-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} margin={{ left: -20, right: 10, top: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f4" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} />
                  <Tooltip cursor={{ fill: '#f5f5f4' }} contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px', fontWeight: '900' }} />
                  <Bar dataKey="sent" stackId="a" fill="#f5f5f4" />
                  <Bar dataKey="opened" stackId="a" fill="#1c1917" />
                  <Bar dataKey="clicked" stackId="a" fill="#10b981" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-4 md:gap-8 border-t border-stone-50 pt-6 md:pt-10">
              <div className="flex items-center gap-2 italic">
                <div className="w-2.5 h-2.5 rounded-full bg-stone-100 ring-2 ring-stone-50"></div> 
                <span className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-300">Envoyés</span>
              </div>
              <div className="flex items-center gap-2 italic">
                <div className="w-2.5 h-2.5 rounded-full bg-stone-900 ring-2 ring-stone-50"></div> 
                <span className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-300">Ouverts</span>
              </div>
              <div className="flex items-center gap-2 italic">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-primary ring-2 ring-emerald-50"></div> 
                <span className="text-[8px] md:text-[9px] font-black uppercase tracking-widest text-stone-300">Cliqués</span>
              </div>
            </div>
         </div>

         <div className="bg-stone-900 p-6 md:p-14 rounded-2xl md:rounded-[4.5rem] text-white shadow-2xl relative overflow-hidden space-y-8 md:space-y-12">
            <Target size={120} className="absolute -right-8 -bottom-8 text-white/[0.03] rotate-12" />
            <h3 className="text-base md:text-2xl font-serif italic font-black tracking-tight text-white/90">Segmentation Canaux</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
              <div className="h-48 md:h-64 -mx-6 md:mx-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Push', value: 65 },
                        { name: 'Email', value: 25 },
                        { name: 'SMS', value: 10 }
                      ]}
                      innerRadius="65%"
                      outerRadius="90%"
                      paddingAngle={8}
                      dataKey="value"
                      stroke="none"
                    >
                      {[0,1,2].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={['#10b981', '#3b82f6', '#f59e0b'][index]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '1rem', border: 'none', color: '#000', fontSize: '10px', fontWeight: '900' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-5 md:space-y-8">
                {[
                  { label: 'Notifications', value: '65%', icon: <Bell size={12}/>, color: 'emerald' },
                  { label: 'E-mails', value: '25%', icon: <Mail size={12}/>, color: 'blue' },
                  { label: 'SMS Alerts', value: '10%', icon: <Smartphone size={12}/>, color: 'amber' }
                ].map((item, i) => (
                  <div key={i} className="flex flex-col gap-2 group">
                    <div className="flex justify-between items-center px-1">
                       <span className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-stone-500 group-hover:text-white transition-colors">{item.icon} {item.label}</span>
                       <span className="text-xs md:text-sm font-black italic">{item.value}</span>
                    </div>
                    <div className="h-1 md:h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                       <motion.div 
                         initial={{ width: 0 }} 
                         animate={{ width: item.value }} 
                         className={`h-full shadow-[0_0_15px_rgba(16,185,129,0.3)] ${
                           item.color === 'emerald' ? 'bg-emerald-500' :
                           item.color === 'blue' ? 'bg-blue-500' : 'bg-amber-500'
                         }`} 
                       />
                    </div>
                  </div>
                ))}
              </div>
            </div>
         </div>
      </div>
    </div>
  );
};

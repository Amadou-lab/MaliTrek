import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Bell, 
  Zap, 
  BarChart3, 
  LayoutDashboard, 
  Search, 
  ArrowLeft,
  Settings,
  Filter,
  FileText
} from 'lucide-react';
import { CRMOverview } from './Views/CRMOverview';
import { ClientsView } from './Views/ClientsView';
import { SegmentsView } from './Views/SegmentsView';
import { NotificationsView } from './Views/NotificationsView';
import { AutomationView } from './Views/AutomationView';
import { AnalyticsView } from './Views/AnalyticsView';
import { TemplatesView } from './Views/TemplatesView';

import { UserProfile, Reservation, Circuit, Journey } from '../../../types';

type CRMSubView = 'dashboard' | 'clients' | 'segments' | 'notifications' | 'automation' | 'analytics' | 'templates';

interface CRMMainProps {
  users: UserProfile[];
  reservations: Reservation[];
  circuits: Circuit[];
  journeys: Journey[];
}

export const CRMMain: React.FC<CRMMainProps> = ({ users, reservations, circuits, journeys }) => {
  const [activeSubView, setActiveSubView] = useState<CRMSubView>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');

  const menuItems: { id: CRMSubView; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { id: 'clients', label: 'Clients', icon: <Users size={18} /> },
    { id: 'segments', label: 'Segments', icon: <Filter size={18} /> },
    { id: 'notifications', label: 'Push', icon: <Bell size={18} /> },
    { id: 'automation', label: 'Auto', icon: <Zap size={18} /> },
    { id: 'templates', label: 'Mail', icon: <FileText size={18} /> },
    { id: 'analytics', label: 'Perf', icon: <BarChart3 size={18} /> },
  ];

  return (
    <div className="flex flex-col lg:flex-row bg-stone-50 min-h-screen">
      {/* CRM Sub Navigation - Desktop Sidebar / Mobile Horizontal Scroll */}
      <div className="w-full lg:w-72 bg-white border-b lg:border-b-0 lg:border-r border-stone-100 p-4 lg:p-8 flex flex-row lg:flex-col justify-between overflow-x-auto no-scrollbar sticky top-0 z-[60] lg:relative">
        <div className="flex flex-row lg:flex-col gap-2 lg:gap-10 w-auto min-w-full lg:min-w-0 shrink-0">
          <div className="hidden lg:block">
            <div className="flex items-center gap-3 mb-8">
              <div className="bg-stone-900 text-white p-2 rounded-xl">
                <Zap size={20} fill="currentColor" />
              </div>
              <h2 className="text-xl font-black text-stone-900 tracking-tight italic">CRM MaliTrek</h2>
            </div>
          </div>
          
          <div className="flex flex-row lg:flex-col gap-2 lg:gap-4 shrink-0">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSubView(item.id)}
                className={`flex items-center gap-2 lg:gap-4 px-4 lg:px-6 py-2.5 lg:py-4 rounded-xl lg:rounded-2xl transition-all whitespace-nowrap shrink-0 ${
                  activeSubView === item.id
                    ? 'bg-stone-900 text-white shadow-xl shadow-stone-900/10 lg:translate-x-2'
                    : 'text-stone-400 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <div className={`${activeSubView === item.id ? 'scale-100' : 'scale-90 opacity-60'} transition-transform shrink-0`}>
                  {item.icon}
                </div>
                <span className="text-[10px] lg:text-xs font-black uppercase tracking-widest">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="hidden lg:block border-t border-stone-100 pt-8 mt-8">
           <button className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-stone-400 hover:text-stone-900 hover:bg-stone-100 transition-all">
             <Settings size={18} />
             <span className="text-xs font-black uppercase tracking-widest">Configuration</span>
           </button>
        </div>
      </div>

      {/* Main CRM Area */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Header with Search */}
        <header className="bg-white border-b border-stone-50 px-4 md:px-10 py-4 md:py-6 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4">
          <div className="relative flex-1 max-w-xl">
            <Search size={18} className="absolute left-5 top-1/2 -translate-y-1/2 text-stone-300" />
            <input 
              type="text"
              placeholder="Rechercher..."
              className="w-full bg-stone-50 border border-stone-100 rounded-xl md:rounded-2xl pl-12 pr-6 py-3.5 md:py-4 outline-none focus:ring-4 focus:ring-stone-900/5 transition-all font-bold text-stone-900 text-xs md:text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <div className="flex flex-col text-right">
              <span className="text-[9px] font-black text-stone-300 uppercase tracking-widest leading-tight">Admin System</span>
              <span className="text-xs font-black text-emerald-primary">CRM v2.0</span>
            </div>
            <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center font-black border border-emerald-100 shadow-inner">M</div>
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="flex-1 p-4 md:p-10 overflow-y-auto no-scrollbar">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSubView}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="max-w-7xl mx-auto"
            >
              <div className="stagger-in">
                {activeSubView === 'dashboard' && <CRMOverview users={users} reservations={reservations} circuits={circuits} journeys={journeys} />}
                {activeSubView === 'clients' && <ClientsView users={users} reservations={reservations} />}
                {activeSubView === 'segments' && <SegmentsView users={users} />}
                {activeSubView === 'notifications' && <NotificationsView />}
                {activeSubView === 'automation' && <AutomationView />}
                {activeSubView === 'analytics' && <AnalyticsView />}
                {activeSubView === 'templates' && <TemplatesView />}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

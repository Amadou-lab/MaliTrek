import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, onSnapshot, orderBy, where, doc, getDoc, limit, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../../firebase';
import { UserProfile, GuideTier, GuideStatus, FeaturedStatus } from '../../../types';
import { 
  Users, 
  MapPin, 
  Star, 
  Shield, 
  Crown, 
  Award, 
  TrendingUp, 
  AlertCircle, 
  MoreVertical,
  CheckCircle2,
  XCircle,
  Ban,
  Briefcase,
  ExternalLink,
  ChevronRight,
  Search,
  Filter,
  DollarSign
} from 'lucide-react';
import { trekService } from '../../../services/trekService';
import toast from 'react-hot-toast';

export const AdminGuidesView: React.FC = () => {
  const [guides, setGuides] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [selectedGuide, setSelectedGuide] = useState<UserProfile | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'users'), where('role', '==', 'ROLE_GUIDE'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setGuides(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
      setIsLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleUpdateStatus = async (guideId: string, status: GuideStatus) => {
    const loading = toast.loading('Mise à jour...');
    try {
      await trekService.updateGuideProfile(guideId, { guideStatus: status });
      toast.success('Statut mis à jour', { id: loading });
    } catch (e) {
      toast.error('Erreur de mise à jour', { id: loading });
    }
  };

  const handleUpdateTier = async (guideId: string, tier: GuideTier) => {
    const loading = toast.loading('Attribution du badge...');
    try {
      await trekService.setGuidePremium(guideId, tier);
      toast.success(`Niveau ${tier} attribué`, { id: loading });
      setSelectedGuide(null);
    } catch (e) {
      toast.error('Erreur', { id: loading });
    }
  };

  const handleToggleVerification = async (guideId: string, current: boolean) => {
    try {
      await trekService.updateGuideProfile(guideId, { isVerified: !current });
      toast.success(!current ? 'Guide vérifié ✅' : 'Vérification retirée');
    } catch (e) {}
  };

  const filteredGuides = guides.filter(g => {
    const matchesSearch = g.displayName.toLowerCase().includes(search.toLowerCase()) || g.email.toLowerCase().includes(search.toLowerCase());
    const matchesTier = tierFilter === 'all' || g.guideTier === tierFilter;
    return matchesSearch && matchesTier;
  });

  return (
    <div className="space-y-6 md:space-y-12 pb-32">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 stagger-in">
        <div className="space-y-1 md:space-y-2">
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-1 italic">Professional Marketplace</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Gestion Guides</h2>
          <p className="text-[10px] md:text-sm text-stone-400 font-bold italic">Supervisez les professionnels et les performances terrain.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-300 group-focus-within:text-emerald-primary transition-colors" />
            <input 
              type="text"
              placeholder="Rechercher..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full sm:w-64 pl-11 pr-4 py-3.5 md:py-4 bg-white border border-stone-100 rounded-xl md:rounded-2xl text-xs md:text-sm font-bold text-emerald-primary outline-none focus:ring-4 focus:ring-emerald-500/5 focus:border-emerald-primary transition-all shadow-sahara italic placeholder:text-stone-200"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-4 top-1/2 -translate-y-1/2 w-3 h-3 md:w-4 md:h-4 text-emerald-accent" />
            <select 
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value)}
              className="w-full pl-10 pr-6 py-3.5 md:py-4 bg-white border border-stone-100 rounded-xl md:rounded-2xl text-xs md:text-sm font-black text-emerald-primary uppercase tracking-widest outline-none shadow-sahara italic appearance-none cursor-pointer"
            >
              <option value="all">TOUS NIVEAUX</option>
              <option value="standard">STANDARD</option>
              <option value="premium">PREMIUM</option>
              <option value="elite">ELITE</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-64 md:h-80 bg-stone-50 rounded-[2rem] md:rounded-[3rem] animate-pulse border border-stone-100" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-8">
          <AnimatePresence>
            {filteredGuides.map(guide => (
              <motion.div 
                key={guide.uid}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white rounded-[2rem] md:rounded-[3rem] border border-stone-100 p-6 md:p-8 shadow-sahara hover:shadow-2xl hover:shadow-emerald-primary/5 transition-all group relative overflow-hidden"
              >
                {/* Background Decor */}
                <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full blur-3xl opacity-10 transition-colors ${
                  guide.guideTier === 'elite' ? 'bg-emerald-accent' : 
                  guide.guideTier === 'premium' ? 'bg-emerald-primary' : 'bg-stone-300'
                }`} />

                {/* Badges Stack */}
                <div className="flex flex-wrap gap-1.5 md:gap-2 mb-4 md:mb-6">
                  {guide.guideTier === 'elite' && (
                    <span className="px-2 md:px-3 py-1 bg-emerald-accent/10 text-emerald-accent rounded-full text-[7px] md:text-[8px] font-black uppercase tracking-[0.2em] flex items-center gap-1 italic border border-emerald-accent/20">
                      <Award className="w-2.5 h-2.5" /> Elite
                    </span>
                  )}
                  {guide.guideTier === 'premium' && (
                    <span className="px-2 md:px-3 py-1 bg-emerald-50 text-emerald-primary rounded-full text-[7px] md:text-[8px] font-black uppercase tracking-[0.2em] flex items-center gap-1 italic border border-emerald-primary/20">
                      <Crown className="w-2.5 h-2.5" /> Premium
                    </span>
                  )}
                  {guide.isVerified && (
                    <span className="px-2 md:px-3 py-1 bg-emerald-900 text-white rounded-full text-[7px] md:text-[8px] font-black uppercase tracking-[0.2em] flex items-center gap-1 italic shadow-lg shadow-emerald-900/10">
                      <Shield className="w-2.5 h-2.5" /> Vérifié
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-4 mb-4 md:mb-8">
                  <div className="w-12 h-12 md:w-16 md:h-16 rounded-xl md:rounded-2xl overflow-hidden bg-stone-50 border-2 border-white shadow-inner shrink-0 relative rotate-2 group-hover:rotate-0 transition-transform">
                    {guide.photoURL ? (
                      <img src={guide.photoURL} alt={guide.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xl font-bold font-serif text-stone-200">
                        {guide.displayName[0]}
                      </div>
                    )}
                    {guide.guideStatus === 'active' && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 md:w-4 md:h-4 bg-emerald-accent border-2 border-white rounded-full shadow-sm animate-pulse" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-serif font-black text-emerald-primary truncate tracking-tight text-base md:text-lg italic leading-none mb-1">{guide.displayName}</h3>
                    <p className="text-[10px] md:text-xs font-bold text-stone-300 truncate lowercase italic tracking-tight">{guide.email}</p>
                  </div>
                </div>

                {/* Business Performance KPIs */}
                <div className="grid grid-cols-2 gap-3 md:gap-4 mb-4 md:mb-8">
                  <div className="bg-stone-50/50 rounded-xl md:rounded-2xl p-3 md:p-4 border border-stone-100">
                    <p className="text-[7px] md:text-[9px] font-black text-stone-300 uppercase tracking-widest mb-1 md:mb-2 flex items-center gap-1 italic">
                      <TrendingUp className="w-2.5 h-2.5 text-emerald-accent" /> Score
                    </p>
                    <div className="flex items-end gap-1">
                      <p className="font-black text-emerald-primary leading-none text-base md:text-lg">{(guide.trustScore || 0).toFixed(0)}</p>
                      <span className="text-[8px] font-bold text-stone-300 italic mb-0.5">/100</span>
                    </div>
                  </div>
                  <div className="bg-stone-50/50 rounded-xl md:rounded-2xl p-3 md:p-4 border border-stone-100">
                    <p className="text-[7px] md:text-[9px] font-black text-stone-300 uppercase tracking-widest mb-1 md:mb-2 flex items-center gap-1 italic">
                      <XCircle className="w-2.5 h-2.5 text-rose-400" /> Annul.
                    </p>
                    <p className="font-black text-emerald-primary text-base md:text-lg leading-none">{(guide.cancellationRate || 0).toFixed(0)}%</p>
                  </div>
                </div>

                <div className="flex flex-col gap-2 md:flex-row md:gap-2">
                  <button 
                    onClick={() => setSelectedGuide(guide)}
                    className="w-full bg-stone-900 text-white rounded-xl md:rounded-2xl py-3.5 md:py-4 text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] shadow-xl shadow-stone-900/10 active:scale-95 transition-all flex items-center justify-center gap-2 italic"
                  >
                    Superviser <ChevronRight size={12} />
                  </button>
                  <button 
                    onClick={() => handleToggleVerification(guide.uid, !!guide.isVerified)}
                    className={`h-11 md:h-14 aspect-square rounded-xl md:rounded-2xl flex items-center justify-center border-2 transition-all shrink-0 ${
                      guide.isVerified ? 'bg-emerald-50 border-emerald-primary text-emerald-primary shadow-lg shadow-emerald-primary/5' : 'bg-stone-50 border-stone-100 text-stone-200'
                    }`}
                  >
                    <Shield className="w-4.5 md:w-5 h-4.5 md:h-5" />
                  </button>
                </div>

                {/* Internal Tags Overlay (Admin only) */}
                {guide.rankingScore !== undefined && (
                  <div className="mt-4 pt-4 border-t border-stone-50 flex items-center justify-between">
                    <span className="text-[7px] md:text-[8px] font-black text-stone-200 uppercase tracking-[0.3em] italic">Market Ranking</span>
                    <span className="text-[10px] md:text-xs font-black text-emerald-accent italic">#{Math.round(guide.rankingScore)}</span>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Guide Management Modal */}
      <AnimatePresence>
        {selectedGuide && (
          <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-[200] flex items-end md:items-center justify-center p-0 md:p-4">
            <motion.div 
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              className="bg-white rounded-t-[2.5rem] md:rounded-[3.5rem] w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-100 p-6 md:p-14 relative no-scrollbar"
            >
              <div className="sticky top-0 right-0 flex justify-end z-10 md:absolute md:top-10 md:right-10 pointer-events-none">
                <button 
                  onClick={() => setSelectedGuide(null)}
                  className="p-3 bg-stone-50 text-stone-300 rounded-xl hover:bg-emerald-primary hover:text-white transition-all shadow-sm pointer-events-auto"
                >
                  <XCircle className="w-6 h-6 md:w-8 md:h-8" />
                </button>
              </div>

              <div className="flex flex-col md:flex-row items-center md:items-end gap-4 md:gap-8 mb-8 md:mb-12 text-center md:text-left">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-[2.5rem] md:rounded-[3rem] overflow-hidden bg-stone-50 border-4 border-white shadow-sahara rotate-3">
                  <img src={selectedGuide.photoURL} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="space-y-1">
                  <p className="text-[9px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic mb-1">PRO PROFILE</p>
                  <h3 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">{selectedGuide.displayName}</h3>
                  <p className="font-bold text-stone-300 italic text-sm md:text-base">{selectedGuide.email}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 mb-8 md:mb-12">
                <div className="bg-emerald-50/50 rounded-3xl p-6 border border-emerald-primary/10">
                  <p className="text-[8px] md:text-[10px] font-black text-emerald-primary uppercase tracking-widest mb-3 italic">Portfolio (CFA)</p>
                  <p className="text-2xl md:text-3xl font-serif font-black text-emerald-primary italic">{(selectedGuide.totalEarned || 0).toLocaleString()}</p>
                </div>
                <div className="bg-stone-50 rounded-3xl p-6 border border-stone-100">
                  <p className="text-[8px] md:text-[10px] font-black text-emerald-primary uppercase tracking-widest mb-3 italic">Missions OK</p>
                  <p className="text-2xl md:text-3xl font-serif font-black text-emerald-primary italic">{selectedGuide.completedJourneys || 0}</p>
                </div>
                <div className="bg-emerald-primary text-white rounded-3xl p-6 shadow-xl shadow-emerald-primary/20">
                  <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-widest mb-3 italic">Qualité Service</p>
                  <p className="text-2xl md:text-3xl font-serif font-black italic">{(100 - (selectedGuide.disputeRate || 0)).toFixed(1)}%</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 mb-8 md:mb-12">
                <div className="space-y-5 md:space-y-6">
                  <h4 className="text-[10px] md:text-xs font-black text-stone-200 uppercase tracking-[0.3em] italic">Rating Marketplace</h4>
                  <div className="grid grid-cols-3 md:grid-cols-1 gap-2">
                    {['standard', 'premium', 'elite'].map((tier) => (
                      <button
                        key={tier}
                        onClick={() => handleUpdateTier(selectedGuide.uid, tier as GuideTier)}
                        className={`w-full p-4 rounded-xl md:rounded-2xl border-2 text-center md:text-left transition-all flex flex-col md:flex-row items-center justify-between gap-2 ${
                          selectedGuide.guideTier === tier 
                          ? 'border-emerald-primary bg-emerald-primary text-white shadow-lg' 
                          : 'border-stone-50 bg-stone-50/50 text-stone-300 hover:border-emerald-primary/20'
                        }`}
                      >
                        <span className="font-black uppercase text-[9px] md:text-[10px] tracking-widest italic">{tier}</span>
                        {selectedGuide.guideTier === tier && <Crown className="w-3 h-3 md:w-4 md:h-4 text-emerald-accent" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-5 md:space-y-6">
                  <h4 className="text-[10px] md:text-xs font-black text-stone-200 uppercase tracking-[0.3em] italic">Discipline & Accès</h4>
                  <div className="grid grid-cols-3 md:grid-cols-1 gap-2">
                    {[
                      { id: 'active', label: 'ACTIF', color: 'emerald' },
                      { id: 'suspended', label: 'SUSPENDU', color: 'amber' },
                      { id: 'banned', label: 'BANNI', color: 'rose' }
                    ].map((status) => (
                      <button
                        key={status.id}
                        onClick={() => handleUpdateStatus(selectedGuide.uid, status.id as GuideStatus)}
                        className={`w-full p-4 rounded-xl md:rounded-2xl border-2 text-center md:text-left transition-all flex flex-col md:flex-row items-center justify-between gap-2 ${
                          selectedGuide.guideStatus === status.id 
                          ? `border-${status.color}-500 bg-${status.color}-500 text-white shadow-lg` 
                          : 'border-stone-50 bg-stone-50/50 text-stone-300 hover:border-emerald-primary/20'
                        }`}
                      >
                        <span className="font-black uppercase text-[9px] md:text-[10px] tracking-widest italic">{status.label}</span>
                        {selectedGuide.guideStatus === status.id && <Shield className="w-3 h-3 md:w-4 md:h-4 opacity-50" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Commission Override Section */}
              <div className="bg-stone-50/50 rounded-[2rem] md:rounded-[3rem] p-6 md:p-10 mb-8 md:mb-12 border border-stone-100">
                <div className="flex items-center justify-between mb-4 md:mb-6">
                  <h4 className="text-[10px] md:text-xs font-black text-stone-200 uppercase tracking-[0.3em] italic">Marketplace Commission</h4>
                  <span className="bg-emerald-primary text-white px-3 py-1.5 rounded-full text-[9px] md:text-[10px] font-black shadow-lg shadow-emerald-primary/10">
                    {selectedGuide.customCommissionRate ? `${(selectedGuide.customCommissionRate * 100).toFixed(0)}%` : 'STANDARD 15%'}
                  </span>
                </div>
                <p className="text-xs md:text-sm text-stone-400 font-bold italic mb-6 md:mb-8 leading-relaxed">Ajustez le taux plateforme spécifique pour ce partenaire stratégique.</p>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 md:gap-3">
                  {[0.2, 0.15, 0.1, 0.05].map(rate => (
                    <button 
                      key={rate}
                      onClick={() => trekService.updateGuideProfile(selectedGuide.uid, { customCommissionRate: rate })}
                      className={`py-3 md:py-4 rounded-xl md:rounded-2xl border-2 text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all italic ${
                        selectedGuide.customCommissionRate === rate ? 'border-emerald-primary bg-emerald-primary text-white shadow-lg shadow-emerald-primary/10' : 'bg-white border-stone-100 text-emerald-primary hover:border-emerald-primary/20'
                      }`}
                    >
                      {(rate * 100).toFixed(0)}%
                    </button>
                  ))}
                  <button 
                    onClick={() => trekService.updateGuideProfile(selectedGuide.uid, { customCommissionRate: undefined })}
                    className="col-span-2 sm:col-span-1 py-3 md:py-4 bg-white border-2 border-stone-100 text-stone-300 rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:border-rose-200 hover:text-rose-500 transition-all italic"
                  >
                    Reset
                  </button>
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setSelectedGuide(null)}
                  className="w-full py-5 bg-stone-900 text-white rounded-2xl md:rounded-3xl font-black uppercase tracking-[0.2em] text-[10px] md:text-xs shadow-2xl shadow-stone-900/20 active:scale-95 transition-all italic"
                >
                  Valider Supervision
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

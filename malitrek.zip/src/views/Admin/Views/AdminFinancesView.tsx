import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, onSnapshot, orderBy, where, doc, getDoc, limit } from 'firebase/firestore';
import { db } from '../../../firebase';
import { Transaction, UserProfile, Withdrawal, Reservation } from '../../../types';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle, 
  XSquare, 
  CreditCard, 
  Search,
  Filter,
  TrendingUp,
  ShieldAlert,
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import { trekService } from '../../../services/trekService';
import toast from 'react-hot-toast';

export const AdminFinancesView: React.FC = () => {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState({
    totalCollected: 0,
    totalGuideEarning: 0,
    totalPlatformFees: 0,
    totalRefunded: 0,
    blockedInDispute: 0,
    totalEscrow: 0,
    totalReleased: 0,
    pendingWithdrawals: 0,
    approvedWithdrawals: 0
  });

  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const qW = query(collection(db, 'withdrawals'), orderBy('createdAt', 'desc'));
    const unsubscribeW = onSnapshot(qW, (snap) => {
      const ws = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Withdrawal));
      setWithdrawals(ws);
      setStats(prev => ({
        ...prev,
        pendingWithdrawals: ws.filter(w => w.status === 'pending').reduce((acc, w) => acc + w.amount, 0),
        approvedWithdrawals: ws.filter(w => w.status === 'processed').reduce((acc, w) => acc + w.amount, 0),
      }));
    });

    const qT = query(collection(db, 'transactions'), orderBy('createdAt', 'desc'), limit(500));
    const unsubscribeT = onSnapshot(qT, (snap) => {
      const txs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
      setTransactions(txs);
      
      let platform = 0;
      let refunded = 0;
      let released = 0;
      let earningPending = 0;
      let collected = 0;
      
      txs.forEach(tx => {
         if (tx.type === 'platform_fee') platform += tx.amount;
         if (tx.type.includes('refund')) refunded += tx.amount;
         if (tx.type === 'guide_earning_release') released += tx.amount;
         if (tx.type === 'guide_earning_pending') earningPending += tx.amount;
         if (tx.type === 'client_payment') collected += tx.amount;
      });
      
      setStats(prev => ({
        ...prev,
        totalCollected: collected,
        totalPlatformFees: platform,
        totalRefunded: refunded,
        totalReleased: released,
        totalGuideEarning: earningPending, // Pending Earnings
      }));
      setIsLoading(false);
    });

    return () => { unsubscribeW(); unsubscribeT(); };
  }, []);

  const exportCSV = () => {
    if (transactions.length === 0) return;
    const headers = ['ID', 'Date', 'Type', 'Montant', 'Catégorie', 'Description'];
    const rows = transactions.map(tx => [
      tx.id,
      new Date(tx.createdAt?.seconds * 1000).toLocaleDateString(),
      tx.type,
      tx.amount,
      tx.category,
      tx.description
    ]);

    const csvContent = [headers, ...rows].map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `malitrek_finances_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Rapport exporté !');
  };

  const handleApproveWithdrawal = async (id: string, approved: boolean) => {
    const notes = window.prompt(approved ? "Notes de paiement (Optionnel)" : "Motif de refus (Obligatoire)");
    if (!approved && !notes) return;

    try {
      await trekService.handleWithdrawal(id, approved, notes || '');
      toast.success(approved ? 'Retrait approuvé' : 'Retrait refusé');
    } catch (e) {
      toast.error('Erreur lors du traitement');
    }
  };

  return (
    <div className="space-y-8 md:space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-1 md:space-y-2">
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">Finances</h2>
          <p className="text-[10px] md:text-sm text-slate-500 font-medium">Contrôle des flux et déboursements.</p>
        </div>
        <button 
          onClick={exportCSV}
          className="w-full md:w-auto bg-slate-900 text-white px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-3 active:scale-95 transition-all shadow-xl"
        >
          <Layers size={16} /> EXPORTER RAPPORT
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <div className="bg-white p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] border border-stone-100 shadow-sm space-y-3 md:space-y-4">
           <div className="w-10 h-10 md:w-12 md:h-12 bg-emerald-100 text-emerald-600 rounded-xl md:rounded-2xl flex items-center justify-center">
             <Wallet size={20} />
           </div>
           <div>
             <p className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Commissions</p>
             <p className="text-xl md:text-2xl font-black text-slate-900">{stats.totalPlatformFees.toLocaleString()} CFA</p>
           </div>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] border border-stone-100 shadow-sm space-y-3 md:space-y-4">
           <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-100 text-blue-600 rounded-xl md:rounded-2xl flex items-center justify-center">
             <CheckCircle size={20} />
           </div>
           <div>
             <p className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Libéré Guides</p>
             <p className="text-xl md:text-2xl font-black text-slate-900">{stats.totalReleased.toLocaleString()} CFA</p>
           </div>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] border border-stone-100 shadow-sm space-y-3 md:space-y-4">
           <div className="w-10 h-10 md:w-12 md:h-12 bg-rose-100 text-rose-600 rounded-xl md:rounded-2xl flex items-center justify-center">
             <ArrowDownLeft size={20} />
           </div>
           <div>
             <p className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Remboursé</p>
             <p className="text-xl md:text-2xl font-black text-slate-900">{stats.totalRefunded.toLocaleString()} CFA</p>
           </div>
        </div>

        <div className="bg-slate-900 p-6 md:p-8 rounded-3xl md:rounded-[2.5rem] shadow-xl space-y-3 md:space-y-4">
           <div className="w-10 h-10 md:w-12 md:h-12 bg-white/10 text-amber-400 rounded-xl md:rounded-2xl flex items-center justify-center">
             <Clock size={20} />
           </div>
           <div>
             <p className="text-[9px] md:text-[10px] font-black text-slate-400/60 uppercase tracking-widest">En Escrow</p>
             <p className="text-xl md:text-2xl font-black text-white">{stats.totalGuideEarning.toLocaleString()} CFA</p>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 md:gap-10">
        <div className="xl:col-span-2 space-y-6 md:space-y-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">Retraits</h3>
            <div className="bg-stone-100 p-1 rounded-xl shadow-inner flex overflow-x-auto no-scrollbar w-full sm:w-auto">
               {['all', 'pending', 'approved'].map(t => (
                 <button 
                  key={t}
                  onClick={() => setFilter(t)}
                  className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all ${filter === t ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}
                 >
                   {t}
                 </button>
               ))}
            </div>
          </div>

          <div className="space-y-3 md:space-y-4">
            {withdrawals.filter(w => filter === 'all' || w.status === filter).map(w => (
              <div key={w.id} className="bg-white p-5 md:p-8 rounded-2xl md:rounded-3xl border border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 group hover:shadow-lg transition-all">
                <div className="flex items-center gap-4 md:gap-6">
                   <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center shrink-0 ${w.status === 'pending' ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600'}`}>
                      {w.status === 'pending' ? <Clock size={20} /> : <CheckCircle size={20} />}
                   </div>
                   <div className="min-w-0">
                     <div className="flex items-center gap-2 mb-1 flex-wrap">
                       <h4 className="font-black text-slate-900 truncate">{w.guideName}</h4>
                       <span className={`px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-widest border ${
                         w.status === 'pending' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-emerald-50 text-emerald-600 border-emerald-100'
                       }`}>
                         {w.status}
                       </span>
                     </div>
                     <p className="text-[10px] font-medium text-slate-500 truncate">
                       {w.method} • {w.accountNumber}
                     </p>
                   </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-6 sm:gap-8 border-t sm:border-t-0 pt-4 sm:pt-0">
                  <div className="text-left sm:text-right">
                    <p className="text-lg md:text-xl font-black text-slate-900">{w.amount.toLocaleString()} CFA</p>
                    <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                       {w.createdAt ? new Date(w.createdAt.seconds * 1000).toLocaleDateString() : 'Aujourd\'hui'}
                    </p>
                  </div>
                  {w.status === 'pending' && (
                    <div className="flex gap-2">
                       <button 
                        onClick={() => handleApproveWithdrawal(w.id, false)}
                        className="p-3 bg-rose-50 text-rose-600 rounded-lg md:rounded-xl"
                       >
                         <XSquare size={18} />
                       </button>
                       <button 
                        onClick={() => handleApproveWithdrawal(w.id, true)}
                        className="p-3 bg-emerald-600 text-white rounded-lg md:rounded-xl shadow-lg shadow-emerald-600/20"
                       >
                         <CheckCircle size={18} />
                       </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {withdrawals.length === 0 && (
              <div className="py-16 bg-slate-50/50 border-2 border-dashed border-stone-100 rounded-3xl flex flex-col items-center justify-center text-slate-300 font-bold text-xs uppercase tracking-widest">
                 Aucun retrait.
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6 md:space-y-8">
           <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">Audit Log</h3>
           <div className="bg-white rounded-3xl border border-stone-100 shadow-sm overflow-hidden">
             <div className="p-5 border-b border-stone-100 bg-stone-50/50">
               <div className="relative">
                 <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" />
                 <input 
                  type="text" 
                  placeholder="Rechercher..." 
                  className="w-full bg-white border border-stone-200 rounded-xl pl-10 pr-4 py-2 text-[10px] md:text-xs font-bold outline-none"
                 />
               </div>
             </div>
             <div className="divide-y divide-stone-50">
               {transactions.slice(0, 6).map(tx => (
                 <div key={tx.id} className="p-5 hover:bg-stone-50/50 cursor-pointer">
                    <div className="flex justify-between items-start mb-1.5">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{tx.type}</span>
                      <span className="text-[8px] font-bold text-stone-300">{new Date(tx.createdAt?.seconds * 1000).toLocaleDateString()}</span>
                    </div>
                    <p className="text-[11px] font-bold text-slate-700 mb-2 line-clamp-1">{tx.description}</p>
                    <div className="flex justify-between items-center">
                       <p className={`text-[11px] font-black ${tx.category === 'credit' ? 'text-emerald-600' : 'text-rose-600'}`}>
                         {tx.category === 'credit' ? '+' : '-'}{tx.amount.toLocaleString()} CFA
                       </p>
                       <ArrowRight size={10} className="text-stone-300" />
                    </div>
                 </div>
               ))}
             </div>
             <button className="w-full p-4 text-[9px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 border-t border-stone-50">
               Audit log complet
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { collection, query, onSnapshot, getDocs, where, limit, orderBy } from 'firebase/firestore';
import { db } from '../../../firebase';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Map as MapIcon, 
  CheckCircle, 
  AlertCircle, 
  Calendar,
  Globe,
  Award,
  DollarSign,
  Download,
  Filter,
  Search,
  ChevronDown
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  Cell,
  PieChart,
  Pie,
  AreaChart,
  Area
} from 'recharts';
import { Reservation, Circuit, UserProfile, Journey } from '../../../types';
import { toDate, handleFirestoreError, OperationType } from '../../../lib/firestoreUtils';
import toast from 'react-hot-toast';

const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`bg-white rounded-[2rem] md:rounded-[3rem] border border-stone-100 shadow-sm ${className}`}>
    {children}
  </div>
);

export const AdminReportsView: React.FC = () => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [guides, setGuides] = useState<UserProfile[]>([]);
  const [journeys, setJourneys] = useState<Journey[]>([]);
  const [period, setPeriod] = useState<'7j' | '30j' | '12m'>('30j');
  const [selectedGuideId, setSelectedGuideId] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);

  const [stats, setStats] = useState({
    totalSales: 0,
    platformEarnings: 0,
    activeJourneys: 0,
    totalUsers: 0,
    conversionRate: 0,
    completedTrips: 0
  });

  useEffect(() => {
    setIsLoading(true);
    const unsubRes = onSnapshot(collection(db, 'reservations'), (snap) => {
      setReservations(snap.docs.map(d => ({ id: d.id, ...d.data() } as Reservation)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reservations');
    });

    const unsubCircuits = onSnapshot(collection(db, 'circuits'), (snap) => {
      setCircuits(snap.docs.map(d => ({ id: d.id, ...d.data() } as Circuit)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'circuits');
    });

    const unsubGuides = onSnapshot(query(collection(db, 'users'), where('role', '==', 'ROLE_GUIDE')), (snap) => {
      setGuides(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    const unsubJourneys = onSnapshot(collection(db, 'journeys'), (snap) => {
      setJourneys(snap.docs.map(d => ({ id: d.id, ...d.data() } as Journey)));
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'journeys');
    });

    return () => {
      unsubRes();
      unsubCircuits();
      unsubGuides();
      unsubJourneys();
    };
  }, []);

  useEffect(() => {
    const filteredRes = reservations.filter(r => {
      if (selectedGuideId !== 'all' && r.guideId !== selectedGuideId) return false;
      
      const resDate = toDate(r.createdAt);
      const now = new Date();
      if (period === '7j') {
        const weekAgo = new Date(now.setDate(now.getDate() - 7));
        return resDate >= weekAgo;
      } else if (period === '30j') {
        const monthAgo = new Date(now.setMonth(now.getMonth() - 1));
        return resDate >= monthAgo;
      }
      return true; // 12m or all
    });

    let sales = 0;
    let earnings = 0;
    let completed = 0;

    filteredRes.forEach(r => {
      if (r.paymentStatus === 'paid' || r.paymentStatus === 'released') {
        sales += (r.totalPaid || 0);
        earnings += (r.platformFee || 0);
      }
      if (r.status === 'completed') completed++;
    });

    setStats({
      totalSales: sales,
      platformEarnings: earnings,
      activeJourneys: journeys.filter(j => j.status === 'in_progress').length,
      totalUsers: guides.length, // Simplified or add actual user count
      conversionRate: filteredRes.length > 0 ? Math.round((completed / filteredRes.length) * 100) : 0,
      completedTrips: completed
    });
  }, [reservations, period, selectedGuideId, journeys, guides]);

  const getChartData = () => {
    const days = period === '7j' ? 7 : period === '30j' ? 30 : 12;
    const data = [];
    const now = new Date();

    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      if (period === '12m') d.setMonth(d.getMonth() - i);
      else d.setDate(d.getDate() - i);

      const label = period === '12m' 
        ? d.toLocaleDateString('fr-FR', { month: 'short' }) 
        : d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });

      const dayKey = d.toISOString().split('T')[0];
      const monthKey = d.toISOString().slice(0, 7);

      const periodRes = reservations.filter(r => {
        const rDate = toDate(r.createdAt).toISOString();
        if (period === '12m') return rDate.startsWith(monthKey);
        return rDate.startsWith(dayKey);
      });

      const revenue = periodRes
        .filter(r => r.paymentStatus === 'paid' || r.paymentStatus === 'released')
        .reduce((acc, r) => acc + (r.totalPaid || 0), 0);
      
      const fees = periodRes
        .filter(r => r.paymentStatus === 'paid' || r.paymentStatus === 'released')
        .reduce((acc, r) => acc + (r.platformFee || 0), 0);

      data.push({ name: label, sales: revenue, fee: fees });
    }
    return data;
  };

  const getCategoryData = () => {
    const counts: Record<string, number> = {};
    reservations.forEach(r => {
      const category = r.circuitTitle ? (circuits.find(c => c.id === r.circuitId)?.category || 'Autre') : 'Autre';
      counts[category] = (counts[category] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  };

  const exportToCSV = () => {
    const headers = ['ID', 'Date', 'Client', 'Circuit', 'Guide', 'Montant', 'Commission', 'Status'];
    const rows = reservations.map(r => [
      r.id,
      toDate(r.createdAt).toLocaleDateString(),
      r.fullname,
      r.circuitTitle,
      guides.find(g => g.uid === r.guideId)?.displayName || 'Inconnu',
      r.totalPaid,
      r.platformFee,
      r.status
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `mali_trek_report_${period}_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    toast.success('Rapport exporté !');
  };

  const COLORS = ['#0f172a', '#10b981', '#f43f5e', '#f59e0b', '#8b5cf6'];
  return (
    <div className="space-y-6 md:space-y-12 pb-24 md:pb-20 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b border-stone-200 pb-8 md:pb-12">
        <div className="stagger-in">
          <p className="text-[8px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 italic">Performance Platform</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Analytique <br className="hidden md:block" /><span className="text-stone-300">MaliTrek</span></h2>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
          <div className="relative group flex-1 sm:flex-none">
            <select 
              value={selectedGuideId}
              onChange={(e) => setSelectedGuideId(e.target.value)}
              className="w-full appearance-none bg-white border border-stone-100 pl-10 pr-12 py-3 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest text-emerald-primary shadow-sm focus:ring-4 focus:ring-emerald-500/5 focus:outline-none transition-all cursor-pointer"
            >
              <option value="all">Tous les Guides</option>
              {guides.map(g => (
                <option key={g.uid} value={g.uid}>{g.displayName}</option>
              ))}
            </select>
            <Filter size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-300 group-hover:text-emerald-primary transition-colors" />
            <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-300" />
          </div>

          <div className="bg-white border border-stone-100 p-1 rounded-xl md:rounded-2xl flex gap-1 shadow-sm shrink-0 overflow-x-auto no-scrollbar">
             {(['7j', '30j', '12m'] as const).map(p => (
                <button 
                  key={p} 
                  onClick={() => setPeriod(p)}
                  className={`flex-1 px-4 md:px-6 py-2 rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all ${
                    period === p ? 'bg-stone-900 text-white shadow-lg shadow-stone-900/20' : 'text-stone-400 hover:bg-stone-50'
                  }`}
                >
                  {p}
                </button>
             ))}
          </div>

          <button 
            onClick={exportToCSV}
            className="flex items-center justify-center gap-2 bg-emerald-primary text-white px-6 py-3 rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-emerald-primary/10 transition-all active:scale-95 shrink-0"
          >
            <Download size={14} />
            <span className="hidden sm:inline">Exporter</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
        {[
          { label: 'Volume d\'affaires', value: (stats.totalSales || 0).toLocaleString(), unit: 'CFA', icon: <TrendingUp />, color: 'emerald' },
          { label: 'Revenu Plateforme', value: (stats.platformEarnings || 0).toLocaleString(), unit: 'CFA', icon: <DollarSign />, color: 'stone' },
          { label: 'Taux de Conversion', value: stats.conversionRate, unit: '%', icon: <Award />, color: 'amber' },
          { label: 'Trajets actifs', value: stats.activeJourneys, unit: '', icon: <MapIcon />, color: 'indigo' }
        ].map((kpi, idx) => (
          <Card key={idx} className="p-5 md:p-8 hover:shadow-sahara transition-all relative overflow-hidden group">
            <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center mb-4 md:mb-6 ${
              kpi.color === 'emerald' ? 'bg-emerald-50 text-emerald-600' :
              kpi.color === 'stone' ? 'bg-stone-50 text-stone-600' :
              kpi.color === 'amber' ? 'bg-amber-50 text-amber-600' :
              'bg-indigo-50 text-indigo-600'
            }`}>
              {kpi.icon}
            </div>
            <p className="text-[7px] md:text-[9px] font-black text-stone-400 uppercase tracking-widest mb-1 italic truncate">{kpi.label}</p>
            <p className="text-base md:text-2xl font-black text-emerald-primary leading-none truncate">
              {kpi.value} <span className="text-[10px] md:text-sm text-stone-300 font-bold ml-1">{kpi.unit}</span>
            </p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-10">
        <div className="lg:col-span-2 bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border border-stone-100 shadow-sahara space-y-8 overflow-hidden">
           <div className="flex justify-between items-center">
             <div className="space-y-1">
                <h3 className="text-lg md:text-xl font-black text-emerald-primary tracking-tight font-serif italic">Flux Financiers</h3>
                <p className="text-[8px] md:text-[9px] text-stone-300 font-black uppercase tracking-widest">Revenue vs Profit ({period})</p>
             </div>
             <BarChart3 size={20} className="text-stone-100" />
           </div>
           <div className="h-[250px] md:h-[400px] w-full pt-4 -mx-4 md:mx-0">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={getChartData()} margin={{ left: -20, right: 10, top: 10, bottom: 0 }}>
                 <defs>
                   <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#065f46" stopOpacity={0.1}/>
                     <stop offset="95%" stopColor="#065f46" stopOpacity={0}/>
                   </linearGradient>
                   <linearGradient id="colorFee" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                     <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f4" />
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} dy={10} />
                 <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 8, fontWeight: 900, fill: '#d6d3d1' }} />
                 <Tooltip 
                  contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: '900', fontSize: '10px' }}
                 />
                 <Area type="monotone" dataKey="sales" stroke="#065f46" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                 <Area type="monotone" dataKey="fee" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorFee)" />
               </AreaChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] border border-stone-100 shadow-sahara flex flex-col justify-between overflow-hidden">
           <div>
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-lg md:text-xl font-black text-emerald-primary tracking-tight font-serif italic">Répartition</h3>
                <Globe size={20} className="text-stone-100" />
              </div>
              <div className="h-[220px] md:h-[280px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={getCategoryData()}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={80}
                      paddingAngle={8}
                      dataKey="value"
                    >
                      {getCategoryData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ fontSize: '10px', fontWeight: '900', borderRadius: '1rem' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
           </div>
           
           <div className="space-y-3 md:space-y-4 pt-6 border-t border-stone-50">
              {getCategoryData().map((cat, idx) => (
                <div key={idx} className="flex items-center justify-between group cursor-pointer">
                   <div className="flex items-center gap-3">
                      <div className="w-2.5 h-2.5 rounded-full ring-2 ring-stone-50" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                      <span className="text-[10px] md:text-xs font-black text-stone-500 uppercase tracking-widest group-hover:text-emerald-primary transition-colors">{cat.name}</span>
                   </div>
                   <span className="text-[10px] md:text-xs font-black text-emerald-primary">{cat.value} <span className="text-stone-300 text-[8px] uppercase">rés.</span></span>
                </div>
              ))}
              {getCategoryData().length === 0 && <p className="text-center text-stone-300 text-[10px] font-black uppercase tracking-widest py-8">Silence radio</p>}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10">
         <Card className="bg-stone-900 border-none p-6 md:p-10 space-y-6 md:space-y-10 shadow-sahara relative overflow-hidden group">
            <div className="absolute -right-20 -top-20 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-all duration-700" />
            
            <div className="flex justify-between items-start relative z-10">
               <div className="space-y-2">
                 <h3 className="text-xl md:text-2xl font-serif italic text-white font-black tracking-tight">Classement Guides</h3>
                 <p className="text-stone-500 text-[9px] md:text-xs font-bold uppercase tracking-widest italic leading-relaxed">Performance par volume généré.</p>
               </div>
               <div className="p-3 bg-white/5 rounded-2xl border border-white/5 text-emerald-accent">
                 <Award size={24} />
               </div>
            </div>
            
            <div className="space-y-3 md:space-y-5 relative z-10">
               {guides
                .map(g => {
                  const guideRes = reservations.filter(r => r.guideId === g.uid && (r.paymentStatus === 'paid' || r.paymentStatus === 'released'));
                  const revenue = guideRes.reduce((acc, r) => acc + (r.totalPaid || 0), 0);
                  return { ...g, revenue, tripCount: guideRes.length };
                })
                .sort((a, b) => b.revenue - a.revenue)
                .slice(0, 4)
                .map((guide, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 md:p-6 bg-white/5 rounded-2xl md:rounded-[2.5rem] border border-white/5 hover:bg-white/10 hover:border-emerald-500/30 transition-all cursor-pointer group/item overflow-hidden relative">
                     <div className="flex items-center gap-4 relative z-10">
                        <div className={`w-8 h-8 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center font-black text-xs md:text-base transition-all ${
                          idx === 0 ? 'bg-emerald-accent text-emerald-primary shadow-xl shadow-emerald-accent/20' : 
                          'bg-stone-800 text-stone-500'
                        }`}>
                          {idx + 1}
                        </div>
                        <div className="flex items-center gap-3">
                          <img src={guide.photoURL || ''} alt="" className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover ring-2 ring-white/10 shrink-0" />
                          <div className="min-w-0">
                            <p className="font-black text-xs md:text-sm text-white group-hover/item:text-emerald-accent transition-colors truncate">{guide.displayName}</p>
                            <p className="text-[7px] md:text-[9px] text-stone-500 font-black uppercase tracking-widest truncate">{guide.tripCount} séjours</p>
                          </div>
                        </div>
                     </div>
                     <div className="text-right shrink-0 relative z-10">
                        <p className="font-black text-white text-xs md:text-sm">{(guide.revenue || 0).toLocaleString()} <span className="text-[8px] md:text-[10px] text-stone-500">CFA</span></p>
                     </div>
                  </div>
                ))}
            </div>
         </Card>

         <Card className="p-6 md:p-10 space-y-6 md:space-y-10 shadow-sahara overflow-hidden relative">
            <div className="space-y-6 md:space-y-8">
              <div className="flex justify-between items-start">
                 <div className="space-y-2">
                   <h3 className="text-xl md:text-2xl font-serif italic text-stone-900 font-black tracking-tight">Vigilance Système</h3>
                   <p className="text-stone-400 text-[9px] md:text-xs font-bold uppercase tracking-widest italic">Anomalies et points de contrôle.</p>
                 </div>
                 <div className="p-3 bg-rose-50 rounded-2xl text-rose-500 border border-rose-100">
                    <AlertCircle size={24} />
                 </div>
              </div>
              
              <div className="space-y-3 md:space-y-4">
                 {[
                   { type: 'Litige', desc: 'Remboursement requis #234', date: '45m', urgency: 'critical' },
                   { type: 'Retrait', desc: 'Samba T. - 240k CFA', date: '3h', urgency: 'urgent' },
                   { type: 'Catalogue', desc: 'Guide sans description', date: '1j', urgency: 'normal' },
                   { type: 'Terrain', desc: 'Check-in expiré', date: '2j', urgency: 'normal' },
                 ].map((alert, idx) => (
                   <div key={idx} className="p-4 md:p-5 bg-stone-50 border border-stone-100 rounded-2xl md:rounded-[2.25rem] flex items-center justify-between hover:border-rose-500/20 hover:bg-white transition-all group/item shadow-inner">
                      <div className="flex items-center gap-3 md:gap-4 min-w-0">
                         <div className={`w-2 h-2 rounded-full shrink-0 ${
                           alert.urgency === 'critical' ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)] animate-pulse' :
                           alert.urgency === 'urgent' ? 'bg-amber-500' : 'bg-stone-300'
                         }`} />
                         <div className="min-w-0">
                            <h4 className="font-black text-stone-900 text-xs md:text-sm truncate leading-tight">{alert.type}</h4>
                            <p className="text-[8px] md:text-[10px] font-bold text-stone-400 italic truncate mt-0.5">"{alert.desc}"</p>
                         </div>
                      </div>
                      <span className="text-[8px] font-black text-stone-300 uppercase tracking-widest bg-white px-2 py-1 rounded-full border border-stone-50 group-hover/item:border-rose-100 transition-all shrink-0 ml-2">{alert.date}</span>
                   </div>
                 ))}
              </div>
            </div>
            
            <button className="w-full bg-stone-900 text-white py-4 md:py-5 rounded-xl md:rounded-2xl text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] shadow-xl shadow-stone-900/10 active:scale-95 transition-all">
              Gérer les alertes critiques
            </button>
         </Card>
      </div>
    </div>
  );
};

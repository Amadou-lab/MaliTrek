import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, onSnapshot } from 'firebase/firestore';
import { db } from '../../../firebase';
import { Circuit, Journey, POI } from '../../../types';
import { AdvancedMap } from '../../../components/shared/AdvancedMap';
import { Map as MapIcon, Compass, MapPin, AlertCircle, TrendingUp, Info, Star, XCircle } from 'lucide-react';

export const AdminMapView: React.FC = () => {
    const [circuits, setCircuits] = useState<Circuit[]>([]);
    const [journeys, setJourneys] = useState<Journey[]>([]);
    const [pois, setPois] = useState<POI[]>([]);
    const [stats, setStats] = useState({
        totalCircuits: 0,
        activeJourneys: 0,
        hotZones: 0
    });

    useEffect(() => {
        const unsubC = onSnapshot(collection(db, 'circuits'), (snap) => {
            setCircuits(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Circuit)));
            setStats(prev => ({ ...prev, totalCircuits: snap.size }));
        });

        const unsubJ = onSnapshot(collection(db, 'journeys'), (snap) => {
            setJourneys(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Journey)));
            setStats(prev => ({ ...prev, activeJourneys: snap.docs.filter(d => d.data().status === 'in_progress').length }));
        });

        const unsubP = onSnapshot(collection(db, 'pois'), (snap) => {
            setPois(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as POI)));
        });

        return () => { unsubC(); unsubJ(); unsubP(); };
    }, []);

    const [selectedObject, setSelectedObject] = useState<any>(null);

    const handleMarkerClick = (id: string, type: string) => {
        let obj = null;
        if (type === 'circuit') obj = circuits.find(c => c.id === id);
        if (type === 'journey') obj = journeys.find(j => j.id === id);
        if (type === 'poi') obj = pois.find(p => p.id === id);
        setSelectedObject({ ...obj, type });
    };

    return (
    <div className="flex flex-col h-[calc(100vh-140px)] md:h-full space-y-4 md:space-y-8 -mt-2 md:mt-0">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-3 md:gap-6 stagger-in px-2 md:px-0">
        <div className="space-y-1 md:space-y-2">
          <p className="text-[7px] md:text-[10px] font-black text-emerald-accent uppercase tracking-[0.4em] italic mb-1">Geospatial Intelligence</p>
          <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic leading-none">Supervision Carte</h2>
          <p className="text-[9px] md:text-sm text-stone-400 font-bold italic">Activités en temps réel sur le territoire Malien.</p>
        </div>
        <div className="flex gap-2 md:gap-4 w-full md:w-auto">
          <div className="flex-1 md:flex-none bg-white p-3 md:p-4 rounded-xl md:rounded-3xl border border-stone-100 flex items-center gap-3 md:gap-4 shadow-sahara">
            <div className="w-8 h-8 md:w-10 md:h-10 bg-emerald-50 rounded-lg md:rounded-2xl flex items-center justify-center text-emerald-primary shrink-0"><MapIcon className="w-4 md:w-5 h-4 md:h-5" /></div>
            <div>
              <p className="text-[7px] md:text-[8px] font-black uppercase text-stone-300 italic leading-none mb-1">Circuits</p>
              <p className="font-black text-emerald-primary text-sm md:text-lg leading-none">{stats.totalCircuits}</p>
            </div>
          </div>
          <div className="flex-1 md:flex-none bg-white p-3 md:p-4 rounded-xl md:rounded-3xl border border-stone-100 flex items-center gap-3 md:gap-4 shadow-sahara">
            <div className="w-8 h-8 md:w-10 md:h-10 bg-emerald-900 rounded-lg md:rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg shadow-emerald-900/10"><Compass className="w-4 md:w-5 h-4 md:h-5 animate-spin-slow" /></div>
            <div>
              <p className="text-[7px] md:text-[8px] font-black uppercase text-stone-300 italic leading-none mb-1">Live</p>
              <p className="font-black text-emerald-primary text-sm md:text-lg leading-none">{stats.activeJourneys}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row gap-4 md:gap-8 min-h-0">
        <div className="flex-1 bg-white rounded-3xl md:rounded-[4rem] border border-stone-100 overflow-hidden shadow-2xl relative order-2 md:order-1">
          <AdvancedMap 
            circuits={circuits}
            journeys={journeys}
            pois={pois}
            onMarkerClick={handleMarkerClick}
          />
          
          {/* Floating Info Card */}
          <AnimatePresence>
            {selectedObject && (
              <motion.div 
                initial={{ opacity: 0, y: 50, x: '-50%' }}
                animate={{ opacity: 1, y: 0, x: '-50%' }}
                exit={{ opacity: 0, y: 50, x: '-50%' }}
                className="absolute bottom-4 md:bottom-auto md:top-8 left-1/2 md:left-8 z-[500] w-[90%] md:w-80 bg-white/95 backdrop-blur-xl rounded-[2rem] md:rounded-[2.5rem] border border-white/50 shadow-2xl p-6 md:p-8 space-y-4 md:space-y-6"
              >
                <div className="flex justify-between items-start">
                  <span className={`px-2.5 py-1 rounded-full text-[7px] md:text-[8px] font-black uppercase tracking-[0.2em] italic border ${
                    selectedObject.type === 'circuit' ? 'bg-emerald-50 text-emerald-primary border-emerald-primary/10' : 
                    selectedObject.type === 'journey' ? 'bg-emerald-900 text-white border-emerald-900 shadow-lg' : 'bg-amber-50 text-amber-600 border-amber-600/10'
                  }`}>
                    {selectedObject.type}
                  </span>
                  <button onClick={() => setSelectedObject(null)} className="p-2 bg-stone-50 rounded-lg text-stone-300 hover:text-rose-500 transition-colors">
                    <XCircle size={16} />
                  </button>
                </div>
                <div className="min-w-0">
                  <h4 className="text-lg md:text-xl font-serif font-black text-emerald-primary leading-tight mb-2 italic truncate">{selectedObject.title || selectedObject.name}</h4>
                  <p className="text-[9px] md:text-xs font-bold text-stone-400 flex items-center gap-2 uppercase tracking-widest italic">
                    <MapPin size={12} className="text-emerald-accent" /> {selectedObject.location || 'Localisation indisponible'}
                  </p>
                </div>
                <div className="pt-4 md:pt-6 border-t border-stone-100 flex justify-between items-center">
                  <div className="space-y-0.5 md:space-y-1 min-w-0">
                    <p className="text-[7px] md:text-[8px] font-black text-stone-200 uppercase tracking-widest italic">VALEUR / STATUT</p>
                    <p className="font-black text-emerald-primary text-sm md:text-base italic truncate">
                      {selectedObject.basePrice ? `${selectedObject.basePrice.toLocaleString()} CFA` : selectedObject.status || 'VALIDE'}
                    </p>
                  </div>
                  <button className="w-10 h-10 md:w-12 md:h-12 bg-stone-900 text-white rounded-xl md:rounded-2xl flex items-center justify-center shadow-lg active:scale-90 transition-all shrink-0">
                    <Info className="w-4.5 md:w-5 h-4.5 md:h-5" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="hidden lg:flex flex-col w-80 space-y-6 overflow-y-auto no-scrollbar order-1 md:order-2">
          <div className="bg-stone-900 p-8 rounded-[3rem] text-white space-y-6 shadow-2xl relative overflow-hidden group">
            <Compass size={120} className="absolute -right-10 -bottom-10 text-white/5 -rotate-12 group-hover:rotate-12 transition-transform duration-1000" />
            <h4 className="relative z-10 text-[10px] font-black uppercase tracking-[0.3em] text-emerald-accent italic">Activités Récentes</h4>
            <div className="relative z-10 space-y-5">
              {journeys.slice(0, 3).map((j, i) => (
                <div key={i} className="flex gap-4 group/item cursor-pointer">
                  <div className="w-0.5 h-10 bg-emerald-accent/30 group-hover/item:bg-emerald-accent transition-colors rounded-full" />
                  <div className="min-w-0">
                    <p className="text-[8px] font-black text-white/40 uppercase tracking-widest italic mb-1">{j.date || 'Auj'}</p>
                    <p className="text-xs font-bold text-white/80 group-hover/item:text-white transition-colors truncate">{j.title || 'Expédition'}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-8 rounded-[3rem] border border-stone-100 space-y-6 shadow-sahara">
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-200 italic">Spots Populaires</h4>
            <div className="space-y-3">
              {pois.slice(0, 4).map((poi, i) => (
                <div key={i} className="flex justify-between items-center bg-stone-50/50 p-4 rounded-2xl border border-stone-50 hover:border-emerald-primary/10 transition-all cursor-pointer group">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 bg-white text-emerald-accent rounded-xl flex items-center justify-center shadow-sm group-hover:bg-emerald-primary group-hover:text-white transition-all"><Star size={14} fill="currentColor" /></div>
                    <span className="text-[11px] font-bold text-emerald-primary italic truncate">{poi.name}</span>
                  </div>
                  <TrendingUp size={14} className="text-emerald-accent shrink-0" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

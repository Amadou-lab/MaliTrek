import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, onSnapshot, orderBy, where, doc, updateDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { db, auth } from '../../../firebase';
import { Dispute, Reservation, UserProfile } from '../../../types';
import { ShieldAlert, CheckCircle, XCircle, AlertTriangle, User, Calendar, MessageSquare, Scale, ExternalLink } from 'lucide-react';
import { trekService } from '../../../services/trekService';
import toast from 'react-hot-toast';

const getUrgencyColor = (urgency?: string) => {
  switch (urgency) {
    case 'critical': return 'text-rose-600 bg-rose-50';
    case 'high': return 'text-orange-600 bg-orange-50';
    case 'medium': return 'text-amber-600 bg-amber-50';
    default: return 'text-stone-600 bg-stone-50';
  }
};

export const AdminDisputesView: React.FC = () => {
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null);
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'disputes'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snap) => {
      setDisputes(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Dispute)));
      setIsLoading(false);
    }, (error) => {
      trekService.handleFirestoreError(error, 'list' as any, 'disputes');
    });
  }, []);

  useEffect(() => {
    if (!selectedDispute?.reservationId) {
      setSelectedReservation(null);
      return;
    }
    const fetchRes = async () => {
      try {
        const snap = await getDoc(doc(db, 'reservations', selectedDispute.reservationId!));
        if (snap.exists()) setSelectedReservation(snap.data() as Reservation);
      } catch (e) {
        console.error('Error fetching reservation', e);
      }
    };
    fetchRes();
  }, [selectedDispute]);

  const [splitData, setSplitData] = useState({ refundAmount: 0, guideAmount: 0 });

  const [participantKept, setParticipantKept] = useState(false);

  const handleResolve = async (resolutionType: string) => {
    if (!selectedDispute) return;
    if (!notes && !['reopened', 'closed'].includes(resolutionType)) {
      toast.error('Notes obligatoires pour la résolution.');
      return;
    }

    const adminId = auth.currentUser?.uid || 'ADMIN';
    const decision = {
      resolutionType,
      refundAmount: resolutionType === 'refund_full' ? selectedReservation?.totalPaid : (resolutionType === 'split' || resolutionType === 'refund_partial' ? splitData.refundAmount : 0),
      guideAmount: resolutionType === 'release_guide' ? selectedReservation?.guideShare : (resolutionType === 'split' || resolutionType === 'refund_partial' ? splitData.guideAmount : 0),
      adminComment: notes,
      adminNotes: notes,
      participantKept: resolutionType === 'release_guide' || resolutionType === 'reject' ? true : participantKept
    };

    const loading = toast.loading('Traitement de la décision...');
    try {
      await trekService.resolveDispute(selectedDispute.id, decision, adminId);
      toast.success('Décision appliquée.', { id: loading });
      setSelectedDispute(null);
      setNotes('');
      setSplitData({ refundAmount: 0, guideAmount: 0 });
      setParticipantKept(false);
    } catch (e) {
      toast.error('Erreur lors de la résolution.', { id: loading });
    }
  };

  const handleReopen = async () => {
    if (!selectedDispute || !notes) {
      toast.error('Veuillez indiquer la raison de la réouverture dans les notes.');
      return;
    }
    const adminId = auth.currentUser?.uid || 'ADMIN';
    const loading = toast.loading('Réouverture du litige...');
    try {
      await trekService.reopenDispute(selectedDispute.id, adminId, notes);
      toast.success('Litige réouvert.', { id: loading });
      setNotes('');
    } catch (e) {
      toast.error('Erreur.', { id: loading });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open': return <span className="px-2 py-1 bg-amber-100 text-amber-700 text-[8px] font-black uppercase rounded">Ouvert</span>;
      case 'under_review': return <span className="px-2 py-1 bg-blue-100 text-blue-700 text-[8px] font-black uppercase rounded">En analyse</span>;
      case 'resolved': return <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[8px] font-black uppercase rounded">Résolu</span>;
      case 'rejected': return <span className="px-2 py-1 bg-rose-100 text-rose-700 text-[8px] font-black uppercase rounded">Rejeté</span>;
      case 'reopened': return <span className="px-2 py-1 bg-purple-100 text-purple-700 text-[8px] font-black uppercase rounded">Réouvert</span>;
      case 'closed': return <span className="px-2 py-1 bg-slate-100 text-slate-700 text-[8px] font-black uppercase rounded">Clos</span>;
      default: return <span className="px-2 py-1 bg-slate-100 text-slate-700 text-[8px] font-black uppercase rounded">{status}</span>;
    }
  };

  return (
    <div className="space-y-6 md:space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight mb-1 md:mb-2">Litiges</h2>
          <p className="text-[10px] md:text-sm text-slate-500 font-medium">Revue et arbitrage des conflits.</p>
        </div>
        <div className="w-full md:w-auto bg-slate-900 text-white px-5 py-3 rounded-2xl flex items-center justify-center gap-3">
          <ShieldAlert size={18} className="text-rose-400" />
          <span className="font-black text-[10px] uppercase tracking-widest">{disputes.filter(d => d.status === 'open').length} ouverts</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-3 md:space-y-4">
          {disputes.map(d => (
            <div 
              key={d.id}
              onClick={() => setSelectedDispute(d)}
              className={`p-5 md:p-6 rounded-2xl md:rounded-3xl border transition-all cursor-pointer group ${
                selectedDispute?.id === d.id ? 'md:bg-slate-900 md:border-slate-900 md:text-white bg-slate-50' : 'bg-white border-slate-100 hover:shadow-lg'
              }`}
            >
              <div className="flex justify-between items-start mb-3 md:mb-4">
                <div className={`px-2.5 py-1 rounded-lg text-[7px] md:text-[8px] font-black uppercase tracking-widest border ${getUrgencyColor(d.urgency || 'normal')}`}>
                  {d.urgency || 'Normal'}
                </div>
                <div className="text-right">
                  <p className="text-[9px] md:text-[10px] font-bold text-slate-400">
                    {d.createdAt?.seconds 
                      ? new Date(d.createdAt.seconds * 1000).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })
                      : 'Date...'}
                  </p>
                </div>
              </div>
              <h3 className={`font-black text-base md:text-lg mb-1 md:mb-2 ${selectedDispute?.id === d.id && 'md:text-white'} text-slate-900`}>
                {d.type}
              </h3>
              <p className={`text-[10px] md:text-xs line-clamp-2 mb-3 md:mb-4 font-medium italic ${selectedDispute?.id === d.id ? 'md:text-slate-400 text-slate-500' : 'text-slate-500'}`}>
                "{d.description}"
              </p>
              <div className="flex items-center gap-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest">
                <div className="flex items-center gap-2">
                  {getStatusBadge(d.status)}
                </div>
                {d.status === 'resolved' && (
                   <div className="flex items-center gap-1 text-emerald-500 font-bold">
                     <CheckCircle size={10} /> {d.resolutionType || d.adminDecision}
                   </div>
                )}
              </div>
            </div>
          ))}
          {disputes.length === 0 && !isLoading && (
            <div className="py-16 md:py-20 text-center text-slate-400 font-bold bg-white rounded-3xl border border-dashed text-xs">
              Aucun litige à traiter.
            </div>
          )}
        </div>

        {/* Desktop Sidebar / Mobile Bottom Sheet Simulation */}
        <div className={`
          ${selectedDispute ? 'fixed inset-0 z-50 bg-slate-900/40 lg:relative lg:inset-auto lg:z-auto lg:bg-transparent' : 'hidden lg:block lg:sticky lg:top-8'}
          flex items-end lg:items-start justify-center
        `}
        onClick={() => setSelectedDispute(null)}
        >
          <AnimatePresence mode="wait">
            {selectedDispute ? (
              <motion.div 
                key={selectedDispute.id}
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 100 }}
                className="bg-white rounded-t-[2.5rem] lg:rounded-[2.5rem] p-6 md:p-10 border border-stone-200/50 shadow-2xl space-y-6 md:space-y-8 w-full lg:max-w-none max-h-[90vh] overflow-y-auto no-scrollbar"
                onClick={e => e.stopPropagation()}
              >
                {/* Drag Handle for Mobile */}
                <div className="w-12 h-1.5 bg-stone-200 rounded-full mx-auto mb-4 lg:hidden" />

                <div className="flex justify-between items-start">
                  <div className="space-y-1 md:space-y-2">
                    <div className="flex flex-wrap items-center gap-3">
                      <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">Arbitrage</h3>
                      <span className="text-[8px] md:text-[10px] font-black bg-slate-100 px-3 py-1 rounded-full text-slate-500 uppercase tracking-widest leading-none">
                        Signalé le {selectedDispute.createdAt?.seconds 
                          ? new Date(selectedDispute.createdAt.seconds * 1000).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })
                          : '...'}
                      </span>
                    </div>
                    <p className="text-[9px] font-black uppercase tracking-widest text-slate-300">REF: {selectedDispute.id.slice(0, 8)}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    {getStatusBadge(selectedDispute.status)}
                    <button onClick={() => setSelectedDispute(null)} className="lg:hidden text-stone-300 hover:text-rose-500 transition-colors">
                      <XCircle size={24} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 min-[400px]:grid-cols-3 gap-3 md:gap-4">
                  <div className="bg-emerald-50 p-3 md:p-4 rounded-xl md:rounded-2xl border border-emerald-100">
                     <p className="text-[7px] md:text-[8px] font-black text-emerald-600 uppercase tracking-widest mb-1">Total</p>
                     <p className="font-black text-xs md:text-base text-emerald-900 truncate">{(selectedReservation?.totalPaid || 0).toLocaleString()}</p>
                  </div>
                  <div className="bg-blue-50 p-3 md:p-4 rounded-xl md:rounded-2xl border border-blue-100">
                     <p className="text-[7px] md:text-[8px] font-black text-blue-600 uppercase tracking-widest mb-1">Guide</p>
                     <p className="font-black text-xs md:text-base text-blue-900 truncate">{(selectedReservation?.guideShare || 0).toLocaleString()}</p>
                  </div>
                  <div className="hidden min-[400px]:block bg-stone-50 p-3 md:p-4 rounded-xl md:rounded-2xl border border-stone-100">
                     <p className="text-[7px] md:text-[8px] font-black text-stone-400 uppercase tracking-widest mb-1">Fee</p>
                     <p className="font-black text-xs md:text-base text-stone-900 truncate">{(selectedReservation?.platformFee || 0).toLocaleString()}</p>
                  </div>
                </div>

                <div className="bg-slate-50 p-5 md:p-6 rounded-2xl space-y-1.5 md:space-y-2">
                   <p className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Description</p>
                   <p className="text-xs md:text-sm font-medium text-slate-600 leading-relaxed italic">
                     "{selectedDispute.description}"
                   </p>
                </div>

                {selectedDispute.status === 'open' || selectedDispute.status === 'under_review' || selectedDispute.status === 'reopened' ? (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Commentaire Admin</label>
                      <textarea 
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl md:rounded-2xl px-5 md:px-6 py-3 md:py-4 text-xs md:text-sm font-bold outline-none ring-slate-900 focus:ring-1 min-h-[80px]"
                        placeholder="Motif de la décision..."
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                      />
                    </div>

                    <div className="grid grid-cols-1 min-[400px]:grid-cols-2 gap-3">
                      <button 
                        onClick={() => handleResolve('refund_full')}
                        className="p-3.5 bg-rose-600 text-white rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all active:scale-[0.98]"
                      >
                        Refund Total
                      </button>
                      <button 
                        onClick={() => handleResolve('release_guide')}
                        className="p-3.5 bg-emerald-600 text-white rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all active:scale-[0.98]"
                      >
                        Release Guide
                      </button>

                      <div className="col-span-full space-y-4">
                        <div className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-100 rounded-xl">
                          <input 
                            type="checkbox" 
                            id="participantKept" 
                            className="w-5 h-5 rounded accent-emerald-500"
                            checked={participantKept}
                            onChange={e => setParticipantKept(e.target.checked)}
                          />
                          <label htmlFor="participantKept" className="text-[9px] font-black text-amber-900 uppercase tracking-widest cursor-pointer select-none">
                            Maintenir participant actif
                          </label>
                        </div>

                        <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-100">
                          <div className="space-y-1">
                            <label className="text-[7px] font-black text-slate-400 uppercase tracking-widest">Refund Amt</label>
                            <input 
                              type="number" 
                              className="w-full bg-white border border-stone-200 rounded-lg px-3 py-2 text-[10px] font-bold"
                              value={splitData.refundAmount}
                              onChange={e => setSplitData({ ...splitData, refundAmount: parseInt(e.target.value) || 0 })}
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[7px] font-black text-slate-400 uppercase tracking-widest">Guide Amt</label>
                            <input 
                              type="number" 
                              className="w-full bg-white border border-stone-200 rounded-lg px-3 py-2 text-[10px] font-bold"
                              value={splitData.guideAmount}
                              onChange={e => setSplitData({ ...splitData, guideAmount: parseInt(e.target.value) || 0 })}
                            />
                          </div>
                          <button 
                            onClick={() => handleResolve('split')}
                            className="col-span-full p-3 bg-slate-900 text-white rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-slate-800"
                          >
                            Appliquer Split
                          </button>
                        </div>
                      </div>

                      <button 
                        onClick={() => handleResolve('reject')}
                        className="p-3.5 bg-slate-200 text-slate-700 rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-slate-300 transition-all active:scale-[0.98]"
                      >
                        Rejeter Litige
                      </button>
                      <button 
                        onClick={() => handleResolve('no_action')}
                        className="p-3.5 bg-slate-100 text-slate-500 rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all active:scale-[0.98]"
                      >
                        Clôturer
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-50/50 p-6 md:p-8 rounded-2xl md:rounded-3xl space-y-5 md:space-y-6 border border-emerald-100/50">
                    <div className="flex items-center gap-3 text-emerald-600 font-black uppercase tracking-widest text-[10px] md:text-xs">
                      <Scale size={16} /> Historique décision
                    </div>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-[8px] md:text-[10px] font-black uppercase text-emerald-600/60 mb-1">RÉSOLUTION</p>
                          <p className="font-black text-xs md:text-sm text-emerald-900 uppercase">{selectedDispute.resolutionType || selectedDispute.adminDecision}</p>
                        </div>
                        <div>
                          <p className="text-[8px] md:text-[10px] font-black uppercase text-emerald-600/60 mb-1">Date</p>
                          <p className="font-black text-xs md:text-sm text-slate-900">{selectedDispute.resolvedAt ? new Date(selectedDispute.resolvedAt.seconds * 1000).toLocaleDateString() : '?'}</p>
                        </div>
                      </div>
                      <div className="p-3.5 md:p-4 bg-white rounded-xl border border-emerald-100">
                        <p className="text-[8px] md:text-[10px] font-black uppercase text-slate-400 mb-1">FINANCES</p>
                        <div className="flex justify-between font-black text-[10px] md:text-xs text-slate-700">
                          <span>Client: {selectedDispute.refundAmount?.toLocaleString() || 0}</span>
                          <span>Guide: {selectedDispute.guideAmount?.toLocaleString() || 0}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-[8px] md:text-[10px] font-black uppercase text-emerald-600/60 mb-1">DÉTAILS</p>
                        <p className="text-xs font-medium text-emerald-800 italic bg-white/50 p-4 rounded-xl border border-emerald-50">"{selectedDispute.adminComment || selectedDispute.adminNotes}"</p>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-emerald-100">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2 mb-2 block">Réouverture</label>
                      <textarea 
                        className="w-full bg-white border border-emerald-100 rounded-xl px-4 py-2 text-xs font-bold outline-none mb-3"
                        placeholder="Motif réouverture..."
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                      />
                      <button 
                        onClick={handleReopen}
                        className="w-full p-4 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg active:scale-[0.98]"
                      >
                        Réouvrir
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            ) : (
              <div className="bg-white border-2 border-dashed border-stone-100 rounded-[2.5rem] p-16 md:p-20 flex flex-col items-center justify-center text-center space-y-4">
                <AlertTriangle size={40} className="text-stone-100" />
                <div>
                  <p className="font-black text-stone-200 uppercase tracking-[0.2em] text-[9px] md:text-[10px]">Sélectionnez un litige</p>
                  <p className="text-stone-300 font-medium italic text-xs">pour arbitrage.</p>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

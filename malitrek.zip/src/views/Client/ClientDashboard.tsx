import React, { useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  collection,
  query,
  onSnapshot,
  where,
  doc,
  updateDoc,
  orderBy,
  getDoc,
} from "firebase/firestore";
import { db } from "../../firebase";
import {
  handleFirestoreError,
  OperationType,
  sortByDateDesc,
  toDate,
} from "../../lib/firestoreUtils";
import { useAuth } from "../../contexts/AuthContext";
import { Journey, Reservation, UserProfile, Circuit } from "../../types";
import {
  MapPin,
  Calendar,
  Users,
  Search,
  Clock,
  Map as MapIcon,
  List,
  Bell,
  MessageCircle,
  Star as StarSolid,
  Heart,
  Compass,
  ArrowRight,
  X,
  MessageSquare,
} from "lucide-react";
import { HomeView } from "../Home/HomeView";
import { LoginView } from "../Auth/LoginView";
import { ProfileView } from "../../components/Profile/ProfileView";
import { SettingsView } from "../../components/Settings/SettingsView";
import { ClientReservationsView } from "../../components/reservations/ClientReservationsView";
import { ReservationDetails } from "../../components/reservations/ReservationDetails";
import { NotificationInbox } from "../../components/Notifications/NotificationInbox";
import { LeaderboardView } from "../Leaderboard/LeaderboardView";
import { ReviewModal } from "../../components/Reviews/ReviewModal";
import { QRModal } from "../../components/shared/QRModal";
import { ChatView } from "../General/ChatView";
import { ExploreMapView } from "../Explore/ExploreMapView";
import { trekService } from "../../services/trekService";
import { ActiveJourneyBlock } from "../../components/trek/ActiveJourneyBlock";
import { CircuitDetailsFull } from "../../components/trek/CircuitDetailsFull";
import { DisputeForm } from "../../components/reservations/DisputeForm";
import { CancellationModal } from "../../components/reservations/CancellationModal";
import { ReportIncidentModal } from "../../components/reservations/ReportIncidentModal";
import { JourneyItineraryModal } from "../../components/guide/JourneyItineraryModal";
import { useNavigation } from "../../contexts/NavigationContext";
import toast from "react-hot-toast";

export const ClientDashboard: React.FC<{
  activeView: string;
  onViewChange: (view: string) => void;
}> = ({ activeView, onViewChange }) => {
  const { profile, user } = useAuth();
  const { params } = useNavigation();
  const [journeys, setJourneys] = useState<Journey[]>([]);
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [myReservations, setMyReservations] = useState<Reservation[]>([]);
  const [viewingCircuit, setViewingCircuit] = useState<Circuit | null>(null);
  const [selectedJourney, setSelectedJourney] = useState<Journey | null>(null);
  const [selectedReservation, setSelectedReservation] =
    useState<Reservation | null>(null);
  const [selectedGuideProfile, setSelectedGuideProfile] =
    useState<UserProfile | null>(null);
  const selectedResJourney = useMemo(() => {
    if (!selectedReservation || !journeys.length) return null;
    return journeys.find(j => j.id === selectedReservation.journeyId) || null;
  }, [selectedReservation, journeys]);
  const [activeConversationId, setActiveConversationId] = useState<
    string | null
  >(null);
  const [reviewResId, setReviewResId] = useState<string | null>(null);
  const [boardingPassRes, setBoardingPassRes] = useState<Reservation | null>(
    null,
  );
  const [isDisputing, setIsDisputing] = useState(false);
  const [isReportingIncident, setIsReportingIncident] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [viewingJourneyItinerary, setViewingJourneyItinerary] = useState<Journey | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Tous");

  // Booking form state
  const [passengers, setPassengers] = useState(1);
  const [fullname, setFullname] = useState("");
  const [phone, setPhone] = useState("");

  useEffect(() => {
    if (params.reservationId && activeView === 'reservations') {
      const res = myReservations.find(r => r.id === params.reservationId);
      if (res) setSelectedReservation(res);
      else toast.error("Réservation introuvable");
    }
    if (params.circuitId && (activeView === 'explore' || activeView === 'circuits')) {
      const circuit = circuits.find(c => c.id === params.circuitId);
      if (circuit) setViewingCircuit(circuit);
    }
    if (params.conversationId && activeView === 'messages') {
      setActiveConversationId(params.conversationId);
    }
  }, [params, activeView, myReservations, circuits]);

  useEffect(() => {
    const unsubCircuits = onSnapshot(
      query(collection(db, "circuits"), where("status", "==", "approved")),
      (snap) => {
        setCircuits(
          snap.docs
            .map((doc) => ({ id: doc.id, ...doc.data() }) as Circuit)
            .sort(sortByDateDesc),
        );
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "circuits");
      }
    );

    const unsubJourneys = onSnapshot(
      query(collection(db, "journeys"), where("status", "in", ["open", "in_progress", "full"])),
      (snap) => {
        setJourneys(
          snap.docs
            .map((doc) => ({ id: doc.id, ...doc.data() }) as Journey)
            .sort(sortByDateDesc),
        );
        setIsLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "journeys");
        setIsLoading(false);
      }
    );

    if (user) {
      const unsubRes = onSnapshot(
        query(collection(db, "reservations"), where("userId", "==", user?.uid || "")),
        (snap) => {
          setMyReservations(
            snap.docs
              .map((doc) => ({ id: doc.id, ...doc.data() }) as Reservation)
              .sort(sortByDateDesc),
          );
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, "reservations");
        }
      );
      return () => {
        unsubCircuits();
        unsubJourneys();
        unsubRes();
      };
    }

    return () => {
      unsubCircuits();
      unsubJourneys();
    };
  }, [user]);

  useEffect(() => {
    if (!selectedReservation) {
      setSelectedGuideProfile(null);
      return;
    }

    const fetchGuide = async () => {
      const path = `users/${selectedReservation.guideId}`;
      try {
        const snap = await getDoc(
          doc(db, "users", selectedReservation.guideId),
        );
        if (snap.exists()) setSelectedGuideProfile(snap.data() as UserProfile);
      } catch (e) {
        handleFirestoreError(e, OperationType.GET, path);
      }
    };

    fetchGuide();
  }, [selectedReservation?.guideId]);

  const handleBooking = async () => {
    if (!selectedJourney || !user) return;
    const loadingToast = toast.loading("Création de la réservation...");
    try {
      const res = await trekService.createReservation(
        selectedJourney.id,
        user?.uid || "",
        passengers,
        fullname,
        phone,
      );
      toast.success("Réservation créée !", { id: loadingToast });

      // Simulation: Auto confirm payment for demo
      const payToast = toast.loading("Paiement en cours...");
      await trekService.confirmPayment(res.id, user?.uid || "");
      toast.success("Paiement confirmé (Simulation)", { id: payToast });

      setSelectedJourney(null);
      onViewChange("reservations");
    } catch (error: any) {
      console.error("Reservation Error:", error);
      let msg = error.message || "Erreur lors de la réservation";
      try {
        const parsed = JSON.parse(error.message);
        msg = `Erreur: ${parsed.error}`;
      } catch (e) {
        msg = error.message;
      }
      toast.error(msg, { id: loadingToast });
    }
  };

  const handleToggleFavorite = async (circuitId: string) => {
    if (!user || !profile) {
      toast.error("Connectez-vous pour ajouter aux favoris");
      return;
    }

    try {
      const favorites = profile.favorites || [];
      const newFavorites = favorites.includes(circuitId)
        ? favorites.filter((id) => id !== circuitId)
        : [...favorites, circuitId];

      await updateDoc(doc(db, "users", user?.uid || ""), {
        favorites: newFavorites,
      });

      toast.success(
        favorites.includes(circuitId)
          ? "Retiré des favoris"
          : "Ajouté aux favoris",
      );
    } catch (error) {
      toast.error("Erreur lors de la mise à jour des favoris");
    }
  };

  const filteredCircuits = circuits.filter((c) => {
    const searchLower = searchQuery.toLowerCase();
    const titleLower = (c.title || "").toLowerCase();
    const locationLower = (c.location || "").toLowerCase();

    const matchesSearch =
      titleLower.includes(searchLower) || locationLower.includes(searchLower);
    const matchesCategory =
      selectedCategory === "Tous" || c.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const reservationWithMoreData = React.useMemo(() => {
    if (!selectedReservation) return null;
    return {
      ...selectedReservation,
      journey:
        selectedResJourney ||
        journeys.find(
          (j) => j.id === selectedReservation.journeyId,
        ),
      circuit: circuits.find(
        (c) => c.id === selectedReservation.circuitId,
      ),
    };
  }, [selectedReservation, selectedResJourney, journeys, circuits]);

  return (
    <div className="min-h-screen bg-[#FFF8F3] flex flex-col font-sans text-[#0A1931]">
      <main className="flex-1 overflow-y-auto pb-24 md:pb-32">
        {activeView === "home" && (
          <div className="space-y-0">
             {(user && myReservations.find(r => r.status === 'in_progress')) && (
               <div className="px-4 md:px-12 pt-6 md:pt-8 mb-4">
                 <ActiveJourneyBlock 
                    journey={journeys.find(j => j.id === myReservations.find(r => r.status === 'in_progress')!.journeyId) || { id: myReservations.find(r => r.status === 'in_progress')!.journeyId, title: 'Trajet en cours' } as any}
                    reservations={myReservations.filter(r => r.journeyId === myReservations.find(r => r.status === 'in_progress')!.journeyId)}
                    userRole="ROLE_CLIENT"
                    currentUserId={user?.uid || ""}
                    onAction={(action) => {
                       if (action === 'open_chat') {
                          onViewChange('messages');
                       }
                       if (action === 'view_itinerary') {
                          const journey = journeys.find(j => j.id === myReservations.find(r => r.status === 'in_progress')!.journeyId);
                          if (journey) setViewingJourneyItinerary(journey);
                       }
                       if (action === 'open_map') {
                          onViewChange('explore');
                       }
                    }}
                 />
               </div>
             )}
            <HomeView
            onStartBooking={() => onViewChange("explore")}
            onSearch={(q) => {
              setSearchQuery(q);
              onViewChange("explore");
            }}
            pois={[]}
            circuits={circuits}
            journeys={journeys}
          />
          </div>
        )}

        {activeView === "all_circuits" && (
          <div className="px-4 md:px-12 pt-8 md:pt-12 space-y-12 md:space-y-20 max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 md:gap-10">
              <div className="max-w-2xl stagger-in w-full text-left">
                <span className="text-[9px] font-bold text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 block">Héritage & Nature</span>
                <h2 className="text-3xl min-[400px]:text-4xl md:text-7xl font-serif font-black text-emerald-primary tracking-tighter leading-tight md:leading-[0.9]">
                  Les Secrets <br /><span className="italic text-emerald-accent">du Maliba</span>
                </h2>
              </div>
              <div className="flex gap-2.5 overflow-x-auto pb-4 no-scrollbar w-full md:w-auto -mx-4 px-4 md:mx-0 md:px-0">
                {["Tous", "Culture", "Nature", "Aventure", "Histoire"].map(
                  (cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-6 md:px-10 py-3 md:py-4 rounded-full text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all duration-500 border whitespace-nowrap ${selectedCategory === cat ? "bg-emerald-primary text-white border-emerald-primary shadow-lg" : "bg-white text-emerald-primary/40 border-stone-200"}`}
                    >
                      {cat}
                    </button>
                  ),
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-16 pb-32">
              {filteredCircuits.map((c, idx) => (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  viewport={{ once: true }}
                  className="group bg-white rounded-3xl md:rounded-[3rem] overflow-hidden flex flex-col cursor-pointer border border-stone-100 shadow-sm"
                  onClick={() => setViewingCircuit(c)}
                >
                  <div className="relative h-56 md:h-80 overflow-hidden">
                    <img
                      src={c.image}
                      alt={c.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary/80 via-transparent to-transparent opacity-60" />
                    
                    <div className="absolute top-4 left-4 md:top-8 md:left-8 flex flex-col gap-2">
                       <div className="px-3 py-1 bg-white/20 text-white backdrop-blur-md rounded-lg text-[8px] font-bold uppercase tracking-widest">
                          {c.category}
                       </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleFavorite(c.id);
                      }}
                      className="absolute top-4 right-4 md:top-8 md:right-8 w-10 h-10 md:w-14 md:h-14 bg-white/20 backdrop-blur-md rounded-xl md:rounded-2xl flex items-center justify-center text-white/50 hover:text-rose-500 transition-all"
                    >
                      <Heart
                        size={18}
                        fill={
                          (profile?.favorites || []).includes(c.id)
                            ? "currentColor"
                            : "none"
                        }
                        className={
                          (profile?.favorites || []).includes(c.id)
                            ? "text-rose-500"
                            : ""
                        }
                      />
                    </button>

                    <div className="absolute bottom-4 left-4 right-4 md:bottom-8 md:left-8 md:right-8">
                       <h3 className="text-xl md:text-3xl font-serif font-black text-white leading-tight drop-shadow-md">
                         {c.title}
                       </h3>
                    </div>
                  </div>
                  <div className="p-5 md:p-10 border-t border-stone-50 flex-1 flex flex-col justify-between">
                    <div className="flex items-center gap-4 text-stone-premium/40 text-[9px] md:text-[10px] font-bold uppercase tracking-widest mb-4 md:mb-6">
                       <span className="flex items-center gap-2"><MapPin size={12} className="text-emerald-accent" /> {c.location}</span>
                       <span className="flex items-center gap-2"><Clock size={12} className="text-emerald-accent" /> {c.duration}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-[7px] md:text-[8px] uppercase tracking-[0.3em] font-bold text-stone-premium/30 mb-1">Prix Signature</p>
                        <p className="text-xl md:text-3xl font-serif font-black text-emerald-primary">
                          {(c.basePrice || 0).toLocaleString()}{" "}
                          <span className="text-[10px] md:text-xs font-bold opacity-30">CFA</span>
                        </p>
                      </div>
                      <div className="w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-emerald-primary text-emerald-accent flex items-center justify-center transition-all shadow-md">
                         <ArrowRight className="w-5 h-5 md:w-6 md:h-6" />
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {activeView === "all_journeys" && (
          <div className="px-4 md:px-12 pt-8 md:pt-12 space-y-12 md:space-y-20 max-w-7xl mx-auto">
            <div className="stagger-in w-full">
              <span className="text-[9px] md:text-[10px] font-bold text-emerald-accent uppercase tracking-[0.4em] mb-2 md:mb-4 block">Privilèges & Départs</span>
              <h2 className="text-3xl min-[400px]:text-4xl md:text-7xl font-serif font-black text-emerald-primary tracking-tighter leading-tight md:leading-[0.9]">
                Expéditions <br /><span className="italic underline decoration-emerald-accent/30 underline-offset-4 md:underline-offset-[12px]">Haut de Gamme</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12 pb-32">
              {journeys.map((j) => {
                const circuit = circuits.find((c) => c.id === j.circuitId);
                if (!circuit) return null;
                return (
                  <motion.div
                    key={j.id}
                    className="bg-white rounded-[2.5rem] p-6 md:p-12 border border-stone-100 shadow-sm transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between min-h-[24rem] md:h-[36rem]"
                    onClick={() => setViewingCircuit(circuit)}
                  >
                    <Compass className="absolute -right-6 -top-6 w-20 h-20 md:w-40 md:h-40 text-emerald-primary/[0.03] -rotate-12" />
                    
                    <div>
                      <div className="flex flex-row justify-between items-start gap-4 mb-6 md:mb-10">
                        <span className="px-3 py-1 bg-stone-50 border border-emerald-accent/10 rounded-lg text-[8px] font-bold text-emerald-accent italic">
                          {circuit.category}
                        </span>
                        <div className="text-right">
                          <p className="text-[8px] md:text-[10px] font-bold text-stone-premium/30 uppercase tracking-widest mb-1">Tarif Exclusif</p>
                          <p className="text-2xl md:text-4xl font-serif italic font-black text-emerald-primary">
                            {(j.pricePerPerson || 0).toLocaleString()} <span className="text-[10px] md:text-sm font-bold opacity-30">CFA</span>
                          </p>
                        </div>
                      </div>

                      <h3 className="text-xl md:text-4xl font-serif font-black text-emerald-primary mb-6 md:mb-10 leading-tight">
                        {j.title || circuit.title}
                      </h3>

                      <div className="space-y-4 text-[9px] md:text-[10px] font-bold uppercase tracking-[0.2em] text-stone-premium/50 bg-stone-50/50 rounded-2xl p-4 md:p-6 border border-stone-50">
                        <div className="flex items-center gap-3">
                          <Calendar size={16} className="text-emerald-accent" />
                          <span className="text-stone-premium">{new Date(j.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <Users size={16} className="text-emerald-accent" />
                          <div>
                            <span className="text-emerald-primary font-black">{j.availableSeats}</span> places libres
                          </div>
                        </div>
                      </div>
                    </div>

                    <button className="w-full bg-emerald-primary text-white h-14 md:h-16 rounded-xl md:rounded-2xl mt-6 font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 shadow-lg active:scale-95 transition-all">
                      RÉSERVER <ArrowRight size={16} />
                    </button>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {activeView === "explore" && <ExploreMapView />}

        {activeView === "reservations" && (
          <div className="px-4 md:px-12 pt-8 md:pt-12 max-w-7xl mx-auto space-y-10 md:space-y-16">
            <div className="stagger-in">
              <span className="text-[9px] md:text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-2 md:mb-4 block">Carnet de Route</span>
              <h2 className="text-3xl md:text-7xl font-serif font-black text-emerald-primary tracking-tighter leading-tight">
                Mes <span className="italic text-emerald-accent">Explorations</span>
              </h2>
            </div>
            <ClientReservationsView
              reservations={myReservations.map((r) => ({
                ...r,
                journey: journeys.find((j) => j.id === r.journeyId),
                circuit: circuits.find((c) => c.id === r.circuitId),
              }))}
              onSelectDetail={(res) => setSelectedReservation(res)}
            />
          </div>
        )}

        {activeView === "favorites" && (
          <div className="px-4 md:px-12 pt-8 md:pt-12 space-y-12 md:space-y-20 max-w-7xl mx-auto">
            <div className="max-w-2xl stagger-in">
              <span className="text-[9px] md:text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-2 md:mb-4 block">Sélection Privée</span>
              <h2 className="text-3xl md:text-7xl font-serif font-black text-emerald-primary tracking-tighter leading-tight">
                Mes Coups <br /><span className="italic text-rose-500">de Cœur</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-16 pb-32">
              {circuits
                .filter((c) => (profile?.favorites || []).includes(c.id))
                .map((c) => (
                  <motion.div
                    key={c.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="group bg-white rounded-[2.5rem] border border-stone-100 overflow-hidden cursor-pointer shadow-sm"
                    onClick={() => setViewingCircuit(c)}
                  >
                    <div className="relative h-56 md:h-80 overflow-hidden">
                      <img
                        src={c.image}
                        alt={c.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-emerald-primary/80 via-transparent to-transparent opacity-60" />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite(c.id);
                        }}
                        className="absolute top-4 right-4 w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl text-rose-500 flex items-center justify-center"
                      >
                        <Heart size={20} fill="currentColor" />
                      </button>
                      <div className="absolute bottom-4 left-4 right-4">
                         <h3 className="text-xl md:text-3xl font-serif font-black text-white leading-tight">
                           {c.title}
                         </h3>
                      </div>
                    </div>
                    <div className="p-6 md:p-10 border-t border-stone-50">
                      <p className="text-xl md:text-3xl font-serif font-black text-emerald-primary">
                        {(c.basePrice || 0).toLocaleString()}{" "}
                        <span className="text-[10px] font-bold opacity-30 uppercase tracking-widest text-stone-premium">CFA</span>
                      </p>
                    </div>
                  </motion.div>
                ))}
              {circuits.filter((c) => (profile?.favorites || []).includes(c.id))
                .length === 0 && (
                <div className="col-span-full py-20 md:py-48 bg-stone-50/50 rounded-[2.5rem] md:rounded-[4rem] text-center flex flex-col items-center gap-6 md:gap-10 border border-stone-100 px-6">
                  <div className="w-20 h-20 md:w-32 md:h-32 rounded-2xl md:rounded-[2.5rem] bg-white flex items-center justify-center text-rose-500 shadow-md">
                     <Heart size={32} className="opacity-20" />
                  </div>
                  <div className="space-y-4">
                    <p className="text-xl md:text-4xl font-serif italic font-black text-emerald-primary">Votre galerie est encore vierge.</p>
                    <p className="text-[9px] md:text-[11px] font-black text-stone-premium/30 uppercase tracking-[0.3em] max-w-xs mx-auto">Commencez l'aventure en découvrant nos expéditions signature.</p>
                  </div>
                  <button 
                    onClick={() => onViewChange('all_circuits')} 
                    className="px-8 md:px-12 h-14 md:h-16 bg-emerald-primary text-white rounded-xl md:rounded-2xl font-black text-[10px] uppercase tracking-widest"
                  >
                    EXPLORER LES CIRCUITS
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {activeView === "leaderboard" && (
          <div className="px-6 md:px-12 pt-8">
            <LeaderboardView />
          </div>
        )}

        {activeView === "notifications" && (
          <div className="px-6 md:px-12 pt-8">
            <NotificationInbox />
          </div>
        )}

        {activeView === "explore" && (
          <ExploreMapView onViewChange={onViewChange} />
        )}

        {activeView === "messages" && (
          <div className="px-6 md:px-12 pt-8 h-full">
            <ChatView
              initialConversationId={activeConversationId}
              onBack={() => {
                setActiveConversationId(null);
                onViewChange("home");
              }}
            />
          </div>
        )}

        {activeView === "profile" && <ProfileView />}
        {activeView === "settings" && <SettingsView />}
      </main>

      {/* Circuit Detail Overlay */}
      <AnimatePresence>
        {viewingCircuit && (
          <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-0 lg:p-12">
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="bg-white rounded-t-[4rem] lg:rounded-[4rem] w-full max-w-7xl h-full lg:h-full overflow-hidden shadow-sahara"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="h-full overflow-y-auto custom-scrollbar">
                <CircuitDetailsFull 
                  circuit={viewingCircuit}
                  role="ROLE_CLIENT"
                  onClose={() => setViewingCircuit(null)}
                  onBook={(journeyId) => {
                    const journey = journeys.find(j => j.id === journeyId);
                    if (journey) {
                      setSelectedJourney(journey);
                      setViewingCircuit(null);
                    }
                  }}
                  availableJourneys={journeys.filter(j => j.circuitId === viewingCircuit.id)}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Booking Modal */}
      <AnimatePresence>
        {selectedJourney && (
          <div className="fixed inset-0 bg-stone-900/80 backdrop-blur-xl z-[160] flex items-center justify-center p-6">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[4rem] p-12 w-full max-w-xl shadow-sahara relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="absolute -top-12 -right-12 w-40 h-40 bg-emerald-accent/10 rounded-full blur-3xl" />
              
              <div className="mb-12">
                <span className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-3 block">Réservation Sécurisée</span>
                <h3 className="text-4xl font-serif font-black text-emerald-primary tracking-tighter italic">
                  Confirmation <br /><span className="text-stone-300">de Voyage</span>
                </h3>
              </div>

              <div className="space-y-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] ml-2">
                    Configuration de l'équipe
                  </label>
                  <div className="flex items-center gap-6 bg-stone-50 p-3 rounded-[2rem] border border-stone-100">
                    <button
                      onClick={() => setPassengers(Math.max(1, passengers - 1))}
                      className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-sm text-emerald-primary hover:bg-emerald-accent transition-colors"
                    >
                      <span className="text-2xl font-black">-</span>
                    </button>
                    <div className="flex-1 text-center">
                      <span className="font-serif italic font-black text-4xl text-emerald-primary mr-2">
                        {passengers}
                      </span>
                      <span className="text-[10px] font-bold text-stone-premium/40 uppercase tracking-widest">Voyageurs</span>
                    </div>
                    <button
                      onClick={() =>
                        setPassengers(
                          Math.min(
                            selectedJourney.availableSeats,
                            passengers + 1,
                          ),
                        )
                      }
                      className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-sm text-emerald-primary hover:bg-emerald-accent transition-colors"
                    >
                      <span className="text-2xl font-black">+</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] ml-2">
                    Identité du Référent
                  </label>
                  <input
                    className="w-full bg-stone-50 border border-stone-100 rounded-[1.5rem] px-8 py-5 font-bold text-emerald-primary outline-none focus:ring-4 focus:ring-emerald-accent/20 placeholder:text-stone-200"
                    value={fullname}
                    onChange={(e) => setFullname(e.target.value)}
                    placeholder="Votre Nom & Prénom"
                  />
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] ml-2">
                    Liaison WhatsApp
                  </label>
                  <div className="relative">
                    <input
                      className="w-full bg-stone-50 border border-stone-100 rounded-[1.5rem] px-8 py-5 font-bold text-emerald-primary outline-none focus:ring-4 focus:ring-emerald-accent/20 placeholder:text-stone-200"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+223 XX XX XX XX"
                    />
                    <div className="absolute right-6 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-emerald-accent/10 flex items-center justify-center">
                       <MessageSquare size={14} className="text-emerald-accent" />
                    </div>
                  </div>
                </div>

                <div className="pt-10 border-t border-stone-100">
                  <div className="flex justify-between items-end mb-10">
                    <div className="space-y-1">
                      <p className="text-stone-premium/30 font-bold uppercase tracking-widest text-[9px]">
                        Engagement d'Aventure
                      </p>
                      <p className="text-[10px] text-emerald-accent font-black uppercase tracking-widest">Paiement Garanti</p>
                    </div>
                    <div className="text-right">
                       <p className="text-4xl font-serif italic font-black text-emerald-primary">
                        {(
                          selectedJourney.pricePerPerson * passengers
                        ).toLocaleString()}{" "}
                        <span className="text-sm font-sans not-italic font-bold opacity-30">CFA</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <button
                      onClick={handleBooking}
                      className="flex-[2] btn-premium !bg-emerald-primary !text-white h-20 shadow-2xl shadow-emerald-primary/20 active:scale-95 transition-all flex items-center justify-center gap-4"
                    >
                      FINALISER & RÉSERVER <ArrowRight size={20} />
                    </button>
                    <button
                      onClick={() => setSelectedJourney(null)}
                      className="flex-1 bg-stone-50 text-stone-premium/40 rounded-[1.5rem] font-black uppercase tracking-widest text-[10px] transition-all hover:bg-stone-100"
                    >
                      RETOUR
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Reservation Details Overlay */}
      <AnimatePresence>
        {selectedReservation && (
          <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xl z-[150] flex items-end md:items-center justify-center p-0 md:p-8">
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="bg-white rounded-t-[4rem] md:rounded-[4rem] w-full max-w-6xl h-[95vh] md:h-[85vh] overflow-hidden shadow-sahara"
            >
              <div className="h-full overflow-y-auto custom-scrollbar">
                <ReservationDetails
                  reservation={reservationWithMoreData!}
                  userRole="ROLE_CLIENT"
                  guideProfile={selectedGuideProfile || undefined}
                  onClose={() => setSelectedReservation(null)}
                  onAction={async (action, payload) => {
                    if (action === "view_boarding_pass") {
                      setBoardingPassRes(selectedReservation);
                    }
                  if (action === "message_person") {
                    if (!user || !selectedReservation) return;
                    const loadingToast = toast.loading(
                      "Ouverture de la discussion...",
                    );
                    try {
                      const convId = await trekService.getOrCreateConversation({
                        reservationId: selectedReservation.id,
                        clientId: selectedReservation.userId,
                        guideId: selectedReservation.guideId,
                        journeyId: selectedReservation.journeyId,
                        circuitId: selectedReservation.circuitId,
                      });
                      if (convId) {
                        setActiveConversationId(convId);
                        setSelectedReservation(null);
                        onViewChange("messages");
                      }
                      toast.dismiss(loadingToast);
                    } catch (e) {
                      toast.error("Erreur lors de l'ouverture du chat", {
                        id: loadingToast,
                      });
                    }
                  }
                  if (action === "validate_experience") {
                    try {
                      const loadingToast = toast.loading("Validation...");
                      await trekService.validateExperience(
                        selectedReservation.id,
                        user?.uid || "",
                      );
                      toast.success("Expérience validée !", {
                        id: loadingToast,
                      });
                      setReviewResId(selectedReservation.id);
                      setSelectedReservation(null);
                    } catch (error: any) {
                      toast.error(error.message || "Erreur de validation");
                    }
                  }
                  if (action === "rate_trip") {
                    setReviewResId(selectedReservation.id);
                    setSelectedReservation(null);
                  }
                  if (action === "report_issue") {
                    setIsDisputing(true);
                  }
                  if (action === "cancel_reservation") {
                    setIsCancelling(true);
                  }
                }}
              />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isReportingIncident && selectedReservation && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-transparent w-full max-w-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <ReportIncidentModal 
                reservation={{
                  ...selectedReservation,
                  journey: journeys.find(j => j.id === selectedReservation.journeyId)
                }}
                profile={profile!}
                onClose={() => setIsReportingIncident(false)}
                onSuccess={() => {
                  setIsReportingIncident(false);
                  setSelectedReservation(null);
                }}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isDisputing && selectedReservation && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-transparent w-full max-w-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <DisputeForm 
                reservationId={selectedReservation.id}
                journeyId={selectedReservation.journeyId}
                userId={user?.uid || ""}
                userRole={profile?.role || "ROLE_CLIENT"}
                onClose={() => setIsDisputing(false)}
                onSuccess={() => {
                  setIsDisputing(false);
                  setSelectedReservation(null);
                }}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isCancelling && selectedReservation && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-transparent w-full max-w-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <CancellationModal 
                reservation={{
                  ...selectedReservation,
                  journey: journeys.find(j => j.id === selectedReservation.journeyId)
                }}
                onClose={() => setIsCancelling(false)}
                onSuccess={() => {
                  setIsCancelling(false);
                  setSelectedReservation(null);
                }}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ReviewModal
        isOpen={!!reviewResId}
        onClose={() => setReviewResId(null)}
        reservationId={reviewResId || ""}
        userId={user?.uid || ""}
        userName={profile?.displayName || "Client MaliTrek"}
      />

      <QRModal
        isOpen={!!boardingPassRes}
        onClose={() => setBoardingPassRes(null)}
        reservationId={boardingPassRes?.id || ""}
        itemName={
          circuits.find((c) => c.id === boardingPassRes?.circuitId)?.title ||
          "Voyage MaliTrek"
        }
        passengers={boardingPassRes?.passengers || 1}
        date={
          journeys.find((j) => j.id === boardingPassRes?.journeyId)?.date ||
          "Bientôt"
        }
      />
      {viewingJourneyItinerary && (
        <JourneyItineraryModal 
          journey={viewingJourneyItinerary} 
          onClose={() => setViewingJourneyItinerary(null)} 
        />
      )}
    </div>
  );
};

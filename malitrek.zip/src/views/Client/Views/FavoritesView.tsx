import React from 'react';
import { motion } from 'motion/react';
import { Journey, Circuit } from '../../../types';
import { Heart, MapPin, Calendar, ArrowRight, Trash2 } from 'lucide-react';

interface FavoritesViewProps {
  favorites: string[];
  journeys: Journey[];
  circuits: Circuit[];
  onToggleFavorite: (id: string) => void;
  onBook: (journey: Journey) => void;
  onViewDetails: (journey: Journey) => void;
  onViewChange: (view: string) => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({ 
  favorites, 
  journeys, 
  circuits, 
  onToggleFavorite, 
  onBook,
  onViewDetails,
  onViewChange
}) => {
  const favoriteJourneys = journeys.filter(j => favorites.includes(j.id));
  const favoriteCircuits = circuits.filter(c => favorites.includes(c.id));

  const allFavorites = [
    ...favoriteJourneys.map(j => ({ type: 'journey' as const, data: j })),
    ...favoriteCircuits.map(c => ({ type: 'circuit' as const, data: c }))
  ];

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-4xl font-black text-stone-900 tracking-tight mb-2">Mes Favoris</h1>
        <p className="text-stone-500 font-medium">Retrouvez ici tous les circuits et trajets que vous avez aimés.</p>
      </div>

      {allFavorites.length === 0 ? (
        <div className="bg-white rounded-[3rem] p-20 text-center border border-stone-100 shadow-sm">
          <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-6 text-stone-300">
            <Heart size={40} />
          </div>
          <h3 className="text-2xl font-black text-stone-900 mb-2">Aucun favori pour le moment</h3>
          <p className="text-stone-500 mb-8 max-w-sm mx-auto">Explorez les circuits et cliquez sur le cœur pour les ajouter à votre liste.</p>
          <button 
            onClick={() => onViewChange('explore')}
            className="bg-emerald-600 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
          >
            Explorer les circuits
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {allFavorites.map(item => {
            if (item.type === 'journey') {
              const journey = item.data;
              const circuit = circuits.find(c => c.id === journey.circuitId);
              const displayImage = circuit?.image || journey.image || `https://picsum.photos/seed/${journey.id}/600/400`;
              
              return (
                <motion.div 
                  key={journey.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="group bg-white rounded-[2.5rem] overflow-hidden border border-stone-100 shadow-sm hover:shadow-2xl transition-all"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={displayImage} 
                      alt={journey.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[8px] font-black uppercase text-emerald-600 tracking-widest">Trajet Plannifié</div>
                    <div className="absolute top-6 right-6">
                      <button 
                        onClick={() => onToggleFavorite(journey.id)}
                        className="w-12 h-12 bg-white/90 backdrop-blur-md rounded-2xl flex items-center justify-center text-rose-500 shadow-xl active:scale-90 transition-all"
                      >
                        <Heart size={20} fill="currentColor" />
                      </button>
                    </div>
                  </div>
                  <div className="p-8">
                    <div className="flex items-center gap-2 mb-4">
                      <MapPin size={14} className="text-emerald-600" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">{journey.location}</span>
                    </div>
                    <h3 className="text-xl font-black text-stone-900 mb-4 tracking-tight group-hover:text-emerald-600 transition-colors">{journey.title}</h3>
                    <div className="flex items-center justify-between pt-6 border-t border-stone-50">
                      <div>
                        <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mb-1">Prix</p>
                        <p className="text-lg font-black text-emerald-600">{(journey.pricePerPerson || 0).toLocaleString()} CFA</p>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => onViewDetails(journey)}
                          className="p-4 bg-stone-50 text-stone-600 rounded-2xl hover:bg-stone-100 transition-all"
                        >
                          <ArrowRight size={18} />
                        </button>
                        <button 
                          onClick={() => onBook(journey)}
                          className="bg-emerald-600 text-white px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20"
                        >
                          Réserver
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            } else {
              const circuit = item.data;
              const displayImage = circuit.image || `https://picsum.photos/seed/${circuit.id}/600/400`;
              
              return (
                <motion.div 
                  key={circuit.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="group bg-white rounded-[2.5rem] overflow-hidden border border-stone-100 shadow-sm hover:shadow-2xl transition-all"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={displayImage} 
                      alt={circuit.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[8px] font-black uppercase text-amber-600 tracking-widest">Circuit</div>
                    <div className="absolute top-6 right-6">
                      <button 
                        onClick={() => onToggleFavorite(circuit.id)}
                        className="w-12 h-12 bg-white/90 backdrop-blur-md rounded-2xl flex items-center justify-center text-rose-500 shadow-xl active:scale-90 transition-all"
                      >
                        <Heart size={20} fill="currentColor" />
                      </button>
                    </div>
                  </div>
                  <div className="p-8">
                    <div className="flex items-center gap-2 mb-4">
                      <MapPin size={14} className="text-emerald-600" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">{circuit.location}</span>
                    </div>
                    <h3 className="text-xl font-black text-stone-900 mb-4 tracking-tight group-hover:text-emerald-600 transition-colors">{circuit.title}</h3>
                    <div className="flex items-center justify-between pt-6 border-t border-stone-50">
                      <div>
                        <p className="text-[8px] font-black text-stone-400 uppercase tracking-widest mb-1">À partir de</p>
                        <p className="text-lg font-black text-emerald-600">{(circuit.basePrice || 0).toLocaleString()} CFA</p>
                      </div>
                      <button 
                        onClick={() => onViewChange('explore')}
                        className="bg-stone-900 text-white px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-stone-800 transition-all shadow-lg"
                      >
                        Voir les dates
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            }
          })}
        </div>
      )}
    </div>
  );
};

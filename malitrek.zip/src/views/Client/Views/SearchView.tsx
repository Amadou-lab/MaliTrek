import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Journey, Circuit } from '../../../types';
import { Search, MapPin, Calendar, Filter, SlidersHorizontal, ArrowRight, Star, X } from 'lucide-react';
import { BottomSheet } from '../../../components/shared/UI';

interface SearchViewProps {
  journeys: Journey[];
  circuits: Circuit[];
  onBook: (journey: Journey) => void;
  onViewDetails: (journey: Journey) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({ journeys, circuits, onBook, onViewDetails }) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500000]);
  const [selectedLocation, setSelectedLocation] = useState('Tous');
  const [selectedDifficulty, setSelectedDifficulty] = useState('Tous');
  const [selectedDuration, setSelectedDuration] = useState('Tous');
  const [selectedDate, setSelectedDate] = useState('');
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);

  const locations = ['Tous', ...new Set(journeys.map(j => j.location))];
  const categories = ['Tous', 'Culture', 'Nature', 'Aventure', 'Histoire', 'Artisanat'];
  const difficulties = ['Tous', 'Facile', 'Modéré', 'Difficile'];
  const durations = ['Tous', '1 jour', '2 jours', '3 jours', 'Plus'];

  const filtered = journeys.filter(j => {
    const now = new Date();
    const nowStr = now.toLocaleDateString('en-CA');
    const journeyStr = j.date;
    
    // Un voyage est visible s'il est dans le futur (ou aujourd'hui) ET s'il reste des places ET s'il n'est pas terminé
    const isNotExpired = journeyStr >= nowStr;
    const isAvailable = (j.availableSeats || 0) > 0;
    const isNotFinished = j.status !== 'completed' && j.status !== 'cancelled';
    
    if (!isNotExpired || !isAvailable || !isNotFinished) return false;

    const matchesQuery = j.title.toLowerCase().includes(query.toLowerCase()) || 
                         j.location.toLowerCase().includes(query.toLowerCase());
    const matchesPrice = j.pricePerPerson >= priceRange[0] && j.pricePerPerson <= priceRange[1];
    const matchesLocation = selectedLocation === 'Tous' || j.location === selectedLocation;
    const matchesCategory = selectedCategory === 'Tous' || j.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === 'Tous' || j.difficulty === selectedDifficulty;
    const matchesDate = !selectedDate || j.date === selectedDate;
    
    // Duration match logic
    const matchesDuration = selectedDuration === 'Tous' || (
      selectedDuration === 'Plus' 
        ? parseInt(j.meetingTime) > 3 // Mock logic, usually duration is on Circuit
        : j.meetingTime === selectedDuration
    );

    return matchesQuery && matchesPrice && matchesLocation && matchesCategory && matchesDifficulty && matchesDate;
  });

  const FilterContent = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-10">
      <div className="col-span-1 md:col-span-2 space-y-4">
        <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] ml-2 italic">Recherche Private</label>
        <div className="relative group">
          <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-stone-200 group-focus-within:text-emerald-accent transition-colors" size={20} />
          <input 
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Mopti, Sangha, Djenné..."
            className="w-full h-16 bg-stone-50 border-none rounded-[2rem] pl-20 pr-8 text-sm font-bold focus:bg-white focus:ring-4 focus:ring-emerald-accent/10 transition-all outline-none"
          />
        </div>
      </div>

      <div className="space-y-4">
        <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] ml-2 italic">Catégorie Signature</label>
        <div className="relative">
          <select 
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full h-16 bg-stone-50 border-none rounded-[2rem] px-10 text-xs font-black uppercase tracking-widest text-emerald-primary appearance-none focus:ring-4 focus:ring-emerald-accent/10 outline-none cursor-pointer"
          >
            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>
          <div className="absolute right-8 top-1/2 -translate-y-1/2 pointer-events-none">
             <Filter size={14} className="text-emerald-accent" />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] ml-2 italic">Départ Horizon</label>
        <div className="relative">
          <input 
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full h-16 bg-stone-50 border-none rounded-[2rem] px-10 text-xs font-black uppercase tracking-widest text-emerald-primary focus:ring-4 focus:ring-emerald-accent/10 outline-none"
          />
          <div className="absolute right-8 top-1/2 -translate-y-1/2 pointer-events-none">
             <Calendar size={14} className="text-emerald-accent" />
          </div>
        </div>
      </div>

      <div className="space-y-4">
         <div className="flex justify-between items-center px-4 mb-2">
          <label className="text-[10px] font-bold text-stone-premium/30 uppercase tracking-[0.3em] italic">Tarification Max</label>
          <span className="text-xs font-black text-emerald-accent italic">{(priceRange[1] || 0).toLocaleString()} CFA</span>
        </div>
        <div className="px-4 pt-4">
          <input 
            type="range"
            min="0"
            max="1000000"
            step="10000"
            value={priceRange[1]}
            onChange={(e) => setPriceRange([0, Number(e.target.value)])}
            className="w-full h-1.5 bg-stone-100 rounded-lg appearance-none cursor-pointer accent-emerald-accent"
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-12 md:space-y-20 max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12">
      <div className="premium-card p-8 md:p-12 bg-white/70 backdrop-blur-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none group-hover:opacity-10 transition-opacity duration-1000">
           <Search size={200} className="text-emerald-primary" />
        </div>
        
        <div className="relative z-10 space-y-8 md:space-y-12">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-stone-100 pb-8 md:pb-12">
            <div>
               <p className="text-[10px] font-bold text-emerald-accent uppercase tracking-[0.5em] mb-4 italic">Filtres de Précision</p>
               <h2 className="text-4xl md:text-6xl font-serif font-black text-emerald-primary tracking-tighter leading-none">Sculptez votre <br /><span className="italic underline decoration-emerald-accent/30 decoration-4 md:decoration-8 underline-offset-[8px] md:underline-offset-[12px]">Expédition</span></h2>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
               <button 
                 onClick={() => setIsFilterSheetOpen(true)}
                 className="flex-1 md:hidden bg-stone-900 text-white h-14 rounded-2xl flex items-center justify-center gap-3 text-[10px] font-black uppercase tracking-widest shadow-xl"
               >
                 <SlidersHorizontal size={16} /> Filtres
               </button>
               <button onClick={() => {
                 setQuery('');
                 setSelectedCategory('Tous');
                 setSelectedLocation('Tous');
                 setSelectedDifficulty('Tous');
                 setSelectedDate('');
                 setPriceRange([0, 500000]);
               }} className="hidden md:block text-[10px] font-black uppercase tracking-widest text-stone-300 hover:text-rose-500 transition-colors">Réinitialiser</button>
            </div>
          </div>

          <div className="hidden md:block">
            <FilterContent />
          </div>

          <BottomSheet 
            isOpen={isFilterSheetOpen} 
            onClose={() => setIsFilterSheetOpen(false)} 
            title="Affiner l'Expédition"
          >
            <div className="space-y-10">
              <FilterContent />
              <button 
                onClick={() => setIsFilterSheetOpen(false)}
                className="w-full bg-emerald-primary text-white h-16 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl"
              >
                APPLIQUER LES FILTRES
              </button>
              <button onClick={() => {
                 setQuery('');
                 setSelectedCategory('Tous');
                 setSelectedLocation('Tous');
                 setSelectedDifficulty('Tous');
                 setSelectedDate('');
                 setPriceRange([0, 500000]);
                 setIsFilterSheetOpen(false);
               }} className="w-full text-[10px] font-black uppercase tracking-widest text-stone-400 py-2 transition-colors">Réinitialiser</button>
            </div>
          </BottomSheet>
        </div>
      </div>

      <div className="space-y-8 md:space-y-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-2 md:gap-0">
          <div>
            <h2 className="text-3xl md:text-5xl font-serif font-black text-emerald-primary tracking-tighter italic">Résultats <span className="text-stone-300">Exploration</span></h2>
            <p className="text-[10px] font-bold text-stone-premium/40 uppercase tracking-[0.3em] mt-2 italic">{filtered.length} pépites trouvées</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
          {filtered.map(journey => (
            <motion.div 
              key={journey.id}
              whileHover={{ y: -12 }}
              className="premium-card bg-white group cursor-pointer overflow-hidden border border-stone-50 shadow-sahara hover:shadow-2xl transition-all duration-700"
              onClick={() => onViewDetails(journey)}
            >
              <div className="relative h-64 md:h-80 overflow-hidden">
                <img 
                  src={journey.image || `https://picsum.photos/seed/${journey.id}/800/600`} 
                  alt={journey.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-x-4 md:inset-x-8 top-4 md:top-8 flex justify-between items-start">
                   <div className="px-4 md:px-5 py-2 bg-white/90 backdrop-blur-md rounded-xl md:rounded-2xl text-[8px] md:text-[9px] font-black uppercase tracking-widest text-emerald-accent shadow-xl border border-stone-100">
                    {journey.location}
                  </div>
                  <div className="bg-emerald-primary/90 backdrop-blur-md px-3 md:px-4 py-1.5 md:py-2 rounded-xl md:rounded-2xl shadow-xl flex items-center gap-2 border border-white/5">
                    <Star size={12} className="text-emerald-accent fill-current md:w-3.5 md:h-3.5" />
                    <span className="text-[9px] md:text-[10px] font-black text-white">
                      {circuits.find(c => c.id === journey.circuitId)?.averageRating?.toFixed(1) || '4.8'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="p-6 md:p-10 space-y-6 md:space-y-8">
                <h3 className="text-2xl md:text-3xl font-serif font-black text-emerald-primary leading-tight group-hover:text-emerald-accent transition-colors truncate italic">{journey.title}</h3>
                
                <div className="flex items-center gap-6 md:gap-8 text-[10px] md:text-[11px] font-bold uppercase tracking-widest text-stone-premium/40">
                  <span className="flex items-center gap-2 md:gap-3"><Calendar size={14} className="text-emerald-accent md:w-4 md:h-4" /> {new Date(journey.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>
                  <span className="flex items-center gap-2 md:gap-3"><Star size={14} className="text-emerald-accent md:w-4 md:h-4" /> {journey.difficulty}</span>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between pt-6 md:pt-8 border-t border-stone-50 gap-6">
                  <div>
                    <p className="text-[8px] md:text-[9px] font-bold text-stone-premium/30 uppercase tracking-widest mb-1 italic">Tarif Exceptionnel</p>
                    <p className="text-2xl md:text-4xl font-serif italic font-black text-emerald-primary leading-none">{(journey.pricePerPerson || 0).toLocaleString()} <span className="text-[10px] md:text-xs font-sans not-italic font-bold opacity-30">CFA</span></p>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onBook(journey);
                    }}
                    className="bg-emerald-primary text-white h-14 md:h-16 px-8 md:px-10 rounded-xl md:rounded-2xl font-black text-[9px] md:text-[10px] uppercase tracking-widest hover:bg-emerald-accent hover:text-emerald-primary transition-all shadow-xl shadow-emerald-primary/10 active:scale-95"
                  >
                    SÉCURISER
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="py-20 md:py-40 text-center bg-stone-50/50 rounded-[2rem] md:rounded-[4rem] border-2 border-dashed border-stone-100 stagger-in px-4">
            <div className="w-24 md:w-32 h-24 md:h-32 bg-white rounded-2xl md:rounded-[2.5rem] flex items-center justify-center mx-auto text-stone-100 mb-8 md:top-10 shadow-xl">
              <Search className="md:w-12 md:h-12 w-8 h-8" />
            </div>
            <h3 className="text-2xl md:text-4xl font-serif font-black text-emerald-primary mb-4 italic">Aucun secret n'a été dévoilé</h3>
            <p className="text-stone-premium/40 text-xs md:text-sm font-medium max-w-xs md:max-w-sm mx-auto uppercase tracking-widest leading-loose">Ajustez vos filtres pour découvrir de nouvelles pépites maliennes.</p>
            <button 
              onClick={() => {
                setQuery('');
                setSelectedCategory('Tous');
                setSelectedLocation('Tous');
                setSelectedDifficulty('Tous');
              }}
              className="mt-8 md:mt-10 px-8 md:px-10 h-14 md:h-16 rounded-xl md:rounded-2xl bg-emerald-accent text-emerald-primary font-black text-[9px] md:text-[10px] uppercase tracking-widest shadow-xl shadow-emerald-accent/20"
            >
              VOIR TOUT LE CATALOGUE
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import toast from 'react-hot-toast';
import { useAuth } from '../../contexts/AuthContext';
import { LogIn, Map, Compass, Shield, User as UserIcon, X, Mail, Chrome, Phone, ArrowRight } from 'lucide-react';
import { UserRole } from '../../types';
import { motion, AnimatePresence } from 'motion/react';

import { RecaptchaVerifier, ConfirmationResult } from 'firebase/auth';
import { auth } from '../../firebase';

export const LoginView: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authMethod, setAuthMethod] = useState<'options' | 'email' | 'phone' | 'verify' | 'mfa'>('options');
  const [isRegistering, setIsRegistering] = useState(false);
  
  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);

  const { login, loginWithEmail, registerWithEmail, signInWithPhone, createProfile, mfaResolver, sendMfaCode, resolveMfa } = useAuth();

  const handleGoogleLogin = async () => {
    if (!selectedRole) return;
    setIsLoggingIn(true);
    try {
      await login(selectedRole);
    } catch (error: any) {
      if (error.code === 'auth/multi-factor-auth-required') {
        toast.loading('Double authentification requise...', { duration: 2000 });
        try {
          const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
            size: 'invisible'
          });
          await sendMfaCode(verifier);
          setAuthMethod('mfa');
        } catch (mfaErr: any) {
          toast.error('Erreur lors de l\'envoi du code MFA');
        }
      } else {
        toast.error(error.message || 'Erreur de connexion');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;

    if (isRegistering && password.length < 6) {
      toast.error('Le mot de passe doit contenir au moins 6 caractères');
      return;
    }

    setIsLoggingIn(true);
    try {
      if (isRegistering) {
        await registerWithEmail(email, password, selectedRole, name);
      } else {
        await loginWithEmail(email, password, selectedRole);
      }
    } catch (error: any) {
      if (error.code === 'auth/multi-factor-auth-required') {
        toast.loading('Double authentification requise...', { duration: 2000 });
        try {
          const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
            size: 'invisible'
          });
          await sendMfaCode(verifier);
          setAuthMethod('mfa');
        } catch (mfaErr: any) {
          toast.error('Erreur lors de l\'envoi du code MFA');
        }
      } else {
        toast.error(error.message || 'Erreur d\'authentification');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handlePhoneAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;
    
    const maliRegex = /^(\+223|00223)?[2456789]\d{7}$/;
    if (!maliRegex.test(phoneNumber)) {
      toast.error('Veuillez entrer un numéro malien valide');
      return;
    }

    const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber : `+223${phoneNumber}`;
    
    setIsLoggingIn(true);
    try {
      const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible'
      });
      const result = await signInWithPhone(formattedPhone, verifier);
      setConfirmationResult(result);
      setAuthMethod('verify');
    } catch (error: any) {
      toast.error(error.message || 'Erreur d\'envoi du SMS');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;
    
    setIsLoggingIn(true);
    try {
      if (authMethod === 'mfa') {
        await resolveMfa(verificationCode);
      } else if (confirmationResult) {
        const result = await confirmationResult.confirm(verificationCode);
        await createProfile(result.user, selectedRole);
      }
    } catch (error: any) {
      toast.error('Code invalide ou expiré');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const resetModal = () => {
    setSelectedRole(null);
    setAuthMethod('options');
    setEmail('');
    setPassword('');
    setPhoneNumber('');
  };

  return (
    <div className="min-h-screen bg-[#0A1931] flex flex-col items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Background Decor - Mali Pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none overflow-hidden">
        <div className="scale-[2] rotate-12">
          <Map className="w-full h-full text-white" strokeWidth={0.1} />
        </div>
      </div>
      
      <div className="max-w-md w-full bg-[#FFF8F3] rounded-[4rem] shadow-[0_50px_100px_rgba(0,0,0,0.4)] p-12 text-center relative overflow-hidden min-h-[700px] flex flex-col border border-white/10">
        <div className="mb-14 pt-6">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-28 h-28 bg-[#0A1931] rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-[#0A1931]/20 relative group"
          >
            <Map className="text-[#FDE68A] w-14 h-14 transition-transform group-hover:scale-110 duration-500" />
          </motion.div>
          <h1 className="text-6xl font-serif italic font-black text-[#0A1931] mb-4 tracking-tighter">MaliTrek</h1>
          <p className="text-[#0A1931]/50 font-serif italic text-lg leading-relaxed">Le privilège de l'exploration authentique.</p>
        </div>

        <div className="space-y-6 flex-1">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedRole('ROLE_CLIENT')}
            className="w-full flex items-center justify-between p-8 bg-white border border-[#0A1931]/5 rounded-[2.5rem] transition-all hover:shadow-2xl hover:shadow-[#0A1931]/5 group active:scale-95"
          >
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-[#FFF8F3] rounded-3xl flex items-center justify-center shadow-inner group-hover:bg-[#0A1931] group-hover:text-white transition-all duration-700">
                <UserIcon className="text-[#0A1931]/40 group-hover:text-[#FDE68A]" size={32} />
              </div>
              <div className="text-left">
                <span className="block font-black text-[#0A1931] text-2xl tracking-tighter">Voyageur</span>
                <span className="text-[10px] text-[#C06014] font-black uppercase tracking-[0.2em] mt-1 block">Découverte Premium</span>
              </div>
            </div>
            <ArrowRight className="text-[#0A1931]/20 group-hover:text-[#C06014] group-hover:translate-x-2 transition-all duration-500" size={28} />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedRole('ROLE_GUIDE')}
            className="w-full flex items-center justify-between p-8 bg-white border border-[#0A1931]/5 rounded-[2.5rem] transition-all hover:shadow-2xl hover:shadow-[#0A1931]/5 group active:scale-95"
          >
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-[#FFF8F3] rounded-3xl flex items-center justify-center shadow-inner group-hover:bg-[#C06014] group-hover:text-white transition-all duration-700">
                <Compass className="text-[#0A1931]/40 group-hover:text-white" size={32} />
              </div>
              <div className="text-left">
                <span className="block font-black text-[#0A1931] text-2xl tracking-tighter">Guide</span>
                <span className="text-[10px] text-[#C06014] font-black uppercase tracking-[0.2em] mt-1 block">Expert du Sahara</span>
              </div>
            </div>
            <ArrowRight className="text-[#0A1931]/20 group-hover:text-[#C06014] group-hover:translate-x-2 transition-all duration-500" size={28} />
          </motion.button>

          <div className="pt-10">
            <button
              onClick={() => setSelectedRole('ROLE_ADMIN')}
              className="text-[#0A1931]/30 hover:text-[#0A1931] text-[9px] font-black uppercase tracking-[0.4em] flex items-center gap-4 mx-auto transition-all group"
            >
              <Shield size={16} className="group-hover:text-[#C06014] transition-colors" />
              Accès Privilège
            </button>
          </div>
        </div>

        {/* Login Modal Overlay - Luxury Edition */}
        <AnimatePresence>
          {selectedRole && (
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 40, stiffness: 300 }}
              className="absolute inset-0 bg-[#FFF8F3] z-50 flex flex-col p-12"
            >
              <div className="flex justify-between items-center mb-12">
                {authMethod !== 'options' ? (
                  <button 
                    onClick={() => setAuthMethod('options')}
                    className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-[#0A1931]/30 hover:text-[#0A1931] hover:bg-white shadow-sm transition-all"
                  >
                    <ArrowRight className="rotate-180" size={24} />
                  </button>
                ) : <div />}
                <button 
                  onClick={resetModal}
                  className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-[#0A1931]/30 hover:text-[#C06014] hover:bg-white shadow-sm transition-all"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 flex flex-col items-center">
                <div className={`w-24 h-24 rounded-[2.5rem] flex items-center justify-center mb-10 shadow-2xl ${
                  selectedRole === 'ROLE_CLIENT' ? 'bg-[#0A1931] text-[#FDE68A] shadow-[#0A1931]/20' :
                  selectedRole === 'ROLE_GUIDE' ? 'bg-[#C06014] text-white shadow-[#C06014]/20' :
                  'bg-stone-900 text-white shadow-stone-900/20'
                }`}>
                  {selectedRole === 'ROLE_CLIENT' ? <UserIcon size={44} /> :
                   selectedRole === 'ROLE_GUIDE' ? <Compass size={44} /> :
                   <Shield size={44} />}
                </div>

                <h2 className="text-4xl font-serif italic font-black text-[#0A1931] mb-4 tracking-tight">
                  {selectedRole === 'ROLE_CLIENT' ? 'Immersion Voyageur' :
                   selectedRole === 'ROLE_GUIDE' ? 'Console du Guide' :
                   'Administration'}
                </h2>
                <p className="text-[#0A1931]/40 mb-12 text-center font-medium max-w-[300px] text-sm leading-relaxed">
                  {authMethod === 'options' ? 'Sélectionnez votre clé d\'accès pour commencer.' :
                   authMethod === 'email' ? (isRegistering ? 'Édition de votre profil explorateur.' : 'Accédez à votre compte Signature.') :
                   authMethod === 'phone' ? 'Identification par terminal malien.' :
                   authMethod === 'mfa' ? 'Double protection requise.' :
                   'Validation du code transmis par satellite.'}
                </p>

                <div className="w-full space-y-5">
                  <div id="recaptcha-container"></div>
                  {authMethod === 'options' && (
                    <>
                      <motion.button
                        whileHover={{ y: -2 }}
                        onClick={handleGoogleLogin}
                        disabled={isLoggingIn}
                        className="w-full h-20 flex items-center justify-center gap-4 bg-white border border-[#0A1931]/5 text-[#0A1931] rounded-[1.8rem] font-black text-[10px] uppercase tracking-[0.3em] transition-all disabled:opacity-50 shadow-sm active:scale-95"
                      >
                        <Chrome size={20} className="text-[#4285F4]" />
                        Compte Google
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ y: -2 }}
                        onClick={() => { setAuthMethod('email'); setIsRegistering(false); }}
                        className="w-full h-20 flex items-center justify-center gap-4 bg-[#0A1931] text-white rounded-[1.8rem] font-black text-[10px] uppercase tracking-[0.3em] transition-all shadow-2xl shadow-[#0A1931]/20 active:scale-95"
                      >
                        <Mail size={20} className="text-[#FDE68A]" />
                        Email Signature
                      </motion.button>

                      <motion.button
                        whileHover={{ y: -2 }}
                        onClick={() => setAuthMethod('phone')}
                        className="w-full h-20 flex items-center justify-center gap-4 bg-white border border-[#0A1931]/5 text-[#0A1931] rounded-[1.8rem] font-black text-[10px] uppercase tracking-[0.3em] transition-all shadow-sm active:scale-95"
                      >
                        <Phone size={20} className="text-[#C06014]" />
                        Numéro de téléphone
                      </motion.button>
                    </>
                  )}

                  {authMethod === 'email' && (
                    <form onSubmit={handleEmailAuth} className="space-y-6 w-full">
                      {isRegistering && (
                        <div className="space-y-3 text-left">
                          <label className="text-[9px] font-black text-[#0A1931]/30 uppercase ml-4 tracking-[0.3em]">Identité</label>
                          <input 
                            type="text"
                            required
                            className="w-full h-18 px-8 bg-white border border-[#0A1931]/5 rounded-[1.5rem] outline-none focus:ring-2 focus:ring-[#C06014] transition-all font-bold text-[#0A1931] text-lg placeholder:text-[#0A1931]/10"
                            placeholder="Votre nom complet"
                            value={name}
                            onChange={e => setName(e.target.value)}
                          />
                        </div>
                      )}
                      <div className="space-y-3 text-left">
                        <label className="text-[9px] font-black text-[#0A1931]/30 uppercase ml-4 tracking-[0.3em]">Adresse Mail</label>
                        <input 
                          type="email"
                          required
                          className="w-full h-18 px-8 bg-white border border-[#0A1931]/5 rounded-[1.5rem] outline-none focus:ring-2 focus:ring-[#C06014] transition-all font-bold text-[#0A1931] text-lg placeholder:text-[#0A1931]/10"
                          placeholder="votre@prestige.com"
                          value={email}
                          onChange={e => setEmail(e.target.value)}
                        />
                      </div>
                      <div className="space-y-3 text-left">
                        <label className="text-[9px] font-black text-[#0A1931]/30 uppercase ml-4 tracking-[0.3em]">Mot de passe</label>
                        <input 
                          type="password"
                          required
                          minLength={isRegistering ? 6 : undefined}
                          className="w-full h-18 px-8 bg-white border border-[#0A1931]/5 rounded-[1.5rem] outline-none focus:ring-2 focus:ring-[#C06014] transition-all font-bold text-[#0A1931] text-lg placeholder:text-[#0A1931]/10"
                          placeholder="••••••••"
                          value={password}
                          onChange={e => setPassword(e.target.value)}
                        />
                      </div>
                      <button 
                        type="submit"
                        disabled={isLoggingIn}
                        className="w-full h-20 bg-[#0A1931] text-white rounded-[1.8rem] font-black uppercase tracking-[0.3em] text-[10px] hover:bg-[#0A1931]/90 shadow-2xl shadow-[#0A1931]/20 transition-all active:scale-95"
                      >
                        {isLoggingIn ? 'Traitement...' : (isRegistering ? 'Créer le profil' : 'Signature d\'accès')}
                      </button>
                      <button 
                        type="button"
                        onClick={() => setIsRegistering(!isRegistering)}
                        className="w-full text-[#0A1931]/50 text-[10px] font-black uppercase tracking-widest hover:text-[#0A1931] transition-colors"
                      >
                        {isRegistering ? 'Passer à la connexion' : 'Nouveau sur MaliTrek ? Créer un profil'}
                      </button>
                    </form>
                  )}

                  {authMethod === 'phone' && (
                    <form onSubmit={handlePhoneAuth} className="space-y-8 w-full">
                      <div className="space-y-3 text-left">
                        <label className="text-[9px] font-black text-[#0A1931]/30 uppercase ml-4 tracking-[0.3em]">Terminal 223</label>
                        <div className="relative">
                          <span className="absolute left-8 top-1/2 -translate-y-1/2 font-black text-[#C06014] text-xl">+223</span>
                          <input 
                            type="tel"
                            required
                            className="w-full h-20 pl-24 bg-white border border-[#0A1931]/5 rounded-[1.8rem] outline-none focus:ring-2 focus:ring-[#C06014] transition-all font-black text-[#0A1931] text-2xl"
                            placeholder="70 00 00 00"
                            value={phoneNumber}
                            onChange={e => setPhoneNumber(e.target.value)}
                          />
                        </div>
                      </div>
                      <button 
                        type="submit"
                        disabled={isLoggingIn}
                        className="w-full h-20 bg-[#C06014] text-white rounded-[1.8rem] font-black uppercase tracking-[0.3em] text-[10px] shadow-2xl shadow-[#C06014]/20 active:scale-95"
                      >
                        {isLoggingIn ? 'Transmission...' : 'Demander la clé SMS'}
                      </button>
                    </form>
                  )}

                  {(authMethod === 'verify' || authMethod === 'mfa') && (
                    <form onSubmit={handleVerifyCode} className="space-y-10 w-full">
                      <div className="space-y-4 text-left">
                        <label className="text-[9px] font-black text-[#0A1931]/30 uppercase ml-4 tracking-[0.3em] block text-center">Code d'accès reçu</label>
                        <input 
                          type="text"
                          required
                          className="w-full h-24 bg-white border border-[#0A1931]/5 rounded-[2rem] outline-none focus:ring-2 focus:ring-[#C06014] transition-all text-center text-4xl tracking-[0.6em] font-serif italic italic font-black text-[#0A1931] shadow-inner"
                          placeholder="000000"
                          maxLength={6}
                          value={verificationCode}
                          onChange={e => setVerificationCode(e.target.value)}
                        />
                      </div>
                      <button 
                        type="submit"
                        disabled={isLoggingIn}
                        className="w-full h-20 bg-[#0A1931] text-white rounded-[1.8rem] font-black uppercase tracking-[0.3em] text-[10px] active:scale-95 shadow-2xl shadow-[#0A1931]/20"
                      >
                        {isLoggingIn ? 'Validation...' : 'Certifier l\'accès'}
                      </button>
                    </form>
                  )}
                </div>
              </div>

              <div className="mt-12 text-center">
                 <p className="text-[9px] text-[#0A1931]/30 leading-relaxed font-black uppercase tracking-[0.2em] whitespace-pre-wrap">
                    MaliTrek Signature Edition • © 2026
                 </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      <div className="mt-12 flex items-center gap-6 text-[#FFF8F3]/20 font-black text-[9px] uppercase tracking-[0.5em]">
        <span>Bamako</span>
        <div className="w-1.5 h-1.5 bg-[#C06014]/30 rounded-full" />
        <span>Mopti</span>
        <div className="w-1.5 h-1.5 bg-[#C06014]/30 rounded-full" />
        <span>Tombouctou</span>
      </div>
    </div>
  );
};
